package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import kotlin.math.abs

enum class CardProfileType(
    val displayName: String,
    val shortBadge: String,
    val defaultFareKurus: Long,
    val transferFareKurus: Long
) {
    NORMAL(
        displayName = "Normal (Tam)",
        shortBadge = "TAM KART",
        defaultFareKurus = 2700L,
        transferFareKurus = 1933L
    ),
    OGRENCI(
        displayName = "Öğrenci",
        shortBadge = "ÖĞRENCİ",
        defaultFareKurus = 1318L,
        transferFareKurus = 577L
    )
}

@Entity(tableName = "saved_cards")
data class SavedCardEntity(
    @PrimaryKey val uidHex: String,
    val nickname: String,
    val cardType: CardProfileType,
    val chipModel: String,
    val balanceKurus: Long?,
    val isBalanceFromChip: Boolean,
    val discoveredAids: String,
    val lastScannedAt: Long
)

@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardUidHex: String,
    val cardNickname: String,
    val cardType: CardProfileType,
    val balanceKurus: Long?,
    val deltaKurus: Long?,
    val eventLabel: String,
    val timestamp: Long
)

class CardTypeConverters {
    @TypeConverter
    fun fromCardProfileType(value: CardProfileType): String = value.name

    @TypeConverter
    fun toCardProfileType(value: String): CardProfileType =
        runCatching { CardProfileType.valueOf(value) }.getOrDefault(CardProfileType.NORMAL)
}

fun formatKurusAsTl(kurus: Long): String {
    val sign = if (kurus < 0) "-" else ""
    val absolute = abs(kurus)
    val lira = absolute / 100
    val remainder = absolute % 100
    val liraFormatted = lira.toString()
        .reversed()
        .chunked(3)
        .joinToString(".")
        .reversed()
    val kurusFormatted = remainder.toString().padStart(2, '0')
    return "${sign}₺$liraFormatted,$kurusFormatted"
}

fun formatDeltaKurus(deltaKurus: Long): String {
    val prefix = if (deltaKurus >= 0) "+" else "-"
    return "$prefix${formatKurusAsTl(abs(deltaKurus))}"
}
