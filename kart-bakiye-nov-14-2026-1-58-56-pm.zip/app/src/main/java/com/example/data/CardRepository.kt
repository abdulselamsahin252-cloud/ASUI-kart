package com.example.data

import kotlinx.coroutines.flow.Flow

class CardRepository(private val cardDao: CardDao) {
    val savedCards: Flow<List<SavedCardEntity>> = cardDao.observeAllCards()
    val recentHistory: Flow<List<ScanHistoryEntity>> = cardDao.observeRecentHistory()

    suspend fun getCardByUid(uidHex: String): SavedCardEntity? = cardDao.getCardByUid(uidHex)

    suspend fun upsertCard(card: SavedCardEntity) = cardDao.upsertCard(card)

    suspend fun deleteCard(uidHex: String) = cardDao.deleteCardByUid(uidHex)

    suspend fun recordHistory(entry: ScanHistoryEntity) = cardDao.insertHistory(entry)

    suspend fun clearHistory() = cardDao.clearHistory()
}
