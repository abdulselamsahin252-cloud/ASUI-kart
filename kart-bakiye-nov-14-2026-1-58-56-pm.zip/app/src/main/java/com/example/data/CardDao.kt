package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CardDao {
    @Query("SELECT * FROM saved_cards ORDER BY lastScannedAt DESC")
    fun observeAllCards(): Flow<List<SavedCardEntity>>

    @Query("SELECT * FROM saved_cards WHERE uidHex = :uidHex LIMIT 1")
    suspend fun getCardByUid(uidHex: String): SavedCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCard(card: SavedCardEntity)

    @Query("DELETE FROM saved_cards WHERE uidHex = :uidHex")
    suspend fun deleteCardByUid(uidHex: String)

    @Query("SELECT * FROM scan_history ORDER BY timestamp DESC LIMIT 50")
    fun observeRecentHistory(): Flow<List<ScanHistoryEntity>>

    @Insert
    suspend fun insertHistory(entry: ScanHistoryEntity)

    @Query("DELETE FROM scan_history")
    suspend fun clearHistory()
}
