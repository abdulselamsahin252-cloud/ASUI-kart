package com.example.nfc

import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import android.nfc.tech.NfcA
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException

sealed interface TagReadOutcome

sealed interface NfcScanResult : TagReadOutcome {
    val uidHex: String
    val chipModel: String
    val discoveredAids: List<String>

    data class ChipBalanceRead(
        override val uidHex: String,
        override val chipModel: String,
        override val discoveredAids: List<String>,
        val balanceKurus: Long,
        val sourceDetail: String
    ) : NfcScanResult

    data class EncryptedCardIdentified(
        override val uidHex: String,
        override val chipModel: String,
        override val discoveredAids: List<String>,
        val statusCodeHex: String,
        val protocolDetail: String
    ) : NfcScanResult
}

data class NfcReadError(
    val message: String,
    val technicalReason: String
) : TagReadOutcome

sealed interface NfcHardwareStatus {
    data object Active : NfcHardwareStatus
    data object Disabled : NfcHardwareStatus
    data object Unavailable : NfcHardwareStatus
}

class IstanbulkartNfcReader {

    suspend fun readTag(tag: Tag): TagReadOutcome = withContext(Dispatchers.IO) {
        val uidBytes = tag.id ?: byteArrayOf()
        val uidHex = DesfireParser.formatUidHex(uidBytes)

        val isoDep = IsoDep.get(tag)
        if (isoDep != null) {
            return@withContext readIsoDepDesfire(isoDep, uidHex)
        }

        val mifareClassic = MifareClassic.get(tag)
        if (mifareClassic != null) {
            return@withContext readMifareClassic(mifareClassic, uidHex)
        }

        val ultralight = MifareUltralight.get(tag)
        if (ultralight != null) {
            val typeName = when (ultralight.type) {
                MifareUltralight.TYPE_ULTRALIGHT_C -> "MIFARE Ultralight C"
                else -> "MIFARE Ultralight"
            }
            return@withContext NfcScanResult.EncryptedCardIdentified(
                uidHex = uidHex,
                chipModel = typeName,
                discoveredAids = emptyList(),
                statusCodeHex = "ISO-14443-3A",
                protocolDetail = "MifareUltralight UID okundu"
            )
        }

        val nfcA = NfcA.get(tag)
        val sak = nfcA?.sak?.toInt() ?: 0
        NfcScanResult.EncryptedCardIdentified(
            uidHex = uidHex,
            chipModel = "ISO 14443-3A (SAK 0x${"%02X".format(sak)})",
            discoveredAids = emptyList(),
            statusCodeHex = "NfcA",
            protocolDetail = "Temassız kart kimliği okundu"
        )
    }

    private fun readIsoDepDesfire(isoDep: IsoDep, uidHex: String): TagReadOutcome {
        return try {
            isoDep.connect()
            isoDep.timeout = 3000

            val versionResult = transceiveDesfireChain(isoDep, 0x60.toByte())
            val chipModel = if (versionResult.statusWord == 0x9100 && versionResult.payload.size >= 14) {
                DesfireParser.parseDesfireVersionModel(versionResult.payload)
            } else {
                "MIFARE DESFire (IsoDep)"
            }

            // Query Application IDs (0x6A)
            val aidsResult = transceiveDesfireChain(isoDep, 0x6A.toByte())
            val aidBytesList = if (aidsResult.statusWord == 0x9100) {
                DesfireParser.parseAidList(aidsResult.payload)
            } else {
                emptyList()
            }
            val aidHexList = aidBytesList.map { DesfireParser.formatAidHex(it) }

            var lastSecurityStatus = if (aidsResult.statusWord != 0x9100 && aidsResult.statusWord != -1) {
                aidsResult.statusWord
            } else {
                0x91AE
            }

            // Inspect each discovered application for free-read value or data files
            for (aid in aidBytesList) {
                val selectRes = transceiveDesfireChain(isoDep, 0x5A.toByte(), aid)
                if (selectRes.statusWord != 0x9100) {
                    if (selectRes.statusWord > 0) lastSecurityStatus = selectRes.statusWord
                    continue
                }

                val filesRes = transceiveDesfireChain(isoDep, 0x6F.toByte())
                if (filesRes.statusWord != 0x9100) {
                    if (filesRes.statusWord > 0) lastSecurityStatus = filesRes.statusWord
                    continue
                }

                for (fileId in filesRes.payload) {
                    val settingsRes = transceiveDesfireChain(isoDep, 0xF5.toByte(), byteArrayOf(fileId))
                    val fileType = if (settingsRes.statusWord == 0x9100 && settingsRes.payload.isNotEmpty()) {
                        settingsRes.payload[0].toInt() and 0xFF
                    } else {
                        -1
                    }

                    // FileType 0x02 = Value File -> attempt unauthenticated GetValue (0x6C)
                    if (fileType == 0x02 || fileType == -1) {
                        val valRes = transceiveDesfireChain(isoDep, 0x6C.toByte(), byteArrayOf(fileId))
                        if (valRes.statusWord == 0x9100) {
                            val rawValue = DesfireParser.parseLittleEndianInt32(valRes.payload)
                            if (rawValue != null && rawValue in 0..5_000_000) {
                                return NfcScanResult.ChipBalanceRead(
                                    uidHex = uidHex,
                                    chipModel = chipModel,
                                    discoveredAids = aidHexList,
                                    balanceKurus = rawValue.toLong(),
                                    sourceDetail = "AID ${DesfireParser.formatAidHex(aid)} • File 0x${"%02X".format(fileId)}"
                                )
                            }
                        } else if (valRes.statusWord == 0x91AE || valRes.statusWord == 0x919D) {
                            lastSecurityStatus = valRes.statusWord
                        }
                    }
                }
            }

            NfcScanResult.EncryptedCardIdentified(
                uidHex = uidHex,
                chipModel = chipModel,
                discoveredAids = aidHexList,
                statusCodeHex = "0x${"%04X".format(lastSecurityStatus)}",
                protocolDetail = if (aidHexList.isEmpty()) {
                    "IsoDep DESFire • Korumalı Uygulama Dizini"
                } else {
                    "IsoDep DESFire • ${aidHexList.size} uygulama algılandı (Şifreli)"
                }
            )
        } catch (e: IOException) {
            NfcReadError(
                message = "Kart çok hızlı çekildi veya bağlantı kesildi.",
                technicalReason = e.message ?: "IOException"
            )
        } finally {
            runCatching { isoDep.close() }
        }
    }

    private fun readMifareClassic(mfc: MifareClassic, uidHex: String): TagReadOutcome {
        val model = when (mfc.type) {
            MifareClassic.TYPE_CLASSIC -> "MIFARE Classic (${mfc.size} B)"
            MifareClassic.TYPE_PLUS -> "MIFARE Plus (${mfc.size} B)"
            MifareClassic.TYPE_PRO -> "MIFARE Pro (${mfc.size} B)"
            else -> "MIFARE Classic"
        }
        return try {
            mfc.connect()
            val candidateKeys = listOf(
                MifareClassic.KEY_DEFAULT,
                MifareClassic.KEY_MIFARE_APPLICATION_DIRECTORY,
                MifareClassic.KEY_NFC_FORUM
            )
            for (sector in 0 until mfc.sectorCount) {
                val authed = candidateKeys.any { key ->
                    runCatching { mfc.authenticateSectorWithKeyA(sector, key) }.getOrDefault(false)
                }
                if (authed) {
                    val firstBlock = mfc.sectorToBlock(sector)
                    val blockCount = mfc.getBlockCountInSector(sector)
                    for (offset in 0 until blockCount - 1) {
                        val blockData = runCatching { mfc.readBlock(firstBlock + offset) }.getOrNull()
                        if (blockData != null) {
                            val parsedValue = DesfireParser.parseMifareClassicValueBlock(blockData)
                            if (parsedValue != null && parsedValue in 0..5_000_000) {
                                return NfcScanResult.ChipBalanceRead(
                                    uidHex = uidHex,
                                    chipModel = model,
                                    discoveredAids = emptyList(),
                                    balanceKurus = parsedValue.toLong(),
                                    sourceDetail = "MIFARE Sektör $sector • Blok ${firstBlock + offset}"
                                )
                            }
                        }
                    }
                }
            }
            NfcScanResult.EncryptedCardIdentified(
                uidHex = uidHex,
                chipModel = model,
                discoveredAids = emptyList(),
                statusCodeHex = "0x91AE",
                protocolDetail = "MIFARE Classic • Şifreli Sektörler"
            )
        } catch (e: IOException) {
            NfcReadError(
                message = "Kart bağlantısı tamamlanmadan kesildi.",
                technicalReason = e.message ?: "IOException"
            )
        } finally {
            runCatching { mfc.close() }
        }
    }

    private data class DesfireResponse(val payload: ByteArray, val statusWord: Int)

    private fun transceiveDesfireChain(
        isoDep: IsoDep,
        ins: Byte,
        data: ByteArray = byteArrayOf()
    ): DesfireResponse {
        val output = ByteArrayOutputStream()
        var response = isoDep.transceive(DesfireParser.wrapDesfireCommand(ins, data))
        var sw = DesfireParser.extractStatusWord(response)
        output.write(DesfireParser.extractPayload(response))

        var safetyCounter = 0
        while (sw == 0x91AF && safetyCounter < 12) {
            response = isoDep.transceive(DesfireParser.wrapDesfireCommand(0xAF.toByte()))
            sw = DesfireParser.extractStatusWord(response)
            output.write(DesfireParser.extractPayload(response))
            safetyCounter++
        }
        return DesfireResponse(output.toByteArray(), sw)
    }
}
