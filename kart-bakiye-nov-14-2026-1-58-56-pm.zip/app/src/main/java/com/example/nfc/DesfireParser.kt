package com.example.nfc

import java.nio.ByteBuffer
import java.nio.ByteOrder

object DesfireParser {

    fun formatUidHex(uid: ByteArray): String =
        uid.joinToString(":") { "%02X".format(it.toInt() and 0xFF) }

    fun formatUidCompact(uid: ByteArray): String =
        uid.joinToString("") { "%02X".format(it.toInt() and 0xFF) }

    fun wrapDesfireCommand(ins: Byte, data: ByteArray = byteArrayOf()): ByteArray {
        return if (data.isEmpty()) {
            byteArrayOf(0x90.toByte(), ins, 0x00, 0x00, 0x00)
        } else {
            byteArrayOf(0x90.toByte(), ins, 0x00, 0x00, data.size.toByte()) + data + byteArrayOf(0x00)
        }
    }

    fun extractStatusWord(response: ByteArray): Int {
        if (response.size < 2) return -1
        val sw1 = response[response.size - 2].toInt() and 0xFF
        val sw2 = response[response.size - 1].toInt() and 0xFF
        return (sw1 shl 8) or sw2
    }

    fun extractPayload(response: ByteArray): ByteArray {
        if (response.size <= 2) return byteArrayOf()
        return response.copyOfRange(0, response.size - 2)
    }

    fun parseDesfireVersionModel(versionPayload: ByteArray): String {
        if (versionPayload.size < 14) return "MIFARE DESFire (ISO 14443-4)"
        val hwVendor = versionPayload[0].toInt() and 0xFF
        val hwMajor = versionPayload[3].toInt() and 0xFF
        val hwStorage = versionPayload[5].toInt() and 0xFF
        val swMajor = versionPayload[10].toInt() and 0xFF

        val vendorName = if (hwVendor == 0x04) "NXP" else "ISO"
        val generation = when (swMajor) {
            0 -> "DESFire MF3ICD40"
            1 -> "DESFire EV1"
            2 -> "DESFire EV2"
            3 -> "DESFire EV3"
            else -> "DESFire (v$hwMajor.$swMajor)"
        }
        val capacity = when (hwStorage) {
            0x16 -> "2 KB"
            0x18 -> "4 KB"
            0x1A -> "8 KB"
            0x1C -> "16 KB"
            0x1E -> "32 KB"
            else -> ""
        }
        return listOf(vendorName, "MIFARE", generation, capacity)
            .filter { it.isNotBlank() }
            .joinToString(" ")
    }

    fun parseAidList(payload: ByteArray): List<ByteArray> {
        val aids = mutableListOf<ByteArray>()
        var offset = 0
        while (offset + 3 <= payload.size) {
            aids.add(payload.copyOfRange(offset, offset + 3))
            offset += 3
        }
        return aids
    }

    fun formatAidHex(aid: ByteArray): String =
        aid.joinToString("") { "%02X".format(it.toInt() and 0xFF) }

    fun parseLittleEndianInt32(bytes: ByteArray): Int? {
        if (bytes.size < 4) return null
        return ByteBuffer.wrap(bytes, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
    }

    /**
     * Checks standard MIFARE Classic 16-byte value block integrity:
     * Bytes 0..3 == value, Bytes 4..7 == ~value, Bytes 8..11 == value.
     */
    fun parseMifareClassicValueBlock(block: ByteArray): Int? {
        if (block.size != 16) return null
        val v0 = ByteBuffer.wrap(block, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
        val vInv = ByteBuffer.wrap(block, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        val v2 = ByteBuffer.wrap(block, 8, 4).order(ByteOrder.LITTLE_ENDIAN).int
        if (v0 != v2 || v0 != vInv.inv()) return null
        val addr0 = block[12]
        val addr1 = block[13]
        val addr2 = block[14]
        val addr3 = block[15]
        val addrValid = (addr0 == addr2) && (addr1 == addr3) && ((addr0.toInt() xor addr1.toInt()) and 0xFF == 0xFF)
        return if (addrValid && v0 >= 0) v0 else null
    }
}
