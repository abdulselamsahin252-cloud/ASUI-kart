package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Contactless
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CardProfileType
import com.example.data.formatKurusAsTl
import com.example.ui.theme.GoldChip
import com.example.ui.theme.IstanbulRedDeep
import com.example.ui.theme.IstanbulRedPrimary
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.SilverChip
import com.example.ui.theme.StudentBluePrimary
import com.example.ui.theme.StudentTealAccent
import kotlin.math.roundToLong

@Composable
fun AnimatedIstanbulCard(
    profileType: CardProfileType,
    balanceKurus: Long?,
    uidHex: String?,
    cardNickname: String?,
    isReading: Boolean,
    isChipVerifiedBalance: Boolean,
    scanPulseTrigger: Int,
    modifier: Modifier = Modifier
) {
    val targetStart = if (profileType == CardProfileType.NORMAL) IstanbulRedPrimary else StudentBluePrimary
    val targetEnd = if (profileType == CardProfileType.NORMAL) IstanbulRedDeep else StudentTealAccent
    val targetChip = if (profileType == CardProfileType.NORMAL) GoldChip else SilverChip

    val gradientStart by animateColorAsState(
        targetValue = targetStart,
        animationSpec = tween(420, easing = FastOutSlowInEasing),
        label = "cardStartColor"
    )
    val gradientEnd by animateColorAsState(
        targetValue = targetEnd,
        animationSpec = tween(420, easing = FastOutSlowInEasing),
        label = "cardEndColor"
    )
    val chipColor by animateColorAsState(
        targetValue = targetChip,
        animationSpec = tween(420),
        label = "chipColor"
    )

    // Subtle 3D tilt animation when profile switches or scan finishes
    var targetTilt by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(profileType, scanPulseTrigger) {
        targetTilt = if (profileType == CardProfileType.OGRENCI) 8f else -8f
        kotlinx.coroutines.delay(180)
        targetTilt = 0f
    }
    val rotationY by animateFloatAsState(
        targetValue = targetTilt,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "cardFlipTilt"
    )

    val scale by animateFloatAsState(
        targetValue = if (isReading) 1.03f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "cardReadingScale"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "cardShimmer")
    val shimmerProgress by infiniteTransition.animateFloat(
        initialValue = -0.5f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isReading) 900 else 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerOffset"
    )

    // Animated balance roll-up
    val animatedBalanceFloat by animateFloatAsState(
        targetValue = (balanceKurus ?: 0L).toFloat(),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "balanceCounter"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1.586f)
            .graphicsLayer {
                this.rotationY = rotationY
                this.scaleX = scale
                this.scaleY = scale
                cameraDistance = 14f * density
            }
            .shadow(
                elevation = 18.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = gradientStart.copy(alpha = 0.45f),
                spotColor = gradientStart.copy(alpha = 0.55f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(gradientStart, gradientEnd),
                    start = Offset.Zero,
                    end = Offset(1000f, 700f)
                )
            )
    ) {
        // Custom Canvas: Bosphorus bridge arch lines, geometric wave, EMV chip & shimmer sweep
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Subtle decorative arcs
            drawCircle(
                color = Color.White.copy(alpha = 0.06f),
                radius = h * 0.85f,
                center = Offset(w * 0.92f, h * 0.15f)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.04f),
                radius = h * 0.60f,
                center = Offset(w * 0.10f, h * 0.95f)
            )

            // Stylized Bosphorus suspension bridge cable silhouette
            val bridgePath = Path().apply {
                moveTo(0f, h * 0.72f)
                quadraticTo(w * 0.25f, h * 0.50f, w * 0.52f, h * 0.70f)
                quadraticTo(w * 0.76f, h * 0.48f, w, h * 0.66f)
            }
            drawPath(
                path = bridgePath,
                color = Color.White.copy(alpha = 0.13f),
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
            )

            // Bridge vertical towers
            drawLine(
                color = Color.White.copy(alpha = 0.12f),
                start = Offset(w * 0.26f, h * 0.48f),
                end = Offset(w * 0.26f, h * 0.80f),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = Color.White.copy(alpha = 0.12f),
                start = Offset(w * 0.76f, h * 0.46f),
                end = Offset(w * 0.76f, h * 0.78f),
                strokeWidth = 2.dp.toPx()
            )

            // EMV Chip Graphic
            val chipW = 46.dp.toPx()
            val chipH = 34.dp.toPx()
            val chipX = 24.dp.toPx()
            val chipY = h * 0.34f
            drawRoundRect(
                color = chipColor.copy(alpha = 0.92f),
                topLeft = Offset(chipX, chipY),
                size = Size(chipW, chipH),
                cornerRadius = CornerRadius(7.dp.toPx(), 7.dp.toPx())
            )
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.18f),
                topLeft = Offset(chipX + 6.dp.toPx(), chipY + 6.dp.toPx()),
                size = Size(chipW - 12.dp.toPx(), chipH - 12.dp.toPx()),
                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )

            // Shimmer highlight sweep
            val sweepStart = w * shimmerProgress
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = if (isReading) 0.22f else 0.08f),
                        Color.Transparent
                    ),
                    start = Offset(sweepStart - w * 0.3f, 0f),
                    end = Offset(sweepStart + w * 0.15f, h)
                )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(22.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Row: Brand title + Card Type Badge + Contactless Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = cardNickname ?: "istanbulkart",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.3).sp
                        ),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.18f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (profileType == CardProfileType.OGRENCI) {
                                Icon(
                                    imageVector = Icons.Rounded.School,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                            Text(
                                text = profileType.shortBadge,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                ),
                                color = Color.White
                            )
                        }
                    }
                }

                Icon(
                    imageVector = Icons.Rounded.Contactless,
                    contentDescription = "Temassız NFC Kart",
                    tint = Color.White.copy(alpha = 0.90f),
                    modifier = Modifier.size(34.dp)
                )
            }

            // Bottom Balance & UID Readout
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (isReading) "OKUNUYOR..." else "BAKİYE",
                        style = MaterialTheme.typography.labelMedium.copy(
                            letterSpacing = 1.1.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = Color.White.copy(alpha = 0.78f)
                    )
                    if (uidHex != null && !isReading) {
                        Icon(
                            imageVector = if (isChipVerifiedBalance) Icons.Rounded.Verified else Icons.Rounded.Lock,
                            contentDescription = if (isChipVerifiedBalance) "Çip doğrulandı" else "Şifreli çip",
                            tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = when {
                        isReading -> "••••••"
                        balanceKurus != null -> formatKurusAsTl(animatedBalanceFloat.roundToLong())
                        uidHex != null -> "Şifreli Çip"
                        else -> "₺--, --"
                    },
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = uidHex ?: "NFC BEKLENİYOR",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 12.sp,
                            letterSpacing = 1.2.sp
                        ),
                        color = Color.White.copy(alpha = 0.84f)
                    )
                    Text(
                        text = "ÇEVRİMDIŞI",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = Color.White.copy(alpha = 0.65f)
                    )
                }
            }
        }
    }
}
