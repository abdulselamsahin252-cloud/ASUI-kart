package com.example.ui

import android.app.Application
import android.nfc.Tag
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CardProfileType
import com.example.data.CardRepository
import com.example.data.SavedCardEntity
import com.example.data.ScanHistoryEntity
import com.example.nfc.IstanbulkartNfcReader
import com.example.nfc.NfcHardwareStatus
import com.example.nfc.NfcReadError
import com.example.nfc.NfcScanResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab {
    SCAN,
    CARDS
}

sealed interface ScanUiState {
    data object Idle : ScanUiState
    data object Reading : ScanUiState
    data class Success(
        val card: SavedCardEntity,
        val isChipVerifiedBalance: Boolean,
        val statusCodeHex: String,
        val protocolDetail: String,
        val lastDeltaKurus: Long? = null
    ) : ScanUiState
    data class Error(
        val message: String,
        val technicalReason: String
    ) : ScanUiState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = CardRepository(database.cardDao())
    private val nfcReader = IstanbulkartNfcReader()

    private val _selectedProfile = MutableStateFlow(CardProfileType.NORMAL)
    val selectedProfile: StateFlow<CardProfileType> = _selectedProfile.asStateFlow()

    private val _nfcStatus = MutableStateFlow<NfcHardwareStatus>(NfcHardwareStatus.Disabled)
    val nfcStatus: StateFlow<NfcHardwareStatus> = _nfcStatus.asStateFlow()

    private val _nfcWarningDismissed = MutableStateFlow(false)
    val nfcWarningDismissed: StateFlow<Boolean> = _nfcWarningDismissed.asStateFlow()

    private val _scanUiState = MutableStateFlow<ScanUiState>(ScanUiState.Idle)
    val scanUiState: StateFlow<ScanUiState> = _scanUiState.asStateFlow()

    private val _activeTab = MutableStateFlow(MainTab.SCAN)
    val activeTab: StateFlow<MainTab> = _activeTab.asStateFlow()

    val savedCards: StateFlow<List<SavedCardEntity>> = repository.savedCards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentHistory: StateFlow<List<ScanHistoryEntity>> = repository.recentHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: MainTab) {
        _activeTab.value = tab
    }

    fun selectProfile(profile: CardProfileType) {
        _selectedProfile.value = profile
        val current = _scanUiState.value
        if (current is ScanUiState.Success) {
            viewModelScope.launch {
                val updated = current.card.copy(cardType = profile)
                repository.upsertCard(updated)
                _scanUiState.value = current.copy(card = updated)
            }
        }
    }

    fun updateNfcStatus(status: NfcHardwareStatus) {
        val previous = _nfcStatus.value
        _nfcStatus.value = status
        if (status == NfcHardwareStatus.Active) {
            _nfcWarningDismissed.value = false
        } else if (status == NfcHardwareStatus.Disabled && previous != NfcHardwareStatus.Disabled) {
            _nfcWarningDismissed.value = false
        }
    }

    fun dismissNfcWarning() {
        _nfcWarningDismissed.value = true
    }

    fun reopenNfcWarning() {
        _nfcWarningDismissed.value = false
    }

    fun resetToIdle() {
        _scanUiState.value = ScanUiState.Idle
    }

    fun onTagDiscovered(tag: Tag) {
        if (_scanUiState.value is ScanUiState.Reading) return
        viewModelScope.launch {
            _activeTab.value = MainTab.SCAN
            _scanUiState.value = ScanUiState.Reading
            // Brief visual beat so the reading shimmer animation is legible
            delay(280)

            when (val outcome = nfcReader.readTag(tag)) {
                is NfcScanResult.ChipBalanceRead -> {
                    val existing = repository.getCardByUid(outcome.uidHex)
                    val resolvedType = existing?.cardType ?: _selectedProfile.value
                    val resolvedName = existing?.nickname ?: defaultNicknameFor(resolvedType)
                    _selectedProfile.value = resolvedType

                    val entity = SavedCardEntity(
                        uidHex = outcome.uidHex,
                        nickname = resolvedName,
                        cardType = resolvedType,
                        chipModel = outcome.chipModel,
                        balanceKurus = outcome.balanceKurus,
                        isBalanceFromChip = true,
                        discoveredAids = outcome.discoveredAids.joinToString(", "),
                        lastScannedAt = System.currentTimeMillis()
                    )
                    repository.upsertCard(entity)
                    repository.recordHistory(
                        ScanHistoryEntity(
                            cardUidHex = entity.uidHex,
                            cardNickname = entity.nickname,
                            cardType = entity.cardType,
                            balanceKurus = entity.balanceKurus,
                            deltaKurus = null,
                            eventLabel = "Çipten NFC Okuma",
                            timestamp = System.currentTimeMillis()
                        )
                    )
                    _scanUiState.value = ScanUiState.Success(
                        card = entity,
                        isChipVerifiedBalance = true,
                        statusCodeHex = "0x9100",
                        protocolDetail = outcome.sourceDetail
                    )
                }

                is NfcScanResult.EncryptedCardIdentified -> {
                    val existing = repository.getCardByUid(outcome.uidHex)
                    val resolvedType = existing?.cardType ?: _selectedProfile.value
                    val resolvedName = existing?.nickname ?: defaultNicknameFor(resolvedType)
                    _selectedProfile.value = resolvedType

                    val entity = SavedCardEntity(
                        uidHex = outcome.uidHex,
                        nickname = resolvedName,
                        cardType = resolvedType,
                        chipModel = outcome.chipModel,
                        balanceKurus = existing?.balanceKurus,
                        isBalanceFromChip = false,
                        discoveredAids = outcome.discoveredAids.joinToString(", "),
                        lastScannedAt = System.currentTimeMillis()
                    )
                    repository.upsertCard(entity)
                    repository.recordHistory(
                        ScanHistoryEntity(
                            cardUidHex = entity.uidHex,
                            cardNickname = entity.nickname,
                            cardType = entity.cardType,
                            balanceKurus = entity.balanceKurus,
                            deltaKurus = null,
                            eventLabel = "NFC Kart Tanımlandı",
                            timestamp = System.currentTimeMillis()
                        )
                    )
                    _scanUiState.value = ScanUiState.Success(
                        card = entity,
                        isChipVerifiedBalance = false,
                        statusCodeHex = outcome.statusCodeHex,
                        protocolDetail = outcome.protocolDetail
                    )
                }

                is NfcReadError -> {
                    _scanUiState.value = ScanUiState.Error(
                        message = outcome.message,
                        technicalReason = outcome.technicalReason
                    )
                }
            }
        }
    }

    fun updateCardDetails(
        uidHex: String,
        nickname: String,
        cardType: CardProfileType,
        newBalanceKurus: Long?
    ) {
        viewModelScope.launch {
            val existing = repository.getCardByUid(uidHex) ?: return@launch
            val oldBalance = existing.balanceKurus
            val delta = if (oldBalance != null && newBalanceKurus != null) {
                newBalanceKurus - oldBalance
            } else {
                null
            }
            val updated = existing.copy(
                nickname = nickname.trim().ifEmpty { defaultNicknameFor(cardType) },
                cardType = cardType,
                balanceKurus = newBalanceKurus,
                isBalanceFromChip = false,
                lastScannedAt = System.currentTimeMillis()
            )
            repository.upsertCard(updated)
            repository.recordHistory(
                ScanHistoryEntity(
                    cardUidHex = updated.uidHex,
                    cardNickname = updated.nickname,
                    cardType = updated.cardType,
                    balanceKurus = updated.balanceKurus,
                    deltaKurus = delta,
                    eventLabel = "Bakiye Güncelleme",
                    timestamp = System.currentTimeMillis()
                )
            )
            _selectedProfile.value = cardType
            val current = _scanUiState.value
            if (current is ScanUiState.Success && current.card.uidHex == uidHex) {
                _scanUiState.value = current.copy(
                    card = updated,
                    isChipVerifiedBalance = false,
                    lastDeltaKurus = delta
                )
            }
        }
    }

    fun applyOfflineTransaction(uidHex: String, deltaKurus: Long, label: String) {
        viewModelScope.launch {
            val existing = repository.getCardByUid(uidHex) ?: return@launch
            val baseBalance = existing.balanceKurus ?: 0L
            val nextBalance = (baseBalance + deltaKurus).coerceAtLeast(0L)
            val actualDelta = nextBalance - baseBalance

            val updated = existing.copy(
                balanceKurus = nextBalance,
                isBalanceFromChip = false,
                lastScannedAt = System.currentTimeMillis()
            )
            repository.upsertCard(updated)
            repository.recordHistory(
                ScanHistoryEntity(
                    cardUidHex = updated.uidHex,
                    cardNickname = updated.nickname,
                    cardType = updated.cardType,
                    balanceKurus = nextBalance,
                    deltaKurus = actualDelta,
                    eventLabel = label,
                    timestamp = System.currentTimeMillis()
                )
            )

            val current = _scanUiState.value
            if (current is ScanUiState.Success && current.card.uidHex == uidHex) {
                _scanUiState.value = current.copy(
                    card = updated,
                    isChipVerifiedBalance = false,
                    lastDeltaKurus = actualDelta
                )
            }
        }
    }

    fun openSavedCardInScanner(card: SavedCardEntity) {
        _selectedProfile.value = card.cardType
        _scanUiState.value = ScanUiState.Success(
            card = card,
            isChipVerifiedBalance = card.isBalanceFromChip,
            statusCodeHex = if (card.isBalanceFromChip) "0x9100" else "0x91AE",
            protocolDetail = "Kayıtlı çevrimdışı kart profili"
        )
        _activeTab.value = MainTab.SCAN
    }

    fun deleteSavedCard(uidHex: String) {
        viewModelScope.launch {
            repository.deleteCard(uidHex)
            val current = _scanUiState.value
            if (current is ScanUiState.Success && current.card.uidHex == uidHex) {
                _scanUiState.value = ScanUiState.Idle
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    private fun defaultNicknameFor(type: CardProfileType): String = when (type) {
        CardProfileType.NORMAL -> "İstanbulkart (Tam)"
        CardProfileType.OGRENCI -> "İstanbulkart Öğrenci"
    }
}
