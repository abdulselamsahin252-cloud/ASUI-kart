package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFF6B6B),
    onPrimary = Color(0xFF2B0004),
    primaryContainer = Color(0xFF6B0F18),
    onPrimaryContainer = Color(0xFFFFDAD9),
    secondary = Color(0xFF38BDF8),
    onSecondary = Color(0xFF002438),
    secondaryContainer = Color(0xFF0C3B5E),
    onSecondaryContainer = Color(0xFFD0ECFF),
    tertiary = StatusEmerald,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    error = StatusCoral,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = IstanbulRedPrimary,
    onPrimary = Color.White,
    primaryContainer = IstanbulRedSoft,
    onPrimaryContainer = IstanbulRedDeep,
    secondary = StudentBluePrimary,
    onSecondary = Color.White,
    secondaryContainer = StudentBlueSoft,
    onSecondaryContainer = Color(0xFF062C54),
    tertiary = StatusEmerald,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    error = StatusCoral,
    onError = Color.White
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun KartBakiyeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
