package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.CardProfileType
import com.example.data.SavedCardEntity
import kotlin.math.roundToLong

@Composable
fun BalanceEditDialog(
    card: SavedCardEntity,
    onSave: (nickname: String, cardType: CardProfileType, balanceKurus: Long?) -> Unit,
    onDismiss: () -> Unit
) {
    var nickname by remember(card.uidHex) { mutableStateOf(card.nickname) }
    var selectedType by remember(card.uidHex) { mutableStateOf(card.cardType) }
    var balanceText by remember(card.uidHex) {
        mutableStateOf(
            card.balanceKurus?.let { kurus ->
                val lira = kurus / 100.0
                "%.2f".format(lira).replace('.', ',')
            } ?: ""
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(
                text = "Kart ve Bakiye Düzenle",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "UID: ${card.uidHex}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = nickname,
                    onValueChange = { nickname = it },
                    label = { Text("Kart Adı") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_nickname_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CardProfileType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type.displayName) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { input ->
                        val sanitized = input.filter { it.isDigit() || it == ',' || it == '.' }
                        balanceText = sanitized
                    },
                    label = { Text("Mevcut Bakiye (₺)") },
                    placeholder = { Text("Örn: 150,00") },
                    prefix = { Text("₺") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_balance_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val normalized = balanceText.replace(',', '.').toDoubleOrNull()
                    val kurus = normalized?.let { (it * 100.0).roundToLong().coerceAtLeast(0L) }
                    onSave(nickname, selectedType, kurus)
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("save_balance_confirm_button")
            ) {
                Text("Kaydet")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text("İptal")
            }
        }
    )
}
