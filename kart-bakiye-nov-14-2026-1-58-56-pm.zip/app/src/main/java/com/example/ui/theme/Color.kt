package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Card Signature Colors
val IstanbulRedPrimary = Color(0xFFC81D25)
val IstanbulRedDeep = Color(0xFF8C0D14)
val IstanbulRedSoft = Color(0xFFFFEBEE)

val StudentBluePrimary = Color(0xFF0E4D92)
val StudentTealAccent = Color(0xFF008B8B)
val StudentBlueSoft = Color(0xFFE6F4FA)

val GoldChip = Color(0xFFE6C27A)
val SilverChip = Color(0xFFD6E4F0)

// Status Semantics
val StatusEmerald = Color(0xFF0E9F6E)
val StatusEmeraldContainer = Color(0xFFDEF7EC)
val StatusAmber = Color(0xFFD97706)
val StatusAmberContainer = Color(0xFFFEF3C7)
val StatusCoral = Color(0xFFDC2626)
val StatusCoralContainer = Color(0xFFFEE2E2)

// Light Theme Surfaces
val LightBackground = Color(0xFFF6F8FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F7)
val LightOutline = Color(0xFFDCE3ED)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

// Dark Theme Surfaces
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF131C31)
val DarkSurfaceVariant = Color(0xFF1D2943)
val DarkOutline = Color(0xFF2B3A5B)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
