package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.DirectionsBus
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Nfc
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.CardProfileType
import com.example.data.SavedCardEntity
import com.example.data.formatDeltaKurus
import com.example.data.formatKurusAsTl
import com.example.nfc.NfcHardwareStatus
import com.example.ui.ScanUiState
import com.example.ui.components.AnimatedIstanbulCard
import com.example.ui.components.BalanceEditDialog
import com.example.ui.components.NfcDisabledInlineCard
import com.example.ui.components.NfcHardwareUnavailableCard
import com.example.ui.components.NfcRadarPromptCard
import com.example.ui.theme.IstanbulRedPrimary
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusAmberContainer
import com.example.ui.theme.StatusCoral
import com.example.ui.theme.StatusCoralContainer
import com.example.ui.theme.StatusEmerald
import com.example.ui.theme.StatusEmeraldContainer
import com.example.ui.theme.StudentBluePrimary

@Composable
fun ScannerScreen(
    selectedProfile: CardProfileType,
    nfcStatus: NfcHardwareStatus,
    scanUiState: ScanUiState,
    onSelectProfile: (CardProfileType) -> Unit,
    onOpenNfcSettings: () -> Unit,
    onResetToIdle: () -> Unit,
    onUpdateCardDetails: (uidHex: String, nickname: String, type: CardProfileType, balanceKurus: Long?) -> Unit,
    onApplyOfflineTransaction: (uidHex: String, deltaKurus: Long, label: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var editingCard by remember { mutableStateOf<SavedCardEntity?>(null) }
    var pulseCounter by remember { mutableIntStateOf(0) }

    val successState = scanUiState as? ScanUiState.Success
    val currentCard = successState?.card

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Status Header
            HeaderBar(
                nfcStatus = nfcStatus,
                onNfcBadgeClick = {
                    if (nfcStatus == NfcHardwareStatus.Disabled) onOpenNfcSettings()
                }
            )

            // Normal / Öğrenci Mode Switcher
            ProfileSegmentedControl(
                selectedProfile = selectedProfile,
                onSelectProfile = onSelectProfile
            )

            // Hero Animated İstanbulkart
            AnimatedIstanbulCard(
                profileType = currentCard?.cardType ?: selectedProfile,
                balanceKurus = currentCard?.balanceKurus,
                uidHex = currentCard?.uidHex,
                cardNickname = currentCard?.nickname,
                isReading = scanUiState is ScanUiState.Reading,
                isChipVerifiedBalance = successState?.isChipVerifiedBalance ?: false,
                scanPulseTrigger = pulseCounter + (currentCard?.lastScannedAt?.toInt() ?: 0)
            )

            // Main Animated Content Area
            AnimatedContent(
                targetState = scanUiState,
                transitionSpec = {
                    (fadeIn(tween(240)) + scaleIn(
                        initialScale = 0.96f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
                    )).togetherWith(fadeOut(tween(180)))
                },
                label = "scannerContentTransition"
            ) { state ->
                when (state) {
                    is ScanUiState.Idle -> {
                        when (nfcStatus) {
                            NfcHardwareStatus.Active -> {
                                NfcRadarPromptCard(
                                    profileType = selectedProfile,
                                    isReading = false
                                )
                            }
                            NfcHardwareStatus.Disabled -> {
                                NfcDisabledInlineCard(onOpenNfcSettings = onOpenNfcSettings)
                            }
                            NfcHardwareStatus.Unavailable -> {
                                NfcHardwareUnavailableCard()
                            }
                        }
                    }

                    is ScanUiState.Reading -> {
                        NfcRadarPromptCard(
                            profileType = selectedProfile,
                            isReading = true
                        )
                    }

                    is ScanUiState.Success -> {
                        ScanResultDetailsCard(
                            result = state,
                            onEditBalance = { editingCard = state.card },
                            onApplyTransaction = { delta, label ->
                                pulseCounter++
                                onApplyOfflineTransaction(state.card.uidHex, delta, label)
                            },
                            onScanAgain = onResetToIdle
                        )
                    }

                    is ScanUiState.Error -> {
                        ScanErrorCard(
                            message = state.message,
                            technicalReason = state.technicalReason,
                            onRetry = onResetToIdle
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    editingCard?.let { cardToEdit ->
        BalanceEditDialog(
            card = cardToEdit,
            onSave = { nickname, type, balanceKurus ->
                onUpdateCardDetails(cardToEdit.uidHex, nickname, type, balanceKurus)
                editingCard = null
            },
            onDismiss = { editingCard = null }
        )
    }
}

@Composable
private fun HeaderBar(
    nfcStatus: NfcHardwareStatus,
    onNfcBadgeClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.WifiOff,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = stringResource(R.string.offline_badge),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        val (bgColor, textColor, label) = when (nfcStatus) {
            NfcHardwareStatus.Active -> Triple(
                StatusEmeraldContainer,
                StatusEmerald,
                stringResource(R.string.status_nfc_active)
            )
            NfcHardwareStatus.Disabled -> Triple(
                StatusAmberContainer,
                StatusAmber,
                stringResource(R.string.status_nfc_off)
            )
            NfcHardwareStatus.Unavailable -> Triple(
                StatusCoralContainer,
                StatusCoral,
                stringResource(R.string.status_nfc_unavailable)
            )
        }

        Surface(
            shape = CircleShape,
            color = bgColor,
            modifier = Modifier
                .clip(CircleShape)
                .clickable(enabled = nfcStatus == NfcHardwareStatus.Disabled, onClick = onNfcBadgeClick)
                .heightIn(min = 38.dp)
                .testTag("nfc_status_pill")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Nfc,
                    contentDescription = label,
                    tint = textColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = textColor
                )
            }
        }
    }
}

@Composable
private fun ProfileSegmentedControl(
    selectedProfile: CardProfileType,
    onSelectProfile: (CardProfileType) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CardProfileType.entries.forEach { profile ->
                val selected = selectedProfile == profile
                val targetBg = when {
                    selected && profile == CardProfileType.NORMAL -> IstanbulRedPrimary
                    selected && profile == CardProfileType.OGRENCI -> StudentBluePrimary
                    else -> Color.Transparent
                }
                val bgColor by animateColorAsState(
                    targetValue = targetBg,
                    animationSpec = tween(250),
                    label = "profileChipBg"
                )
                val contentColor by animateColorAsState(
                    targetValue = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    animationSpec = tween(250),
                    label = "profileChipFg"
                )

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = bgColor,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onSelectProfile(profile) }
                        .testTag(
                            if (profile == CardProfileType.NORMAL) "profile_normal_button"
                            else "profile_student_button"
                        )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (profile == CardProfileType.OGRENCI) {
                                Icons.Rounded.School
                            } else {
                                Icons.Rounded.CreditCard
                            },
                            contentDescription = null,
                            tint = contentColor,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = profile.displayName,
                            style = MaterialTheme.typography.labelLarge,
                            color = contentColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScanResultDetailsCard(
    result: ScanUiState.Success,
    onEditBalance: () -> Unit,
    onApplyTransaction: (deltaKurus: Long, label: String) -> Unit,
    onScanAgain: () -> Unit
) {
    val card = result.card

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Verification / Encryption Status Pill
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (result.isChipVerifiedBalance) StatusEmeraldContainer else StatusAmberContainer.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (result.isChipVerifiedBalance) Icons.Rounded.Verified else Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = if (result.isChipVerifiedBalance) StatusEmerald else StatusAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (result.isChipVerifiedBalance) {
                                stringResource(R.string.chip_read_verified)
                            } else {
                                stringResource(R.string.chip_encrypted_notice)
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (result.isChipVerifiedBalance) {
                                result.protocolDetail
                            } else {
                                stringResource(R.string.chip_encrypted_explain)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Recent delta pill if user just deducted or topped up
            result.lastDeltaKurus?.let { delta ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "Son İşlem: ${formatDeltaKurus(delta)}",
                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily),
                        color = if (delta >= 0) StatusEmerald else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // Quick Balance Edit + Offline Fare Deduction Actions
            Button(
                onClick = onEditBalance,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("edit_balance_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (card.balanceKurus == null) "Mevcut Bakiyeyi Gir" else stringResource(R.string.action_save_balance)
                )
            }

            if (card.balanceKurus != null) {
                Text(
                    text = "Hızlı Çevrimdışı Bakiye İşlemleri (${card.cardType.displayName})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = {
                            onApplyTransaction(
                                -card.cardType.defaultFareKurus,
                                "${card.cardType.displayName} Tam Biniş"
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("deduct_single_fare_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DirectionsBus,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "-${formatKurusAsTl(card.cardType.defaultFareKurus)}",
                            maxLines = 1
                        )
                    }

                    FilledTonalButton(
                        onClick = {
                            onApplyTransaction(
                                -card.cardType.transferFareKurus,
                                "${card.cardType.displayName} Aktarma"
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("deduct_transfer_fare_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SwapHoriz,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "-${formatKurusAsTl(card.cardType.transferFareKurus)}",
                            maxLines = 1
                        )
                    }

                    FilledTonalButton(
                        onClick = { onApplyTransaction(10000L, "Bakiye Yükleme (+₺100)") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("topup_100_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "₺100", maxLines = 1)
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            // Chip Technical Metadata
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                TechSpecRow(label = "Kart UID", value = card.uidHex)
                TechSpecRow(label = "Çip Teknolojisi", value = card.chipModel)
                TechSpecRow(label = "Durum Kodu", value = result.statusCodeHex)
                if (card.discoveredAids.isNotBlank()) {
                    TechSpecRow(label = "DESFire AID", value = card.discoveredAids)
                }
            }

            OutlinedButton(
                onClick = onScanAgain,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("scan_again_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = stringResource(R.string.action_scan_again))
            }
        }
    }
}

@Composable
private fun TechSpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ScanErrorCard(
    message: String,
    technicalReason: String,
    onRetry: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = StatusCoralContainer.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.ErrorOutline,
                contentDescription = "Okuma Hatası",
                tint = StatusCoral,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = message,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = technicalReason,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = StatusCoral),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("retry_scan_button")
            ) {
                Text("Tekrar Dene")
            }
        }
    }
}
