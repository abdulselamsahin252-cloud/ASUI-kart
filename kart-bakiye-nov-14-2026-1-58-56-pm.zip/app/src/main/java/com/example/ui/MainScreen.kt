package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Nfc
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.Nfc
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.nfc.NfcHardwareStatus
import com.example.ui.components.NfcDisabledDialog
import com.example.ui.screens.CardsHistoryScreen
import com.example.ui.screens.ScannerScreen

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onOpenNfcSettings: () -> Unit
) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val selectedProfile by viewModel.selectedProfile.collectAsStateWithLifecycle()
    val nfcStatus by viewModel.nfcStatus.collectAsStateWithLifecycle()
    val nfcWarningDismissed by viewModel.nfcWarningDismissed.collectAsStateWithLifecycle()
    val scanUiState by viewModel.scanUiState.collectAsStateWithLifecycle()
    val savedCards by viewModel.savedCards.collectAsStateWithLifecycle()
    val recentHistory by viewModel.recentHistory.collectAsStateWithLifecycle()

    BackHandler(enabled = activeTab == MainTab.CARDS) {
        viewModel.selectTab(MainTab.SCAN)
    }

    BackHandler(
        enabled = activeTab == MainTab.SCAN &&
            (scanUiState is ScanUiState.Success || scanUiState is ScanUiState.Error)
    ) {
        viewModel.resetToIdle()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                windowInsets = NavigationBarDefaults.windowInsets
            ) {
                NavigationBarItem(
                    selected = activeTab == MainTab.SCAN,
                    onClick = { viewModel.selectTab(MainTab.SCAN) },
                    icon = {
                        Icon(
                            imageVector = if (activeTab == MainTab.SCAN) Icons.Rounded.Nfc else Icons.Outlined.Nfc,
                            contentDescription = stringResource(R.string.tab_scan)
                        )
                    },
                    label = { Text(stringResource(R.string.tab_scan)) },
                    modifier = Modifier.testTag("nav_scan_tab")
                )
                NavigationBarItem(
                    selected = activeTab == MainTab.CARDS,
                    onClick = { viewModel.selectTab(MainTab.CARDS) },
                    icon = {
                        Icon(
                            imageVector = if (activeTab == MainTab.CARDS) Icons.Rounded.CreditCard else Icons.Outlined.CreditCard,
                            contentDescription = stringResource(R.string.tab_cards)
                        )
                    },
                    label = { Text(stringResource(R.string.tab_cards)) },
                    modifier = Modifier.testTag("nav_cards_tab")
                )
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = activeTab,
            animationSpec = tween(220),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding(),
            label = "mainTabCrossfade"
        ) { tab ->
            when (tab) {
                MainTab.SCAN -> {
                    ScannerScreen(
                        selectedProfile = selectedProfile,
                        nfcStatus = nfcStatus,
                        scanUiState = scanUiState,
                        onSelectProfile = viewModel::selectProfile,
                        onOpenNfcSettings = {
                            viewModel.reopenNfcWarning()
                            onOpenNfcSettings()
                        },
                        onResetToIdle = viewModel::resetToIdle,
                        onUpdateCardDetails = viewModel::updateCardDetails,
                        onApplyOfflineTransaction = viewModel::applyOfflineTransaction
                    )
                }
                MainTab.CARDS -> {
                    CardsHistoryScreen(
                        savedCards = savedCards,
                        recentHistory = recentHistory,
                        onSelectCard = viewModel::openSavedCardInScanner,
                        onDeleteCard = viewModel::deleteSavedCard,
                        onClearHistory = viewModel::clearHistory
                    )
                }
            }
        }
    }

    // Automatic popup warning whenever NFC is disabled and not dismissed
    if (nfcStatus == NfcHardwareStatus.Disabled && !nfcWarningDismissed) {
        NfcDisabledDialog(
            onOpenNfcSettings = onOpenNfcSettings,
            onDismiss = viewModel::dismissNfcWarning
        )
    }
}
