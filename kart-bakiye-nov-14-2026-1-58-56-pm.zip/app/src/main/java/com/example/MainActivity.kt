package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.nfc.NfcHardwareStatus
import com.example.ui.MainScreen
import com.example.ui.MainViewModel
import com.example.ui.theme.KartBakiyeTheme

class MainActivity : ComponentActivity(), NfcAdapter.ReaderCallback {

    private val viewModel: MainViewModel by viewModels()
    private var nfcAdapter: NfcAdapter? = null

    private val nfcStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == NfcAdapter.ACTION_ADAPTER_STATE_CHANGED) {
                val state = intent.getIntExtra(
                    NfcAdapter.EXTRA_ADAPTER_STATE,
                    NfcAdapter.STATE_OFF
                )
                when (state) {
                    NfcAdapter.STATE_ON -> {
                        viewModel.updateNfcStatus(NfcHardwareStatus.Active)
                        enableNfcReaderMode()
                    }
                    NfcAdapter.STATE_OFF,
                    NfcAdapter.STATE_TURNING_OFF -> {
                        disableNfcReaderMode()
                        viewModel.updateNfcStatus(NfcHardwareStatus.Disabled)
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        syncNfcHardwareState()

        setContent {
            KartBakiyeTheme {
                MainScreen(
                    viewModel = viewModel,
                    onOpenNfcSettings = ::openNfcSettings
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(NfcAdapter.ACTION_ADAPTER_STATE_CHANGED)
        ContextCompat.registerReceiver(
            this,
            nfcStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onResume() {
        super.onResume()
        syncNfcHardwareState()
        if (nfcAdapter?.isEnabled == true) {
            enableNfcReaderMode()
        }
    }

    override fun onPause() {
        super.onPause()
        disableNfcReaderMode()
    }

    override fun onStop() {
        super.onStop()
        runCatching { unregisterReceiver(nfcStateReceiver) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val tag: Tag? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        }
        if (tag != null) {
            onTagDiscovered(tag)
        }
    }

    override fun onTagDiscovered(tag: Tag?) {
        val discoveredTag = tag ?: return
        runOnUiThread {
            triggerHapticPulse()
            viewModel.onTagDiscovered(discoveredTag)
        }
    }

    private fun syncNfcHardwareState() {
        val adapter = nfcAdapter
        val status = when {
            adapter == null -> NfcHardwareStatus.Unavailable
            adapter.isEnabled -> NfcHardwareStatus.Active
            else -> NfcHardwareStatus.Disabled
        }
        viewModel.updateNfcStatus(status)
    }

    private fun enableNfcReaderMode() {
        val adapter = nfcAdapter ?: return
        if (!adapter.isEnabled) return
        val flags = NfcAdapter.FLAG_READER_NFC_A or
            NfcAdapter.FLAG_READER_NFC_B or
            NfcAdapter.FLAG_READER_NFC_F or
            NfcAdapter.FLAG_READER_NFC_V or
            NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK
        val options = Bundle().apply {
            putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250)
        }
        runCatching {
            adapter.enableReaderMode(this, this, flags, options)
        }
    }

    private fun disableNfcReaderMode() {
        runCatching {
            nfcAdapter?.disableReaderMode(this)
        }
    }

    private fun openNfcSettings() {
        val panelIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Intent(Settings.Panel.ACTION_NFC)
        } else {
            Intent(Settings.ACTION_NFC_SETTINGS)
        }
        runCatching {
            startActivity(panelIntent)
        }.onFailure {
            runCatching {
                startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
            }.onFailure {
                runCatching {
                    startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                }
            }
        }
    }

    private fun triggerHapticPulse() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(VibratorManager::class.java)
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as? Vibrator
        } ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(45L, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(45L)
        }
    }
}
