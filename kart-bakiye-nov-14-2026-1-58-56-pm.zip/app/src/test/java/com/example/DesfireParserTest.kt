package com.example

import com.example.data.formatDeltaKurus
import com.example.data.formatKurusAsTl
import com.example.nfc.DesfireParser
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DesfireParserTest {

    @Test
    fun `formatUidHex produces uppercase colon separated string`() {
        val uid = byteArrayOf(0x04, 0xA2.toByte(), 0x31, 0x9C.toByte(), 0x55, 0x10, 0x80.toByte())
        assertEquals("04:A2:31:9C:55:10:80", DesfireParser.formatUidHex(uid))
    }

    @Test
    fun `parseDesfireVersionModel detects NXP DESFire EV2 8KB`() {
        // 7 hw bytes + 7 sw bytes
        val versionPayload = byteArrayOf(
            0x04, 0x01, 0x01, 0x02, 0x00, 0x1A, 0x05,
            0x04, 0x01, 0x01, 0x02, 0x00, 0x1A, 0x05
        )
        assertEquals("NXP MIFARE DESFire EV2 8 KB", DesfireParser.parseDesfireVersionModel(versionPayload))
    }

    @Test
    fun `parseAidList splits 3-byte AIDs`() {
        val payload = byteArrayOf(0x01, 0x00, 0x00, 0x42, 0x45, 0x4C)
        val aids = DesfireParser.parseAidList(payload)
        assertEquals(2, aids.size)
        assertEquals("010000", DesfireParser.formatAidHex(aids[0]))
        assertEquals("42454C", DesfireParser.formatAidHex(aids[1]))
    }

    @Test
    fun `parseLittleEndianInt32 extracts kurus value`() {
        // 14250 kurus = 0x000037AA -> little endian AA 37 00 00
        val bytes = byteArrayOf(0xAA.toByte(), 0x37, 0x00, 0x00)
        assertEquals(14250, DesfireParser.parseLittleEndianInt32(bytes))
    }

    @Test
    fun `parseMifareClassicValueBlock validates intact value block and rejects corrupt block`() {
        // Value = 2700 (0x00000A8C) -> LE: 8C 0A 00 00; ~Value = FFFFF573 -> LE: 73 F5 FF FF
        val validBlock = byteArrayOf(
            0x8C.toByte(), 0x0A, 0x00, 0x00,
            0x73, 0xF5.toByte(), 0xFF.toByte(), 0xFF.toByte(),
            0x8C.toByte(), 0x0A, 0x00, 0x00,
            0x04, 0xFB.toByte(), 0x04, 0xFB.toByte()
        )
        assertEquals(2700, DesfireParser.parseMifareClassicValueBlock(validBlock))

        val corruptBlock = validBlock.copyOf().apply { this[4] = 0x00 }
        assertNull(DesfireParser.parseMifareClassicValueBlock(corruptBlock))
    }

    @Test
    fun `wrapDesfireCommand formats ISO7816-4 wrapped APDU`() {
        val getVersion = DesfireParser.wrapDesfireCommand(0x60.toByte())
        assertArrayEquals(byteArrayOf(0x90.toByte(), 0x60, 0x00, 0x00, 0x00), getVersion)

        val selectApp = DesfireParser.wrapDesfireCommand(0x5A.toByte(), byteArrayOf(0x01, 0x02, 0x03))
        assertArrayEquals(
            byteArrayOf(0x90.toByte(), 0x5A, 0x00, 0x00, 0x03, 0x01, 0x02, 0x03, 0x00),
            selectApp
        )
    }

    @Test
    fun `Turkish currency formatting formats kurus with dot thousands and comma decimal`() {
        assertEquals("₺27,00", formatKurusAsTl(2700L))
        assertEquals("₺13,18", formatKurusAsTl(1318L))
        assertEquals("₺1.250,50", formatKurusAsTl(125050L))
        assertEquals("-₺13,18", formatDeltaKurus(-1318L))
        assertEquals("+₺100,00", formatDeltaKurus(10000L))
    }
}
