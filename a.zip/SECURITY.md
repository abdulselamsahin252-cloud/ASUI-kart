# Security Policy

## Supported Versions

| Version | Supported |
|---|---|
| Latest stable release | Yes |
| Current `main` branch | Yes |
| Older releases | No |

## Reporting a Vulnerability

**Please do not open public issues for security vulnerabilities.**

Report security issues privately via:
- **Email (Security & Support):** support@awaydoomscrollin.com
- **General Inquiries:** info@resolvecommunity.com
- **GitLab:** Use the [confidential issue](https://gitlab.com/resolve-community/AwayDoomscrollin/-/issues/new?issue%5Bconfidential%5D=true) feature

Please include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

We will respond within **72 hours** and aim to release a fix within **14 days** for critical issues.

## Scope

This app:
- Performs screen-content analysis and blocking locally on the device
- Declares Android `INTERNET` permission only for explicit opt-in telemetry
- Keeps telemetry disabled by default and sends no request to `awaydoomscrollin.com` until the user explicitly opts in
- Generates a random per-installation UUID for telemetry that is not derived from Android ID, IMEI, MAC address, hardware, account, or advertising data
- Sends the constant `PSEUDONYMOUS_TELEMETRY` type marker, that UUID, the disclosed device/app fields, and aggregate blocking and protection measurements to `awaydoomscrollin.com` while telemetry is enabled (local streak and XP statistics are not sent)
- Allows one immediate attempt after explicit opt-in; afterward automatic app-startup and blocking-event triggers share one persisted 24-hour attempt interval, including failed attempts
- Stops future submissions when the user opts out; the latest server snapshot expires within 90 days
- Executes all detection and protection logic locally on-device without remote dependencies
- Stores blocking statistics locally via `SharedPreferences` in addition to the disclosed aggregate telemetry submissions

Instagram Explore/search checks use a serial reader with at most one active read
and one conflated follow-up. Back and navigation invalidate obsolete observations;
positive results recheck foreground/window identity, and unsupported layouts retain
protection and use the existing detector. Explore's keyboard-layer flag changes
window stacking while preserving the feed cover's bounds and touch blocking.

## Beta Compatibility Scope

Instagram Reels, TikTok, and YouTube Shorts detection are beta features. Third-party UI/accessibility-tree changes and manufacturer-specific Android behavior can cause missed detections or false positives. Reports about those compatibility failures are in scope as functional bugs, but the project does not claim perfect detection or universal device compatibility.

Out of scope: vulnerabilities in Android OS, third-party libraries, or user device configurations.


