# Privacy Policy

**Effective Date:** November 18, 2026

## 1. Introduction
Resolve Community ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains our data collection and processing practices for the **AwayDoomscrollin'** Android application.

Our philosophy is simple: keep screen-content analysis on-device and disclose every network path clearly.

## 2. Accessibility Service API
AwayDoomscrollin' utilizes the Android Accessibility Service API exclusively to detect when you enter targeted short-video platforms (e.g., Instagram Reels, TikTok, YouTube Shorts). 
- **What it does:** It inspects accessibility node text, content descriptions, view identifiers, and scroll/window events in memory to recognize target feeds and safe areas. If detected, it intervenes to stop the scrolling loop.
- **Open in Messages (optional, off by default):** If you turn it on, the service also taps Instagram's Messages button when Instagram opens on Home. To act only once per opening, it keeps a short on-device list of the last Instagram window numbers it has seen (numbers assigned by Android, not screen content), and the troubleshooting log notes when it opened Messages. Nothing from the screen is saved.
- **Instagram search:** Search detection runs on-device. Its background reader uses view identifiers, input focus and geometry without reading the search query; unsupported layouts use the existing on-device detector.
- **What it does NOT do:** It does not record the screen, retain accessibility content, or include screen text, messages, comments, passwords, keystrokes, photos, or browsing history in network payloads. Apart from the window numbers used by Open in Messages and the last position of its own Home curtain (a number of pixels, so that the curtain starts in the right place after a restart), the only thing it keeps is the local troubleshooting log described in section 3.3, which records what protection did, not what was on the screen.
- **Beta status and limitations:** Instagram, TikTok, and YouTube Shorts detection is a beta feature. Their interfaces and accessibility trees are controlled by third parties and can change without notice. Detection can therefore be missed or a safe area can be misclassified. No claim of perfect detection, perfect safe-zone classification, or compatibility with every device/OS build is made.

## 3. Data Collection and Telemetry
Screen analysis and blocking run locally on the device. The Android manifest declares `android.permission.INTERNET` only for the optional telemetry path disclosed below; the app is therefore offline-first, not a zero-network-permission app.

| Network path | Default | Destination | Trigger and frequency | User control |
|---|---|---|---|---|
| Pseudonymous telemetry | Off | `https://awaydoomscrollin.com/api/telemetry` | First explicit opt-in may attempt immediately; afterward automatic app-startup and blocking-event triggers share one persisted 24-hour attempt interval | Can be enabled or disabled during onboarding and later in About |

### 3.1 Explicit opt-in telemetry

Telemetry is disabled by default. On a clean installation, the app does not create a telemetry installation UUID and does not make a request to `awaydoomscrollin.com` unless the user reads the disclosure and explicitly agrees to share. Protection works without sharing. Users who enabled the narrower v2 summary are asked again before the expanded v3 summary is enabled; their earlier choice does not silently authorize YouTube curtain-time sharing. Enabling v3 may immediately trigger the first submission and create or reuse the random per-installation UUID in `SharedPreferences`. The UUID is not derived from hardware, an account, Android ID, IMEI, a MAC address, or advertising data. Clearing app data or uninstalling the app removes it.

After explicit opt-in, automatic app-startup and blocking-event triggers share one persisted 24-hour **attempt** interval. The timestamp is reserved synchronously before networking, so concurrent events do not launch duplicate requests; a failed attempt also consumes the interval. Disabling and explicitly re-enabling telemetry may start a new immediate opt-in attempt. Turning telemetry off stops future submissions. Because networking is asynchronous, a request already handed to the operating-system network stack may finish; the app checks the preference before preparing and immediately before starting a request. The latest snapshot in the active telemetry table is retained for no more than 90 days and then deleted. Encrypted local operational backups use a separate 14-day rotation. The server stores a SHA-256 installation key rather than the raw UUID.

### 3.2 Data sent while telemetry is enabled

- We do not ask for a name, email address, phone number, account identifier, precise location, contacts, photos, screen contents, messages, passwords, Android ID, IMEI, MAC address, or advertising identifier in the Android telemetry payload.
- Telemetry is **pseudonymous, not anonymous**: the random installation UUID makes submissions from the same installation linkable until app data is cleared or the app is reinstalled.
- **If telemetry is enabled, the following pseudonymous data is collected and sent to our servers:**
  - **Protocol Information:** The constant marker `PSEUDONYMOUS_TELEMETRY`, schema version 3, a monotonically increasing snapshot sequence, and a random report UUID used for safe retries.
  - **Random Installation Identifier:** A UUID generated by this app installation and used to keep snapshots from different installations separate. The server stores its SHA-256 hash instead of the raw UUID.
  - **Device Information:** Manufacturer, Model, Android Version, SDK Level.
  - **Compatibility Information:** AwayDoomscrollin', Instagram, TikTok, and YouTube version names and version codes; screen width, screen height, and density in pixels/DPI.
  - **Protection Measurements:** Total and per-platform intervention counts; accumulated Instagram and YouTube curtain-visibility times and their measurement versions. Curtain time is not blocked-video duration or an estimate of time saved.
  - **Not included:** Local streak days and XP are not part of telemetry v3.
  - *The telemetry payload does not contain an IP address, MAC address, location, screen content, hardware identifier, account identifier, or advertising identifier. It does contain the random installation UUID described above. As with any HTTPS request, the server, reverse proxy, and network provider can observe the source IP at the transport layer. The application telemetry database does not store that IP as a telemetry field.*
  - The troubleshooting log described below is never part of the telemetry payload.

### 3.3 Local troubleshooting log

Starting with version 1.4.1, the app keeps a short technical log on the device so that problems can be diagnosed when you contact support. It is not a network path: the app never sends it anywhere, whether or not telemetry is enabled. Since version 1.5.0 the log is off on a new installation and records nothing until you turn it on with the switch on the "Troubleshooting log" card in About; an installation updated from 1.4.x where it was on keeps it on. You can turn it off at any time. Turning it off deletes the stored log at once, and nothing is recorded until you turn it on again.

- **What it records:** the time of each protection event and a few technical values about it, for example which protected app was in front (Instagram, TikTok, YouTube, or simply "other" for any other app), which kind of page was recognized (such as Home feed, Reels or Shorts), whether a curtain was shown or removed and where on the screen, whether a Reel or Short was allowed or closed, screen size changes after folding or rotating, slow responses, and the reason Android gave if the app was previously stopped.
- **What it never records:** screen text, labels or view identifiers, names or usernames, messages, comments, passwords, keystrokes, photos, links, or the names of other apps you use. Values are filtered to short technical codes before they are written.
- **Where it is stored and for how long:** in the app's private storage on the device. Entries older than 24 hours are deleted, and the log is limited to about 120 KB. It is excluded from Android cloud backup and device-to-device transfer. You can delete it at any time with "Delete log" in About or by turning the log off; clearing app data or uninstalling the app also removes it.
- **How it is shared:** only by you. "Copy log" in About places the log on the clipboard (marked as sensitive, so Android 13 and later hide it from the clipboard preview) so you can paste it into an email to support. In "Send feedback", ticking "Attach the troubleshooting log" adds the same text to the email draft instead; it is sent only if you send that email. The copied text starts with a short header: the app version, phone manufacturer and model, Android version, the installed versions of Instagram, TikTok and YouTube, the protection settings for each app, whether the accessibility permission is on, the screen size, the app language, and the battery optimization and background restriction status. You can read the whole text before sending it. We use a log you send only to answer your support request.

## 4. Open Source Transparency
AwayDoomscrollin' is fully open-source. The entire codebase is publicly auditable on our [GitHub Repository](https://github.com/ResolveCommunity/AwayDoomscrollin), ensuring complete transparency regarding how the app functions and handles your data.

## 5. Contact Us
For any questions regarding this Privacy Policy or the app's security, please contact us at:
**Email:** info@resolvecommunity.com

---

For the full legal Privacy Policy and Terms of Service, please visit our official website:
- **Privacy Policy:** [https://awaydoomscrollin.com/privacy](https://awaydoomscrollin.com/privacy)
- **Terms of Service:** [https://awaydoomscrollin.com/terms](https://awaydoomscrollin.com/terms)




