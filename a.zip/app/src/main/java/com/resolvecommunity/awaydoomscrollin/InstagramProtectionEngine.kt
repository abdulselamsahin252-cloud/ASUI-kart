package com.resolvecommunity.awaydoomscrollin

internal enum class InstagramScreen {
    HOME_FEED,
    REELS,
    EXPLORE,
    NOTIFICATIONS,
    SEARCH_RESULTS,
    DIRECT_MESSAGES,
    DIRECT_SHARED_MEDIA,
    PROFILE,
    SAVED_COLLECTION,
    COMMENTS_OR_DETAIL,
    STORY,
    CREATION,
    UNKNOWN
}

internal enum class InstagramTab {
    HOME,
    REELS,
    DIRECT,
    SEARCH,
    PROFILE
}

internal enum class InstagramEventKind {
    WINDOW_CHANGED,
    CONTENT_CHANGED,
    CLICK,
    SCROLL
}

internal enum class InstagramGuardAction {
    COVER_FEED,
    EXIT_REELS,
    NAVIGATE_DIRECT,
    ALLOW,
    KEEP_CURRENT
}

internal data class InstagramUiSignals(
    val ids: Set<String> = emptySet(),
    val selectedTabs: Set<InstagramTab> = emptySet(),
    val sourceIds: Set<String> = emptySet(),
    val sourceLabels: Set<String> = emptySet(),
    val sourceTab: InstagramTab? = null,
    val searchFieldFocused: Boolean = false,
    val titles: Set<String> = emptySet(),
    val hasBackNavigation: Boolean = false,
    val hasCameraAction: Boolean = false,
    val hasClipsInteractionBar: Boolean = false,
    val hasFullscreenReelsViewer: Boolean = false,
    /** Id-less grid image tiles (Bloks media grids such as Likes/Reposts/Tags). */
    val idlessMediaTiles: Int = 0
)

internal data class InstagramInteraction(
    val kind: InstagramEventKind,
    val deltaX: Int = 0,
    val deltaY: Int = 0,
    val fromIndex: Int = -1,
    val toIndex: Int = -1
) {
    val isVerticalScroll: Boolean
        get() {
            if (kind != InstagramEventKind.SCROLL) return false
            if (deltaX != 0 || deltaY != 0) {
                return kotlin.math.abs(deltaY) >= kotlin.math.abs(deltaX)
            }
            return false
        }
}

/**
 * Pure decision logic for Instagram protection.
 *
 * Unknown screens deliberately remain UNKNOWN. Treating missing evidence as the
 * home feed caused false positives in DMs, profiles and settings.
 */
internal object InstagramProtectionEngine {

    @Suppress("UNUSED_PARAMETER")
    fun guardAction(
        signals: InstagramUiSignals,
        interaction: InstagramInteraction,
        config: InstagramProtectionConfig = InstagramProtectionConfig(),
        previousScreen: InstagramScreen = InstagramScreen.UNKNOWN,
        navigatedBackFromDm: Boolean = false
    ): InstagramGuardAction {
        val currentScreen = classify(signals, navigatedBackFromDm)

        // A click is reported before Instagram has necessarily replaced its
        // accessibility tree. Catch known media entry points while the tree is
        // still a safe host screen.
        if (isBlockedContentLaunch(signals, interaction, config)) {
            return InstagramGuardAction.EXIT_REELS
        }

        if (navigatedBackFromDm && (signals.ids.hasAny("main_feed_action_bar") || signals.selectedTabs.contains(InstagramTab.HOME))) {
            return InstagramGuardAction.COVER_FEED
        }

        return when (currentScreen) {
            InstagramScreen.HOME_FEED -> {
                if (config.feedMode == InstagramProtectionConfig.FEED_MODE_DIRECTLY_DM && !navigatedBackFromDm) {
                    InstagramGuardAction.NAVIGATE_DIRECT
                } else {
                    InstagramGuardAction.COVER_FEED
                }
            }

            InstagramScreen.EXPLORE -> {
                if (config.hideExploreFeed) {
                    InstagramGuardAction.COVER_FEED
                } else {
                    InstagramGuardAction.ALLOW
                }
            }

            InstagramScreen.NOTIFICATIONS -> InstagramGuardAction.ALLOW

            InstagramScreen.CREATION -> InstagramGuardAction.ALLOW

            InstagramScreen.REELS -> {
                InstagramGuardAction.EXIT_REELS
            }

            InstagramScreen.STORY -> {
                if (config.blockStories) {
                    InstagramGuardAction.EXIT_REELS
                } else {
                    InstagramGuardAction.ALLOW
                }
            }

            InstagramScreen.COMMENTS_OR_DETAIL -> {
                if (config.blockComments) {
                    InstagramGuardAction.EXIT_REELS
                } else {
                    InstagramGuardAction.ALLOW
                }
            }

            InstagramScreen.UNKNOWN -> InstagramGuardAction.KEEP_CURRENT
            else -> InstagramGuardAction.ALLOW
        }
    }

    fun classify(signals: InstagramUiSignals, navigatedBackFromDm: Boolean = false): InstagramScreen {
        val ids = signals.ids

        // Saved/Likes/Reposts are user-curated collections. Classify them
        // before generic Reels/title checks so Balanced can expose the library
        // without mistaking it for an algorithmic feed.
        if (InstagramProfileSurfacePolicy.isUserCollection(ids, signals.idlessMediaTiles)) {
            return InstagramScreen.SAVED_COLLECTION
        }

        // Localized titles never decide a screen: Instagram renders them in
        // the user's language, so a title rule only ever works for the
        // languages it lists. Every decision below uses view ids and layout.
        val hasBackNav = signals.hasBackNavigation || ids.hasBackNavigation()
        val hasExploreContext = ids.hasAny("explore_action_bar")

        val hasStableHomeHost = ids.hasAny("main_feed_action_bar") &&
            signals.selectedTabs.contains(InstagramTab.HOME)
        val reelsIsOnlySelectedTab = signals.selectedTabs.contains(InstagramTab.REELS) &&
            signals.selectedTabs.none { it != InstagramTab.REELS }

        // Instagram can briefly report more than one selected bottom-tab node
        // while replacing an embedded Home video. A large clips player is also
        // used inside the feed, so neither signal may override a verified Home
        // shell unless genuine viewer navigation (Back) is present.
        if (reelsIsOnlySelectedTab ||
            (signals.hasFullscreenReelsViewer && (!hasStableHomeHost || hasBackNav))) {
            return InstagramScreen.REELS
        }

        // A story viewer may retain the host tab beneath it.
        if (ids.hasStoryViewer()) return InstagramScreen.STORY

        // An opened viewer can retain the Home tab/header during its transition.
        // Dedicated viewer chrome plus Back is stronger evidence than that host.
        // clips_ufi or an embedded video alone is NOT enough.
        if (hasBackNav && ids.hasAny("clips_viewer_action_bar") && signals.hasClipsInteractionBar) {
            return InstagramScreen.REELS
        }

        // 2. Notifications screen (allowed)
        val hasNotificationsContext = ids.hasAnyContaining(
            "activity_feed",
            "newsfeed_recycler",
            "notifications_recycler",
            "follow_requests_header"
        )
        if (hasNotificationsContext) {
            return InstagramScreen.NOTIFICATIONS
        }

        // 3. Direct Messages structure (allowed)
        val hasDirectDetails = ids.hasAny("thread_details_pager") &&
            ids.hasAny("thread_details_header", "shared_section")
        if (hasDirectDetails) {
            return if (ids.hasAny("shared_media_list")) {
                InstagramScreen.DIRECT_SHARED_MEDIA
            } else {
                InstagramScreen.DIRECT_MESSAGES
            }
        }

        val hasDirectStructure = ids.hasAny(
            "direct_inbox_action_bar",
            "direct_thread_header",
            "direct_thread_content_below_action_bar",
            "message_composer_bar",
            "row_thread_composer_container",
            "row_thread_composer_edittext"
        ) || ids.hasAny("inbox_refreshable_thread_list_recyclerview") ||
            signals.selectedTabs.contains(InstagramTab.DIRECT)
        // Instagram Notes ("durum"): the notes tray, the note composer and its
        // audience picker live inside the Direct area and are a safe zone in
        // both modes. Their exact ids classify the screen as Direct Messages
        // so no feed curtain is ever mounted over them.
        val hasNotesStructure = ids.hasAny(
            "notes_creation_top_container",
            "pog_note_bubble_card_view",
            "notes_audience_picker_share_with",
            "condensed_audience_picker_container",
            "alternative_notes_options"
        )

        // The own profile shows the user's note as a bubble on its avatar
        // (pog_note_bubble_card_view). A visible profile header means this is
        // the profile, not the Direct notes tray.
        val hasProfileHeader = ids.hasAny("profile_header_container", "profile_tabs_container")
        if (hasNotesStructure && !hasProfileHeader) {
            return InstagramScreen.DIRECT_MESSAGES
        }

        if (signals.selectedTabs.contains(InstagramTab.DIRECT) ||
            (hasDirectStructure &&
                !signals.selectedTabs.contains(InstagramTab.SEARCH) &&
                !signals.selectedTabs.contains(InstagramTab.PROFILE) &&
                !signals.selectedTabs.contains(InstagramTab.REELS))
        ) {
            return InstagramScreen.DIRECT_MESSAGES
        }

        // 4. Creation / Publishing flow (+ Button, Media Picker, Camera, Composer)
        // Must have back/cancel navigation or standalone creation views without main feed shell
        val hasCreationViews = ids.hasAny(
            "gallery_grid", "gallery_recycler_view", "gallery_folder_menu_btn",
            "photo_preview", "crop_image_view", "next_button_textview",
            "camera_shutter_button", "quick_capture_bottom_navigation",
            "cam_filter_preview", "caption_edit_text", "composer_edit_text",
            "action_bar_button_next", "publish_button", "media_picker_view",
            "album_thumbnail_view", "gallery_container", "gallery_header",
            // Story camera and its post-capture editor (text, stickers);
            // they publish no title, so only these ids identify them.
            "quick_capture_root_container", "post_capture_button_share_container",
            "post_capture_compose_view"
        )
        val isCreationFlow = (hasBackNav && hasCreationViews) ||
            (hasCreationViews && !ids.hasAny("main_feed_action_bar", "reels_tray_container"))

        if (isCreationFlow && !signals.selectedTabs.contains(InstagramTab.REELS)) {
            return InstagramScreen.CREATION
        }

        // Following/Favorites are separate action-bar screens, but still
        // infinite Home feeds. Empty Favorites has no row_feed_* nodes; its
        // empty-state ids and list shell keep the curtain owned.
        if (InstagramHomeGeometry.isAlternateFeed(ids, signals.titles, hasBackNav)) {
            return InstagramScreen.HOME_FEED
        }

        // 5. Unambiguous Home Feed Context:
        // When on Home tab or main_feed_action_bar is present, and NOT an explicit post detail,
        // this is DEFINITIVELY the HOME FEED!
        val isExplicitPostDetail = !ids.hasAny("main_feed_action_bar") &&
            ids.hasStructuralCommentView()

        val isHomeFeedContext = !reelsIsOnlySelectedTab &&
            signals.sourceTab != InstagramTab.REELS &&
            !isExplicitPostDetail &&
            (ids.hasAny("main_feed_action_bar") ||
                (signals.selectedTabs.contains(InstagramTab.HOME) && !hasBackNav)) &&
            !hasExploreContext

        if (isHomeFeedContext) {
            return InstagramScreen.HOME_FEED
        }

        // 6. Stories viewer is blocked (only when genuine fullscreen viewer, not inside DM or Home shell)
        val isStoryViewer = !hasDirectStructure &&
            !signals.selectedTabs.contains(InstagramTab.DIRECT) &&
            !ids.hasAny(
                "main_feed_action_bar",
                "direct_inbox_action_bar",
                "direct_thread_header",
                "message_composer_bar",
                "inbox_refreshable_thread_list_recyclerview"
            ) &&
            ids.hasStoryViewer()

        if (isStoryViewer) {
            return InstagramScreen.STORY
        }

        // 7. Reels & Full-Screen Video Viewers:
        val isReelsViewer = !isHomeFeedContext && !isCreationFlow && !hasDirectStructure && (
            reelsIsOnlySelectedTab ||
            signals.sourceTab == InstagramTab.REELS ||
            (hasBackNav && hasExploreContext && (
                signals.hasClipsInteractionBar || ids.hasStrongReelsPlayer()
                )) ||
            (hasBackNav && (signals.hasClipsInteractionBar || ids.hasAny("clips_ufi", "row_feed_comment_edit_text"))) ||
            (ids.hasStrongReelsPlayer() && !hasDirectStructure)
        )

        if (isReelsViewer) {
            return InstagramScreen.REELS
        }

        // 8. Post Detail or Comments (only when reading someone else's post, not creating or on home feed or returning from DM)
        val isPostOrCommentDetail = !isHomeFeedContext &&
            !isCreationFlow &&
            !hasDirectStructure &&
            !navigatedBackFromDm &&
            !ids.hasAny("main_feed_action_bar", "reels_tray_container") && (
                ids.hasStructuralCommentView() ||
                (hasBackNav && ids.hasPostViewer() && !ids.hasAny("sticky_header_list", "list"))
            )
        if (isPostOrCommentDetail) {
            return InstagramScreen.COMMENTS_OR_DETAIL
        }

        // 9. Profile shell (if not a media viewer)
        if (ids.hasAny(
                "profile_header_container",
                "profile_action_bar",
                "user_detail_fragment",
                "profile_viewpager",
                "profile_tabs_container"
            ) &&
            (!signals.selectedTabs.contains(InstagramTab.SEARCH) || hasBackNav)
        ) {
            return InstagramScreen.PROFILE
        }
        if (signals.selectedTabs.contains(InstagramTab.PROFILE)) {
            return InstagramScreen.PROFILE
        }

        // 10. Search results vs Explore
        if (signals.searchFieldFocused || ids.hasActiveSearch() ||
            (hasBackNav && ids.hasAny("action_bar_search_edit_text"))
        ) {
            return InstagramScreen.SEARCH_RESULTS
        }

        if (ids.hasAny(
                "explore_action_bar",
                "layout_recyclerview_parent_container",
                "grid_card_layout_container",
                "image_preview"
            ) || signals.selectedTabs.contains(InstagramTab.SEARCH) ||
            signals.sourceTab == InstagramTab.SEARCH
        ) {
            return InstagramScreen.EXPLORE
        }

        // 11. Home Feed
        val hasHomeStructure = ids.hasAny(
            "main_feed_action_bar",
            "row_feed_profile_header",
            "reels_tray_container",
            "carousel_media_group"
        ) || ids.any { it.startsWith("row_feed_") }

        val hasScrollableHomeShell = ids.hasAny("refreshable_container") &&
            ids.hasAny("sticky_header_list") &&
            ids.hasAny(
                "list",
                "swipeable_nav_view_pager_inner_recycler_view"
            )

        if (signals.selectedTabs.contains(InstagramTab.HOME) ||
            signals.sourceTab == InstagramTab.HOME ||
            ids.hasAny("main_feed_action_bar") ||
            hasHomeStructure ||
            hasScrollableHomeShell
        ) {
            return InstagramScreen.HOME_FEED
        }

        return InstagramScreen.UNKNOWN
    }

    @Suppress("UNUSED_PARAMETER")
    fun shouldBlock(
        signals: InstagramUiSignals,
        interaction: InstagramInteraction,
        previousScreen: InstagramScreen,
        config: InstagramProtectionConfig = InstagramProtectionConfig()
    ): Boolean {
        val screen = classify(signals)

        if (isBlockedContentLaunch(signals, interaction, config)) return true

        if (screen == InstagramScreen.CREATION || screen == InstagramScreen.NOTIFICATIONS) {
            return false
        }

        if (screen == InstagramScreen.STORY && config.blockStories) {
            return true
        }

        if (screen == InstagramScreen.COMMENTS_OR_DETAIL && config.blockComments) {
            return true
        }

        if (screen == InstagramScreen.REELS) {
            if (interaction.kind == InstagramEventKind.WINDOW_CHANGED ||
                interaction.kind == InstagramEventKind.CONTENT_CHANGED
            ) {
                return true
            }
        }

        if (interaction.kind != InstagramEventKind.SCROLL) return false

        val protectedScreen = when (screen) {
            InstagramScreen.HOME_FEED -> true
            InstagramScreen.REELS -> true
            InstagramScreen.EXPLORE -> config.hideExploreFeed
            else -> false
        }
        if (!protectedScreen) return false

        // Safe nested scrollers only apply outside the Home feed.
        if (screen != InstagramScreen.HOME_FEED &&
            signals.sourceIds.hasSafeScrollableSource()
        ) {
            return false
        }

        return interaction.isVerticalScroll
    }

    fun isBlockedContentLaunch(
        signals: InstagramUiSignals,
        interaction: InstagramInteraction,
        config: InstagramProtectionConfig = InstagramProtectionConfig()
    ): Boolean {
        if (interaction.kind != InstagramEventKind.CLICK) return false
        if (signals.sourceTab == InstagramTab.REELS) return true

        val sourceIds = signals.sourceIds
        if (sourceIds.hasAnyContaining(
                "profile_tab_icon_view",
                "profile_tab_layout",
                "profile_tabs_container"
            )
        ) {
            return false
        }

        // Creation buttons or within creation flow
        val isCreationAction = sourceIds.hasAny(
            "action_bar_button_new_post", "creation_tab", "action_bar_button_create"
        ) || sourceIds.hasAnyContaining("new_post", "camera_shutter", "composer")
        if (isCreationAction) {
            return false
        }

        // Direct icon or action bar messaging
        val isDirectAction = sourceIds.hasAny(
            "action_bar_button_action",
            "direct_inbox_action_bar",
            "direct_thread_header",
            "message_composer_bar",
            "direct_tab"
        ) || sourceIds.hasAnyContaining("direct", "inbox")
        if (isDirectAction) {
            return false
        }

        // Notifications icon
        val isNotificationsAction = sourceIds.hasAnyContaining("notification", "activity_feed")
        if (isNotificationsAction) {
            return false
        }

        // Back navigation is never a blocked content launch
        val isBackAction = sourceIds.hasAny(
            "action_bar_button_back", "back_button"
        ) || sourceIds.hasAnyContaining("action_bar_back", "navigation_back")
        if (isBackAction) {
            return false
        }

        val hostScreen = classify(signals)
        if (hostScreen == InstagramScreen.CREATION ||
            hostScreen == InstagramScreen.NOTIFICATIONS
        ) {
            return false
        }

        // Inside DM Inbox, navigating between conversations is always safe
        val isInboxList = signals.ids.hasAny(InstagramSurfacePolicy.INBOX_LIST_ID) ||
            (signals.ids.hasAny("list_container") &&
                InstagramSurfacePolicy.INBOX_HEADER_IDS.any(signals.ids::contains)) ||
            sourceIds.hasAnyContaining("inbox", "thread_row", "row_inbox")
        if (isInboxList) {
            return false
        }

        val isDirectMediaClick = hostScreen == InstagramScreen.DIRECT_MESSAGES &&
            sourceIds.hasAny("message_content_generic_xma_container", "media_container", "clips_grid_item")

        if (hostScreen == InstagramScreen.DIRECT_MESSAGES && !isDirectMediaClick) {
            return false
        }

        // Story viewing or clicking stories tray is safe when stories are allowed
        val isStoryClick = sourceIds.hasAnyContaining(
            "reels_tray",
            "tray_recycler",
            "story_ring",
            "story_view",
            "highlight"
        )
        if (!config.blockStories && isStoryClick) {
            return false
        }

        val hasMediaSource = sourceIds.hasAnyContaining(
            "clips_grid_item",
            "media_grid_item",
            "grid_media",
            "media_container",
            "media_thumbnail",
            "image_preview"
        ) || (config.blockStories && sourceIds.hasAnyContaining("story_ring", "story_view", "highlight")) ||
        (hostScreen == InstagramScreen.PROFILE && sourceIds.hasAnyContaining(
            "image_button",
            "imageview",
            "thumbnail",
            "avatar",
            "clips_grid"
        ))
        return hasMediaSource
    }

    private fun Set<String>.hasStrongReelsPlayer(): Boolean =
        hasAnyContaining(
            "clips_video_container",
            "clips_viewer",
            "clips_player",
            "clips_view_pager",
            "clips_viewer_view_pager",
            "reels_viewer",
            "reel_player",
            "reel_viewer_layout",
            "clips_timeline",
            "clips_swipe_refresh",
            "viewer_media_view_pager",
            "feed_preview_keep_watching",
            "feed_preview_bottom_cta"
        )

    private fun Set<String>.hasStructuralCommentView(): Boolean =
        hasAnyContaining(
            "comments_recycler",
            "comment_thread",
            "layout_comment_thread",
            "comment_list"
        )

    private fun Set<String>.hasStoryViewer(): Boolean =
        InstagramStoryIdentity.isViewer(this)

    private fun Set<String>.hasPostViewer(): Boolean =
        hasAnyContaining(
            "media_view_pager",
            "carousel_media_group",
            "post_detail",
            "feed_detail",
            "single_media_view"
        )

    private fun Set<String>.hasActiveSearch(): Boolean =
        hasAnyContaining(
            "search_row",
            "echo_text",
            "search_results_list"
        )

    private fun Set<String>.hasBackNavigation(): Boolean =
        hasAnyContaining(
            "action_bar_button_back",
            "action_bar_back",
            "back_button",
            "up_button"
        )

    private fun Set<String>.hasSafeScrollableSource(): Boolean =
        hasAnyContaining(
            "tab_recycler_view",
            "profile_tabs",
            "search_results_list",
            "direct_thread_list"
        )

    private fun Set<String>.hasAny(vararg candidates: String): Boolean =
        candidates.any { contains(it) }

    private fun Set<String>.hasAnyContaining(vararg needles: String): Boolean =
        any { value ->
            needles.any { needle ->
                value.contains(needle, ignoreCase = true)
            }
        }
}
