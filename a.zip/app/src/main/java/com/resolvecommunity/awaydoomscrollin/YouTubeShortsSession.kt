package com.resolvecommunity.awaydoomscrollin

internal enum class YouTubeShortsSessionState {
    OUTSIDE,
    ENTERING,
    WATCHING,
    SAFE_SHEET,
    EXITING
}

internal enum class YouTubeShortsDecision {
    ALLOW,
    EXIT
}

internal data class YouTubeShortsObservation(
    val nowMs: Long,
    val shortsStructureVisible: Boolean,
    val launchRequested: Boolean,
    val definitelyOutsideShorts: Boolean,
    val safeBottomSheetOpen: Boolean,
    val isScrollEvent: Boolean,
    val hasVerticalMovement: Boolean,
    val sourceIsShortsPager: Boolean,
    val feedTabEntry: Boolean = false,
    /**
     * The Shorts pager row filling the screen, read only when the scroll
     * event carries no direction. Null when unknown or mid-swipe.
     */
    val visiblePagerRow: Int? = null
)

/**
 * Explicit lifecycle for one intentional Shorts viewing session.
 *
 * YouTube emits zero-movement pager scroll events while opening a Short and while dismissing a
 * bottom sheet. Those events update context but never request an exit. Only a scroll carrying
 * real vertical movement whose source path is the Shorts pager can move a confirmed session to
 * EXITING. Duplicate events are suppressed only for a bounded exit attempt, not forever.
 * Each attempt has an identity so delayed work cannot act on a newly opened viewer.
 *
 * Android 9-10 can drop the scroll deltas (Galaxy S9+: the open and the swipe
 * both arrived as -1/-1). The session then remembers the pager row of the
 * Short it opened on, and a different row filling the screen counts as the
 * move to the next Short.
 *
 * The opening row is only fixed once the viewer has settled. Opened from a
 * list (a channel's Shorts, a shelf), YouTube first lays the viewer out at
 * row 0 and then jumps to the tapped Short (Galaxy S23, YouTube 21.44: row 0,
 * then row 2 273 ms later). Fixing row 0 read that jump as a swipe and closed
 * the Short the user had just chosen.
 */
internal class YouTubeShortsSession {
    companion object {
        const val LAUNCH_PENDING_MS = 2_000L
        const val EXIT_PENDING_MS = 750L

        /** How long the opening row may still change before it is fixed. */
        const val ROW_ANCHOR_SETTLE_MS = 1_200L
    }

    var state: YouTubeShortsSessionState = YouTubeShortsSessionState.OUTSIDE
        private set

    private var launchPendingUntilMs = 0L
    private var exitPendingUntilMs = 0L
    var generation: Long = 0L
        private set

    /** Pager row of the Short this session opened on, tied to [anchorGeneration]. */
    private var anchorRow: Int? = null
    private var anchorGeneration = -1L
    private var anchorSinceMs = 0L

    private fun movedToAnotherRow(row: Int?, nowMs: Long): Boolean {
        if (row == null) return false
        // A closing viewer can still report a row after the session ended;
        // only a viewer this session is entering or watching sets the anchor.
        if (state != YouTubeShortsSessionState.ENTERING &&
            state != YouTubeShortsSessionState.WATCHING) return false
        if (anchorGeneration != generation || anchorRow == null) {
            anchorGeneration = generation
            anchorRow = row
            anchorSinceMs = nowMs
            return false
        }
        if (nowMs - anchorSinceMs < ROW_ANCHOR_SETTLE_MS) {
            // Still opening: follow the jump to the tapped Short.
            anchorRow = row
            return false
        }
        return row != anchorRow
    }

    fun isExitPending(token: Long, nowMs: Long): Boolean =
        token == generation && state == YouTubeShortsSessionState.EXITING &&
            nowMs < exitPendingUntilMs

    fun finishExit(token: Long) {
        if (token == generation && state == YouTubeShortsSessionState.EXITING) clear()
    }

    fun observe(observation: YouTubeShortsObservation): YouTubeShortsDecision {
        if (state == YouTubeShortsSessionState.EXITING &&
            observation.nowMs >= exitPendingUntilMs
        ) clear()
        if (observation.feedTabEntry) {
            if (state == YouTubeShortsSessionState.EXITING) return YouTubeShortsDecision.ALLOW
            return requestExit(observation.nowMs)
        }
        if (observation.launchRequested) {
            generation++
            exitPendingUntilMs = 0L
            state = YouTubeShortsSessionState.ENTERING
            launchPendingUntilMs = observation.nowMs + LAUNCH_PENDING_MS
        }

        val launchStillPending = state == YouTubeShortsSessionState.ENTERING &&
            observation.nowMs <= launchPendingUntilMs
        if ((state == YouTubeShortsSessionState.ENTERING &&
                !launchStillPending &&
                !observation.shortsStructureVisible) ||
            (observation.definitelyOutsideShorts &&
                !observation.shortsStructureVisible &&
                !observation.launchRequested &&
                !launchStillPending)
        ) {
            clear()
        }

        val knownShortsContext = observation.shortsStructureVisible ||
            observation.sourceIsShortsPager ||
            state == YouTubeShortsSessionState.WATCHING ||
            state == YouTubeShortsSessionState.SAFE_SHEET
        if (state != YouTubeShortsSessionState.EXITING) {
            if (observation.safeBottomSheetOpen && knownShortsContext) {
                state = YouTubeShortsSessionState.SAFE_SHEET
            } else if (observation.shortsStructureVisible) {
                state = YouTubeShortsSessionState.WATCHING
                launchPendingUntilMs = 0L
            }
        }

        if (state == YouTubeShortsSessionState.EXITING) {
            return YouTubeShortsDecision.ALLOW
        }

        val inShortsContext = knownShortsContext ||
            state == YouTubeShortsSessionState.WATCHING ||
            state == YouTubeShortsSessionState.SAFE_SHEET
        val rowMoved = observation.isScrollEvent && observation.sourceIsShortsPager &&
            !observation.safeBottomSheetOpen &&
            movedToAnotherRow(observation.visiblePagerRow, observation.nowMs)
        val shouldExit = YouTubeShortsPolicy.shouldExit(
            protectionEnabled = true,
            isScrollEvent = observation.isScrollEvent,
            packageInForeground = true,
            shortsVisible = inShortsContext && observation.sourceIsShortsPager,
            isVerticalScroll = observation.hasVerticalMovement || rowMoved,
            isSafeSourcePath = observation.safeBottomSheetOpen
        )
        if (!shouldExit) return YouTubeShortsDecision.ALLOW

        return requestExit(observation.nowMs)
    }

    private fun requestExit(nowMs: Long): YouTubeShortsDecision {
        generation++
        state = YouTubeShortsSessionState.EXITING
        exitPendingUntilMs = nowMs + EXIT_PENDING_MS
        return YouTubeShortsDecision.EXIT
    }

    fun clear() {
        generation++
        state = YouTubeShortsSessionState.OUTSIDE
        launchPendingUntilMs = 0L
        exitPendingUntilMs = 0L
    }
}
