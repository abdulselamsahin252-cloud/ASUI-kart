package com.resolvecommunity.awaydoomscrollin

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.UserManager

class DoomscrollDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        applyLockdownPolicies(context)
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        applyLockdownPolicies(context)
    }

    companion object {
        fun componentName(context: Context): ComponentName =
            ComponentName(context, DoomscrollDeviceAdminReceiver::class.java)

        fun isDeviceAdminActive(context: Context): Boolean {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
                ?: return false
            return dpm.isAdminActive(componentName(context))
        }

        fun isDeviceOwner(context: Context): Boolean {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
                ?: return false
            return dpm.isDeviceOwnerApp(context.packageName)
        }

        fun applyLockdownPolicies(context: Context) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
                ?: return
            val admin = componentName(context)
            if (!dpm.isDeviceOwnerApp(context.packageName)) return

            try {
                // Uygulamanın kaldırılmasını sistem düzeyinde engelle
                dpm.setUninstallBlocked(admin, context.packageName, true)
                // Uygulama ayarları / kontrol kısıtlaması (Verileri temizle & Durdurmaya zorla kilidi)
                dpm.addUserRestriction(admin, UserManager.DISALLOW_APPS_CONTROL)
                // Fabrika ayarlarına sıfırlamayı da kısıtla (isteğe bağlı)
                dpm.addUserRestriction(admin, UserManager.DISALLOW_FACTORY_RESET)
            } catch (_: SecurityException) {
            }
        }
    }
}