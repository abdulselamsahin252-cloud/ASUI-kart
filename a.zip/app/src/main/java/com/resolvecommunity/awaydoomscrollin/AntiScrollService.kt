﻿package com.resolvecommunity.awaydoomscrollin

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import android.util.DisplayMetrics
import android.view.View
import android.view.WindowManager
import android.view.WindowInsets
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class AntiScrollService : AccessibilityService() {

    companion object {
        private const val TAG = "AntiScrollService"
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        private const val REEL_WINDOW_REBIND_MS = 3_000L
        /** Support log: only stalls a user could notice. */
        private const val SUPPORT_SLOW_MS = 500L
        /** Stand-in destination for a focused window the service cannot read. */
        private const val UNREADABLE_FOREGROUND = "unreadable.foreground"
        private const val TIKTOK_PACKAGE = "com.zhiliaoapp.musically"
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private const val YOUTUBE_SOURCE_PATH_DEPTH = 24
        private const val INSTAGRAM_EXIT_TREE_QUIET_MS = 220L
        private const val INSTAGRAM_VIEWER_EXIT_RETRY_MS = 500L
        private const val DIRECT_MODAL_COVER_MAX_MS = 1_500L
        private const val PRECOVER_DRAW_HOLD_MS = 150L
        private const val INSTAGRAM_STORY_LAUNCH_WINDOW_MS =1_500L
        private const val INSTAGRAM_NOTIFICATION_MAX_BACKS = 4
        private const val INSTAGRAM_NOTIFICATION_COMMENT_GRACE_MS = 700L
        private const val PROFILE_ALLOWED_DEPARTURE_QUIET_MS = 450L
        private const val DIRECT_DETAILS_LAUNCH_PENDING_MS = 1_200L
        private const val DIRECT_REEL_LAUNCH_PENDING_MS = 1_500L
        private const val DIRECT_DETAILS_FALLBACK_BACK_MS = 180L
        private const val DIRECT_DETAILS_GUARD_SETTLE_MS = 320L
        private const val DIRECT_REEL_INTENT_DEBOUNCE_MS = 250L
        private const val DIRECT_CONVERSATION_GUARD_HOLD_MS = 1_800L
        private const val DIRECT_CONVERSATION_ENTRY_GUARD_TIMEOUT_MS = 2_500L
        private const val DIRECT_CONVERSATION_SURFACE_GUARD_TIMEOUT_MS = 650L
        private const val DIRECT_NAVIGATION_GRACE_MS = 2_500L
        private const val DIRECT_RECOVER_COVER_MS = 500L
        private const val SEARCH_RELEASE_PROBE_MS = 400L
        private const val SURFACE_LEFT_PROBE_GAP_MS = 64L
        private const val DIRECT_RECOVER_DIALOG_RECHECK_MS = 250L
        private const val INSTAGRAM_RESUME_RESCAN_MS = 48L
        private const val INSTAGRAM_USER_LAUNCH_GRACE_MS = 1_200L
        private const val INSTAGRAM_PROTECTED_NAVIGATION_HOLD_MS = 2_000L
        private const val INSTAGRAM_PROTECTED_NAVIGATION_FALLBACK_MS = 160L
        private const val PROFILE_COVER_JITTER_PX = 24
        private const val PROFILE_COVER_UP_STEP_PX = 60
        // The protective body hold releases as soon as the row position stops
        // changing: two stable samples plus this quiet window. A stopped finger
        // therefore sees the exact pose again after roughly a fifth of a second.
        private const val PROFILE_FULL_COVER_SETTLE_HOLD_MS = 150L
        private const val PROFILE_FULL_COVER_MAX_HOLD_MS = 700L
        private const val YOUTUBE_SURFACE_SCAN_DELAY_MS = 24L
        private const val YOUTUBE_CONTENT_SCAN_SPACING_MS = 120L
        private const val YOUTUBE_IDLE_RESCAN_MS = 450L
        private const val YOUTUBE_CLICK_INTENT_MS = 1_500L
private const val YOUTUBE_SHORTS_TAB_CLICK_LATCH_MS = 2_000L
private const val YOUTUBE_ALLOWED_FLIP_SETTLE_MS = 200L
/** How long the feed pager's settle scroll can trail a tab tap or page change. */
private const val YOUTUBE_FEED_PAGER_SETTLE_MS = 800L
private const val YOUTUBE_BARS_RESTORE_INTERVAL_MS = 700L
private const val KEY_INSTAGRAM_SEEN_WINDOWS = "instagram_seen_windows"
// "top|width|instagramVersionCode" of the last Home curtain, in pixels.
private const val KEY_SAVED_HOME_CURTAIN_TOP = "instagram_home_curtain_top"
        private const val YOUTUBE_QUICK_IDENTITY_MAX_NODES = 80
        private const val OVERLAY_FOREGROUND_CHECK_MS = 250L
        private const val MAX_TREE_NODES = 240
        private const val PROFILE_ENSURE_MAX_TICKS = 100
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private val searchInputThread = lazy { HandlerThread("instagram-search-input").apply { start() } }
    private var searchInputActive = false
    private var searchInputBypassUntil = 0L
    /** Read on the reader thread: the request was made on a covered Home. */
    @Volatile private var searchInputExpectHome = false
    private val searchInputDispatcher = lazy {
        val worker = Handler(searchInputThread.value.looper)
        val reader = InstagramSearchInputReader({ rootInActiveWindow }, { windows },
            expectHome = { searchInputExpectHome },
            homeStoriesBlocked = { instagramStoriesBlocked() })
        LatestObservationDispatcher(
            worker = java.util.concurrent.Executor { worker.post(it) },
            owner = java.util.concurrent.Executor { mainHandler.post(it) },
            read = reader::read,
            accept = { result: Result<InstagramSearchInputObservation> ->
                if (searchInputActive) result.fold(::applySearchInputObservation) { fallBackFromSearchInput() }
            })
    }

    private fun canObserveSearchInput(): Boolean {
        val now = SystemClock.uptimeMillis()
        return now >= searchInputBypassUntil && taskSwitcherOwner == null &&
            !instagramOverlay.isNotificationShadeSuspended && !instagramResumePending &&
            !instagramResumeGeometryGate.isActive && !instagramExitInProgress &&
            !instagramProfileIngress.pending && !instagramProfileIngress.awaitingCurtainDraw &&
            now >= precoverDrawPendingUntil &&
            !instagramProtectedNavigation.isPending(InstagramTab.HOME, now) &&
            !instagramProtectedNavigation.isPending(InstagramTab.SEARCH, now) &&
            ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) &&
            currentInstagramWindowId >= 0 &&
            ((lastInstagramScreen == InstagramScreen.EXPLORE &&
                instagramOverlay.visibleCurtain()?.first == InstagramScreen.EXPLORE) ||
                (lastInstagramScreen == InstagramScreen.SEARCH_RESULTS && instagramExploreSearchSeen) ||
                coveredHomeSettled(now))
    }

    /**
     * A covered standard Home whose cover is not being moved: no Following or
     * Favorites feed, and no scroll hold of the header (that logic stays on
     * the official path).
     */
    private fun coveredHomeSettled(now: Long): Boolean =
        lastInstagramScreen == InstagramScreen.HOME_FEED &&
            instagramOverlay.visibleCurtain()?.first == InstagramScreen.HOME_FEED &&
            !instagramAlternateFeedActive && scrollCoverTop == null && now >= scrollCoverUntil

    private fun requestSearchInputObservation(invalidate: Boolean = false): Boolean {
        if (!canObserveSearchInput()) {
            stopSearchInputObservation()
            return false
        }
        searchInputActive = true
        searchInputExpectHome = lastInstagramScreen == InstagramScreen.HOME_FEED
        searchInputDispatcher.value.request(invalidate)
        return true
    }

    private fun stopSearchInputObservation() {
        searchInputActive = false
        if (searchInputDispatcher.isInitialized()) searchInputDispatcher.value.cancel()
    }

    private fun fallBackFromSearchInput() {
        stopSearchInputObservation()
        // Unsupported/unfocused surfaces keep their current protection. Give the
        // existing detector ownership instead of repeatedly retrying this path.
        searchInputBypassUntil = SystemClock.uptimeMillis() + 500L
        queueInstagramScan(0L)
    }

    private fun handleSearchInputEvent(event: AccessibilityEvent): Boolean {
        if (!canObserveSearchInput()) return false
        if (lastInstagramScreen == InstagramScreen.HOME_FEED) {
            // Home: only the stream of content changes from Home's own window
            // goes to the reader. Taps, scrolls, window changes and anything
            // from another window (a Story, a dialog) keep the official path.
            if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                event.windowId != currentInstagramWindowId) return false
            return requestSearchInputObservation()
        }
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            // Keep native intent handling and invalidate the old read. Leave
            // this scope active until that handling changes it, so a foreground
            // tick cannot put blocking IPC back ahead of the queued search scan.
            if (searchInputDispatcher.isInitialized()) searchInputDispatcher.value.cancel()
            return false
        }
        return requestSearchInputObservation(invalidate =
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)
    }

    private fun applySearchInputObservation(observation: InstagramSearchInputObservation) {
        if (!canObserveSearchInput() || observation.surface == InstagramSearchInputSurface.OTHER ||
            observation.windowId != currentInstagramWindowId) {
            fallBackFromSearchInput()
            return
        }
        if (observation.surface == InstagramSearchInputSurface.EXPLORE ||
            observation.surface == InstagramSearchInputSurface.HOME) {
            // Only skip rediscovery of exactly the already covered geometry.
            // Resizing, scrolling chrome and returns still use the official path.
            val expected = if (observation.surface == InstagramSearchInputSurface.HOME)
                InstagramScreen.HOME_FEED else InstagramScreen.EXPLORE
            val cover = observation.cover
            if (lastInstagramScreen != expected || cover == null ||
                instagramOverlay.visibleCurtain()?.second != cover.rect()) {
                if (ProtectionFlightRecorder.ENABLED && expected == InstagramScreen.HOME_FEED) {
                    ProtectionFlightRecorder.record(this, "instagram.home.reader",
                        "fallback cover=$cover curtain=${instagramOverlay.visibleCurtain()?.second}")
                }
                fallBackFromSearchInput()
            }
            return
        }
        if (observation.surface != InstagramSearchInputSurface.FOCUSED_SEARCH) {
            fallBackFromSearchInput()
            return
        }
        // One final foreground check on the owner, after queued navigation events
        // invalidated older reads. Never let an old worker result hide a new cover.
        val current = rootInActiveWindow
        if (current?.packageName?.toString() != INSTAGRAM_PACKAGE ||
            current.windowId != observation.windowId) {
            fallBackFromSearchInput()
            return
        }
        instagramExploreSearchSeen = true
        hideInstagramContentOverlay()
        instagramEntryTargets.clear()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        instagramOverlay.updateNavigationGuards(emptyMap())
        instagramOverlay.updateReelsTabGuard(observation.reelsTab?.rect())
        instagramOverlay.updateSearchReturnGuard(observation.back?.rect(), ::onSearchReturnBack)
        observeInstagramScreen(InstagramScreen.SEARCH_RESULTS, observation.windowId)
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.search.input", "focused=true window=${observation.windowId}")
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
    }

    private fun InstagramGeometrySample.rect() = Rect(left, top, right, bottom)
    // Instagram can block the accessibility service's main looper for several
    // seconds while it rebuilds a notification/comment tree.  The second Back
    // for a verified notification comment viewer must not wait behind that
    // scan, so keep a tiny independent queue for this one-shot action.
    private val instagramFastExitThread = HandlerThread("InstagramFastExit").apply { start() }
    private val instagramFastExitHandler = Handler(instagramFastExitThread.looper)
    private var instagramFastExitDeadlineAt = 0L
    private var instagramFastExitGeneration = 0L
    private val instagramFastNotificationBack: Runnable = Runnable {
        if (!instagramExitInProgress ||
            !instagramExitFromNotifications ||
            !instagramNotificationReelExitIssued ||
            instagramFastExitGeneration != instagramNotificationExitGeneration) return@Runnable
        // The main-looper verifier may already have issued the one permitted
        // fallback click. Never race it with another click from this worker;
        // a second accepted action can leave Instagram's notification stack.
        if (instagramNotificationReelSecondBackIssued) return@Runnable
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return@Runnable
        val now = SystemClock.uptimeMillis()
        if (instagramFastExitDeadlineAt == 0L || now >= instagramFastExitDeadlineAt) {
            return@Runnable
        }
        val activeRoot = runCatching { rootInActiveWindow }.getOrNull()
        if (activeRoot == null || activeRoot.packageName?.toString() != INSTAGRAM_PACKAGE) {
            if (now < instagramFastExitDeadlineAt) {
                requeueFastNotificationBack()
            } else {
                // No foreground proof means this retry is stale. Never send a
                // blind Back that could land in a different notification item.
                mainHandler.post { cancelInstagramExit() }
            }
            return@Runnable
        }
        // Prefer the freshly published Instagram application window over the
        // active root, which may still be a stale notification/overlay root
        // during the transition animation.
        val root = findInstagramNotificationViewerRoot(activeRoot)?.first
        if (root == null) {
            if (hasFastNotificationsSurface(activeRoot)) {
                // Only cancel after probing every Instagram window. The
                // notification list can remain the active root while the
                // blocked viewer lives in a separate application window.
                mainHandler.post { cancelInstagramExit() }
            } else if (now < instagramFastExitDeadlineAt) {
                requeueFastNotificationBack()
            } else {
                mainHandler.post { cancelInstagramExit() }
            }
            return@Runnable
        }
        val commentStillVisible = hasFastCommentSheetInRoot(root)
        val reelStillVisible = hasFastReelsViewer(root, directLaunchPending = true)
        if (commentStillVisible && now < instagramFastExitDeadlineAt) {
            requeueFastNotificationBack()
            return@Runnable
        }
        if (!commentStillVisible && !reelStillVisible) {
            if (now < instagramFastExitDeadlineAt) requeueFastNotificationBack()
            else mainHandler.post { cancelInstagramExit() }
            return@Runnable
        }
        val clickedViewerBack = performViewerBackFromRoot(root)
        val accepted = clickedViewerBack
        if (accepted) {
            instagramNotificationBackCount++
            instagramNotificationReelSecondBackIssued = true
            Log.d(TAG, "IG_NOTIFICATION_REEL_FAST_RETRY_BACK " +
                "count=$instagramNotificationBackCount source=worker " +
                "viewerBack=$clickedViewerBack")
            // An accepted accessibility action is not proof of navigation.
            // Keep the bounded worker alive until the Notifications surface is
            // actually observed, or until its short deadline expires.
            // One fresh-window targeted click is enough. Do not click the same
            // top-left control again while Instagram is publishing a stale
            // viewer root; a second click can leave Notifications too.
            mainHandler.post { queueInstagramScan(0L) }
        } else if (now < instagramFastExitDeadlineAt) {
            // The Reel root may still be settling. Retry only the targeted
            // Instagram control; never fall back to a global Back that could
            // leave Instagram entirely.
            requeueFastNotificationBack()
        }
    }
    private var lastTikTokExitTime = 0L
    private var lastTikTokTopTabCheckMs = 0L
    private val youtubeShortsSession = YouTubeShortsSession()
    private val youtubeBlockedAttempt = BlockedAttemptCounter()
    private val instagramBlockedAttempt = BlockedAttemptCounter()
    private val instagramProtectedNavigation = InstagramProtectedNavigationLatch(
        holdMs = INSTAGRAM_PROTECTED_NAVIGATION_HOLD_MS)
    private val youtubeCurtainState = YouTubeCurtainState(
        subscriptionsProtected = ::youtubeSubscriptionsProtected)
    private var youtubeObservedScreen = YouTubeCurtainScreen.UNKNOWN
    private var youtubeLastVerifiedScreen = YouTubeCurtainScreen.UNKNOWN
    private var youtubeAllowedFlipSince = 0L
    private var youtubeBarsRestoredAt = 0L
    private var lastYouTubeCurtainStateSignature = ""
    private var lastYouTubeSignalsSignature = ""
    private var youtubeNotificationChildOpen = false
    private var youtubeTabGestureDestination: YouTubeNavigationDestination? = null
    private var youtubeTabGestureGeneration: Long? = null
    private var youtubeLastDispatchedTab = YouTubeNavigationDestination.UNKNOWN
    private var youtubeLastDispatchedTabAt = 0L
    private var youtubeStrictShortsExitAt = 0L
    private var youtubeLastTrace = ""
    private var youtubeOverlayForegroundCheckScheduled = false
    private var youtubeOverlayForegroundCheckAt = 0L
    private var youtubeAllowedReturnSurface: YouTubeProtectedSurface? = null
    private var youtubeAllowedReturnBounds: Rect? = null
    private var youtubeLastStableDestination = YouTubeNavigationDestination.UNKNOWN
    /** When the visible page last became Subscriptions (uptime ms). */
    private var youtubeSubscriptionsSince = 0L
    private var youtubeSurfaceScanScheduled = false
    private var youtubeSurfaceScanAt = 0L
    private var lastPackage = ""
    private var instagramSessionStartedAt = 0L
    private var lastInstagramScreen = InstagramScreen.UNKNOWN
    private val instagramStateMachine = InstagramProtectionStateMachine()
    private val instagramBalancedProfilePost = InstagramBalancedProfilePostSession()
    private var instagramBalancedProfileReelIntentWindowId = -1
    private var instagramBalancedProfileReelIntentUntil = 0L
    private var instagramBalancedCollectionReelIntentWindowId = -1
    private var instagramBalancedCollectionReelIntentUntil = 0L
    private var instagramBalancedReelOrigin = InstagramScreen.UNKNOWN
    private var instagramCollectionFeedOrigin: InstagramScreen? = null
    private var lastCollectionReturnProbeAt = 0L
    private var precoverDrawPendingUntil = 0L

    /**
     * A precover's window draws on this service's main thread. A full scan
     * started right after it occupied that thread for ~650 ms on device and
     * the curtain reached the screen only afterwards. Scans wait for the
     * curtain's first frame (bounded), then verify the destination.
     */
    /**
     * Balanced Saved opened from Explore/Home returns to that feed on Back.
     * Four exact lookups prove the feed is back; the full classifier needs
     * ~30 and took 0.5-0.8 s while Instagram animated the return.
     */
    private fun precoverCollectionReturn(knownRoot: AccessibilityNodeInfo? = null): Boolean {
        val origin = instagramCollectionFeedOrigin ?: return false
        if (lastInstagramScreen != InstagramScreen.SAVED_COLLECTION ||
            instagramOverlay.visibleCurtain() != null) return false
        val now = SystemClock.uptimeMillis()
        if (knownRoot == null && now - lastCollectionReturnProbeAt < 60L) return false
        lastCollectionReturnProbeAt = now
        val feedRoot = knownRoot ?: rootInActiveWindow ?: return false
        if (feedRoot.packageName?.toString() != INSTAGRAM_PACKAGE ||
            !matchesRetainedInstagramFeed(feedRoot, origin)) return false
        clearInstagramResumeProtection()
        currentInstagramWindowId = feedRoot.windowId
        val window = instagramWindowBounds(feedRoot)
        val bounds = if (origin == InstagramScreen.EXPLORE) {
            calculateExploreBounds(feedRoot, window)
        } else calculateHomeFeedBounds(feedRoot, window)
        clampCurtainBottomToNavigation(feedRoot, bounds)
        supportCurtainReason = "back"
        if (!showInstagramCurtain(bounds, origin)) return false
        instagramCollectionFeedOrigin = null
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.collection.back", "precover=$origin")
        scanAfterPrecoverDraw()
        return true
    }

    private fun scanAfterPrecoverDraw() {
        precoverDrawPendingUntil = SystemClock.uptimeMillis() + PRECOVER_DRAW_HOLD_MS
        instagramOverlay.afterCurtainDraw {
            precoverDrawPendingUntil = 0L
            queueInstagramScan(0L)
        }
        queueInstagramScan(PRECOVER_DRAW_HOLD_MS)
    }
    private var instagramBalancedNotificationPostWatching = false
    private var instagramUnknownSince = 0L
    /** The window whose unrecognized frames [instagramUnknownWindowSince] times. */
    private var instagramUnknownWindowId = -1
    private var instagramUnknownWindowSince = 0L
    private var instagramExploreSearchSeen = false
    private val instagramReelsSession = InstagramReelsSession()
    private val instagramReelShadeHold = InstagramReelShadeHold()
    private val instagramStoryExitReadiness = InstagramStoryExitReadiness()
    private val instagramReelsPagerMotion = InstagramReelsPagerMotion()
    private var instagramReelsMotionGeneration = -1L
    private var instagramReelsVerifiedAt = Long.MAX_VALUE
    /** Viewer window the allowed Balanced Reel was verified in. */
    private var instagramReelsVerifiedWindowId = -1
    /** After a fold/rotation the viewer window may be recreated under a new id. */
    private var instagramReelWindowRebindUntil = 0L
    // Support log: why the next curtain / viewer exit happens. Set right before
    // the call by paths other than plain screen recognition; read and reset by
    // showInstagramCurtain() / exitBlockedViewer().
    private var supportCurtainReason = "screen"
    private var supportExitReason = "screen"
    /** The pending profile-Reel intent came from a late profile-grid tap. */
    private var instagramBalancedLateProfileTap = false

    /** View ids of [source] and up to [depth] ancestors (source first). */
    private fun ancestorIds(source: AccessibilityNodeInfo?, depth: Int): List<String> {
        val ids = ArrayList<String>(depth)
        var current = source
        repeat(depth) {
            val node = current ?: return ids
            compactId(node.viewIdResourceName).takeIf { it.isNotEmpty() }?.let(ids::add)
            current = node.parent
        }
        return ids
    }

    /**
     * Window of the allowed Reel itself. The state machine may still point at
     * a blocked viewer that was just closed on top of it.
     */
    private fun allowedReelWindowId(): Int =
        instagramReelsVerifiedWindowId.takeIf { it >= 0 } ?: instagramStateMachine.currentWindowId
    private val instagramNotificationReturn = InstagramNotificationReturnState()
    private val instagramProfileReturn = InstagramProfileReturnState()
    private val instagramNotificationMotion = InstagramNotificationMotionGate()
    private val instagramNotificationIngress = InstagramNotificationIngress()
    private var overlayForegroundCheckScheduled = false
    private var instagramExitInProgress = false
    private var instagramExitFromDirectConversation = false
    private var instagramExitFromNotifications = false
    private var instagramNotificationBackCount = 0
    private var instagramNotificationExitHoldUntil = 0L
    private var instagramNotificationReelExitIssued = false
    private var instagramNotificationReelSecondBackIssued = false
    private var instagramNotificationCommentLayerObserved = false
    private var instagramNotificationCommentNeedsSecondBack = false
    private var instagramNotificationCommentWaitStartedAt = 0L
    private var instagramNotificationLastEventExitAt = 0L
    private var instagramNotificationEventLocked = false
    private var instagramNotificationExitGeneration = 0L
    private var instagramNotificationGestureReplayUntil = 0L
    private var instagramExitTreeQuietUntil = 0L
    private var instagramDetailExitChecksRemaining = 0
    private val instagramViewerExitRetry: Runnable = Runnable {
        if (!instagramExitInProgress) return@Runnable
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) {
            cancelInstagramExit()
            return@Runnable
        }
        // Notification-origin viewers have one owner for navigation: the
        // fresh-window worker above. The main-looper retry may only trigger a
        // scan, never a second Back, otherwise delayed accessibility trees can
        // race the worker and escape the notification list.
        if (instagramExitFromNotifications) {
            queueInstagramScan(0L)
            return@Runnable
        }

        // When the notification opened a Reel with a comment sheet, the first
        // Back is known to dismiss that sheet. Do not wait for a fresh
        // accessibility root (which can block for several seconds while
        // Instagram animates); send the second Back from the verified state
        // transition itself. Direct notification Reels do not take this path.
        if (instagramExitFromNotifications &&
            instagramNotificationCommentLayerObserved &&
            instagramNotificationReelExitIssued &&
            !instagramNotificationReelSecondBackIssued &&
            instagramStateMachine.currentScreen == InstagramScreen.REELS) {
            val accepted = rootInActiveWindow
                ?.takeIf { it.packageName?.toString() == INSTAGRAM_PACKAGE }
                ?.let(::performViewerBackFromRoot) == true
            if (accepted) {
                instagramNotificationBackCount++
                instagramNotificationReelSecondBackIssued = true
                Log.d(TAG, "IG_NOTIFICATION_REEL_FAST_RETRY_BACK " +
                    "count=$instagramNotificationBackCount")
            }
            scheduleFastNotificationSecondBack(initialDelayMs = 120L)
            return@Runnable
        }
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != INSTAGRAM_PACKAGE) {
            cancelInstagramExit()
            return@Runnable
        }

        if (instagramExitFromNotifications && instagramNotificationCommentNeedsSecondBack) {
            // A liked-comment notification opens a comment sheet over the
            // blocked Reel. The first Back only dismisses that sheet; once it
            // is gone, send exactly one more Back to close the Reel itself.
            val commentSheetStillVisible = hasFastCommentSheetInRoot(root)
            val reelStillVisible = hasFastReelsViewer(root, directLaunchPending = true)
            val postStillVisible = hasFastSinglePostViewer(root)
            val commentWaitElapsed = instagramNotificationCommentWaitStartedAt
                .takeIf { it > 0L }
                ?.let { SystemClock.uptimeMillis() - it } ?: 0L
            if (hasFastNotificationsSurface(root)) {
                instagramNotificationCommentNeedsSecondBack = false
                cancelInstagramExit()
            } else if (!commentSheetStillVisible ||
                commentWaitElapsed >= INSTAGRAM_NOTIFICATION_COMMENT_GRACE_MS) {
                instagramNotificationCommentNeedsSecondBack = false
                if (reelStillVisible) {
                    instagramNotificationReelExitIssued = false
                    instagramNotificationReelSecondBackIssued = true
                }
                Log.d(TAG, "IG_NOTIFICATION_COMMENT_SECOND_BACK " +
                    "sheetVisible=$commentSheetStillVisible waitMs=$commentWaitElapsed")
                supportExitReason = "notification"
                exitBlockedViewer(
                    root,
                    instagramWindowBounds(root),
                    if (reelStillVisible || postStillVisible) {
                        if (reelStillVisible) InstagramScreen.REELS
                        else InstagramScreen.COMMENTS_OR_DETAIL
                    } else InstagramScreen.COMMENTS_OR_DETAIL,
                    useGlobalBackOnly = false
                )
            } else {
                Log.d(TAG, "IG_NOTIFICATION_COMMENT_WAIT " +
                    "sheetVisible=true waitMs=$commentWaitElapsed")
                scheduleInstagramViewerExitRetry(120L)
            }
            return@Runnable
        }
        if (instagramExitFromNotifications && instagramNotificationReelExitIssued) {
            if (instagramNotificationReelSecondBackIssued) {
                // The independent fast path owns retries, but an accepted
                // action is not proof that Instagram navigated. Let its
                // bounded worker verify the Notifications surface.
                val viewerStillVisible = findInstagramNotificationViewerRoot(root) != null
                if (!viewerStillVisible && hasFastNotificationsSurface(root)) {
                    cancelInstagramExit()
                } else if (SystemClock.uptimeMillis() < instagramNotificationExitHoldUntil) {
                    scheduleInstagramViewerExitRetry(220L)
                } else {
                    cancelInstagramExit()
                }
                return@Runnable
            }
            // The notification list can remain the active root while the
            // opened Reel/comment viewer is exposed through another Instagram
            // accessibility window. Resolve the viewer window first; treating
            // the active Notifications root as proof of return here would
            // cancel the exit while the video is still on screen.
            val notificationViewerRoot = findInstagramNotificationViewerRoot(root)?.first
            if (notificationViewerRoot == null && hasFastNotificationsSurface(root)) {
                if (SystemClock.uptimeMillis() < instagramNotificationExitHoldUntil) {
                    scheduleInstagramViewerExitRetry(120L)
                } else {
                    cancelInstagramExit()
                }
                return@Runnable
            }
            val viewerRoot = notificationViewerRoot ?: root
            // The first Back can dismiss only the comment layer while the Reel
            // remains visible. Send one bounded second Back only when the
            // current foreground tree still proves that Reel is on screen.
            if (hasFastNotificationsSurface(viewerRoot) && notificationViewerRoot == null) {
                val attemptElapsed = instagramNotificationAttemptStartedAt
                    .takeIf { it > 0L }
                    ?.let { SystemClock.uptimeMillis() - it }
                Log.d(TAG, "IG_NOTIFICATION_RETURN elapsedMs=$attemptElapsed " +
                    "backCount=$instagramNotificationBackCount")
                cancelInstagramExit()
                observeInstagramScreen(InstagramScreen.NOTIFICATIONS, root.windowId)
                refreshInstagramNotificationBackGuard(root, instagramWindowBounds(root))
                refreshInstagramNotificationEntryGuards()
                queueInstagramScan(0L)
                return@Runnable
            }
            if (!hasFastReelsViewer(viewerRoot, directLaunchPending = true) &&
                !hasFastCommentSheetInRoot(viewerRoot) &&
                instagramStateMachine.currentScreen != InstagramScreen.REELS) {
                // Instagram can briefly publish an incomplete accessibility
                // tree while the comment layer is settling. Keep the bounded
                // notification exit alive when the state machine still proves
                // that the Reel viewer is the active surface; cancel only once
                // the viewer is actually gone or Notifications is visible.
                cancelInstagramExit()
                return@Runnable
            }
            if (!instagramNotificationReelSecondBackIssued) {
                instagramNotificationReelSecondBackIssued = true
            }
            if (instagramNotificationBackCount < INSTAGRAM_NOTIFICATION_MAX_BACKS) {
                val accepted = performViewerBackFromRoot(viewerRoot)
                if (accepted) {
                    instagramNotificationBackCount++
                    instagramExitTreeQuietUntil = SystemClock.uptimeMillis() +
                        INSTAGRAM_EXIT_TREE_QUIET_MS
                }
                val attemptElapsed = instagramNotificationAttemptStartedAt
                    .takeIf { it > 0L }
                    ?.let { SystemClock.uptimeMillis() - it }
                Log.d(TAG, "IG_NOTIFICATION_REEL_RETRY_BACK count=$instagramNotificationBackCount " +
                    "accepted=$accepted elapsedMs=$attemptElapsed")
            } else {
                cancelInstagramExit()
                return@Runnable
            }
            scheduleInstagramViewerExitRetry(220L)
            return@Runnable
        }
        if (instagramExitFromNotifications &&
            instagramNotificationBackCount < INSTAGRAM_NOTIFICATION_MAX_BACKS) {
            if (instagramStateMachine.currentScreen != InstagramScreen.NOTIFICATIONS &&
                !hasFastNotificationsSurface(root)) {
                val accepted = performViewerBackFromRoot(root)
                if (accepted) {
                    instagramNotificationBackCount++
                    instagramExitTreeQuietUntil = SystemClock.uptimeMillis() +
                        INSTAGRAM_EXIT_TREE_QUIET_MS
                    Log.d(TAG, "IG_NOTIFICATION_FAST_BACK count=$instagramNotificationBackCount")
                }
                scheduleInstagramViewerExitRetry(120L)
                return@Runnable
            }
            // After the first Back, Instagram can keep the underlying Reel in
            // a second accessibility window while the notification list stays
            // focused. Use the same all-window probe as the initial launch so
            // the second Back does not wait for focus to move back.
            findInstagramNotificationViewerRoot(root)?.let { (viewerRoot, viewerScreen) ->
                supportExitReason = "notification"
                exitBlockedViewer(
                    viewerRoot,
                    instagramWindowBounds(viewerRoot),
                    viewerScreen,
                    useGlobalBackOnly = false)
                return@Runnable
            }
        }

        if (instagramStateMachine.currentScreen == InstagramScreen.COMMENTS_OR_DETAIL &&
            instagramDetailExitChecksRemaining > 0) {
            instagramDetailExitChecksRemaining--
            // A reply opens keyboard -> comments -> post layers. A successful
            // Back may remove only one. Verify the next current layer even when
            // Instagram publishes no further accessibility event.
            if (hasFastSinglePostViewer(root)) {
                supportExitReason = "post"
                exitBlockedViewer(root, instagramWindowBounds(root), InstagramScreen.COMMENTS_OR_DETAIL)
            } else if (hasFastCommentSheet(root)) {
                supportExitReason = "post"
                exitBlockedViewer(root, instagramWindowBounds(root), InstagramScreen.COMMENTS_OR_DETAIL,
                    useGlobalBackOnly = true)
            }
            if (instagramExitInProgress && instagramDetailExitChecksRemaining > 0) {
                scheduleInstagramViewerExitRetry()
            }
            return@Runnable
        }

        // Instagram can accept GLOBAL_ACTION_BACK without acting on it when the
        // main pager has just settled from DM/Home onto Reels. Retry once, but
        // only while current foreground structure still proves a Reel viewer.
        if (hasFastStoryViewer(root) && instagramStoriesBlocked()) {
            supportExitReason = "story"
            exitBlockedViewer(root, instagramWindowBounds(root), InstagramScreen.STORY, useGlobalBackOnly = true)
        } else if (hasFastMainReelsTabDestination(root) ||
            hasFastReelsViewer(root) || hasFastReelPreview(root) ||
            (instagramBalancedReelOrigin == InstagramScreen.SAVED_COLLECTION &&
                hasFastSavedCollectionReelList(root))) {
            Log.d(TAG, "IG_VIEWER_EXIT_RETRY stillVisible=true")
            supportExitReason = "retry"
            exitBlockedViewer(root, instagramWindowBounds(root), InstagramScreen.REELS)
        } else if (instagramExitFromNotifications &&
            instagramNotificationBackCount < INSTAGRAM_NOTIFICATION_MAX_BACKS) {
            // Notification comments may reveal the underlying Reel only after
            // the first Back settles. Keep checking briefly so the second Back
            // is sent as soon as that layer appears, without a long dwell.
            scheduleInstagramViewerExitRetry(120L)
        } else {
            cancelInstagramExit()
        }
    }
    private var profileAllowedDepartureUntil = 0L
    private var directDetailsLaunchPendingUntil = 0L
    private var directDetailsFallbackBackAt = 0L
    private var directReelLaunchPendingUntil = 0L
    private var directReelIntentDebounceUntil = 0L
    private var instagramReelsTabTapUntil = 0L
    private var youtubeShortsTabClickUntil = 0L
    private var reelsSlipCoverUntil = 0L
    private var reelsSlipCoverExit = false
    private var lastReelsTabGuardBounds: Rect? = null
    private var reelsTabGuardHoldUntil = 0L
    private var lastReelsTabGuardLogState: String? = null
    private var directConversationGuardHoldUntil = 0L
    private var directDetailsGuardHoldUntil = 0L
    private val instagramResumeGeometryGate = InstagramResumeGeometryGate()
    private var instagramResumePending = false
    private var currentInstagramWindowId = -1
    private var instagramNotificationShadeWindowId = -1
    // A notification row removes its list markers before Instagram publishes
    // the opened post/Reel. Keep that short hand-off native so the old Home
    // curtain cannot flash over it.
    private var instagramNotificationContentLaunchUntil = 0L
    /** Last Home curtain, see [InstagramHomeGeometry.tabPrecoverTop]. */
    private var lastHomeCurtainTop = -1
    private var lastHomeCurtainWindowId = -1
    private var lastHomeCurtainWidth = 0
    private val saveHomeCurtainTop = Runnable {
        val version = instagramVersionCode() ?: return@Runnable
        if (lastHomeCurtainTop < 0) return@Runnable
        val value = "$lastHomeCurtainTop|$lastHomeCurtainWidth|$version"
        val prefs = getSharedPreferences(ProtectionPreferences.PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getString(KEY_SAVED_HOME_CURTAIN_TOP, null) != value) {
            prefs.edit().putString(KEY_SAVED_HOME_CURTAIN_TOP, value).apply()
        }
    }

    /** The saved Home curtain top for this screen width and Instagram build, if any. */
    private fun savedHomeCurtainTop(width: Int): Int? {
        val saved = getSharedPreferences(ProtectionPreferences.PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SAVED_HOME_CURTAIN_TOP, null) ?: return null
        val parts = saved.split('|')
        if (parts.size != 3) return null
        val version = instagramVersionCode() ?: return null
        return parts[0].toIntOrNull()?.takeIf {
            parts[1].toIntOrNull() == width && parts[2].toLongOrNull() == version
        }
    }

    private fun instagramVersionCode(): Long? = runCatching {
        val info = packageManager.getPackageInfo(INSTAGRAM_PACKAGE, 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode
        else @Suppress("DEPRECATION") info.versionCode.toLong()
    }.getOrNull()

    /** Debug trace only: last Home tray/header geometry recorded. */
    private var lastHomeGeometryKey = ""
    /** See [InstagramNotificationViewerProbePolicy]; true so the first scan probes. */
    private var instagramWindowChangedSinceViewerProbe = true
    private var instagramNotificationAttemptStartedAt = 0L
    private var instagramNotificationViewerDetectedAt = 0L
    private var lastVerifiedInstagramCurtain: Pair<InstagramScreen, Rect>? = null
    private var directDetailsInteractionBounds: Rect? = null
    private var lastInstagramScanTime = 0L
    private var lastInboxProbeLogAt = 0L
    private var instagramFeedSnapshotYields = 0
    private var instagramAlternateFeedActive = false
    private var lastInstagramUserInputAt = Long.MIN_VALUE
    private val instagramOverlay by lazy {
        InstagramFeedOverlayController(
            this,
            ::onInstagramOverlayTouched,
            onProfileSwipeUp = {
                // Strict owns the whole profile body. Consuming a swipe must
                // not synthesize Back or let the moving grid escape the fixed
                // curtain; Balanced has no profile curtain at all.
                if (lastInstagramScreen == InstagramScreen.PROFILE &&
                    instagramProfilePostsBlocked()) queueInstagramScan(0L)
            },
            onProtectedNavigation = ::onInstagramProtectedNavigation,
            onEntryGuardVerticalSwipe = ::onInstagramEntryGuardVerticalSwipe,
            onEntryGuardGesture = ::onInstagramEntryGuardGesture,
            onStoryEntrySwipe = ::onInstagramStoryEntrySwipe,
            onProfileSwipeDown = { _, _ -> expandStrictProfileHeader() },
            entryGuardReplaysLongPress = {
                lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES &&
                    InstagramDmInteractionPolicy.blocksSharedMedia(
                        ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))
            }
        )
    }
    private val youtubeOverlay by lazy {
        YouTubeProtectionOverlayController(
            service = this,
            onShortsBlocked = ::onYouTubeShortsGuardBlocked,
            onProtectedNavigation = ::onYouTubeProtectedNavigation,
            onAllowedBackNavigation = ::onYouTubeAllowedBackNavigation,
            onAllowedYouNavigation = ::onYouTubeAllowedYouNavigation,
            onAllowedBackNavigationDown = ::onYouTubeAllowedBackNavigationDown,
            onAllowedLaunchNavigation = ::onYouTubeAllowedToolbarNavigation,
            onCurtainVisibilityChanged = ::measureYouTubeCurtainVisibility,
            subscriptionsOpen = { !youtubeSubscriptionsProtected() }
        )
    }
    private fun measureYouTubeCurtainVisibility(visible: Boolean) {
        val interactive = getSystemService(android.os.PowerManager::class.java)?.isInteractive == true
        YouTubeProtectionMetrics.onVisibilityChanged(this, visible && interactive)
    }
    private fun onYouTubeShortsGuardBlocked() {
        // The guard consumed one completed native-button tap; no viewer exit
        // follows. Each distinct user attempt counts as one intervention.
        SupportDiagnostics.record(this, SupportEvent.YOUTUBE_SHORTS, mapOf("what" to "tab"))
        recordIntervention(YOUTUBE_PACKAGE, System.currentTimeMillis())
    }
    private fun recordYouTubeViewerIntervention(accepted: Boolean) {
        if (youtubeBlockedAttempt.acceptedIntervention(accepted)) {
            recordIntervention(YOUTUBE_PACKAGE, System.currentTimeMillis())
        }
    }
    private val youtubeSurfaceScan = Runnable {
        youtubeSurfaceScanScheduled = false
        youtubeSurfaceScanAt = 0L
        // A curtain lifted just now is still on screen until its relayout
        // frame runs; a scan here would keep it there for the whole scan.
        if (SystemClock.uptimeMillis() < youtubeOverlay.parkCommitPendingUntil) {
            queueYouTubeSurfaceScan(8L)
            return@Runnable
        }
        runYouTubeScan("event")
    }
    private var youtubeLastScanFinishedAt = 0L
    private var youtubeLastClickAt = 0L
    private var youtubeClicklessReturnSince = 0L
    private var youtubeLastSelectedDestination = YouTubeNavigationDestination.UNKNOWN
    /** Notifications and the pages opened from it, until a tab or Search is verified. */
    private var youtubeNotificationsVisit = false

    private fun runYouTubeScan(source: String) {
        val started = SystemClock.uptimeMillis()
        try {
            currentYouTubeRoot()?.let(::refreshYouTubeSurfaceProtection)
        } finally {
            clearNodeLookupCache()
            youtubeLastScanFinishedAt = SystemClock.uptimeMillis()
            val elapsed = youtubeLastScanFinishedAt - started
            if (ProtectionFlightRecorder.ENABLED && elapsed >= 40L) {
                ProtectionFlightRecorder.record(this, "youtube.scan",
                    "elapsedMs=$elapsed source=$source screen=$youtubeObservedScreen")
            }
        }
    }
    private fun onYouTubeAllowedBackNavigationDown() {
        val surface = youtubeAllowedReturnSurface ?: return
        if (youtubeCurtainState.pendingDestination == surface.curtainScreen()) return
        youtubeCurtainState.request(surface.curtainScreen(), SystemClock.uptimeMillis())
        youtubeOverlay.showCurtain(
            youtubeAllowedReturnBounds, surface, isEnglish(), preserveBounds = true
        )
        traceYouTubeProtection("back-down")
        scheduleYouTubeOverlayForegroundCheck()
    }

    private fun onYouTubeAllowedToolbarNavigation(target: YouTubeCurtainScreen) {
        val root = currentYouTubeRoot() ?: return
        if (focusedNonOverlayPackage() != YOUTUBE_PACKAGE) return
        val window = Rect().also(root::getBoundsInScreen)
        val toolbar = collectYouTubeToolbar(root, window)
        val launch = toolbar.launchNodes[target] ?: return
        youtubeAllowedReturnSurface = youtubeCurtainState.currentSurface
        youtubeCurtainState.request(target, SystemClock.uptimeMillis())
        toolbar.bounds?.let { bounds ->
            if (youtubeAllowedReturnSurface != null) {
                youtubeOverlay.updateAllowedBackGuard(
                    leftToRight(Rect(window.left, bounds.top, window.left + dp(56), bounds.bottom),
                        window, YOUTUBE_PACKAGE), isEnglish()
                )
            }
        }
        youtubeOverlay.releaseAllowedLaunchGuard(target)
        launch.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        traceYouTubeProtection("allowed-launch")
        queueYouTubeSurfaceScan(0L)
        scheduleYouTubeOverlayForegroundCheck()
    }

    private fun onYouTubeAllowedBackNavigation() {
        onYouTubeAllowedBackNavigationDown()
        youtubeOverlay.releaseAllowedBackGuard()
        val token = youtubeCurtainState.generation
        youtubeOverlay.afterCurtainDraw {
            if (youtubeCurtainState.isCurrentGeneration(token)) dispatchYouTubeAllowedBack(token)
        }
    }

    private fun dispatchYouTubeAllowedBack(token: Long) {
        val root = currentYouTubeRoot() ?: return
        val accepted = findYouTubeBackNavigationNode(root)
            ?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
        if (!accepted) performGlobalAction(GLOBAL_ACTION_BACK)
        mainHandler.postDelayed({
            if (youtubeCurtainState.isCurrentGeneration(token) &&
                youtubeCurtainState.pendingDestination in setOf(
                    YouTubeCurtainScreen.HOME, YouTubeCurtainScreen.SUBSCRIPTIONS
                )
            ) {
                // A Back control clicked during entry animation can accept ACTION_CLICK
                // without navigating. Retry only a freshly verified, stationary Notifications
                // page; never an outgoing frame, Search/IME, or a later navigation generation.
                currentYouTubeRoot()?.let { live ->
                    if (collectYouTubeCurtainSignals(live).screen == YouTubeCurtainScreen.NOTIFICATIONS) {
                        performGlobalAction(GLOBAL_ACTION_BACK)
                        queueYouTubeSurfaceScan(0L)
                    }
                }
            }
        }, 450L)
        queueYouTubeSurfaceScan(0L)
        scheduleYouTubeOverlayForegroundCheck()
    }

    private fun YouTubeProtectedSurface.curtainScreen(): YouTubeCurtainScreen =
        when (this) {
            YouTubeProtectedSurface.HOME -> YouTubeCurtainScreen.HOME
            YouTubeProtectedSurface.SUBSCRIPTIONS -> YouTubeCurtainScreen.SUBSCRIPTIONS
        }

    private fun youtubeSubscriptionsProtected(): Boolean =
        YouTubeSurfacePolicy.subscriptionsProtected(
            ProtectionPreferences.getMode(this, ProtectedApp.YOUTUBE))

    /** The curtain a feed tab needs; Balanced leaves Subscriptions uncovered. */
    private fun youtubeFeedSurface(destination: YouTubeNavigationDestination): YouTubeProtectedSurface? =
        when (destination) {
            YouTubeNavigationDestination.HOME -> YouTubeProtectedSurface.HOME
            YouTubeNavigationDestination.SUBSCRIPTIONS ->
                YouTubeProtectedSurface.SUBSCRIPTIONS.takeIf { youtubeSubscriptionsProtected() }
            else -> null
        }

    private fun onYouTubeProtectedNavigation(surface: YouTubeProtectedSurface) {
        navigateYouTubeTab(
            if (surface == YouTubeProtectedSurface.HOME) YouTubeNavigationDestination.HOME
            else YouTubeNavigationDestination.SUBSCRIPTIONS
        )
    }

    private fun onYouTubeAllowedYouNavigation() {
        navigateYouTubeTab(YouTubeNavigationDestination.YOU)
    }

    private fun navigateYouTubeTab(destination: YouTubeNavigationDestination) {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.YOUTUBE)) return
        if (currentYouTubeRoot() == null) return
        val now = SystemClock.uptimeMillis()
        val token = youtubeCurtainState.request(destination.curtainScreen(), now)
        youtubeAllowedReturnSurface = null
        youtubeTabGestureDestination = null
        youtubeTabGestureGeneration = null
        val surface = youtubeCurtainState.currentSurface
        val curtainAlreadyVisible = youtubeOverlay.isCurtainVisible
        youtubeOverlay.showCurtain(null, surface, isEnglish(), preserveBounds = true)
        traceYouTubeProtection("tab-armed")
        // addView/state publication is not a rendered opaque frame. Do not let YouTube
        // start its feed animation until that frame has actually passed pre-draw.
        // An open destination (Balanced Subscriptions from an uncovered page)
        // mounts no curtain, so waiting for its draw would swallow the tap.
        if (!curtainAlreadyVisible && surface != null && destination in setOf(
                YouTubeNavigationDestination.HOME, YouTubeNavigationDestination.SUBSCRIPTIONS
            )) {
            youtubeOverlay.afterCurtainDraw {
                if (youtubeCurtainState.isCurrentGeneration(token)) dispatchYouTubeTabNavigation(destination, token)
            }
        } else dispatchYouTubeTabNavigation(destination, token)
    }

    private fun dispatchYouTubeTabNavigation(destination: YouTubeNavigationDestination, token: Long) {
        val root = currentYouTubeRoot() ?: return
        val targetNode = findYouTubeNavigationNode(root, destination)
        youtubeLastDispatchedTab = destination
        youtubeLastDispatchedTabAt = SystemClock.uptimeMillis()
        // Accessibility actions operate on the real tab without removing its touch guard.
        performYouTubeNavigationClick(targetNode)
        traceYouTubeProtection("tab-request")
        queueYouTubeSurfaceScan(0L)
        scheduleYouTubeOverlayForegroundCheck()
        mainHandler.postDelayed(fallback@ {
            if (!youtubeCurtainState.isCurrentGeneration(token)) return@fallback
            val pendingDestination = youtubeCurtainState.pendingDestination
            if (pendingDestination != destination.curtainScreen() &&
                !(pendingDestination == null && destination == YouTubeNavigationDestination.YOU)
            ) return@fallback
            val fresh = currentYouTubeRoot() ?: return@fallback
            // The selected tab survives behind search/results. Only skip the physical
            // fallback when the visible page is also consistent with tab navigation.
            val signals = collectYouTubeCurtainSignals(fresh)
            if (!YouTubeSurfacePolicy.shouldRetryTabNavigation(
                    destination, signals.selectedDestination, signals.screen
                )) return@fallback
            val freshNode = findYouTubeNavigationNode(fresh, destination) ?: return@fallback
            val bounds = Rect().also(freshNode::getBoundsInScreen)
            if (bounds.width() <= 0 || bounds.height() <= 0) return@fallback
            youtubeTabGestureDestination = destination
            youtubeTabGestureGeneration = token
            when (destination) {
                YouTubeNavigationDestination.HOME ->
                    youtubeOverlay.releaseProtectedNavigationGuard(YouTubeProtectedSurface.HOME)
                YouTubeNavigationDestination.SUBSCRIPTIONS ->
                    youtubeOverlay.releaseProtectedNavigationGuard(YouTubeProtectedSurface.SUBSCRIPTIONS)
                YouTubeNavigationDestination.YOU -> youtubeOverlay.releaseYouNavigationGuard()
                else -> return@fallback
            }
            // Only retry a still-pending current request, using freshly resolved geometry.
            dispatchScreenTap(bounds.centerX().toFloat(), bounds.centerY().toFloat()) {
                if (!youtubeCurtainState.isCurrentGeneration(token)) return@dispatchScreenTap
                youtubeTabGestureDestination = null
                youtubeTabGestureGeneration = null
                queueYouTubeSurfaceScan(0L)
            }
        }, 160L)
    }

    private var gestureDispatchInProgress = false

    private fun dispatchScreenTap(
        x: Float,
        y: Float,
        durationMs: Long = 35L,
        onResult: ((Boolean) -> Unit)? = null
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || gestureDispatchInProgress) {
            onResult?.invoke(false)
            return false
        }
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(
            GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L))
        ).build()
        gestureDispatchInProgress = true
        val queued = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureDispatchInProgress = false
                onResult?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureDispatchInProgress = false
                onResult?.invoke(false)
            }
        }, mainHandler)
        if (!queued) {
            gestureDispatchInProgress = false
            onResult?.invoke(false)
        }
        return queued
    }

    private fun dispatchScreenSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long,
        onResult: ((Boolean) -> Unit)? = null
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || gestureDispatchInProgress) {
            onResult?.invoke(false)
            return false
        }
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder().addStroke(
            // Instagram's message list treats very short synthetic strokes as
            // fling/page commands. Keep a quick finger drag smooth enough to
            // track the intended movement instead of skipping message rows.
            GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(260L, 1_000L))
        ).build()
        gestureDispatchInProgress = true
        val queued = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureDispatchInProgress = false
                onResult?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureDispatchInProgress = false
                onResult?.invoke(false)
            }
        }, mainHandler)
        if (!queued) {
            gestureDispatchInProgress = false
            onResult?.invoke(false)
        }
        return queued
    }

    private fun performYouTubeNavigationClick(node: AccessibilityNodeInfo?): Boolean {
        var current = node
        repeat(4) {
            val candidate = current ?: return false
            if (candidate.isClickable &&
                candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            ) return true
            current = candidate.parent
        }
        return false
    }

    private fun traceYouTubeProtection(reason: String) {
        if (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE == 0) return
        val trace = "screen=$youtubeObservedScreen target=${youtubeCurtainState.pendingDestination} " +
            "curtain=${youtubeOverlay.currentCurtainSurface} generation=${youtubeCurtainState.generation}"
        if (trace == youtubeLastTrace) return
        youtubeLastTrace = trace
        Log.d("YTProtection", "${SystemClock.uptimeMillis()} $reason $trace")
    }

    private val youtubeOverlayForegroundCheck = object : Runnable {
        override fun run() {
            youtubeOverlayForegroundCheckScheduled = false
            youtubeOverlayForegroundCheckAt = 0L
            // Numeric window visibility alone does not prove an illuminated display.
            // The existing foreground loop also pauses/resumes measurement at screen off/on.
            measureYouTubeCurtainVisibility(youtubeOverlay.isCurtainVisible)
            val foreground = focusedNonOverlayPackage()
            if (foreground == YOUTUBE_PACKAGE && youtubeOverlay.hasVisibleWindows &&
                isTaskSwitcherShowing(rootInActiveWindow)) {
                enterTaskSwitcher(YOUTUBE_PACKAGE)
                return
            }
            if (foreground != null && foreground != YOUTUBE_PACKAGE) {
                // Accessibility overlays are above the shade on Samsung. Suspend their visual
                // windows, not the navigation state/geometry, and restore the existing windows
                // as soon as YouTube regains focus. Never curtain the system notification panel.
                if (foreground == "com.android.systemui" && isYouTubeNotificationShade()) {
                    youtubeOverlay.setSystemUiSuspended(true)
                    scheduleYouTubeOverlayForegroundCheck()
                    return
                }
                resetYouTubeProtection()
                if (foreground == "com.android.systemui") {
                    scheduleYouTubeOverlayForegroundCheck()
                }
                return
            }
            if (!ProtectionPreferences.isEnabled(this@AntiScrollService, ProtectedApp.YOUTUBE)) {
                resetYouTubeProtection()
                return
            }
            // YouTube's runtime permission prompt (notifications on first start)
            // is focused but unreadable: the service may read only the protected
            // apps, so focusedNonOverlayPackage() falls back to YouTube's active
            // window and the curtain stayed over the dialog. YouTube itself is
            // always readable, so a persisting unreadable focused app window is
            // another app. Hide the windows like for the notification shade and
            // restore them once YouTube has focus again.
            youtubeUnreadableForegroundChecks =
                if (focusedAppWindowUnreadable()) youtubeUnreadableForegroundChecks + 1 else 0
            if (YouTubeSurfacePolicy.suspendForUnreadableFocus(
                    youtubeOverlay.isSystemUiSuspended, youtubeUnreadableForegroundChecks)) {
                if (!youtubeOverlay.isSystemUiSuspended) {
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                        this@AntiScrollService, "youtube.foreign-focus", "pkg=unreadable")
                    SupportDiagnostics.record(this@AntiScrollService, SupportEvent.STEPPED_ASIDE,
                        mapOf("app" to "youtube", "why" to "other-app"))
                }
                youtubeOverlay.setSystemUiSuspended(true)
                scheduleYouTubeOverlayForegroundCheck()
                return
            }
            // YouTube's own pop-up (Premium offer, menu) is still open: stay hidden.
            if (youtubeOverlay.isSystemUiSuspended &&
                rootInActiveWindow?.let(::isYouTubePopUpOverMain) == true) {
                scheduleYouTubeOverlayForegroundCheck()
                return
            }
            youtubeOverlay.setSystemUiSuspended(false)
            // Reclassify even when only tab guards remain; a missing final event must not
            // leave a returned Home feed uncovered. The cheap focus probe above runs every
            // tick; the full classification only when no event-driven scan ran recently.
            // Uncovered while a feed tab is selected (search, notifications or a
            // watch page over Home/Subscriptions) is where a silent return to the
            // feed can happen: keep the original 200 ms cadence there.
            val feedReturnPossible = !youtubeOverlay.isCurtainVisible &&
                youtubeLastSelectedDestination in setOf(
                    YouTubeNavigationDestination.HOME, YouTubeNavigationDestination.SUBSCRIPTIONS)
            val idleRescanMs = if (feedReturnPossible) 200L else YOUTUBE_IDLE_RESCAN_MS
            if (youtubeCurtainState.isPending ||
                SystemClock.uptimeMillis() - youtubeLastScanFinishedAt >= idleRescanMs) {
                runYouTubeScan("foreground")
            }
            if (youtubeOverlay.hasVisibleWindows || youtubeCurtainState.isPending) {
                scheduleYouTubeOverlayForegroundCheck()
            }
        }
    }
    private val overlayForegroundCheck = object : Runnable {
        override fun run() {
            overlayForegroundCheckScheduled = false
            if (!instagramOverlay.hasVisibleWindows) return
            if (searchInputActive && requestSearchInputObservation()) {
                // The narrow reader already checks foreground/window identity.
                // Do not put this periodic IPC back onto the overlay thread.
                scheduleOverlayForegroundCheck()
                return
            }

            val activeRoot = rootInActiveWindow
            var activePkg = activeRoot?.packageName?.toString()
            if (ProtectionFlightRecorder.ENABLED && activePkg == INSTAGRAM_PACKAGE && activeRoot != null) {
                val rootBounds = Rect().also(activeRoot::getBoundsInScreen)
                if (!isFullscreenWindow(rootBounds) && rootBounds != lastWindowedInstagramRoot) {
                    ProtectionFlightRecorder.record(this@AntiScrollService, "instagram.root.windowed",
                        "root=$rootBounds display=${currentDisplayBounds()}")
                }
                lastWindowedInstagramRoot = rootBounds.takeUnless { isFullscreenWindow(it) }
            }
            if (activePkg == INSTAGRAM_PACKAGE && isTaskSwitcherShowing(activeRoot)) {
                enterTaskSwitcher(INSTAGRAM_PACKAGE)
                return
            }
            if (activePkg == null) {
                // The runtime permission prompt is focused but unreadable: the
                // service may read only the protected apps, so its root is null.
                // Instagram itself is always readable, so a focused application
                // window without a root that persists is another app.
                val focusedApp = windows.firstOrNull {
                    it.isFocused && it.type == AccessibilityWindowInfo.TYPE_APPLICATION
                }
                unreadableForegroundChecks =
                    if (focusedApp != null && focusedApp.root == null) unreadableForegroundChecks + 1 else 0
                if (InstagramSurfacePolicy.isUnreadableForeground(unreadableForegroundChecks)) {
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                        this@AntiScrollService, "instagram.foreign-focus", "pkg=unreadable")
                    SupportDiagnostics.record(this@AntiScrollService, SupportEvent.STEPPED_ASIDE,
                        mapOf("app" to "instagram", "why" to "other-app"))
                    unreadableForegroundChecks = 0
                    instagramUnreadableForeground = true
                    activePkg = UNREADABLE_FOREGROUND
                }
            } else {
                unreadableForegroundChecks = 0
            }
            if (activePkg == INSTAGRAM_PACKAGE) {
                InstagramSurfacePolicy.foreignFocusedPackage(activePkg, focusedNonOverlayPackage())
                    ?.let { foreign ->
                        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                            this@AntiScrollService, "instagram.foreign-focus", "pkg=$foreign")
                        activePkg = foreign
                    }
            }
            if (activePkg != null && activePkg != INSTAGRAM_PACKAGE) {
                if (retainInstagramCurtainUnderNotificationShade(activePkg, rootInActiveWindow)) return
                // Window IPC above can span the shade's entire closing frame.
                // Never tear down from the pre-probe SystemUI snapshot when
                // the application has already returned during that IPC.
                val returnedRoot = rootInActiveWindow
                if (InstagramNotificationShadePolicy.returnedDuringProbe(
                        instagramOverlay.isNotificationShadeSuspended,
                        returnedRoot?.packageName?.toString())) {
                    returnedRoot?.let(::resumeInstagramNotificationShade)
                    scheduleOverlayForegroundCheck()
                    return
                }
                suspendInstagramProtection(activePkg)
                trackPackageTransition("")
                return
            }
            if (!ProtectionPreferences.isEnabled(this@AntiScrollService, ProtectedApp.INSTAGRAM)) {
                hideInstagramProtection()
                return
            }

            rootInActiveWindow?.let(::resumeInstagramNotificationShade)

            scheduleOverlayForegroundCheck()
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        stopSearchInputObservation()
        searchInputBypassUntil = SystemClock.uptimeMillis() + 500L
        // Folding, unfolding or rotating can recreate Instagram's viewer
        // window under a new id; the allowed Reel moves with it once.
        if (instagramReelsSession.watching) {
            instagramReelWindowRebindUntil = SystemClock.uptimeMillis() + REEL_WINDOW_REBIND_MS
        }
        val display = currentDisplayBounds()
        SupportDiagnostics.record(this, SupportEvent.DISPLAY_CHANGED,
            mapOf("w" to display.width(), "h" to display.height(), "fold" to true))
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        AppText.init(this)
        instagramStructuralNodesRequested = null
        if (!AccessibilityConsent.isAccepted(this)) {
            Log.w(TAG, "Accessibility service disabled: in-app disclosure has not been accepted")
            disableSelf()
            return
        }
        InstagramProtectionMetrics.discardInterruptedSession(this)
        YouTubeProtectionMetrics.discardInterruptedSession(this)
        restoreInstagramWindowMemory()
        AccessibilityStreakPolicy.onServiceConnected(this)
        ProtectionStopWatch.markRunning(this)
        mainHandler.removeCallbacks(watchdogHeartbeat)
        watchdogHeartbeat.run()
        serviceShutdownNotified = false
        NotificationHelper.cancelShieldNotification(this, StatusNotificationPolicy.STOPPED_ID)
        NotificationHelper.cancelShieldNotification(this, 1003)

        NotificationHelper.showShieldStatusNotification(
            this,
            AppText.get(R.string.notif_protection_active_title),
            AppText.get(R.string.notif_protection_active_text),
            StatusNotificationPolicy.ACTIVE_ID
        )
        Log.d(TAG, "Accessibility protection connected")
        SupportDiagnostics.record(this, SupportEvent.SERVICE_CONNECTED)
        SupportDiagnostics.recordPreviousExit(this)
        SupportDiagnostics.watchSettings(this)
        if (ProtectionFlightRecorder.ENABLED) {
            @Suppress("DEPRECATION")
            val versionName = runCatching {
                packageManager.getPackageInfo(packageName, 0).versionName
            }.getOrNull().orEmpty().ifBlank { "unknown" }
            ProtectionFlightRecorder.startSession(this, versionName)
            ProtectionFlightRecorder.record(this, "service.connected",
                "root=${rootInActiveWindow?.packageName ?: "none"}")
        }

        // Auto-return: the user just flipped the service toggle from Settings. Inside
        // the background-start grace period (~10 s after leaving the app) this launch
        // succeeds on stock Android; if an OEM blocks it, the user navigates back as
        // before. Guarded by the foreground package so a boot-time or silent service
        // rebind never pops the app, and wrapped so a blocked launch can never break
        // the service.
        mainHandler.postDelayed({
            val foreground = rootInActiveWindow?.packageName?.toString() ?: return@postDelayed
            if (!foreground.startsWith("com.android.settings")) return@postDelayed
            try {
                startActivity(
                    Intent(this, MainActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                )
            } catch (e: Exception) {
                Log.d(TAG, "Auto-return to app not allowed: ${e.message}")
            }
        }, 250L)

        // Updating the APK or attaching UiAutomation can reconnect this service
        // while Instagram is already foreground. No new accessibility event is
        // guaranteed, so initialize protection from the current root as well.
        mainHandler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            when (root.packageName?.toString()) {
                INSTAGRAM_PACKAGE -> {
                    updateInstagramStructuralNodeAccess(true)
                    queueInstagramScan(0L)
                }
                YOUTUBE_PACKAGE -> queueYouTubeSurfaceScan(0L)
            }
        }, 120L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Lookups are only valid for the root instances fetched while handling
        // this one event; never carry their snapshot nodes into later work.
        val started = SystemClock.uptimeMillis()
        try { dispatchAccessibilityEvent(event) } finally {
            clearNodeLookupCache()
            val elapsed = SystemClock.uptimeMillis() - started
            if (ProtectionFlightRecorder.ENABLED && elapsed >= 24L && event != null) {
                ProtectionFlightRecorder.record(this, "a11y.slow",
                    "type=${event.eventType} pkg=${event.packageName} elapsedMs=$elapsed")
            }
            if (elapsed >= SUPPORT_SLOW_MS && event != null) {
                SupportDiagnostics.record(this, SupportEvent.SLOW,
                    mapOf("ms" to elapsed, "app" to supportAppName(event.packageName?.toString())))
            }
        }
    }

    private fun dispatchAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !AccessibilityConsent.isAccepted(this)) return
        maybeRecordHeartbeat()

        val reportedPackage = ProtectedApp.canonicalPackage(event.packageName?.toString())
        if (reportedPackage != null && event.windowId >= 0) {
            windowPackages[event.windowId] = reportedPackage
        }
        // Open in Messages acts only when Instagram opens fresh, in a window not
        // seen before; returning to a known window is a resume (see the policy).
        val instagramWindowFresh = reportedPackage == INSTAGRAM_PACKAGE &&
            instagramWindowMemory.add(event.windowId)
        if (instagramWindowFresh) saveInstagramWindowMemory()
        // A live Recents card keeps publishing the app's own events; they must
        // not re-mount curtains over the switcher. The return check resumes.
        if (taskSwitcherOwner != null &&
            (reportedPackage == INSTAGRAM_PACKAGE || reportedPackage == YOUTUBE_PACKAGE)) return
        if (ProtectionFlightRecorder.ENABLED && reportedPackage in setOf(
                INSTAGRAM_PACKAGE, YOUTUBE_PACKAGE, TIKTOK_PACKAGE, "com.android.systemui")) {
            val traceNow = SystemClock.uptimeMillis()
            val highValueEvent = event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                traceNow - lastFlightContentEventAt >= 80L
            if (highValueEvent) {
                if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                    lastFlightContentEventAt = traceNow
                }
                val packageKey = when (reportedPackage) {
                    INSTAGRAM_PACKAGE -> "instagram"
                    YOUTUBE_PACKAGE -> "youtube"
                    TIKTOK_PACKAGE -> "tiktok"
                    else -> "systemui"
                }
                ProtectionFlightRecorder.record(this, "a11y.event",
                    "pkg=$packageKey type=${event.eventType} window=${event.windowId} " +
                        "ageMs=${(SystemClock.uptimeMillis() - event.eventTime).coerceAtLeast(0L)} " +
                        "lastPkg=${when (lastPackage) {
                            INSTAGRAM_PACKAGE -> "instagram"
                            YOUTUBE_PACKAGE -> "youtube"
                            TIKTOK_PACKAGE -> "tiktok"
                            else -> "other"
                        }} ig=$lastInstagramScreen yt=$youtubeObservedScreen" +
                        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)
                            " class=${event.className}"
                        else "")
            }
        }
        if (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0 &&
            reportedPackage == INSTAGRAM_PACKAGE && event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            InstagramNotificationShadePolicy.isProtectedFeedOrigin(lastInstagramScreen)) {
            Log.d(TAG, "IG_FEED_CLICK_DELIVERY window=${event.windowId} " +
                "eventAt=${event.eventTime} receivedAt=${SystemClock.uptimeMillis()}")
        }
        if (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0 &&
            reportedPackage == INSTAGRAM_PACKAGE && instagramOverlay.visibleProfileBounds() != null &&
            event.eventType in setOf(AccessibilityEvent.TYPE_VIEW_CLICKED,
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED, AccessibilityEvent.TYPE_WINDOWS_CHANGED)) {
            // No node/source lookup here: measure delivery before foreground IPC.
            Log.d(TAG, "IG_PROFILE_RETURN_EVENT type=${event.eventType} window=${event.windowId} " +
                "eventAt=${event.eventTime} receivedAt=${SystemClock.uptimeMillis()}")
        }
        // The header collapse of a profile fling publishes only content
        // changes (no scroll event) and a still profile publishes none, so
        // these run the anchor probe before any coalescing or scan below.
        if (reportedPackage == INSTAGRAM_PACKAGE &&
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            lastInstagramScreen == InstagramScreen.PROFILE) {
            kickProfileGeometryWatch(urgent = true)
        }
        // A native account-row tap can beat the search proxy during a cold
        // return or mode change. Arm the existing profile handoff before other
        // applications' window queries delay the first profile frame.
        if (reportedPackage == INSTAGRAM_PACKAGE &&
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            armInstagramNativeAccountEntry(event)) return
        // TYPE_WINDOWS_CHANGED for our own accessibility overlays can have the
        // Instagram root active. Never reinterpret that event as Instagram.
        if (reportedPackage == this.packageName) return
        // A mounted curtain was re-verified within one identical-window content
        // event of another: queueing another full scan for video progress ticks,
        // story timers and like-state changes costs the main thread 8+ remote
        // queries per event with no new decision. Clicks, state and window
        // events always retain normal routing.
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            SystemClock.uptimeMillis() - setCurtainVerifiedAtMs < 64L &&
            event.windowId == setCurtainVerifiedWindowId &&
            instagramOverlay.visibleCurtain() != null) return
        // Surface-left precover: search results and notifications are allowed
        // screens whose leaving transition exposes a protected feed. Their
        // markers disappear at the very start of the animation, well before
        // classification resolves, so the destination curtain is pre-mounted
        // from that first structural event (system Back gestures included).
        if (reportedPackage == INSTAGRAM_PACKAGE &&
            event.eventType in setOf(
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED) &&
            surfaceLeftProbeApplies()) {
            // Coalesced: one pending probe however many events arrive. Run per
            // event, its two remote queries (16-80 ms each while Instagram
            // draws) queued Notifications' ~10 events a second up, so the Back
            // that returns to Home was handled 0.8-1.1 s late and the feed
            // showed for up to 1.5 s (Galaxy S23, Instagram 454).
            scheduleSurfaceLeftProbe()
        }
        if (instagramProfileIngress.coalesceStructuralEvent(
                instagramEvent = reportedPackage == INSTAGRAM_PACKAGE,
                sameTrackedApp = lastPackage == INSTAGRAM_PACKAGE,
                structuralEvent = event.eventType in setOf(
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                    AccessibilityEvent.TYPE_WINDOWS_CHANGED))) {
            // The account-entry owner already verified the foreground package.
            // Every scan still checks the active root/enabled setting; real
            // SystemUI/other-app events and clicks retain normal routing.
            // Re-querying all focused windows for each animation event can
            // occupy the main looper before the curtain's first draw callback.
            queueInstagramScan(if (instagramProfileIngress.awaitingCurtainDraw) 48L else 16L)
            return
        }
        val shadeReturnRoot = if (InstagramNotificationShadePolicy.useCurrentInstagramRoot(
                reportedSystemUi = reportedPackage == "com.android.systemui",
                hasInstagramSession = instagramOverlay.isNotificationShadeSuspended ||
                    lastPackage == INSTAGRAM_PACKAGE)) rootInActiveWindow else null
        val packageName = if ((event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
                shadeReturnRoot != null) &&
            (shadeReturnRoot ?: rootInActiveWindow)?.packageName?.toString() == INSTAGRAM_PACKAGE) {
            INSTAGRAM_PACKAGE
        } else reportedPackage ?: return
        if (packageName == this.packageName) return
        if (retainInstagramCurtainUnderNotificationShade(packageName)) return
        if (packageName == INSTAGRAM_PACKAGE && instagramOverlay.isNotificationShadeSuspended) {
            // The resume helper is a no-op unless the shade suspended the
            // curtain; do not pay a remote root query for every event.
            rootInActiveWindow?.let(::resumeInstagramNotificationShade)
        }
        updateInstagramStructuralNodeAccess(packageName == INSTAGRAM_PACKAGE)
        val returningToInstagram = packageName == INSTAGRAM_PACKAGE && lastPackage != INSTAGRAM_PACKAGE
        val returningToYouTube = packageName == YOUTUBE_PACKAGE && lastPackage != YOUTUBE_PACKAGE
        // Suspend once when Instagram is left, not for every YouTube/TikTok
        // event: each call also queued a delayed recovery probe with a remote
        // root query, so a stream of events stacked dozens of them on the
        // main looper and delayed every other app's protection.
        if (packageName != INSTAGRAM_PACKAGE && packageName != this.packageName &&
            (lastPackage == INSTAGRAM_PACKAGE || instagramOverlay.hasVisibleWindows)) {
            suspendInstagramProtection(packageName)
        }
        // The focused-window probe is two remote calls. It only matters while
        // YouTube protection still has state to reset or the event did not
        // come from a tracked app; Instagram/TikTok events paid it every time.
        val youtubeNeedsForegroundProbe = packageName != YOUTUBE_PACKAGE &&
            (lastPackage == YOUTUBE_PACKAGE || youtubeOverlay.hasVisibleWindows ||
                youtubeOverlay.isSystemUiSuspended ||
                (packageName != INSTAGRAM_PACKAGE && packageName != TIKTOK_PACKAGE))
        val activeRootPackage = if (youtubeNeedsForegroundProbe) {
            focusedNonOverlayPackage()
                ?: rootInActiveWindow?.packageName?.toString()
        } else null
        if (packageName != YOUTUBE_PACKAGE && packageName != this.packageName &&
            activeRootPackage != YOUTUBE_PACKAGE
        ) {
            if (activeRootPackage == "com.android.systemui" && isYouTubeNotificationShade()) {
                youtubeOverlay.setSystemUiSuspended(true)
                scheduleYouTubeOverlayForegroundCheck()
            } else {
                resetYouTubeProtection()
            }
        }
        trackPackageTransition(packageName)
        if (returningToYouTube && ProtectionPreferences.isEnabled(this, ProtectedApp.YOUTUBE)) {
            scheduleYouTubeOverlayForegroundCheck()
        }
        if (instagramWindowFresh) {
            // Decided by the window alone: the service gets no launcher events,
            // and leaving Instagram from an uncovered screen (Messages) is never
            // seen, so "returning from another app" misses real launches.
            val armed = InstagramOpenInMessagesPolicy.armsOnEntry(
                settingOn = ProtectionPreferences.opensInstagramInMessages(this),
                protectionOn = ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM),
                openedFresh = true)
            instagramOpenInMessagesArmedAt = if (armed) SystemClock.uptimeMillis() else 0L
            instagramOpenInMessagesWindow = event.windowId
            mainHandler.removeCallbacks(instagramQuickHomeCheck)
            if (armed) mainHandler.postAtFrontOfQueue(instagramQuickHomeCheck)
        }
        if (returningToInstagram) {
            // The first Instagram event can arrive while SystemUI is still the
            // active accessibility root. Keep the request pending until an
            // actual Instagram root is available in scanInstagram().
            instagramResumePending = true
            beginInstagramResumeProtection()
        }

        when (packageName) {
            INSTAGRAM_PACKAGE -> handleInstagram(event)
            TIKTOK_PACKAGE -> handleTikTok(event)
            YOUTUBE_PACKAGE -> handleYouTube(event)
            else -> {
                if (activeRootPackage == YOUTUBE_PACKAGE) {
                    handleYouTube(event)
                }
            }
        }
    }

    private val scanSchedule = InstagramScanSchedule()
    private var lastHeartbeatMs = 0L
    private var lastFlightContentEventAt = 0L
    private var lastFlightScanAt = 0L
    private var lastFlightScanSignature = ""
    private var lastFlightSignalsSignature = ""

    // Debug only: the visible ids behind each distinct classification, so a
    // screen in any UI language can be identified from the flight log. Titles
    // are never written: a chat or profile header shows a person's name.
    private fun recordInstagramSignals(signals: InstagramUiSignals) {
        val screen = InstagramProtectionEngine.classify(
            signals.copy(sourceIds = emptySet(), sourceLabels = emptySet(), sourceTab = null))
        val signature = "$screen|${signals.ids.sorted().joinToString(",")}"
        if (signature == lastFlightSignalsSignature) return
        lastFlightSignalsSignature = signature
        ProtectionFlightRecorder.record(this, "instagram.signals",
            "screen=$screen tabs=${signals.selectedTabs} back=${signals.hasBackNavigation} " +
                "search=${signals.searchFieldFocused} tiles=${signals.idlessMediaTiles}")
        signals.ids.sorted().joinToString(",").chunked(800).forEach { part ->
            ProtectionFlightRecorder.record(this, "instagram.signals.ids", part)
        }
        // Language audit: the only titles still read are Saved's untranslated
        // filter labels; flag any decision that would differ without them.
        // Only the two results are kept, never the titles themselves.
        val neutral = InstagramProtectionEngine.classify(signals.copy(titles = emptySet(),
            sourceIds = emptySet(), sourceLabels = emptySet(), sourceTab = null))
        if (neutral != screen) ProtectionFlightRecorder.record(this, "instagram.textdep",
            "screen=$screen withoutTitles=$neutral")
    }

    /**
     * One scan asks the same view id up to a dozen times across the fast
     * surface probe, geometry calculation and layer checks. Every distinct
     * query is a separate remote traversal, so results are memoized per root
     * instance for the duration of one callback chain. The key holds the root
     * reference itself: a fresh rootInActiveWindow instance is fetched for
     * every scan, so cross-scan staleness is impossible without manual clears.
     */
    /**
     * AccessibilityNodeInfo.equals() compares only the window and source node
     * ids, so every fresh rootInActiveWindow instance of the same window is
     * "equal" to the previous one. Keying the cache by that equality silently
     * reused snapshot nodes (stale visibility and bounds) across scans, event
     * handlers and foreground checks. The key therefore uses reference
     * identity of the root instance that one callback chain fetched.
     */
    private class NodeLookupKey(val root: AccessibilityNodeInfo, val id: String) {
        override fun equals(other: Any?): Boolean =
            other is NodeLookupKey && other.root === root && other.id == id
        override fun hashCode(): Int = System.identityHashCode(root) * 31 + id.hashCode()
    }
    private val nodeLookupCache = HashMap<NodeLookupKey, List<AccessibilityNodeInfo>>(64)

    private fun cachedNodeLookup(root: AccessibilityNodeInfo, id: String): List<AccessibilityNodeInfo> {
        val key = NodeLookupKey(root, id)
        nodeLookupCache[key]?.let { return it }
        val started = SystemClock.uptimeMillis()
        val result = runCatching { root.findAccessibilityNodeInfosByViewId(id) }
            .getOrNull().orEmpty()
        if (ProtectionFlightRecorder.ENABLED) {
            val elapsed = SystemClock.uptimeMillis() - started
            if (elapsed >= 12L) ProtectionFlightRecorder.record(this, "lookup.slow",
                "id=${id.substringAfter(":id/")} elapsedMs=$elapsed n=${result.size}")
        }
        if (nodeLookupCache.size >= 96) nodeLookupCache.clear()
        nodeLookupCache[key] = result
        return result
    }

    private fun clearNodeLookupCache() {
        if (nodeLookupCache.isNotEmpty()) nodeLookupCache.clear()
    }

    private fun igVisible(root: AccessibilityNodeInfo, id: String): Boolean =
        cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id").any { it.isVisibleToUser }

    private fun igSelected(root: AccessibilityNodeInfo, id: String): Boolean =
        cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
            .any { it.isVisibleToUser && isSelectedRecursive(it, 2) }

    // Surface-left precover (Notifications, Explore search, Saved). The probe
    // reads the current root only, never the event, so one pending run covers
    // any number of events. It runs at most once per SURFACE_LEFT_PROBE_GAP_MS
    // after the previous run ended.
    private fun surfaceLeftProbeApplies(): Boolean =
        !instagramProfileIngress.pending && !instagramProfileIngress.awaitingCurtainDraw &&
            instagramOverlay.visibleCurtain() == null &&
            (lastInstagramScreen == InstagramScreen.SEARCH_RESULTS ||
                lastInstagramScreen == InstagramScreen.SAVED_COLLECTION ||
                lastInstagramScreen == InstagramScreen.NOTIFICATIONS)

    private var surfaceLeftProbePending = false
    private var surfaceLeftProbeEndedAt = 0L
    private val surfaceLeftProbe = Runnable {
        surfaceLeftProbePending = false
        try {
            if (surfaceLeftProbeApplies()) runSurfaceLeftProbe()
        } finally {
            surfaceLeftProbeEndedAt = SystemClock.uptimeMillis()
        }
    }

    private fun scheduleSurfaceLeftProbe() {
        if (surfaceLeftProbePending) return
        surfaceLeftProbePending = true
        val wait = (surfaceLeftProbeEndedAt + SURFACE_LEFT_PROBE_GAP_MS - SystemClock.uptimeMillis())
            .coerceAtLeast(0L)
        mainHandler.postDelayed(surfaceLeftProbe, wait)
    }

    private fun runSurfaceLeftProbe() {
        when (lastInstagramScreen) {
            // Only a search opened from Explore leaves onto Explore. Other
            // search lists (Close friends, settings) return to safe pages.
            InstagramScreen.SEARCH_RESULTS -> if (instagramExploreSearchSeen) {
                val searchRoot = rootInActiveWindow
                    ?.takeIf { it.packageName?.toString() == INSTAGRAM_PACKAGE }
                // The editor check comes first: it is visible for every
                // event while the user stays on search, so one lookup ends
                // the probe instead of six (~150 ms per event measured).
                val editorVisible = searchRoot != null &&
                    igVisible(searchRoot, "action_bar_search_edit_text")
                // Instagram 454 gives Explore's own search bar the same id,
                // so after Back the editor never disappears and the grid
                // stayed uncovered until the 0.7 s scan (Galaxy S23). The
                // Explore header without a Back control is Explore itself:
                // the search page has Back and no Explore header.
                val returnedToExplore = searchRoot != null && editorVisible &&
                    igVisible(searchRoot, "explore_action_bar") &&
                    !igVisible(searchRoot, "action_bar_button_back")
                if (searchRoot != null && (returnedToExplore || (!editorVisible &&
                    !hasFastDirectSafeReturn(searchRoot) &&
                    !hasVisibleProfileHeaderMarkers(searchRoot) &&
                    !igVisible(searchRoot, "row_search_user_container") &&
                    !igVisible(searchRoot, "search_row") && !igVisible(searchRoot, "echo_text")))) {
                    clearInstagramResumeProtection()
                    currentInstagramWindowId = searchRoot.windowId
                    stopSearchInputObservation()
                    searchInputBypassUntil = SystemClock.uptimeMillis() + 500L
                    supportCurtainReason = "back"
                    showInstagramCurtain(
                        calculateExploreBounds(searchRoot, instagramWindowBounds(searchRoot)),
                        InstagramScreen.EXPLORE)
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                        this, "instagram.search.back",
                        if (returnedToExplore) "precover=explore-header" else "precover=editor-gone")
                    scanAfterPrecoverDraw()
                }
            }
            InstagramScreen.SAVED_COLLECTION -> {
                // Balanced allows Saved, but Back returns to the feed whose
                // bookmark opened it; cover that feed on its first frames.
                precoverCollectionReturn()
            }
            InstagramScreen.NOTIFICATIONS -> {
                // Notifications are an allowed native surface; opening a
                // row can publish a post/Reel in another Instagram window,
                // so nothing is pre-covered from the row tap. Leaving with
                // Back is different: on the first event after it, the Home
                // header is already visible in the active root while the
                // notification list and its Back control are gone (on the
                // notification page neither header is visible). The scan
                // recognised Home ~550 ms later, long enough to open a
                // Story from the uncovered tray in Strict.
                val probeNow = SystemClock.uptimeMillis()
                if (!instagramExitInProgress && probeNow >= instagramNotificationContentLaunchUntil) {
                    val homeRoot = rootInActiveWindow
                    if (homeRoot != null && homeRoot.packageName?.toString() == INSTAGRAM_PACKAGE &&
                        igVisible(homeRoot, "main_feed_action_bar") &&
                        !igVisible(homeRoot, "newsfeed_you") &&
                        !igVisible(homeRoot, "action_bar_button_back")) {
                        clearInstagramResumeProtection()
                        currentInstagramWindowId = homeRoot.windowId
                        val bounds = calculateHomeFeedBounds(homeRoot, instagramWindowBounds(homeRoot))
                        clampCurtainBottomToNavigation(homeRoot, bounds)
                        supportCurtainReason = "back"
                        showInstagramCurtain(bounds, InstagramScreen.HOME_FEED)
                        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                            this, "instagram.notifications.back", "precover=home-header")
                        // A scan right away held the main thread ~600 ms before
                        // the curtain's first frame; scan once it has drawn.
                        scanAfterPrecoverDraw()
                    }
                }
            }
            else -> Unit
        }
    }

    private fun maybeRecordHeartbeat(now: Long = System.currentTimeMillis()) {
        if (now - lastHeartbeatMs >= 60_000L) {
            lastHeartbeatMs = now
            AccessibilityStreakPolicy.recordHeartbeat(this, now)
        }
    }
    private var queuedClick: AccessibilityEvent? = null
    private var directNavigationUntil = 0L
    private var directNavigationSourceWindowId = -1

    // Profile tab tap in Balanced (InstagramTabReleasePolicy): the feed curtain
    // is lifted on the tap; until the profile is verified, scans that still see
    // the old feed wait instead of covering it again.
    private var instagramTabReleaseUntil = 0L
    private var instagramTabReleaseClickAt = 0L
    private val instagramTabRecoverCover = Runnable { recoverTabReleaseCover() }

    // The curtain is lifted when the profile is in the tree, not on the tap
    // itself: a profile Instagram still has to build must not show the old
    // feed for a frame. One lookup per frame instead of the full scan.
    private val instagramTabReleaseProbe = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            if (now >= instagramTabReleaseUntil) return
            val root = rootInActiveWindow
            if (root != null && root.packageName?.toString() == INSTAGRAM_PACKAGE &&
                (igVisible(root, "profile_header_container") || igVisible(root, "profile_tabs_container"))) {
                clearNodeLookupCache()
                instagramOverlay.hide()
                mainHandler.postDelayed(instagramTabRecoverCover, InstagramTabReleasePolicy.RECOVER_MS)
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                    this@AntiScrollService, "instagram.tab.release",
                    "tab=PROFILE afterClickMs=${now - instagramTabReleaseClickAt}")
                return
            }
            clearNodeLookupCache()
            // Not there yet: look again next frame; the regular scan still
            // runs and lifts the curtain on the verified profile either way.
            if (now - instagramTabReleaseClickAt < InstagramTabReleasePolicy.PROBE_MS) {
                mainHandler.postDelayed(this, 16L)
            }
        }
    }

    // A tap on Explore's search field: the Explore curtain lifts as soon as the
    // focused search page is there, by the same evidence the search reader
    // uses (focused field, Search's own Back, no keyword tabs). Waiting for the
    // click handling and the reader kept it over the search page for ~0.4 s.
    private var instagramSearchReleaseClickAt = 0L
    private val instagramSearchReleaseProbe = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            if (instagramOverlay.visibleCurtain()?.first != InstagramScreen.EXPLORE) return
            val root = rootInActiveWindow
            val focused = root != null && root.packageName?.toString() == INSTAGRAM_PACKAGE &&
                isFocusedExploreSearch(root)
            clearNodeLookupCache()
            if (focused) {
                instagramOverlay.hide()
                queueInstagramScan(0L)
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                    this@AntiScrollService, "instagram.search.release",
                    "afterClickMs=${now - instagramSearchReleaseClickAt}")
                return
            }
            if (now - instagramSearchReleaseClickAt < SEARCH_RELEASE_PROBE_MS) {
                mainHandler.postDelayed(this, 16L)
            }
        }
    }

    private fun isFocusedExploreSearch(root: AccessibilityNodeInfo): Boolean {
        val focus = runCatching { root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }.getOrNull()
            ?: return false
        if (focus.packageName?.toString() != INSTAGRAM_PACKAGE || focus.windowId != root.windowId ||
            !focus.isVisibleToUser || !focus.isFocused ||
            focus.viewIdResourceName != "$INSTAGRAM_PACKAGE:id/action_bar_search_edit_text" ||
            focus.className?.toString()?.contains("EditText", ignoreCase = true) != true) return false
        // Keyword result tabs carry the protected recommendation grid.
        if (cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/search_tab_bar_layout").isNotEmpty()) return false
        return igVisible(root, "action_bar_button_back")
    }

    private fun recoverTabReleaseCover() {
        if (SystemClock.uptimeMillis() >= instagramTabReleaseUntil) return
        // The profile (or any other page) was verified meanwhile.
        if (lastInstagramScreen != InstagramScreen.HOME_FEED &&
            lastInstagramScreen != InstagramScreen.EXPLORE &&
            lastInstagramScreen != InstagramScreen.UNKNOWN) return
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        instagramTabReleaseUntil = 0L
        val retained = lastVerifiedInstagramCurtain?.takeIf { (screen, _) ->
            InstagramSurfacePolicy.needsCurtain(screen) && instagramOverlay.visibleCurtain() == null
        } ?: return
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.recover.cover", "screen=${retained.first} reason=tab-release")
        supportCurtainReason = "restore"
        showInstagramCurtain(Rect(retained.second), retained.first)
        queueInstagramScan(0L)
    }

    /** The bottom tab a click came from: the tab itself or a child of it. */
    private fun tappedInstagramTab(source: AccessibilityNodeInfo?): InstagramTab? {
        var node = source
        repeat(3) {
            val current = node ?: return null
            tabForId(compactId(current.viewIdResourceName))?.let { return it }
            node = current.parent
        }
        return null
    }

    /**
     * Re-cover safety net for the fast DM release: if the messaging intent
     * never produced a verified inbox inside the recovery window, put the last
     * verified feed rectangle back on screen so a mistap cannot leave a
     * protected feed exposed while Instagram finishes its tree swap.
     */
    private val instagramDirectRecoverCover = object : Runnable { override fun run() = recoverDirectCover(this) }

    private fun recoverDirectCover(self: Runnable) {
        if (directNavigationSourceWindowId == -1) return
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        if (SystemClock.uptimeMillis() >= directNavigationUntil) return
        // Instagram can open a one-time promo dialog over the new inbox. It
        // hides the inbox ids, so the inbox cannot be verified yet; covering
        // now put "Feed is protected" over DM and the dialog (seen on device).
        // Wait while the dialog is up: it only appears over the DM
        // destination, and the regular scan still covers a real feed.
        if (InstagramSurfacePolicy.isInstagramDialog(
                igVisible(root, "dialog_container"), igVisible(root, "igds_promo_dialog_headline"))) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                this@AntiScrollService, "instagram.recover.cover", "deferred=dialog")
            mainHandler.postDelayed(self, DIRECT_RECOVER_DIALOG_RECHECK_MS)
            return
        }
        val retained = lastVerifiedInstagramCurtain
            ?.takeIf { (screen, _) ->
                InstagramSurfacePolicy.needsCurtain(screen) &&
                    instagramOverlay.visibleCurtain() == null
            }
        val homeVerified = lastInstagramScreen == InstagramScreen.HOME_FEED ||
            lastInstagramScreen == InstagramScreen.EXPLORE ||
            lastInstagramScreen == InstagramScreen.UNKNOWN
        if (retained != null && homeVerified) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                this@AntiScrollService, "instagram.recover.cover",
                "screen=${retained.first} directWindowId=$directNavigationSourceWindowId")
            supportCurtainReason = "restore"
            showInstagramCurtain(Rect(retained.second), retained.first)
        }
    }
    private var strictProfilePrecoverAtMs = 0L
    private var setCurtainVerifiedAtMs = 0L
    private var setCurtainVerifiedWindowId = -1
    private val instagramScan = Runnable {
        scanSchedule.clear()
        // The coalesced surface-left probe waits up to SURFACE_LEFT_PROBE_GAP_MS
        // after its last run. On a busy Notifications page a full scan due in
        // that gap ran first (~650 ms) and the Back to Home was covered only
        // by that scan, ~1.4 s late (Galaxy S23, Strict). A scan queued before
        // the Back's first event missed it the same way. Run it first; its
        // first lookup is the one the scan starts with anyway (cached), and a
        // precover then holds this scan until its curtain has drawn.
        if (surfaceLeftProbePending || surfaceLeftProbeApplies()) {
            mainHandler.removeCallbacks(surfaceLeftProbe)
            surfaceLeftProbe.run()
        }
        val precoverRemaining = precoverDrawPendingUntil - SystemClock.uptimeMillis()
        if (precoverRemaining > 0L) {
            queueInstagramScan(precoverRemaining)
            return@Runnable
        }
        // A curtain lifted just now is still on screen until its relayout
        // frame runs; a scan here would keep it there for the whole scan.
        if (SystemClock.uptimeMillis() < instagramOverlay.parkCommitPendingUntil) {
            queueInstagramScan(8L)
            return@Runnable
        }
        val storyLaunchRemaining = instagramStoryLaunchUntil - SystemClock.uptimeMillis()
        if (storyLaunchRemaining > 0L) {
            // A Strict Story launch is starting: Instagram's UI thread answers
            // no tree query for 1-3 s and a scan would block the main looper,
            // delaying the very window event that triggers the exit.
            queueInstagramScan(minOf(120L, storyLaunchRemaining + 16L))
            return@Runnable
        }
        val click = queuedClick
        queuedClick = null
        val started = SystemClock.uptimeMillis()
        try {
            // On a covered Home a tap keeps the full scan: its click context
            // (which tab, which control) belongs to the official path.
            val readerTakesScan = (click == null || lastInstagramScreen != InstagramScreen.HOME_FEED) &&
                requestSearchInputObservation()
            if (!readerTakesScan) scanInstagram(click)
        } finally {
            @Suppress("DEPRECATION")
            click?.recycle()
            clearNodeLookupCache()
            val elapsed = SystemClock.uptimeMillis() - started
            if (ProtectionFlightRecorder.ENABLED) {
                val curtain = instagramOverlay.visibleCurtain()
                val signature = "$lastInstagramScreen/$currentInstagramWindowId/" +
                    "${curtain?.first ?: "none"}/${curtain?.second ?: "none"}"
                val traceNow = SystemClock.uptimeMillis()
                if (elapsed >= 24L || signature != lastFlightScanSignature ||
                    traceNow - lastFlightScanAt >= 500L) {
                    lastFlightScanAt = traceNow
                    lastFlightScanSignature = signature
                    ProtectionFlightRecorder.record(this, "instagram.scan",
                        "elapsedMs=$elapsed state=$lastInstagramScreen window=$currentInstagramWindowId " +
                            "curtain=${curtain?.first ?: "none"} bounds=${curtain?.second ?: "none"}")
                }
            }
            if (elapsed > 100L) Log.w(TAG, "IG_SLOW_SCAN elapsedMs=$elapsed")
        }
    }
    private val instagramResumeRescan = object : Runnable {
        override fun run() {
            if (!instagramResumeGeometryGate.isActive) return
            if (instagramResumeGeometryGate.expired(SystemClock.uptimeMillis())) {
                // The retained curtain stays; event-driven scans continue.
                clearInstagramResumeProtection()
                return
            }
            queueInstagramScan(0L)
            if (instagramResumeGeometryGate.isActive) {
                mainHandler.postDelayed(this, INSTAGRAM_RESUME_RESCAN_MS)
            }
        }
    }
    private fun queueInstagramScan(delay: Long) {
        if (!scanSchedule.request(SystemClock.uptimeMillis(), delay)) return
        mainHandler.removeCallbacks(instagramScan)
        mainHandler.postDelayed(instagramScan, delay)
    }

    // After returning from an allowed surface (or on entry) Instagram rebuilds the
    // profile fragment and the pager measures partial or offset for a while - sometimes
    // silently, with no further events. This loop drives the curtain to its settled
    // geometry on its own cadence: it waits through the transition, mounts as soon as
    // the gate accepts, then keeps re-measuring until the mounted rect repeats
    // identically twice, so the tail of the slide animation cannot leave a gap.
    private val profileCurtainEnsure = object : Runnable {
        override fun run() {
            if (!profileCurtainEnsureActive) return
            if (!instagramProfilePostsBlocked()) {
                stopProfileCurtainEnsure()
                releaseAllowedProfileSurface()
                return
            }
            val root = rootInActiveWindow
            if (root == null || root.packageName?.toString() != INSTAGRAM_PACKAGE ||
                !ProtectionPreferences.isEnabled(this@AntiScrollService, ProtectedApp.INSTAGRAM)
            ) {
                stopProfileCurtainEnsure()
                return
            }
            if (profileGeometryWatchActive && profileWatchedFullCover &&
                instagramProfilePostsBlocked()) {
                // The strict-profile geometry watch holds the whole collapsible
                // body during a collapse. Re-mounting the row-based curtain
                // here would cut its top and flash; defer to the watch.
                profileCurtainEnsureAttempts++
                if (profileCurtainEnsureAttempts > 60) stopProfileCurtainEnsure()
                mainHandler.postDelayed(this, 96L)
                return
            }
            val windowBounds = instagramWindowBounds(root)
            val now = SystemClock.uptimeMillis()
            if (now < profileAllowedDepartureUntil) {
                // A verified departure is owned by the transition scanner. Do not
                // recreate the outgoing grid while that scanner is releasing it.
                mainHandler.postDelayed(this, profileAllowedDepartureUntil - now)
                return
            }
            if (hasVisibleProfileNativeSheet(root) || hasVisibleAboutAccountSurface(root)) {
                armInstagramProfileReturn(root, now)
                stopProfileCurtainEnsure()
                return
            }
            val bounds = profileGridBounds(root, windowBounds)
            if (bounds == null) {
                if (!hasVisibleProfileHeaderMarkers(root)) {
                    stopProfileCurtainEnsure()
                    return
                }
                // The pager node is not in the tree yet (Instagram rebuilding the
                // fragment); keep waiting for it at this cadence.
                profileCurtainEnsureAttempts++
                if (profileCurtainEnsureAttempts > PROFILE_ENSURE_MAX_TICKS) {
                    stopProfileCurtainEnsure()
                    return
                }
                mainHandler.postDelayed(this, 64L)
                return
            }
            mountEnsureProfileCurtain(root, windowBounds, bounds)
            // A stable ACTUAL rect is not enough on its own: while the resume geometry
            // gate is active it keeps re-applying retained bounds, so a frozen partial
            // curtain would look "stable". Keep feeding samples until the gate clears.
            if (profileCurtainEnsureStableStreak >= 2 &&
                !instagramResumeGeometryGate.isActive
            ) {
                stopProfileCurtainEnsure()
                return
            }
            profileCurtainEnsureAttempts++
            mainHandler.postDelayed(this, 96L)
        }
    }

    private fun mountEnsureProfileCurtain(
        root: AccessibilityNodeInfo,
        windowBounds: Rect,
        bounds: Rect
    ) {
        profileWindowId = root.windowId
        profileScrollFloor = calculateProfileScrollFloor(root, windowBounds)
        bounds.top = profileScrollCover.measure(
            bounds.top, profileScrollFloor, SystemClock.uptimeMillis())
        observeInstagramScreen(InstagramScreen.PROFILE, root.windowId)
        applyStrictProfileCurtain(root, windowBounds, bounds)
        // Fingerprint what the overlay ACTUALLY shows: the resume geometry gate inside
        // showInstagramCurtain can substitute retained bounds, and comparing against the
        // requested rect would declare victory while a partial curtain stays mounted.
        val actual = instagramOverlay.visibleCurtain()?.second ?: bounds
        val fingerprint = actual.flattenToString()
        profileCurtainEnsureStableStreak =
            if (fingerprint == lastProfileCurtainFingerprint) {
                profileCurtainEnsureStableStreak + 1
            } else 1
        lastProfileCurtainFingerprint = fingerprint
    }

    private fun armProfileCurtainEnsure() {
        if (profileCurtainEnsureActive) return
        profileCurtainEnsureActive = true
        profileCurtainEnsureAttempts = 0
        profileCurtainEnsureStableStreak = 0
        mainHandler.postDelayed(profileCurtainEnsure, 48L)
    }

    /**
     * Strict-profile geometry watch. Event delivery from Instagram cannot keep
     * up with a collapsing header (scroll events often carry no delta at all),
     * so this pro-active loop owns the curtain while it is mounted: it measures
     * the grid top at a fixed cadence, covers the whole collapsible body for as
     * long as any motion lasts, and releases to the exact grid rectangle once
     * the geometry repeats stably. A tap aimed through the moving header lands
     * on the curtain instead of a sliver, and no stale hold can pin the cover
     * over the whole page after the scroll ends.
     */
    private var profileGeometryWatchActive = false
    private var profileWatchedCoverTop: Int? = null
    private var profileWatchedStableSamples = 0
    private var profileWatchedLastChangeAt = 0L
    private var profileWatchedFullCover = false
    private var profileWatchedFullCoverStartedAt = 0L
    /**
     * Last travelled direction of the row: +1 = content expanded downward
     * (header opening back), -1 = content collapsed upward, 0 unknown. An
     * anchor loss happens in both directions, but only a collapse can move
     * grid content above the mounted edge; an expansion moves content away
     * from it, so the anchor loss there keeps the last verified cover
     * instead of flashing the whole body.
     */
    private var profileWatchedLastDirection = 0
    private var profileWatchTick = 0

    /**
     * Strict-profile geometry watch.
     *
     * Event delivery from Instagram cannot follow the collapsing header (its
     * scroll events often carry no delta at all), so while the curtain is
     * mounted this loop polls the Follow/Message row bottom at a fixed cadence
     * and follows every position change without flashing: the row belongs to
     * the scrolling block, so covering from its current bottom keeps the grid
     * under the cover at ALL poses. The only dangerous case is the row (and
     * its anchors) vanishing from the tree entirely while content is still
     * travelling: that arms a bounded full-body hold until the anchor
     * publishes again or the hold cap expires. Within the jitter band stability
     * accumulates and the exact geometry remounts once.
     */
    private val profileGeometryWatch = object : Runnable {
        override fun run() {
            if (!profileGeometryWatchActive) return
            profileWatchLastTickAt = SystemClock.uptimeMillis()
            val departureRemaining = maxOf(profileAllowedDepartureUntil, profileWatchQuietUntil) -
                SystemClock.uptimeMillis()
            if (departureRemaining > 0L) {
                // A verified allowed departure (Story ring, Edit Profile, menu
                // sheet...) is in flight. Do not query the animating tree: one
                // such tick measured 1.6 s and delayed the Story exit with it.
                profileWatchedCoverTop = Int.MIN_VALUE
                profileWatchedFullCover = false
                profileWatchedStableSamples = 0
                profileWatchIdleTicks = 0
                mainHandler.postDelayed(this, departureRemaining + 16L)
                return
            }
            val root = rootInActiveWindow
            if (root == null || root.packageName?.toString() != INSTAGRAM_PACKAGE ||
                !ProtectionPreferences.isEnabled(this@AntiScrollService, ProtectedApp.INSTAGRAM) ||
                !instagramProfilePostsBlocked()) {
                // Leaving Instagram or losing the mode stops the loop for good.
                profileGeometryWatchActive = false
                return
            }
            // Transitional classifications (UNKNOWN right after fragment swaps)
            // must NOT kill the guard: the header collapse happens exactly in
            // those frames. Silence decisions while unknown, keep ticking.
            val screenIsProfile = lastInstagramScreen == InstagramScreen.PROFILE
            val otherCurtain = instagramOverlay.visibleCurtain()?.first
            if (otherCurtain != null && otherCurtain != InstagramScreen.PROFILE) {
                // A tab tap mounted Home's or Explore's curtain before the
                // state left PROFILE. Remounting the profile cover here turned
                // it back into the profile rectangle and then hid it, so
                // Explore's grid showed for ~0.6 s in Strict (Galaxy S23).
                profileGeometryWatchActive = false
                return
            }
            if (!screenIsProfile &&
                lastInstagramScreen != InstagramScreen.UNKNOWN &&
                instagramOverlay.visibleProfileBounds() == null) {
                // A verified different surface owns the screen now.
                profileGeometryWatchActive = false
                return
            }
            if (instagramProfileCurtainMustYield(root)) {
                // An allowed profile layer (avatar preview, Edit Profile,
                // highlights picker) owns the screen: retire any mounted
                // curtain at once and re-anchor for the moment it closes.
                if (instagramOverlay.visibleProfileBounds() != null) {
                    instagramOverlay.hide()
                    instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                        this@AntiScrollService, "profile.watch", "decision=layer-yield")
                }
                profileWatchedCoverTop = Int.MIN_VALUE
                profileWatchedFullCover = false
                profileWatchedStableSamples = 0
                mainHandler.postDelayed(this, nextProfileWatchDelay())
                return
            }
            val window = instagramWindowBounds(root)
            val coverTop = instagramStrictProfileRowBottom(root, window)
            val now = SystemClock.uptimeMillis()
            if (now < profileAllowedDepartureUntil) {
                // A verified allowed departure (Edit Profile, menu sheet, About
                // layer...) is in flight: keep the curtain away and re-check
                // after the quiet window instead of flashing it back on.
                profileWatchedCoverTop = Int.MIN_VALUE
                profileWatchedFullCover = false
                profileWatchedStableSamples = 0
                mainHandler.postDelayed(this, nextProfileWatchDelay())
                return
            }
            val floor = if (profileScrollFloor > window.top) profileScrollFloor else
                calculateProfileScrollFloor(root, window)
            val bottom = stableMainNavigationTop(root, window, InstagramScreen.PROFILE)
                .takeIf { it > window.centerY() } ?: window.bottom
            fun mountAt(top: Int?) {
                profileWindowId = root.windowId
                val resolved = top?.coerceAtMost(bottom - 1) ?: floor
                supportCurtainReason = "profile"
                showInstagramCurtain(Rect(window.left, resolved, window.right, bottom),
                    InstagramScreen.PROFILE)
            }
            if (profileWatchedFullCover &&
                now - profileWatchedFullCoverStartedAt > PROFILE_FULL_COVER_MAX_HOLD_MS) {
                // The protective hold outlived any realistic scroll gesture:
                // treat the ongoing instability as animation noise and release
                // to the last measured row position.
                profileWatchedFullCover = false
                mountAt(profileWatchedCoverTop)
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                    this@AntiScrollService, "profile.watch", "decision=cap-release top=$profileWatchedCoverTop")
                profileWatchedStableSamples = 0
            }
            when {
                coverTop == null -> {
                    if (!hasVisibleProfileHeaderMarkers(root)) {
                        // The profile shell left the tree: a full-screen layer
                        // (hamburger menu, account switcher, other page) owns
                        // the screen. Yield: never mount over it, retire any
                        // mounted curtain, and re-anchor for the return.
                        if (instagramOverlay.visibleProfileBounds() != null) {
                            instagramOverlay.hide()
                            instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
                            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                                this@AntiScrollService, "profile.watch",
                                "decision=shell-absent-yield")
                        }
                        profileWatchedCoverTop = Int.MIN_VALUE
                        profileWatchedFullCover = false
                        profileWatchedStableSamples = 0
                        mainHandler.postDelayed(this, nextProfileWatchDelay())
                        return
                    }
                    // Row unmeasured (rebuild or exotic layout) while the shell
                    // is present.
                    if (!profileWatchedFullCover) {
                        val mounted = instagramOverlay.visibleProfileBounds()
                        if (mounted == null || mounted.top > floor + PROFILE_COVER_JITTER_PX) {
                            val collapseRisk = profileWatchedLastDirection <= 0
                            if (collapseRisk && mounted != null) {
                                // A collapse (or unknown) direction with the
                                // anchor gone: content is climbing above the
                                // mounted edge. Hold the whole body until the
                                // anchor publishes again (bounded by the cap).
                                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                                    this@AntiScrollService, "profile.watch",
                                    "decision=anchor-lost-hold mounted=${mounted.top} dir=$profileWatchedLastDirection")
                                profileWatchedFullCover = true
                                profileWatchedFullCoverStartedAt = now
                                profileScrollCover.reset()
                                mountAt(null)
                            } else if (profileWatchedLastDirection > 0 && profileWatchedCoverTop != null) {
                                // Expansion moved content away: keep the last
                                // verified cover position, no flash.
                                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                                    this@AntiScrollService, "profile.watch",
                                    "decision=anchor-lost-keep top=$profileWatchedCoverTop dir=$profileWatchedLastDirection")
                                mountAt(profileWatchedCoverTop)
                            } else if (mounted == null) {
                                // Nothing mounted and unknown direction.
                                mountAt(null)
                            }
                        }
                    }
                }
                profileWatchedCoverTop == null || profileWatchedCoverTop == Int.MIN_VALUE -> {
                    // First observation after arming: anchor only.
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                        this@AntiScrollService, "profile.watch", "decision=anchor top=$coverTop")
                    profileWatchedCoverTop = coverTop
                    profileWatchedLastChangeAt = now
                    // A dropped curtain must not wait for the next move.
                    if (instagramOverlay.visibleProfileBounds() == null) mountAt(coverTop)
                }
                kotlin.math.abs(coverTop - profileWatchedCoverTop!!) <= PROFILE_COVER_JITTER_PX -> {
                    profileWatchedStableSamples++
                    val settled = if (profileWatchedFullCover) {
                        // Release the protective hold as soon as the row stops
                        // moving: stable samples plus a short quiet window. The
                        // row and the grid travel together, so a stopped finger
                        // means the exact pose is safe to mount again.
                        profileWatchedStableSamples >= 2 &&
                            now - profileWatchedLastChangeAt >= PROFILE_FULL_COVER_SETTLE_HOLD_MS
                    } else {
                        profileWatchedStableSamples >= 3 &&
                            now - profileWatchedLastChangeAt >= 240L
                    }
                    if (settled) {
                        profileWatchedLastChangeAt = now
                        val mounted = instagramOverlay.visibleProfileBounds()
                        if (profileWatchedFullCover) {
                            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                                this@AntiScrollService, "profile.watch", "decision=release top=$coverTop samples=$profileWatchedStableSamples")
                            profileWatchedFullCover = false
                            mountAt(coverTop)
                        } else if (mounted == null ||
                            mounted.top != coverTop.coerceIn(floor, bottom - 1)) {
                            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                                this@AntiScrollService, "profile.watch", "decision=drift-fix top=$coverTop mounted=${mounted?.top}")
                            mountAt(coverTop)
                        }
                    }
                }
                coverTop > profileWatchedCoverTop!! -> {
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                        this@AntiScrollService, "profile.watch", "decision=follow-down top=$coverTop prev=$profileWatchedCoverTop")
                    profileWatchedFullCover = false
                    mountAt(coverTop)
                    profileWatchedCoverTop = coverTop
                    profileWatchedStableSamples = 0
                    profileWatchedLastChangeAt = now
                    profileWatchedLastDirection = 1
                }
                else -> {
                    val previous = profileWatchedCoverTop
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                        this@AntiScrollService, "profile.watch", "decision=cover-up top=$coverTop prev=$previous")
                    profileWatchedCoverTop = coverTop
                    profileWatchedStableSamples = 0
                    profileWatchedLastChangeAt = now
                    when {
                        profileWatchedFullCover -> {
                            // Protective hold already running: nothing to change.
                        }
                        previous != null && previous != Int.MIN_VALUE &&
                            coverTop > previous - PROFILE_COVER_UP_STEP_PX -> {
                            // Small upward drift: follow the row without a flash.
                            mountAt(coverTop)
                        }
                        else -> {
                            // Real collapse: content climbs several pixels above
                            // the mounted edge in one frame, so hold the whole
                            // collapsible body until it settles.
                            profileWatchedFullCover = true
                            profileWatchedFullCoverStartedAt = now
                            profileScrollCover.reset()
                            mountAt(null)
                        }
                    }
                }
            }
            mainHandler.postDelayed(this, nextProfileWatchDelay())
            if (ProtectionFlightRecorder.ENABLED) {
                profileWatchTick++
                if (profileWatchTick % 8 == 0) ProtectionFlightRecorder.record(
                    this@AntiScrollService, "profile.watch.tick",
                    "screen=$lastInstagramScreen top=$coverTop watched=$profileWatchedCoverTop " +
                        "active=${profileGeometryWatchActive} full=$profileWatchedFullCover")
            }
        }
    }

    private var profileWatchIdleTicks = 0
    private var profileWatchLastTickAt = 0L
    private var profileWatchLastSignature = ""

    /**
     * Every tick costs several remote lookups (100-185 ms measured). While the
     * header and grid are moving the watch keeps its 48 ms cadence; once the
     * pose has repeated it backs off to at most 480 ms. Instagram scroll and
     * click events wake it immediately through [kickProfileGeometryWatch].
     */
    private fun nextProfileWatchDelay(): Long {
        val signature = "$profileWatchedCoverTop|$profileWatchedFullCover|" +
            "${instagramOverlay.visibleProfileBounds()}"
        if (signature == profileWatchLastSignature) profileWatchIdleTicks++ else {
            profileWatchIdleTicks = 0
            profileWatchLastSignature = signature
        }
        return if (profileWatchIdleTicks < 4) 48L
        else minOf(480L, 48L shl minOf(profileWatchIdleTicks - 3, 4))
    }

    private fun kickProfileGeometryWatch(urgent: Boolean = false) {
        if (!profileGeometryWatchActive) return
        val now = SystemClock.uptimeMillis()
        if (urgent) {
            // A header collapse is in progress: the anchor probe must run
            // before the general scan (which first spends ~100-200 ms on
            // viewer probes), or the first grid row shows above the curtain.
            if (now - profileWatchLastTickAt < 120L) return
            profileWatchIdleTicks = 0
            mainHandler.removeCallbacks(profileGeometryWatch)
            mainHandler.postAtFrontOfQueue(profileGeometryWatch)
            return
        }
        if (profileWatchIdleTicks < 4) return
        profileWatchIdleTicks = 0
        mainHandler.removeCallbacks(profileGeometryWatch)
        mainHandler.post(profileGeometryWatch)
    }

    private fun armProfileGeometryWatch() {
        if (profileGeometryWatchActive) return
        profileWatchIdleTicks = 0
        profileWatchLastSignature = ""
        profileGeometryWatchActive = true
        profileWatchedCoverTop = Int.MIN_VALUE
        profileWatchedStableSamples = 0
        profileWatchedFullCover = false
        mainHandler.postDelayed(profileGeometryWatch, 48L)
    }

    private fun stopProfileCurtainEnsure() {
        profileCurtainEnsureActive = false
        profileCurtainEnsureAttempts = 0
        profileCurtainEnsureStableStreak = 0
    }

    private val exitGate = InstagramExitGate()
    private val instagramEntryTargets = mutableListOf<Pair<Rect, Boolean>>()
    private val lastDirectConversationGuards = mutableListOf<Rect>()
    private var verifiedInstagramInboxWindowId = -1
    private var verifiedInstagramInboxListBounds: Rect? = null
    private var directConversationEntryGuardArmedAt = 0L
    private var directConversationEntryGuardUntil = 0L
    private var directConversationSurfaceWindowId = -1
    private val directConversationEntryGuardTimeout = Runnable {
        if (directConversationEntryGuardUntil != 0L &&
            SystemClock.uptimeMillis() >= directConversationEntryGuardUntil) {
            clearDirectConversationEntryGuard()
        }
    }
    private val directConversationEntryGuardRelease = Runnable {
        clearDirectConversationEntryGuard()
    }
    private var scrollCoverTop: Int? = null
    private var scrollCoverUntil = 0L
    private var lastHomeScrollAt = 0L
    private var settledHomeTop: Int? = null
    private var stableHomeSamples = 0
    private val homeScrollSettled = object : Runnable {
        override fun run() {
            val refreshed = refreshHomeScrollBounds(null)
            val now = SystemClock.uptimeMillis()
            val homeNavigationPending = instagramProtectedNavigation.isPending(
                InstagramTab.HOME, now) && instagramOverlay.visibleHomeBounds() != null
            if (!refreshed && (homeNavigationPending ||
                    (scrollCoverTop != null && now < scrollCoverUntil))) {
                mainHandler.postDelayed(this, 48L)
            }
        }
    }
    private val directDetailsGuardSettled = Runnable {
        directDetailsGuardHoldUntil = 0L
        val root = rootInActiveWindow
        if (root?.packageName?.toString() == INSTAGRAM_PACKAGE &&
            lastInstagramScreen == InstagramScreen.DIRECT_SHARED_MEDIA) {
            refreshDirectDetailsSurface(root, instagramWindowBounds(root))
        }
    }
    private var profileWindowId = -1
    private var debugProfileScrollActionWindowId = -1
    private var profileScrollFloor = 0
    private var profileCurtainEnsureActive = false
    private var profileCurtainEnsureAttempts = 0
    private var profileCurtainEnsureStableStreak = 0
    private var lastProfileCurtainFingerprint: String? = null
    private val profileScrollCover = InstagramProfileScrollCover()
    private val profileScrollExit = InstagramProfileScrollExit()
    private val profileScrollPositions = mutableMapOf<String, Int>()
    private var exploreTransitionCoverUntil = 0L
    private var exploreTransitionCoverTop = 0
    private var exploreTransitionCoverWindowId = -1
    private val exploreChromeRestore = object : Runnable {
        override fun run() {
            val remaining = exploreTransitionCoverUntil - SystemClock.uptimeMillis()
            if (remaining > 0L) {
                mainHandler.postDelayed(this, remaining)
                return
            }
            if (!ProtectionPreferences.isEnabled(this@AntiScrollService, ProtectedApp.INSTAGRAM)) return
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
            val retained = instagramOverlay.visibleCurtain() ?: return
            val selectedSearch = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/search_tab")
                .any { it.isVisibleToUser && it.isSelected }
            if (!InstagramNavigationGeometry.canRestoreSearchChrome(retained.first,
                    root.windowId == exploreTransitionCoverWindowId, selectedSearch)) return
            val header = attachedExploreHeaderBounds(root, instagramWindowBounds(root)) ?: return
            // Only release the temporary header strip; keep the existing content
            // rectangle mounted. Do not wait for a full accessibility-tree scan.
            val bounds = Rect(retained.second).apply { top = header.bottom }
            if (bounds.top >= bounds.bottom) return
            exploreTransitionCoverUntil = 0L
            instagramOverlay.supportReason = "restore"
            if (instagramOverlay.show(bounds, InstagramScreen.EXPLORE, isEnglish())) {
                lastVerifiedInstagramCurtain = InstagramScreen.EXPLORE to Rect(bounds)
            }
            queueInstagramScan(0L)
        }
    }

    private fun handleInstagram(event: AccessibilityEvent) {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) {
            hideInstagramProtection()
            return
        }
        val eventNow = SystemClock.uptimeMillis()
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            profileLayerInvalidatedAt = eventNow
        }
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            kickProfileGeometryWatch()
        }
        if (handleSearchInputEvent(event)) return
        if (handleStrictInstagramStoryLaunch(event, eventNow)) return
        if (eventNow < instagramStoryLaunchUntil) {
            // No remote queries while the Story viewer starts (see above).
            queueInstagramScan(120L)
            return
        }
        refreshEarlyInstagramProfileReturn(event, eventNow)
        if (instagramProtectedNavigation.isAwaitingDispatch(eventNow)) {
            // Window/content events from the source tab can otherwise perform
            // several remote tree queries before the pre-draw callback gets a
            // main-thread turn. The destination is already covered; coalesce
            // those stale events and scan the resulting tab after dispatch.
            queueInstagramScan(32L)
            return
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            armDirectWindowTransition(event, eventNow)
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            // A viewer can arrive as a new window: let the next Notifications
            // scan probe all windows again.
            instagramWindowChangedSinceViewerProbe = true
        }
        if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) == ProtectionMode.STRICT &&
            lastInstagramScreen == InstagramScreen.NOTIFICATIONS &&
            event.eventType in setOf(
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED) &&
            eventNow - event.eventTime in 0L..700L &&
            // A viewer only opens after a notification row tap, which arms this
            // hold. Without it the ancestor walk below cost 25-40 ms for every
            // content event of the notification list.
            eventNow < instagramNotificationExitHoldUntil &&
            isFreshNotificationViewerEvent(event)) {
            dispatchNotificationViewerBackFromEvent(event, eventNow)
            return
        }
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val freshClick = eventNow - event.eventTime in 0L..1_500L
            if (freshClick) {
                // First, before any tree query of the click handling below:
                // the release is only as fast as the work in front of it.
                // Any later tap ends an earlier profile release, so a quick
                // Home tap is covered by the normal path at once.
                instagramTabReleaseUntil = 0L
                mainHandler.removeCallbacks(instagramTabRecoverCover)
                mainHandler.removeCallbacks(instagramTabReleaseProbe)
                if (InstagramTabReleasePolicy.releasesOnTap(
                        instagramOverlay.visibleCurtain()?.first,
                        tappedInstagramTab(event.source),
                        ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
                    instagramTabReleaseUntil = SystemClock.uptimeMillis() + InstagramTabReleasePolicy.GRACE_MS
                    instagramTabReleaseClickAt = event.eventTime
                    mainHandler.removeCallbacks(instagramTabReleaseProbe)
                    instagramTabReleaseProbe.run()
                }
                mainHandler.removeCallbacks(instagramSearchReleaseProbe)
                // The click of Explore's search field carries no source node on
                // Instagram (Galaxy S23); its class is enough to start looking,
                // the probe itself checks the focused field by id.
                if (instagramOverlay.visibleCurtain()?.first == InstagramScreen.EXPLORE &&
                    event.className?.toString()?.contains("EditText", ignoreCase = true) == true) {
                    instagramSearchReleaseClickAt = event.eventTime
                    instagramSearchReleaseProbe.run()
                }
            }
            if (freshClick && lastInstagramScreen == InstagramScreen.NOTIFICATIONS &&
                isInstagramNotificationContentIntent(event.source)) {
                instagramNotificationBackCount = 0
                // Preserve notification origin through the first state-machine
                // transition. observeInstagramScreen() may change
                // NOTIFICATIONS -> REELS before exitBlockedViewer() runs.
                instagramNotificationExitHoldUntil = eventNow + 10_000L
                instagramNotificationContentLaunchUntil = eventNow + 1_500L
                instagramBalancedNotificationPostWatching = false
                instagramNotificationReelExitIssued = false
                instagramNotificationReelSecondBackIssued = false
                instagramNotificationCommentNeedsSecondBack = false
                instagramOverlay.hide()
                clearInstagramResumeProtection()
                queueInstagramScan(0L)
                Log.d(TAG, "IG_NOTIFICATION_CONTENT_INTENT pending=true")
            }
            if (freshClick && lastInstagramScreen == InstagramScreen.NOTIFICATIONS &&
                !isBackNavigationIntent(event.source)) {
                // Compose notification rows do not always expose their row id
                // through the click event. Keep a short origin latch for any
                // non-header notification tap so the first viewer scan still
                // knows this was notification-originated.
                instagramNotificationExitHoldUntil = eventNow + 10_000L
                instagramNotificationAttemptStartedAt = eventNow
                instagramNotificationViewerDetectedAt = 0L
                instagramNotificationReelExitIssued = false
                instagramNotificationReelSecondBackIssued = false
                instagramNotificationCommentNeedsSecondBack = false
                Log.d(TAG, "IG_NOTIFICATION_TAP ageMs=${eventNow - event.eventTime}")
            }
            if (freshClick && instagramProfileIngress.pending &&
                compactId(event.source?.viewIdResourceName) == "action_bar_button_back") {
                instagramProfileIngress.reset()
                instagramOverlay.updateProfileIngressGuard(null)
            }
            val openingInboxThread = freshClick && armDirectConversationEntryGuard(event, eventNow)
            if (freshClick && lastInstagramScreen == InstagramScreen.PROFILE &&
                instagramBalancedProfilePost.arm(
                    ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM),
                    verifiedProfile = true,
                    profileThumbnail = isProfileThumbnailIntent(event.source),
                    now = eventNow)) {
                Log.d(TAG, "IG_BALANCED_PROFILE_POST_INTENT")
            }
            if (freshClick && lastInstagramScreen == InstagramScreen.SAVED_COLLECTION &&
                instagramBalancedProfilePost.arm(
                    ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM),
                    verifiedProfile = false,
                    profileThumbnail = isCollectionThumbnailIntent(event.source),
                    now = eventNow,
                    verifiedCollection = true)) {
                Log.d(TAG, "IG_BALANCED_COLLECTION_POST_INTENT")
            }
            if (freshClick && lastInstagramScreen == InstagramScreen.PROFILE &&
                isProfileReelThumbnailIntent(event.source)) {
                instagramBalancedProfileReelIntentWindowId = event.windowId
                instagramBalancedProfileReelIntentUntil = eventNow + 1_500L
                Log.d(TAG, "IG_BALANCED_PROFILE_REEL_INTENT window=${event.windowId}")
                if (ProtectionFlightRecorder.ENABLED) {
                    val chain = ancestorIds(event.source, 24)
                    ProtectionFlightRecorder.record(this, "instagram.profile.reel-tap",
                        "grid=${InstagramBalancedReelIngressPolicy.isProfileGridTap(chain)} " +
                            "chain=${chain.joinToString(">")}")
                }
            } else if (lastInstagramScreen == InstagramScreen.REELS && instagramReelsSession.watching &&
                event.windowId != instagramReelsVerifiedWindowId &&
                eventNow - event.eventTime in
                    0L..InstagramBalancedReelIngressPolicy.LATE_PROFILE_TAP_MAX_AGE_MS &&
                isProfileReelThumbnailIntent(event.source) &&
                InstagramBalancedReelIngressPolicy.isProfileGridTap(ancestorIds(event.source, 24))) {
                // A profile opened from the allowed Reel, tapped before the
                // profile could be classified (Instagram stalled the service).
                instagramBalancedProfileReelIntentWindowId = event.windowId
                instagramBalancedProfileReelIntentUntil = eventNow + 1_500L
                instagramBalancedLateProfileTap = true
                Log.d(TAG, "IG_BALANCED_PROFILE_REEL_INTENT late window=${event.windowId} " +
                    "ageMs=${eventNow - event.eventTime}")
            }
            if (freshClick && lastInstagramScreen == InstagramScreen.SAVED_COLLECTION &&
                isCollectionReelThumbnailIntent(event.source)) {
                instagramBalancedCollectionReelIntentWindowId = event.windowId
                instagramBalancedCollectionReelIntentUntil = eventNow + 1_500L
                Log.d(TAG, "IG_BALANCED_COLLECTION_REEL_INTENT window=${event.windowId}")
            }
            val profileCurtainVisible = instagramOverlay.visibleProfileBounds() != null
            val profileDeparture = if (freshClick &&
                (profileCurtainVisible || lastInstagramScreen == InstagramScreen.PROFILE)) {
                allowedProfileDeparture(event.source)
            } else null
            if (profileDeparture != null) {
                // Click delivery can lag behind the profile mount: the search-row
                // click which opened it is not a departure from it. Only a verified
                // allowed destination can release the grid; unknown clicks retain it.
                // Instagram keeps the profile pager mounted behind Highlights
                // and native action sheets. Release the grid curtain before the
                // destination draws, then let structural checks own the state.
                profileAllowedDepartureUntil = eventNow + if (profileDeparture) {
                    1_200L
                } else {
                    PROFILE_ALLOWED_DEPARTURE_QUIET_MS
                }
                instagramProfileReturn.arm(eventNow)
                releaseAllowedProfileSurface()
                Log.d(TAG, "IG_PROFILE_ALLOWED_DEPARTURE")
            }
            if (freshClick && isExploreNavigationIntent(event.source) &&
                !isRecentProxiedNavigation(InstagramTab.SEARCH, eventNow)) {
                // The bottom Search tab always opens Explore before its search
                // field is focused. Cover its grid from the click event instead
                // of waiting for the expensive general tree classification.
                val root = rootInActiveWindow
                if (root?.packageName?.toString() == INSTAGRAM_PACKAGE) {
                    clearInstagramResumeProtection()
                    currentInstagramWindowId = root.windowId
                    // Do not carry the source tab's animated window token into
                    // Explore. Samsung can scale that token during the tab slide.
                    instagramOverlay.hide()
                    val bounds = calculateExploreBounds(root, instagramWindowBounds(root))
                    clampCurtainBottomToNavigation(root, bounds)
                    supportCurtainReason = "tab"
                    showInstagramCurtain(bounds, InstagramScreen.EXPLORE)
                    Log.d(TAG,
                        "IG_EXPLORE_INTENT_CURTAIN eventAgeMs=${eventNow - event.eventTime}")
                }
            }
            if (freshClick && lastInstagramScreen == InstagramScreen.SEARCH_RESULTS &&
                isBackNavigationIntent(event.source) && !isInputMethodVisible()) {
                // Back from search results returns to Explore. The click is
                // often reported ~0.5 s late and the destination scan can take
                // a further ~0.7 s; pre-mount the destination curtain so the
                // returning grid is never exposed while classification runs.
                val root = rootInActiveWindow
                if (root?.packageName?.toString() == INSTAGRAM_PACKAGE &&
                    instagramOverlay.visibleCurtain() == null) {
                    clearInstagramResumeProtection()
                    currentInstagramWindowId = root.windowId
                    supportCurtainReason = "back"
                    showInstagramCurtain(
                        calculateExploreBounds(root, instagramWindowBounds(root)),
                        InstagramScreen.EXPLORE)
                    Log.d(TAG,
                        "IG_SEARCH_BACK_PRECOVER eventAgeMs=${eventNow - event.eventTime}")
                    queueInstagramScan(0L)
                }
            }
            if (freshClick && isHomeNavigationIntent(event.source) &&
                !isRecentProxiedNavigation(InstagramTab.HOME, eventNow)) {
                // A Profile/DM curtain is either too low or absent for Home.
                // Cover the feed conservatively from the action-bar boundary
                // before Instagram publishes its destination tree. The normal
                // Home scan restores the Stories allowance immediately after.
                val root = rootInActiveWindow
                if (root?.packageName?.toString() == INSTAGRAM_PACKAGE) {
                    val display = currentDisplayBounds()
                    val bottom = stableMainNavigationTop(
                        root, display, InstagramScreen.HOME_FEED)
                    val top = (statusBarInset() + dp(56)).coerceIn(display.top, bottom - 1)
                    clearInstagramResumeProtection()
                    currentInstagramWindowId = root.windowId
                    // Recreate instead of resizing the Profile curtain. Keeping
                    // its token lets Samsung animate and briefly shorten it.
                    instagramOverlay.hide()
                    supportCurtainReason = "tab"
                    showInstagramCurtain(
                        Rect(display.left, top, display.right, bottom),
                        InstagramScreen.HOME_FEED)
                    Log.d(TAG,
                        "IG_HOME_INTENT_CURTAIN eventAgeMs=${eventNow - event.eventTime}")
                }
            }
            if (freshClick && isMainTabClick(event.source)) {
                // Bottom-tab switch: the tab bar is static across main tabs, so
                // the blocked Reels tab gets its guard immediately - including
                // the first second of a Profile/DM/Explore transition where
                // the settled-path updates have not run yet.
                if (isReelsTabClick(event.source)) {
                    // A tap on the blocked Reels TAB must never take the
                    // Balanced single-viewer allowance: the transitional feed
                    // frame can miss the tab-bar marker, so the origin is
                    // latched and every feed entry exits immediately.
                    instagramReelsTabTapUntil = eventNow + 3_000L
                    // The click event only exists when the tap reached
                    // Instagram at all (the guard consumed the others). The
                    // feed renders within a few hundred ms of it: arm the
                    // opaque cover now so even its first frame never shows.
                    armReelsSlipCover()
                }
                rootInActiveWindow?.let { tabRoot ->
                    if (tabRoot.packageName?.toString() == INSTAGRAM_PACKAGE) {
                        refreshMainReelsTabGuard(tabRoot)
                    }
                }
            }
            if (freshClick) refreshDirectDetailsTabIntent(event.source)
            if (freshClick && isDirectDetailsMediaIntent(event.source)) {
                directDetailsLaunchPendingUntil = eventNow + DIRECT_DETAILS_LAUNCH_PENDING_MS
                directDetailsFallbackBackAt = eventNow + DIRECT_DETAILS_FALLBACK_BACK_MS
                queueInstagramScan(0L)
                Log.d(TAG, "IG_DIRECT_DETAILS_MEDIA_INTENT")
            }
            if (freshClick && !openingInboxThread && eventNow >= directReelIntentDebounceUntil &&
                eventNow >= directConversationGuardHoldUntil &&
                directReelLaunchPendingUntil == 0L && !instagramExitInProgress &&
                isDirectReelIntent(event.source)) {
                directReelLaunchPendingUntil = eventNow + DIRECT_REEL_LAUNCH_PENDING_MS
                directReelIntentDebounceUntil = eventNow + DIRECT_REEL_INTENT_DEBOUNCE_MS
                directConversationGuardHoldUntil = eventNow + DIRECT_CONVERSATION_GUARD_HOLD_MS
                queueInstagramScan(0L)
                Log.d(TAG, "IG_DIRECT_REEL_INTENT")
            }
            // Consume intent before the fast player scan can discard the queued
            // click. Never rearm from our own viewer Back action.
            if (freshClick) {
                var candidate = event.source
                var isBack = false
                repeat(8) {
                    val node = candidate ?: return@repeat
                    val id = compactId(node.viewIdResourceName)
                    if (id.contains("back", ignoreCase = true)) isBack = true
                    candidate = node.parent
                }
                if (!isBack) {
                    exitGate.userClick(event.eventTime)
                    lastInstagramUserInputAt = event.eventTime
                    val currentRoot = rootInActiveWindow
                    if (instagramExitInProgress &&
                        currentRoot?.packageName?.toString() == INSTAGRAM_PACKAGE &&
                        hasFastNotificationsSurface(currentRoot)) {
                        // A second notification tap can arrive after the first
                        // viewer exit while Instagram still reports the old
                        // Reel encounter. Treat it as a new attempt instead
                        // of letting the stale retry state swallow the click.
                        cancelInstagramExit()
                        instagramNotificationBackCount = 0
                        instagramNotificationExitHoldUntil = eventNow + 10_000L
                        instagramNotificationContentLaunchUntil = eventNow + 1_500L
                        instagramNotificationReelExitIssued = false
                        instagramNotificationReelSecondBackIssued = false
                        instagramNotificationCommentNeedsSecondBack = false
                        Log.d(TAG, "IG_NOTIFICATION_NEW_ATTEMPT reset=true")
                    }
                }
            }
            @Suppress("DEPRECATION")
            queuedClick?.recycle()
            @Suppress("DEPRECATION")
            val copy = AccessibilityEvent.obtain(event)
            queuedClick = copy
            if (InstagramInboxPolicy.canReleaseFeedForDirectIntent(
                    instagramOverlay.visibleCurtain()?.first, freshClick)) {
                var source = event.source
                repeat(5) {
                    val node = source ?: return@repeat
                    if (InstagramInboxPolicy.isDirectNavigation(compactId(node.viewIdResourceName),
                            node.contentDescription?.toString().orEmpty())) {
                        // Intent is not a destination: lift the outgoing feed
                        // curtain at once (messaging is a verified-allowed
                        // surface, and the user asked for a fast release), but
                        // re-cover from the last verified rectangle if no inbox
                        // verification lands inside the short recovery window.
                        directNavigationSourceWindowId = event.windowId
                        directNavigationUntil = SystemClock.uptimeMillis() +
                            DIRECT_NAVIGATION_GRACE_MS
                        // Keep the mounted entry guards through the transition:
                        // the bottom Reels tab must stay covered while the DM
                        // surface loads, otherwise a fast follow-up tap enters
                        // Reels natively.
                        instagramOverlay.hide()
                        mainHandler.postDelayed(instagramDirectRecoverCover,
                            DIRECT_RECOVER_COVER_MS)
                        Log.d(TAG, "IG_DIRECT_INTENT_PENDING eventAgeMs=${SystemClock.uptimeMillis() - event.eventTime}")
                        source = null
                    } else source = node.parent
                }
            }
            if (freshClick && isNotificationsIntent(event.source)) {
                // ACTION_CLICK from our launch proxy is an acknowledgement,
                // not permission to tear down the already mounted bridge.
                // Keep it until the destination row windows have drawn.
                if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) != ProtectionMode.STRICT) {
                    clearInstagramNotificationIngress()
                    instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
                }
                clearInstagramResumeProtection()
                instagramOverlay.hide()
                mainHandler.removeCallbacks(homeScrollSettled)
                scrollCoverTop = null
                scrollCoverUntil = 0L
                directNavigationUntil = 0L
                directNavigationSourceWindowId = -1
                Log.d(TAG, "IG_ALLOWED_NOTIFICATION_INTENT_RELEASE")
            }
        }
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            if (handleBalancedInstagramReelScroll(event)) return
            if (lastInstagramScreen == InstagramScreen.NOTIFICATIONS) {
                // Back already pre-covered Home. The scrolls that follow are
                // Instagram's return animation, not the user: each one used to
                // re-check six Notifications ids and re-measure Home (120-240 ms
                // on a Galaxy S23), so the curtain was drawn up to 0.5 s late.
                if (instagramOverlay.visibleHomeBounds() != null) {
                    queueInstagramScan(16L)
                    return
                }
                val root = rootInActiveWindow
                if (root?.packageName?.toString() == INSTAGRAM_PACKAGE &&
                    !igVisible(root, "activity_feed_root") && surfaceLeftProbeApplies()) {
                    // The current list is gone: this scroll is the first frame
                    // of the return to Home. Run the coalesced Back probe now
                    // instead of after the remaining lookups and the queue.
                    mainHandler.removeCallbacks(surfaceLeftProbe)
                    surfaceLeftProbePending = false
                    try {
                        runSurfaceLeftProbe()
                    } finally {
                        surfaceLeftProbeEndedAt = SystemClock.uptimeMillis()
                    }
                    if (instagramOverlay.visibleHomeBounds() != null) {
                        queueInstagramScan(16L)
                        return
                    }
                }
                if (root?.packageName?.toString() == INSTAGRAM_PACKAGE && hasFastNotificationsSurface(root)) {
                    if (InstagramNotificationEntryPolicy.blocksCommentLikes(
                            ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
                        instagramNotificationMotion.arm(SystemClock.uptimeMillis())
                    }
                    refreshInstagramNotificationEntryGuards()
                    queueInstagramScan(16L)
                    return
                }
            }
            if (lastInstagramScreen == InstagramScreen.DIRECT_SHARED_MEDIA) {
                directDetailsGuardHoldUntil = SystemClock.uptimeMillis() +
                    DIRECT_DETAILS_GUARD_SETTLE_MS
                mainHandler.removeCallbacks(directDetailsGuardSettled)
                mainHandler.postDelayed(
                    directDetailsGuardSettled, DIRECT_DETAILS_GUARD_SETTLE_MS)
                directDetailsInteractionBounds?.let { guard ->
                    // Keep the already mounted touch guard above the moving
                    // pager while its new geometry is being published.
                    instagramOverlay.showTransientTouchGuard(guard, isEnglish())
                }
                val root = rootInActiveWindow
                if (root?.packageName?.toString() == INSTAGRAM_PACKAGE &&
                    refreshDirectDetailsSurface(root, instagramWindowBounds(root))) {
                    // Update the WindowManager curtain in the scroll callback;
                    // waiting for the general scan leaves a tappable seam.
                    queueInstagramScan(16L)
                    return
                }
            }
            val profileBounds = instagramOverlay.visibleProfileBounds()
            if (profileBounds != null && event.windowId == profileWindowId &&
                SystemClock.uptimeMillis() - event.eventTime in 0L..1500L) {
                val dx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaX else 0
                val dy = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaY else 0
                val profileSource = isProfileScrollSource(event)
                val sourceId = compactId(event.source?.viewIdResourceName)
                val oldPosition = if (profileSource && event.scrollY >= 0)
                    profileScrollPositions.put(sourceId, event.scrollY) else null
                val positionDelta = if (oldPosition != null) event.scrollY - oldPosition else 0
                // Some containers report zero deltas. Compare actual grid motion
                // instead of treating zero as either an upward or horizontal swipe.
                val measuredTop = if (profileSource && dx == 0 && dy == 0) {
                    val root = rootInActiveWindow
                    if (root?.packageName?.toString() == INSTAGRAM_PACKAGE && root.windowId == profileWindowId)
                        profileGridBounds(root, instagramWindowBounds(root))?.top else null
                } else null
                val effectiveDy = if (dx == 0 && dy == 0 && positionDelta != 0) positionDelta
                    else InstagramProfileScrollExit.verticalDelta(dx, dy, profileBounds.top, measuredTop)
                Log.d(TAG, "IG_PROFILE_SCROLL dx=$dx dy=$dy y=${event.scrollY} positionDelta=$positionDelta effectiveDy=$effectiveDy source=$profileSource ageMs=${SystemClock.uptimeMillis() - event.eventTime}")
                if (InstagramProfileScrollCover.shouldCover(
                        dx, dy, effectiveDy, profileSource) ||
                    (profileSource && (dx != 0 || dy != 0 || positionDelta != 0))) {
                    // The strict-profile geometry watch owns the curtain while
                    // it is mounted: it polls the row faster than events can
                    // deliver deltas, so this branch only keeps the scanner
                    // warm and lets the watch decide coverage. No visual work
                    // here means no double owner, hence no flash churn.
                    queueInstagramScan(16L)
                    return
                }
            }
            if (refreshHomeScrollBounds(event)) {
                // Let WindowManager render the new bounds before a general tree walk.
                queueInstagramScan(16L)
                return
            }
            if (lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES) {
                val root = rootInActiveWindow
                if (root?.packageName?.toString() == INSTAGRAM_PACKAGE && refreshDirectConversationGuards(root)) {
                    queueInstagramScan(16L)
                    return
                }
                if (lastDirectConversationGuards.isNotEmpty() ||
                    isDirectConversationEntryGuardArmed()) {
                    // Instagram briefly removes the conversation header/list
                    // while opening media. That absence is not proof that the
                    // protected card disappeared. Keep the already attached
                    // windows until the destination tree is classified.
                    Log.d(TAG, "IG_DIRECT_GUARDS retained during unverified scroll transition")
                    queueInstagramScan(16L)
                    return
                }
            }
            instagramOverlay.updateEntryGuards(instagramEntryTargets.filter { it.second }.map { it.first }, isEnglish())
        }
        // The conversation pre-arm does nothing in either mode today. Ask for the
        // root only when it can act: that remote query ran for every Instagram
        // event on every screen (16-80 ms each on a Galaxy S23 while Instagram
        // is busy) and helped queue events up for seconds.
        if ((event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) &&
            InstagramDmInteractionPolicy.interceptsChatTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
            val root = rootInActiveWindow
            if (root?.packageName?.toString() == INSTAGRAM_PACKAGE) {
                prearmDirectConversationSurface(root, SystemClock.uptimeMillis())
            }
        }
        // Coalesce Instagram's burst of DM layout notifications. The transparent
        // conversation guard is mounted synchronously above, so forcing every
        // content event into a zero-delay full scan only starves touch dispatch.
        val scanDelay = InstagramEventScanPolicy.delayMs(event.eventType)
        // Never do the full tree walk inline for each queued accessibility event.
        queueInstagramScan(scanDelay)
    }

    private fun isProfileScrollSource(event: AccessibilityEvent): Boolean {
        var node = event.source
        repeat(10) {
            val current = node ?: return false
            if (compactId(current.viewIdResourceName) in setOf(
                    "profile_viewpager", "profile_header_container", "profile_header_fixed_list",
                    "row_profile_header")) return true
            // The collapsing header can report the coordinator itself, rather
            // than a descendant of the profile pager.
            if (compactId(current.viewIdResourceName) in setOf("coordinator_root_layout", "tab_appbar") &&
                current.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/profile_header_container")
                    .any { it.isVisibleToUser }) return true
            node = current.parent
        }
        return false
    }

    private fun scanInstagram(event: AccessibilityEvent?) {
        val scanNow = SystemClock.uptimeMillis()
        if (directConversationEntryGuardUntil != 0L &&
            scanNow >= directConversationEntryGuardUntil) {
            clearDirectConversationEntryGuard()
        }
        if (instagramExitInProgress && scanNow < instagramExitTreeQuietUntil) {
            // Instagram is replacing the viewer tree after BACK. Querying this
            // short-lived tree can block Accessibility's main thread until the
            // framework's roughly two-second IPC timeout.
            queueInstagramScan(instagramExitTreeQuietUntil - scanNow)
            return
        }
        lastInstagramScanTime = SystemClock.uptimeMillis()
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) {
            hideInstagramProtection()
            return
        }
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) {
            if (retainInstagramCurtainUnderNotificationShade(root.packageName?.toString())) return
            suspendInstagramProtection(root.packageName?.toString())
            // This path is reached when a delayed Instagram event is handled
            // after Recents/SystemUI has already become the active root. Mark
            // the foreground departure just like overlayForegroundCheck does,
            // otherwise the next Instagram event is not recognized as resume.
            trackPackageTransition("")
            return
        }
        resumeInstagramNotificationShade(root)
        // Instagram's own dialog (promo/suggestion pop-up) is the active window.
        // The feed behind it is dimmed and cannot be touched, and a curtain
        // measured from the dialog window would hide the dialog itself. Step
        // aside until the dialog closes; its dismissal rescans Instagram.
        // One lookup per scan: every Instagram dialog seen so far (promo,
        // suggestion) is hosted in dialog_container.
        if (InstagramSurfacePolicy.isInstagramDialog(
                dialogContainerVisible = igVisible(root, "dialog_container"),
                promoHeadlineVisible = false)) {
            if (instagramOverlay.hasVisibleWindows) {
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                    this, "instagram.dialog", "released window=${root.windowId}")
                SupportDiagnostics.record(this, SupportEvent.STEPPED_ASIDE,
                    mapOf("app" to "instagram", "why" to "popup"))
                instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
                hideInstagramContentOverlay()
            }
            return
        }
        if (precoverCollectionReturn(root)) return
        val notificationTransitionActive = lastInstagramScreen == InstagramScreen.NOTIFICATIONS ||
            instagramExitFromNotifications || instagramNotificationReturn.isPending(scanNow) ||
            instagramNotificationIngress.active(scanNow) || scanNow < instagramNotificationExitHoldUntil
        if (notificationTransitionActive &&
            (!instagramNotificationIngress.active(scanNow) ||
                lastInstagramScreen != InstagramScreen.HOME_FEED) &&
            igVisible(root, "main_feed_action_bar") &&
            selectedInstagramMainTab(root) == InstagramTab.HOME &&
            !hasFastActionBarBack(root) && !igVisible(root, "bottom_sheet_container") &&
            !hasFastNotificationsSurface(root)) {
            // A verified destination owns its protection, not the timers from
            // the previous notification visit. Do not cancel an ingress still
            // waiting to leave its Home source tree before Notifications opens.
            clearInstagramNotificationIngress()
            instagramNotificationReturn.reset()
            instagramNotificationContentLaunchUntil = 0L
            instagramNotificationExitHoldUntil = 0L
            cancelInstagramExit()
            val window = instagramWindowBounds(root)
            if (refreshFastMainProtectedSurface(root, window)) {
                refreshProtectedNavigationGuards(root, window)
                return
            }
        }
        if (instagramNotificationReturn.isPending(scanNow)) {
            // Back was already dispatched by the verified Notifications
            // header. Transitional feed/comment nodes are not a new viewer
            // launch and must never trigger an additional Back.
            queueInstagramScan(32L)
            return
        }
        if (instagramNotificationIngress.active(scanNow)) {
            if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) != ProtectionMode.STRICT) {
                clearInstagramNotificationIngress()
            } else {
                // Source-tree scans and native click acknowledgements can run
                // between mounting the input bridge and drawing destination
                // guards. They must not release or reclassify that transition.
                if (!instagramNotificationIngress.awaitingDispatch && hasFastNotificationsSurface(root)) {
                    clearInstagramResumeProtection()
                    instagramOverlay.hide()
                    cancelInstagramExit()
                    observeInstagramScreen(InstagramScreen.NOTIFICATIONS, root.windowId)
                    refreshInstagramNotificationBackGuard(root, instagramWindowBounds(root))
                    refreshInstagramNotificationEntryGuards()
                }
                queueInstagramScan(32L)
                return
            }
        }
        // While a notification-origin viewer is being closed, never fall
        // through to the broad Instagram tree walk. That walk routinely takes
        // 300–500 ms (and occasionally longer), which is directly visible as
        // the delayed return. The targeted window probe is the only authority
        // until Notifications is confirmed again.
        if (instagramExitFromNotifications ||
            (lastInstagramScreen == InstagramScreen.NOTIFICATIONS &&
                scanNow < instagramNotificationExitHoldUntil)) {
            val notificationViewer = findInstagramNotificationViewerRoot(root)
            if (notificationViewer != null) {
                if (instagramExitInProgress) {
                    queueInstagramScan(48L)
                    return
                }
                val (viewerRoot, viewerScreen) = notificationViewer
                if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) ==
                    ProtectionMode.BALANCED &&
                    allowBalancedInstagramNotificationViewer(viewerRoot, viewerScreen)) return
                supportExitReason = "notification"
                exitBlockedViewer(
                    viewerRoot,
                    instagramWindowBounds(viewerRoot),
                    viewerScreen,
                    useGlobalBackOnly = viewerScreen == InstagramScreen.REELS)
                return
            }
            if (instagramExitInProgress && hasFastNotificationsSurface(root)) {
                cancelInstagramExit()
                observeInstagramScreen(InstagramScreen.NOTIFICATIONS, root.windowId)
                refreshInstagramNotificationBackGuard(root, instagramWindowBounds(root))
                refreshInstagramNotificationEntryGuards()
                return
            }
        }
        probeInstagramSearchForProfile(root, scanNow)
        if (instagramProtectedNavigation.shouldHoldBeforeDispatch(scanNow, root.windowId)) {
            // A DM event which was already queued before the user's protected-tab
            // tap must not classify the still-selected inbox and remove the new
            // destination curtain before its first frame. Yield to pre-draw; the
            // draw callback performs the real native tab action exactly once.
            if (instagramOverlay.visibleCurtain() != null) {
                queueInstagramScan(32L)
                return
            }
            instagramProtectedNavigation.clear()
        }
        val initialWindowBounds = instagramWindowBounds(root)
        currentInstagramWindowId = root.windowId
        // Refresh the persistent blocked-Reels-tab guard before ANY early
        // return below: the fast protected-surface paths skip the scan tail,
        // which previously left the Explore/Home tab guard stale while the
        // user could spam the tab during a search-return transition.
        refreshMainReelsTabGuard(root)
        if (InstagramNotificationShadePolicy.isProtectedFeedOrigin(lastInstagramScreen) &&
            instagramOverlay.visibleCurtain() != null &&
            !isDirectConversationEntryGuardArmed() &&
            releaseVerifiedInstagramInbox(root, requireSelectedMainTab = true)) return
        if (InstagramDmInteractionPolicy.prioritizesChangedViewer(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM),
                verifiedConversation = lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES &&
                    directConversationSurfaceWindowId >= 0,
                changedWindow = root.windowId != directConversationSurfaceWindowId) &&
            hasFastReelsViewer(root, directLaunchPending = scanNow < directReelLaunchPendingUntil)) {
            // A current, verified Reel in a new chat-owned window needs no
            // profile/navigation/inbox discovery. Stories still fail this exact
            // Reel predicate and keep their separate transition grace.
            supportExitReason = "reel"
            exitBlockedViewer(root, initialWindowBounds, InstagramScreen.REELS)
            return
        }
        if (releaseProfileCurtainToAccountSearch(root, initialWindowBounds)) return
        // A full-screen Story owns a new foreground root. Do not spend the
        // first frame probing the old profile, inbox, Reel player, or snapshot.
        if (hasFastStoryViewer(root)) {
            stopProfileCurtainEnsure()
            instagramProfileIngress.reset()
            instagramOverlay.updateProfileIngressGuard(null)
            instagramOverlay.updateAccountSearchGuard(null, ::onInstagramAccountSearchTap, {})
            instagramOverlay.updateStoryEntryGuards(emptyList())
            instagramOverlay.updateNavigationGuards(emptyMap())
            if (instagramStoriesBlocked()) {
                val readinessNow = SystemClock.uptimeMillis()
                // The modal window event already proved the viewer window is up.
                val modalAnnounced = root.windowId == instagramModalViewerWindowId &&
                    readinessNow - instagramModalViewerSeenAt in 0L..3_000L
                val wait = if (modalAnnounced) 0L else instagramStoryExitReadiness.delayBeforeBack(
                    root.windowId, readinessNow)
                if (wait > 0L) {
                    clearInstagramResumeProtection()
                    instagramOverlay.hide()
                    instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
                    queueInstagramScan(minOf(wait, 80L))
                    return
                }
                supportExitReason = "story"
                exitBlockedViewer(root, initialWindowBounds, InstagramScreen.STORY, useGlobalBackOnly = true)
            } else {
                releaseAllowedProfileSurface()
                observeInstagramScreen(InstagramScreen.STORY, root.windowId)
            }
            return
        }
        // A mounted main feed which is still the verified destination needs no
        // absent-profile, navigation or general-tree discovery. In particular,
        // let the looper deliver Direct clicks while Instagram's selected tab
        // still describes Explore. Never release the curtain in this shortcut.
        if (InstagramNotificationShadePolicy.isProtectedFeedOrigin(lastInstagramScreen) &&
            instagramOverlay.visibleCurtain() != null &&
            root.windowId == instagramStateMachine.currentWindowId &&
            !hasFastMainReelsTabDestination(root) &&
            refreshFastMainProtectedSurface(root, initialWindowBounds)) {
            refreshProtectedNavigationGuards(root, initialWindowBounds)
            if (SystemClock.uptimeMillis() - lastInstagramUserInputAt in
                    0L..INSTAGRAM_USER_LAUNCH_GRACE_MS) queueInstagramScan(48L)
            return
        }
        if (refreshEnteringInstagramProfile(root, initialWindowBounds)) return
        if (refreshSettledInstagramProfile(root, initialWindowBounds, scanNow)) return
        refreshProtectedNavigationGuards(root, initialWindowBounds)
        if (instagramResumePending) beginInstagramResumeProtection(root)
        if (directReelLaunchPendingUntil != 0L && scanNow >= directReelLaunchPendingUntil) {
            directReelLaunchPendingUntil = 0L
        }
        // Home/DM -> Reels can be a horizontal main-pager swipe. That route has
        // no click intent, can keep the previous Home/DM hierarchy mounted, and
        // may reuse the same accessibility window. Resolve the selected bottom
        // tab before the verified-Home hold and settled-DM shortcuts so neither
        // can pin the old safe surface while Reels is already playing.
        val instagramMode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        if (!InstagramBalancedReelIngressPolicy.keepsVerifiedSession(
                instagramMode, instagramReelsSession.watching, instagramReelsSession.exiting,
                viewerWindowId = root.windowId, verifiedWindowId = instagramReelsVerifiedWindowId,
                rebindAllowed = SystemClock.uptimeMillis() < instagramReelWindowRebindUntil) &&
            hasFastMainReelsTabDestination(root)) {
            instagramReelsSession.observe(instagramMode,
                viewerVisible = true, feedEntry = true)
            supportExitReason = "reelstab"
            exitBlockedViewer(root, initialWindowBounds, InstagramScreen.REELS)
            return
        }
        if (lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES) {
            // DM is intentionally left untouched.  Do not pre-arm a full
            // conversation window: the only enforcement point is the viewer
            // detector below, which sends Back after Instagram actually opens
            // a Reel.
            clearDirectConversationEntryGuard()
        }
        // A structurally complete, full-width inbox is safe to recognize from
        // any previous screen. Doing this before the absent-player/header
        // probes removes the 300-500 ms scan which used to remain queued after
        // Home -> DM and delay the first conversation window event.
        if (!isDirectConversationEntryGuardArmed() &&
            releaseVerifiedInstagramInbox(root)) return
        val keepVerifiedHome = InstagramSurfacePolicy.shouldKeepVerifiedHome(
            currentScreen = instagramStateMachine.currentScreen,
            homeCurtainVisible = instagramOverlay.visibleHomeBounds() != null,
            sameWindow = instagramStateMachine.currentWindowId == root.windowId,
            hasFreshUserInput = scanNow - lastInstagramUserInputAt in
                0L..INSTAGRAM_USER_LAUNCH_GRACE_MS
        )
        // Notifications are an allowed native surface. During a row launch,
        // do not fall through to collectInstagramSnapshot(): that full tree
        // walk can monopolize the accessibility looper for several seconds,
        // which is exactly the delay the user sees before the Reel is closed.
        // Resolve only the small, viewer-specific markers until the surface
        // settles back to Notifications.
        if (lastInstagramScreen == InstagramScreen.NOTIFICATIONS) {
            if (hasFastNotificationsSurface(root)) {
                // Instagram can keep the Notifications tree as the active
                // root while the Reel/comment viewer is published in a
                // separate accessibility window. Only acknowledge return
                // after every Instagram window has been probed.
                val probeViewer = InstagramNotificationViewerProbePolicy.shouldProbe(
                    now = scanNow,
                    exitHoldUntil = instagramNotificationExitHoldUntil,
                    contentLaunchUntil = instagramNotificationContentLaunchUntil,
                    exitInProgress = instagramExitInProgress,
                    windowChangedSinceProbe = instagramWindowChangedSinceViewerProbe)
                if (probeViewer) instagramWindowChangedSinceViewerProbe = false
                val separateViewer = if (probeViewer) findInstagramNotificationViewerRoot(root) else null
                if (separateViewer == null) {
                    instagramNotificationEventLocked = false
                    instagramNotificationLastEventExitAt = 0L
                    cancelInstagramExit()
                    instagramOverlay.hide()
                    refreshInstagramNotificationBackGuard(root, initialWindowBounds)
                    refreshInstagramNotificationEntryGuards()
                    return
                }
                val (viewerRoot, viewerScreen) = separateViewer
                if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) ==
                    ProtectionMode.BALANCED &&
                    allowBalancedInstagramNotificationViewer(viewerRoot, viewerScreen)) {
                    return
                }
                instagramNotificationContentLaunchUntil = 0L
                instagramNotificationExitHoldUntil = SystemClock.uptimeMillis() + 10_000L
                if (viewerScreen == InstagramScreen.REELS) {
                    instagramNotificationReelExitIssued = true
                }
                supportExitReason = "notification"
                exitBlockedViewer(
                    viewerRoot,
                    instagramWindowBounds(viewerRoot),
                    viewerScreen,
                    useGlobalBackOnly = viewerScreen == InstagramScreen.REELS)
                return
            }
            // The list is gone. If Home's header is what replaced it, this is
            // the Back to Home: cover it now instead of after the full scan
            // (~0.7 s with the feed visible when Home appeared just after the
            // probe ran). The probe itself rejects viewers and launches.
            if (surfaceLeftProbeApplies()) {
                runSurfaceLeftProbe()
                if (instagramOverlay.visibleHomeBounds() != null) return
            }
            val notificationReel = hasFastReelsViewer(root, directLaunchPending = true)
            val notificationComment = hasFastCommentSheetInRoot(root)
            if (notificationReel || notificationComment) {
                if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) ==
                    ProtectionMode.BALANCED &&
                    allowBalancedInstagramNotificationViewer(
                        root,
                        if (notificationReel) InstagramScreen.REELS else InstagramScreen.COMMENTS_OR_DETAIL)) {
                    return
                }
                instagramNotificationContentLaunchUntil = 0L
                instagramNotificationExitHoldUntil = SystemClock.uptimeMillis() + 10_000L
                if (notificationReel) instagramNotificationReelExitIssued = true
                supportExitReason = "notification"
                exitBlockedViewer(
                    root,
                    initialWindowBounds,
                    if (notificationReel) InstagramScreen.REELS else InstagramScreen.COMMENTS_OR_DETAIL,
                    useGlobalBackOnly = notificationReel)
                return
            }
            if (scanNow < instagramNotificationContentLaunchUntil || instagramExitInProgress) {
                queueInstagramScan(32L)
                return
            }
        }
        // Check the player before walking the full conversation tree. A stable
        // Home curtain prevents Instagram's autonomous embedded-video rebuild
        // from being mistaken for a user-opened Reel.
        // Search all Instagram windows only during the actual notification
        // click hand-off or while this viewer encounter is still exiting.
        // After the list is verified again, Instagram can retain the old Reel
        // window in AccessibilityWindows for several seconds; treating that
        // stale tree as a new click causes a delayed second/third Back.
        if (lastInstagramScreen == InstagramScreen.NOTIFICATIONS &&
            (scanNow < instagramNotificationContentLaunchUntil || instagramExitInProgress)) {
            findInstagramNotificationViewerRoot(root)?.let { (viewerRoot, viewerScreen) ->
                if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) ==
                    ProtectionMode.BALANCED &&
                    scanNow < instagramNotificationContentLaunchUntil &&
                    allowBalancedInstagramNotificationViewer(viewerRoot, viewerScreen)) {
                    return
                }
                instagramNotificationContentLaunchUntil = 0L
                instagramNotificationExitHoldUntil =
                    // Keep the origin latch long enough to survive a user's
                    // manual close of the comment sheet before the post layer
                    // is published again.
                    SystemClock.uptimeMillis() + 10_000L
                if (viewerScreen == InstagramScreen.REELS) {
                    instagramNotificationReelExitIssued = true
                }
                supportExitReason = "notification"
                exitBlockedViewer(
                    viewerRoot,
                    instagramWindowBounds(viewerRoot),
                    viewerScreen,
                    useGlobalBackOnly = viewerScreen == InstagramScreen.REELS)
                return
            }
        }
        var stageStarted = SystemClock.uptimeMillis()
        val fastReelsViewer = hasFastReelsViewer(
            root,
            directLaunchPending = scanNow < directReelLaunchPendingUntil)
        logSlowInstagramStage("fast-viewer", stageStarted)
        if (fastReelsViewer && !keepVerifiedHome) {
            supportExitReason = "reel"
            exitBlockedViewer(root, instagramWindowBounds(root), InstagramScreen.REELS)
            return
        }
        if (hasFastReelPreview(root) && !keepVerifiedHome) {
            supportExitReason = "reelpreview"
            exitBlockedViewer(root, instagramWindowBounds(root), InstagramScreen.REELS)
            return
        }
        val windowBounds = initialWindowBounds
        if (hasFastSinglePostViewer(root, chosenFromProfile = instagramProfilePostChosen(scanNow))) {
            if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) ==
                ProtectionMode.BALANCED && instagramBalancedNotificationPostWatching) {
                hideInstagramContentOverlay()
                cancelInstagramExit()
                observeInstagramScreen(InstagramScreen.COMMENTS_OR_DETAIL, root.windowId)
                return
            }
            if (allowBalancedInstagramProfilePost(root)) return
            supportExitReason = "post"
            exitBlockedViewer(root, windowBounds, InstagramScreen.COMMENTS_OR_DETAIL)
            return
        }
        // A notification can open a comment sheet over a post. If the user
        // closes that sheet manually, Instagram may keep the underlying post
        // visible after the short launch window has expired. Keep the
        // notification-origin block alive for that hand-off and re-check the
        // broad post markers here; otherwise the post becomes an accidental
        // allowed surface and can be watched indefinitely.
        if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) ==
            ProtectionMode.STRICT &&
            scanNow < instagramNotificationExitHoldUntil &&
            lastInstagramScreen != InstagramScreen.NOTIFICATIONS) {
            val notificationViewer = findInstagramNotificationViewerRoot(root)
                ?: if (hasFastPostViewer(root) || hasFastCommentSheet(root)) {
                    root to InstagramScreen.COMMENTS_OR_DETAIL
                } else null
            notificationViewer?.let { (viewerRoot, viewerScreen) ->
                if (viewerScreen == InstagramScreen.REELS) {
                    instagramNotificationReelExitIssued = true
                }
                supportExitReason = "notification"
                exitBlockedViewer(
                    viewerRoot,
                    instagramWindowBounds(viewerRoot),
                    viewerScreen,
                    useGlobalBackOnly = viewerScreen == InstagramScreen.REELS)
                return
            }
        }
        // A notification row is not an allowed source for a post, Reel or
        // comment viewer. During the short marker-to-viewer hand-off, suppress
        // feed classification and wait for the real viewer so one Back closes
        // it without mounting a flashing Home curtain.
        if (lastInstagramScreen == InstagramScreen.NOTIFICATIONS &&
            scanNow < instagramNotificationContentLaunchUntil) {
            val notificationPostViewer = hasFastPostViewer(root)
            val notificationCommentSheet = hasFastCommentSheet(root)
            if (notificationPostViewer || notificationCommentSheet) {
                if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) ==
                    ProtectionMode.BALANCED &&
                    allowBalancedInstagramNotificationViewer(
                        root, InstagramScreen.COMMENTS_OR_DETAIL)) return
                instagramNotificationContentLaunchUntil = 0L
                supportExitReason = "notification"
                exitBlockedViewer(root, windowBounds, InstagramScreen.COMMENTS_OR_DETAIL)
            } else {
                instagramOverlay.hide()
                // Instagram can publish the notification row click before the
                // Reel/comment window exists. Poll briefly instead of waiting
                // for a second accessibility event; this short loop has no
                // overlay and is bounded by the launch grace above.
                queueInstagramScan(24L)
            }
            return
        }
        if (refreshBalancedInstagramCollection(root)) return
        if (hasFastNotificationsSurface(root)) {
            if (instagramNotificationReturn.isPending(scanNow)) {
                queueInstagramScan(32L)
                return
            }
            clearDirectConversationEntryGuard()
            if (lastInstagramScreen != InstagramScreen.NOTIFICATIONS) clearDirectDetailsScrollGuard()
            clearInstagramResumeProtection()
            instagramOverlay.hide()
            cancelInstagramExit()
            observeInstagramScreen(InstagramScreen.NOTIFICATIONS, root.windowId)
            refreshInstagramNotificationBackGuard(root, windowBounds)
            refreshInstagramNotificationEntryGuards()
            return
        }
        if (hasFastStoryViewer(root)) {
            clearDirectConversationEntryGuard()
            profileAllowedDepartureUntil = 0L
            if (instagramStoriesBlocked()) {
                supportExitReason = "story"
                exitBlockedViewer(root, windowBounds, InstagramScreen.STORY, useGlobalBackOnly = true)
                return
            }
            exitGate.reset()
            releaseAllowedProfileSurface()
            observeInstagramScreen(InstagramScreen.STORY, root.windowId)
            return
        }
        // Inbox and conversation are both direct-ID surfaces. Resolve them
        // before profile/general probes so an old tree walk cannot delay the
        // first conversation guard. Both functions reject mounted Reel/details
        // top layers before allowing the surface.
        if (refreshDirectConversationGuards(root)) return
        if (isDirectConversationEntryGuardArmed()) {
            // A cold ModalActivity can exist well before it publishes its
            // message_list/header nodes. Keep discovery alive underneath the
            // already attached transparent guard instead of falling through to
            // UNKNOWN once and silently letting the guard expire.
            queueInstagramScan(64L)
            return
        }
        if ((lastInstagramScreen == InstagramScreen.DIRECT_SHARED_MEDIA ||
                scanNow < directDetailsLaunchPendingUntil) && hasFastPostViewer(root)) {
            directDetailsLaunchPendingUntil = 0L
            directDetailsFallbackBackAt = 0L
            supportExitReason = "chatmedia"
            exitBlockedViewer(root, windowBounds, InstagramScreen.COMMENTS_OR_DETAIL)
            return
        }
        if (scanNow < directDetailsLaunchPendingUntil) {
            if (hasVisibleDirectDetailsGrid(root)) {
                if (directDetailsFallbackBackAt != 0L && scanNow >= directDetailsFallbackBackAt) {
                    // A real Instagram click was delivered inside a protected
                    // media region. Some photo viewers keep the details grid
                    // mounted behind them, so structure alone cannot prove the
                    // top layer. Global Back targets that top layer reliably.
                    directDetailsLaunchPendingUntil = 0L
                    directDetailsFallbackBackAt = 0L
                    supportExitReason = "chatmedia"
                    exitBlockedViewer(
                        root, windowBounds, InstagramScreen.COMMENTS_OR_DETAIL,
                        useGlobalBackOnly = true)
                    return
                }
                // The click was delivered through a transient seam, but the
                // gallery is still foreground. Keep it covered while Instagram
                // replaces the tree; do not send BACK before the viewer exists.
                refreshDirectDetailsSurface(root, windowBounds)
                val nextCheck = if (directDetailsFallbackBackAt > scanNow) {
                    minOf(24L, directDetailsFallbackBackAt - scanNow)
                } else 0L
                queueInstagramScan(nextCheck)
                return
            }
            if (hasFastDirectSafeReturn(root, lookForRenamedList = true)) {
                directDetailsLaunchPendingUntil = 0L
            } else {
                // The aggregate Media/Reposts gallery is protected regardless
                // of whether the opened item is a photo, post or Reel.
                supportExitReason = "chatmedia"
                exitBlockedViewer(root, windowBounds, InstagramScreen.COMMENTS_OR_DETAIL)
                return
            }
        } else if (directDetailsLaunchPendingUntil != 0L) {
            directDetailsLaunchPendingUntil = 0L
            directDetailsFallbackBackAt = 0L
        }
        if (refreshDirectDetailsSurface(root, windowBounds)) return
        if (refreshFastMainProtectedSurface(root, windowBounds)) return

        // The profile grid is a small set of direct ID lookups. Draw its curtain
        // before inbox/conversation probes and the bounded general tree walk so
        // thumbnails do not wait for the slow classification path.
        val earlyProfileBounds = profileGridBounds(root, windowBounds)
        if (earlyProfileBounds != null) {
            if (!instagramProfilePostsBlocked()) {
                releaseBalancedInstagramProfile(root, windowBounds)
                return
            }
            if (hasVisibleProfileNativeSheet(root) || hasVisibleAboutAccountSurface(root)) {
                profileAllowedDepartureUntil = 0L
                armInstagramProfileReturn(root, scanNow)
                releaseAllowedProfileSurface()
                return
            }
            if (scanNow < profileAllowedDepartureUntil) {
                releaseAllowedProfileSurface()
                queueInstagramScan(profileAllowedDepartureUntil - scanNow)
                return
            }
            profileAllowedDepartureUntil = 0L
            profileWindowId = root.windowId
            profileScrollFloor = calculateProfileScrollFloor(root, windowBounds)
            earlyProfileBounds.top = profileScrollCover.measure(
                earlyProfileBounds.top, profileScrollFloor, scanNow)
            observeInstagramScreen(InstagramScreen.PROFILE, root.windowId)
            if (applyStrictProfileCurtainResult(root, windowBounds, earlyProfileBounds)) {
                clearInstagramProfileReturn()
            }
            val mountedFingerprint = earlyProfileBounds.flattenToString()
            if (mountedFingerprint != lastProfileCurtainFingerprint) {
                // The slide-in tail of a transition can leave the curtain a little narrow
                // or short; keep re-measuring until the mounted rect repeats identically.
                armProfileCurtainEnsure()
            }
            lastProfileCurtainFingerprint = mountedFingerprint
        } else if (hasVisibleProfileHeaderMarkers(root)) {
            armProfileCurtainEnsure()
        }
        // The fast checks above took several hundred ms while Instagram animated
        // a return from Saved; the feed may be back by now. Re-check with a
        // fresh root before the full tree walk (another ~0.5-1 s).
        if (instagramCollectionFeedOrigin != null &&
            precoverCollectionReturn(rootInActiveWindow ?: root)) return
        stageStarted = SystemClock.uptimeMillis()
        val yieldFeedSnapshot = earlyProfileBounds == null &&
            InstagramNotificationShadePolicy.isProtectedFeedOrigin(lastInstagramScreen) &&
            instagramOverlay.visibleCurtain() != null && instagramFeedSnapshotYields < 2
        val signals = collectInstagramSnapshot(root,
            event?.takeIf { it.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
                it.windowId == root.windowId &&
                SystemClock.uptimeMillis() - it.eventTime in 0L..1_500L }?.source,
            protectedProfileGrid = earlyProfileBounds != null && hasVisibleProfileHeaderMarkers(root),
            yieldProtectedFeed = yieldFeedSnapshot)
        logSlowInstagramStage("snapshot", stageStarted)
        if (signals == null) {
            // Never classify an incomplete tree or remove the existing curtain.
            // Return to the event loop so pending Direct clicks and a fresh root
            // can be handled instead of walking the old transition for a second.
            instagramFeedSnapshotYields++
            Log.d(TAG, "IG_FEED_SNAPSHOT_YIELD count=$instagramFeedSnapshotYields")
            queueInstagramScan(24L)
            return
        }
        instagramFeedSnapshotYields = 0
        if (ProtectionFlightRecorder.ENABLED) recordInstagramSignals(signals)
        val retainedCurtain = instagramOverlay.visibleCurtain()
        val profileSideSurface = InstagramProfileSurfacePolicy.hasAllowedLayer(
            signals.ids, signals.titles)
        if (retainedCurtain != null &&
            retainedCurtain.first in setOf(InstagramScreen.EXPLORE, InstagramScreen.HOME_FEED) &&
            profileSideSurface) {
            // Saved/Likes/Reposts can return to the profile menu. That menu is
            // not a feed, so an older Explore/Home curtain must not survive on
            // top of its settings rows while the classifier is UNKNOWN.
            Log.d(TAG, "IG_SETTINGS_RELEASE_STALE_CURTAIN source=${retainedCurtain.first}")
            hideInstagramContentOverlay()
            instagramEntryTargets.clear()
            return
        }
        val profileContext = lastInstagramScreen == InstagramScreen.PROFILE || signals.ids.any { id ->
            id in setOf("profile_header_container", "profile_viewpager", "profile_tabs_container")
        }
        // Menu collection screens are Bloks-driven and expose only an action-bar title.
        // Balanced treats them as a user-curated library; Strict keeps the existing
        // one-shot Back behavior. The title check is intentionally independent of
        // profileContext because Instagram can briefly report UNKNOWN during entry.
        if (InstagramProfileSurfacePolicy.isUserCollection(signals.ids, signals.idlessMediaTiles)) {
            if (refreshBalancedInstagramCollection(root, collectionIds = true)) return
            val collectionOrigin = lastInstagramScreen
            // Saved/Likes/Reposts opened from the profile menu return to that
            // allowed menu, so an older Explore/Home curtain must not survive
            // there. Opened from Explore's or Home's own bookmark button, Back
            // lands on that same feed: removing its curtain first exposed the
            // grid until the next scan re-covered it (0.7-2 s on device).
            val keepProtectedOrigin =
                InstagramProfileSurfacePolicy.keepsFeedCoverOnCollectionExit(
                    collectionOrigin, retainedCurtain?.first)
            Log.d(TAG, "IG_BLOCKED_COLLECTION_EXIT origin=$collectionOrigin " +
                "keepCover=$keepProtectedOrigin")
            supportExitReason = "collection"
            exitBlockedViewer(root, windowBounds, InstagramScreen.COMMENTS_OR_DETAIL,
                preserveObservedOrigin = true,
                keepOriginCover = keepProtectedOrigin)
            return
        }
        if (profileContext && InstagramProfileSurfacePolicy.hasAllowedLayer(signals.ids, signals.titles)) {
            profileAllowedDepartureUntil = 0L
            armInstagramProfileReturn(root, scanNow)
            // Native Back takes a few frames to close the allowed layer. A
            // precovered curtain mounted directly before Back may be dropped by
            // this verified-if-stale layer branch while the tree is still
            // transitional, reopening the protected profile before the next
            // allows-classified scan; hold it through that interval.
            if (scanNow - strictProfilePrecoverAtMs >= 700L ||
                instagramOverlay.visibleProfileBounds() == null) {
                releaseAllowedProfileSurface()
            }
            return
        }
        // Source ancestry describes the old screen. Only the current tree classifies
        // the destination; a click may arm a shield, but cannot trigger BACK itself.
        val classifiedScreen = InstagramProtectionEngine.classify(
            signals.copy(sourceIds = emptySet(), sourceLabels = emptySet(), sourceTab = null))
        if (classifiedScreen == InstagramScreen.SEARCH_RESULTS) {
            instagramExploreSearchSeen = InstagramSurfacePolicy.isExploreSearchSession(
                hasExploreSearchEditor = "action_bar_search_edit_text" in signals.ids,
                continuingSearch = lastInstagramScreen == InstagramScreen.SEARCH_RESULTS,
                previouslySeen = instagramExploreSearchSeen)
        }
        val standardHeaderAttached = attachedInstagramBounds(
            root, windowBounds, "main_feed_action_bar", requireWide = true) != null
        val standardStoriesAttached = findAttachedHomeStoriesBounds(root, windowBounds) != null
        val returnedToStandardHome = InstagramHomeGeometry.returnedToStandardFeed(
            alternateFeedActive = instagramAlternateFeedActive,
            // Instagram leaves the alternate feed's old Back node attached for
            // a few frames after returning Home. Its header is outside our
            // curtain, so the current visible snapshot is authoritative here;
            // an attached-but-hidden Back must not strand alternate geometry.
            backVisible = signals.hasBackNavigation,
            mainHeaderAttached = standardHeaderAttached,
            storiesAttached = standardStoriesAttached
        )
        // Saved's All Posts surface looks like Home once its action-bar title
        // scrolls away, even though the selected Reel and its audio player are
        // still mounted in the list. Keep it classified as the verified Reel
        // until the list is actually exited; otherwise a Home curtain can be
        // shown over a still-playing video without dispatching Back.
        val savedCollectionReelSurface = hasFastSavedCollectionReelList(root) &&
            (lastInstagramScreen in setOf(
                InstagramScreen.SAVED_COLLECTION, InstagramScreen.REELS) ||
                (instagramBalancedReelOrigin == InstagramScreen.SAVED_COLLECTION &&
                    instagramReelsSession.watching))
        val screen = when {
            savedCollectionReelSurface -> InstagramScreen.REELS
            returnedToStandardHome -> InstagramScreen.HOME_FEED
            keepsBalancedNotificationItem(root, classifiedScreen, signals) -> {
                // A thumbnail tap opens the post page directly (no comment
                // sheet first): that page is the notification's one item.
                val kept = if (lastInstagramScreen == InstagramScreen.NOTIFICATIONS) {
                    instagramBalancedNotificationPostWatching = true
                    InstagramScreen.COMMENTS_OR_DETAIL
                } else lastInstagramScreen
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                    "instagram.notification.item", "kept=$kept from=$lastInstagramScreen classified=$classifiedScreen")
                kept
            }
            classifiedScreen == InstagramScreen.REELS && keepVerifiedHome -> {
                Log.d(TAG, "IG_HOME_PLAYER_MUTATION_IGNORED window=${root.windowId}")
                InstagramScreen.HOME_FEED
            }
            else -> classifiedScreen
        }
        val alternateFeedDetected = screen == InstagramScreen.HOME_FEED &&
            InstagramHomeGeometry.isAlternateFeed(
                signals.ids, signals.titles, signals.hasBackNavigation)
        if (returnedToStandardHome) {
            instagramAlternateFeedActive = false
            Log.d(TAG, "IG_ALTERNATE_FEED_RETURN standard-home-ready")
        } else if (alternateFeedDetected) {
            instagramAlternateFeedActive = true
        } else if (screen != InstagramScreen.UNKNOWN &&
            (screen != InstagramScreen.HOME_FEED ||
                ("main_feed_action_bar" in signals.ids && !signals.hasBackNavigation))) {
            instagramAlternateFeedActive = false
        }
        val now = SystemClock.uptimeMillis()
        if (screen != InstagramScreen.DIRECT_MESSAGES && screen != InstagramScreen.UNKNOWN) {
            clearDirectConversationEntryGuard()
            verifiedInstagramInboxWindowId = -1
            verifiedInstagramInboxListBounds = null
        }
        if (screen != InstagramScreen.PROFILE && screen != InstagramScreen.UNKNOWN) {
            profileScrollPositions.clear()
            profileScrollCover.reset()
            profileWindowId = -1
        }
        if (exitGate.observe(
                screen,
                now,
                verifiedProfileReturn = InstagramEntryPolicy.isVerifiedProfileReturn(screen, signals.ids),
                // The fast viewer check above has already rejected a mounted
                // Reel player. A current DM classification therefore proves
                // that a previous viewer encounter ended.
                verifiedConversationReturn = screen == InstagramScreen.DIRECT_MESSAGES
            )) queueInstagramScan(450L)
        // A Reel deliberately opened from a profile, DM or collection is
        // admitted against the screen it was opened from. Observing REELS
        // first would erase that origin (seen with a profile repost, whose
        // localized title is the only difference from any other Reel).
        if (screen == InstagramScreen.REELS && allowBalancedInstagramReel(root)) return
        val stateDecision = observeInstagramScreen(screen, root.windowId)
        if (stateDecision.action == InstagramProtectionAction.EXIT) {
            exitBlockedViewer(root, windowBounds, screen)
            return
        }
        if (screen == InstagramScreen.HOME_FEED && now < directNavigationUntil) {
            // A native DM click precedes replacement of Home's accessibility tree.
            queueInstagramScan(32L)
            return
        }
        if (InstagramTabReleasePolicy.waitsForSwap(screen, now < instagramTabReleaseUntil)) {
            // A profile tab tap precedes the replacement of the feed's tree.
            queueInstagramScan(32L)
            return
        }
        if (screen != InstagramScreen.UNKNOWN && screen != InstagramScreen.HOME_FEED &&
            screen != InstagramScreen.EXPLORE) {
            instagramTabReleaseUntil = 0L
            mainHandler.removeCallbacks(instagramTabRecoverCover)
        }
        if (screen != InstagramScreen.UNKNOWN && screen != InstagramScreen.HOME_FEED) {
            directNavigationUntil = 0L
            directNavigationSourceWindowId = -1
        }
        if (stateDecision.action == InstagramProtectionAction.KEEP_CURRENT) {
            // Do not alter either the curtain or transparent card guards while
            // Instagram publishes an incomplete transition tree. Clearing the
            // guards here created an 86 ms first-tap opening in the captured DM
            // Reel trace.
            if (instagramOverlay.hasVisibleWindows) {
                if (instagramUnknownSince == 0L) instagramUnknownSince = now
                // Timed per window: a long transition in the main window must
                // not let a newly opened window step aside on its first frame.
                if (instagramUnknownWindowId != root.windowId) {
                    instagramUnknownWindowId = root.windowId
                    instagramUnknownWindowSince = now
                }
                if (InstagramSurfacePolicy.stepsAsideForUnknownWindow(
                        unknownForMs = now - instagramUnknownWindowSince,
                        rootWindowId = root.windowId,
                        verifiedWindowId = instagramStateMachine.currentWindowId,
                        tabBarVisible = igVisible(root, "tab_bar"),
                        windowCoversScreen = isFullscreenWindow(Rect().also(root::getBoundsInScreen)))) {
                    if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                        "instagram.unknown-window", "released window=${root.windowId} " +
                            "verified=${instagramStateMachine.currentWindowId} screen=$lastInstagramScreen")
                    SupportDiagnostics.record(this, SupportEvent.STEPPED_ASIDE,
                        mapOf("app" to "instagram", "why" to "page"))
                    instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
                    hideInstagramContentOverlay()
                    return
                }
                queueInstagramScan(InstagramSurfacePolicy.unknownRescanDelayMs(now - instagramUnknownSince))
            }
            return
        }
        val mediaEntriesBlocked = screen == InstagramScreen.DIRECT_MESSAGES &&
            InstagramDmInteractionPolicy.blocksSharedMedia(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))
        val canGuardEntries = screen != InstagramScreen.REELS && screen != InstagramScreen.STORY &&
            screen != InstagramScreen.CREATION && screen != InstagramScreen.UNKNOWN
        instagramOverlay.updateEntryGuards(if (canGuardEntries) {
            instagramEntryTargets.filter {
                (it.second || mediaEntriesBlocked) &&
                    (InstagramDmInteractionPolicy.mayGuardEntry(screen, it.second) ||
                        mediaEntriesBlocked)
            }.map { it.first }.distinct()
        } else emptyList(), isEnglish())
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
        cancelInstagramExit()
        when (stateDecision.action) {
            InstagramProtectionAction.SHOW_CURTAIN -> when (screen) {
            InstagramScreen.HOME_FEED ->
                showInstagramCurtain(calculateHomeFeedBounds(root, windowBounds), screen)
            InstagramScreen.EXPLORE ->
                showInstagramCurtain(calculateExploreBounds(root, windowBounds), screen)
            InstagramScreen.PROFILE -> {
                val bounds = profileGridBounds(root, windowBounds)
                // A temporarily missing grid during layout must not uncover an
                // already protected profile. Retry without removing its window.
                if (bounds != null) {
                    profileWindowId = root.windowId
                    profileScrollFloor = calculateProfileScrollFloor(root, windowBounds)
                    bounds.top = profileScrollCover.measure(
                        bounds.top, profileScrollFloor, SystemClock.uptimeMillis())
                    applyStrictProfileCurtain(root, windowBounds, bounds)
                    if (profileScrollCover.isHolding) queueInstagramScan(48L)
                } else if (coverStrictProfileBeforeGrid(root, windowBounds)) {
                    // Instagram publishes header markers seconds before the grid
                    // pager measures. In Strict that interval leaves every
                    // thumbnail and caption exposed; mount a conservative
                    // full-width cover now and let the ensure loop refine it
                    // once real geometry lands.
                    queueInstagramScan(48L)
                } else {
                    queueInstagramScan(80L)
                }
            }
                else -> Unit
            }
            InstagramProtectionAction.ALLOW -> {
                // Keyword search opens on an algorithmic "For you" grid of
                // Reels and posts: the Explore feed under a search field.
                // Account search (the Accounts tab, typed suggestions) stays
                // open; only that grid is covered, as Explore is.
                val keywordGrid = if (screen == InstagramScreen.SEARCH_RESULTS) {
                    keywordResultsGridBounds(root, windowBounds)
                } else null
                supportCurtainReason = "search"
                if (keywordGrid == null || !showInstagramCurtain(keywordGrid, InstagramScreen.EXPLORE)) {
                    hideInstagramContentOverlay()
                }
                if (screen == InstagramScreen.PROFILE) {
                    // The Balanced profile is an allowed surface but the Reels
                    // tab stays blocked: re-assert its guard on every verified
                    // frame so the entry window after a tab tap is covered.
                    refreshMainReelsTabGuard(root)
                }
            }
            else -> Unit
        }
        // Touch-first return from search results: while that screen is the
        // verified surface, guard its Back control so the Explore curtain is
        // drawn before Instagram runs its own back navigation. Any other
        // destination retires the guard.
        if (screen == InstagramScreen.SEARCH_RESULTS &&
            stateDecision.action == InstagramProtectionAction.ALLOW) {
            val back = findInstagramTopLeftBack(root, windowBounds)
            instagramOverlay.updateSearchReturnGuard(
                back?.let { Rect().also(it::getBoundsInScreen) }, ::onSearchReturnBack)
        } else {
            instagramOverlay.updateSearchReturnGuard(null) {}
        }
        // Keep the persistent Reels-tab guard fresh on every verified frame:
        // present on the main tabs, retired in viewers and sheets.
        refreshMainReelsTabGuard(root)
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
    }

    /**
     * Transition covers can be computed while the bottom bar is momentarily
     * unmeasurable; the fallback inset then lands inside the navigation bar.
     * Clamp the curtain's bottom edge to the visible tab bar top (or the last
     * verified curtain bottom) so a precover never covers the bottom menu.
     */
    private fun keywordResultsGridBounds(root: AccessibilityNodeInfo, window: Rect): Rect? {
        val tabs = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/search_tab_bar_layout")
            ?: return null
        // The keyword page always shows its query field directly above the
        // tabs. Other surfaces misread as search results (the Story editor
        // was) must never receive this curtain.
        val field = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/action_bar_search_edit_text")
            ?: return null
        if (tabs.top < field.bottom || tabs.top - field.bottom > dp(48)) return null
        val gridVisible =
            findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/grid_card_layout_container") != null ||
                findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/media_previews_rv") != null
        if (!gridVisible) return null
        val navigationTop = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/tab_bar")?.top
        val bottom = navigationTop?.takeIf { it > tabs.bottom } ?: window.bottom
        return Rect(window.left, tabs.bottom, window.right, bottom).takeIf { it.height() > dp(80) }
    }

    private fun clampCurtainBottomToNavigation(root: AccessibilityNodeInfo, bounds: Rect) {
        val tabTop = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/tab_bar")?.top
        // The retained curtain may have been measured during the task animation
        // or on another surface. Using it as a permanent ceiling leaves a strip
        // of the feed visible even after the real navigation bar has settled.
        // Missing chrome is already handled by stableMainNavigationTop().
        bounds.bottom = InstagramBottomNavigationGeometry.alignToVisibleNavigation(
            minimumTop = bounds.top + dp(80),
            windowBottom = instagramWindowBounds(root).bottom,
            currentBottom = bounds.bottom,
            visibleNavigationTop = tabTop
        )
    }

    /**
     * Back control of the search results was tapped. Draw the Explore curtain
     * first, then let Instagram run its native Back (arrow click, with a
     * global fallback). The keyboard-open case performs the native Back only:
     * there the first Back closes the IME, not the search surface.
     */
    private fun onSearchReturnBack() {
        stopSearchInputObservation()
        searchInputBypassUntil = SystemClock.uptimeMillis() + 500L
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            lastInstagramScreen != InstagramScreen.SEARCH_RESULTS) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        if (isInputMethodVisible()) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            queueInstagramScan(0L)
            return
        }
        clearInstagramResumeProtection()
        currentInstagramWindowId = root.windowId
        val bounds = calculateExploreBounds(root, instagramWindowBounds(root))
        clampCurtainBottomToNavigation(root, bounds)
        supportCurtainReason = "back"
        val mounted = showInstagramCurtain(bounds, InstagramScreen.EXPLORE)
        if (!mounted) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            queueInstagramScan(0L)
            return
        }
        // Touch-first: the Explore surface returns with the tab bar already
        // blocked, so the immediate tab spam after touching Back cannot slip.
        premountReelsTabGuard()
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.search.back", "precover=mounted")
        instagramOverlay.afterCurtainDraw {
            val current = rootInActiveWindow ?: return@afterCurtainDraw
            if (current.packageName?.toString() != INSTAGRAM_PACKAGE) return@afterCurtainDraw
            val accepted = findInstagramTopLeftBack(current, instagramWindowBounds(current))
                ?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            if (!accepted) performGlobalAction(GLOBAL_ACTION_BACK)
            queueInstagramScan(0L)
        }
    }

    private fun hasVisibleProfileHeaderMarkers(root: AccessibilityNodeInfo): Boolean =
        listOf("profile_header_container", "profile_tabs_container", "profile_action_bar").any { id ->
            igVisible(root, id)
        }

    private var expandedPicCheckedAt = 0L
    private var expandedPicVisible = false

    /**
     * Instagram renders the avatar long-press overlay in its own application
     * window, so the focused root alone cannot prove it. Every Instagram
     * window is checked, throttled so the watcher cadence stays cheap.
     */
    private fun instagramExpandedProfilePictureVisible(): Boolean {
        val now = SystemClock.uptimeMillis()
        if (profileLayerCacheValid(expandedPicCheckedAt, now, expandedPicVisible)) return expandedPicVisible
        expandedPicCheckedAt = now
        fun rootHasOverlay(root: AccessibilityNodeInfo?): Boolean =
            root != null && root.packageName?.toString() == INSTAGRAM_PACKAGE &&
                runCatching {
                    root.findAccessibilityNodeInfosByViewId(
                        "$INSTAGRAM_PACKAGE:id/expanded_profile_pic")
                }.getOrNull().orEmpty().any { it.isVisibleToUser }
        // Only the active window: the expanded avatar takes focus when shown.
        // Probing every application window queried Story/Reel viewer windows
        // whose UI thread was busy; each query waited for the 5 s interaction
        // timeout and froze protection for up to 37 s on a real device.
        expandedPicVisible = rootHasOverlay(rootInActiveWindow)
        return expandedPicVisible
    }

    private var profileYieldCheckedAt = 0L
    private var profileYieldVisible = false
    private var profileLayerInvalidatedAt = 0L

    /**
     * Profile-side layers (expanded avatar, share card, Edit Profile, sheets,
     * About) only appear after a tap or a window change. Their ~30 exact-ID
     * probes ran every 120 ms regardless and were the bulk of a 100-700 ms
     * geometry-watch tick. A "no layer" result measured at least one second
     * after the last structural event stays valid (refreshed every two
     * seconds anyway). A "layer present" result keeps the 120 ms throttle: a
     * layer can close by a swipe without any click or window event, and a
     * stale true would keep the Strict grid uncovered for up to two seconds.
     */
    private fun profileLayerCacheValid(checkedAt: Long, now: Long, cachedVisible: Boolean): Boolean =
        now - checkedAt < 120L ||
            (!cachedVisible && checkedAt - profileLayerInvalidatedAt >= 1_000L &&
                now - checkedAt < 2_000L)

    /**
     * Allowed profile layers that own the screen without changing the tracked
     * profile screen: Edit Profile and the highlights picker. The scan path
     * releases the curtain for them, so the geometry watch must yield too;
     * otherwise it re-covers the layer within one tick and the curtain
     * flickers and finally sticks over the allowed screen.
     */
    private fun instagramProfileCurtainMustYield(root: AccessibilityNodeInfo?): Boolean {
        if (instagramExpandedProfilePictureVisible()) return true
        val now = SystemClock.uptimeMillis()
        if (profileLayerCacheValid(profileYieldCheckedAt, now, profileYieldVisible)) return profileYieldVisible
        profileYieldCheckedAt = now
        val titleRoot = root ?: rootInActiveWindow
        if (titleRoot == null || titleRoot.packageName?.toString() != INSTAGRAM_PACKAGE) {
            profileYieldVisible = false
            return false
        }
        // The notifications/activity surface is an allowed screen: while it is
        // foreground the profile curtain must stay away (its rows can carry
        // post previews whose taps the blocked-viewer exit owns).
        if (hasFastNotificationsSurface(titleRoot)) {
            profileYieldVisible = true
            return true
        }
        // Detailed classification: every allowed profile-side layer (share
        // card, edit profile, native sheets, menu, About) is recognised by its
        // exact visible ids so the user's intentional surfaces are never
        // curtained (localized titles are not read).
        val visibleMarkers = InstagramProfileSurfacePolicy.allowedSurfaceMarkerIds
            .filterTo(mutableSetOf()) { igVisible(titleRoot, it) }
        profileYieldVisible = InstagramProfileSurfacePolicy.isAllowedProfileSurface(visibleMarkers)
        return profileYieldVisible
    }

    /**
     * Strict exposes exactly two native bands: the posts/followers/following
     * numbers and the Follow/Message row. Highlights, name, avatar, bio and the
     * media grid stay covered. Plans over the canonical app-bar-floor body so
     * the result is independent of which geometry owner produced the input.
     */
    /**
     * The bottom Reels tab is blocked in both modes, but the settled-surface
     * fast paths return before the general guard update. Refresh its dedicated
     * guard (from the current tree; the tab bar is static across the main
     * tabs) so a tap spam cannot enter Reels natively, including the first
     * second of a screen transition. Passing the visible clips_tab bounds
     * keeps a persistent window that unrelated guard updates never clear;
     * when the tab is not visible the guard retires - except during a
     * premounted transition window ([premountReelsTabGuard]), where the last
     * verified rectangle stays mounted until the new surface publishes its
     * own bar.
     */
    private fun refreshMainReelsTabGuard(root: AccessibilityNodeInfo, force: Boolean = false) {
        if (force) reelsTabGuardHoldUntil = 0L
        val window = instagramWindowBounds(root)
        val found = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/clips_tab")
            .firstNotNullOfOrNull { node ->
                val bounds = Rect().also(node::getBoundsInScreen)
                bounds.takeIf {
                    node.isVisibleToUser && it.intersect(window) &&
                        it.height() in 1 until window.height() / 2
                }
            }
            ?.let { Rect(it).apply { inset(-dp(4), 0) } }
        val guard: Rect?
        val state: String
        if (found != null) {
            reelsTabGuardHoldUntil = 0L
            lastReelsTabGuardBounds = found
            guard = found
            state = "found"
        } else if (!force && SystemClock.uptimeMillis() < reelsTabGuardHoldUntil) {
            // Transition window (search return, notification return): the new
            // surface has not published its bottom bar yet; keep the last
            // verified rectangle so an immediate tab spam cannot slip through.
            guard = lastReelsTabGuardBounds
            state = "hold"
        } else {
            // Retire now, but keep the last verified rectangle: the next
            // transition can premount it before the bar is published again.
            guard = null
            state = "retired"
        }
        if (ProtectionFlightRecorder.ENABLED) {
            val key = "$state:${guard?.toShortString()}"
            if (key != lastReelsTabGuardLogState) {
                lastReelsTabGuardLogState = key
                ProtectionFlightRecorder.record(this, "instagram.reels.guard",
                    "state=$state bounds=${guard?.toShortString() ?: "none"} " +
                        "last=$lastInstagramScreen")
            }
        }
        instagramOverlay.updateReelsTabGuard(guard)
    }

    /**
     * Covers the transition into a main surface: the incoming tree can be
     * visible for a few frames before its bottom bar node exists, and a tab
     * spam in that window used to reach Instagram natively. The last verified
     * rectangle is mounted immediately and kept until the surface publishes
     * its own bar (bounded by the hold).
     */
    private fun premountReelsTabGuard() {
        val bounds = lastReelsTabGuardBounds ?: return
        reelsTabGuardHoldUntil = SystemClock.uptimeMillis() + 2_000L
        instagramOverlay.updateReelsTabGuard(bounds)
    }

    /**
     * Arms the opaque cover for a Reels feed slip. Called the moment the tap
     * provably reached Instagram (its clips_tab click event) and again when a
     * feed exit is classified. It is retired only after the exit is verified
     * (or after a bounded window when no feed ever appeared).
     */
    private fun armReelsSlipCover() {
        instagramOverlay.showReelsSlipCover(currentDisplayBounds())
        reelsSlipCoverExit = false
        reelsSlipCoverUntil = SystemClock.uptimeMillis() + 1_200L
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.reels.slip", "cover=armed")
    }

    private fun applyStrictProfileCurtain(root: AccessibilityNodeInfo, window: Rect, bounds: Rect) {
        armProfileGeometryWatch()
        refreshMainReelsTabGuard(root)
        if (!instagramProfilePostsBlocked()) {
            instagramOverlay.updateStrictProfilePieceGuards(emptyList())
            supportCurtainReason = "profile"
            showInstagramCurtain(bounds, InstagramScreen.PROFILE)
            return
        }
        // Allowed profile layers (avatar preview, Edit Profile, highlights
        // picker) own the screen: the curtain yields so they stay fully
        // visible and interactive, and returns as soon as they close.
        if (instagramProfileCurtainMustYield(root)) {
            instagramOverlay.updateStrictProfilePieceGuards(emptyList())
            instagramOverlay.hide()
            return
        }
        // The profile photo, the numbers row and the Follow/Message buttons
        // stay native. Everything below them (grid) and the highlight tray
        // (which are rendered above the row in current Instagram layouts) are
        // covered, so "Öne çıkaranlar" can neither be seen nor entered.
        val rowBottom = instagramStrictProfileRowBottom(root, window)
        val floor = if (profileScrollFloor > window.top) profileScrollFloor else
            calculateProfileScrollFloor(root, window)
        if (rowBottom == null) {
            if (!hasVisibleProfileHeaderMarkers(root)) {
                // The profile shell is not in the tree: a full-screen layer
                // (hamburger menu, account switcher, other page) owns the
                // screen. Never mount a curtain over it.
                instagramOverlay.updateStrictProfilePieceGuards(emptyList())
                instagramOverlay.hide()
                return
            }
            // The row and its anchors are not measurable yet (fragments
            // building): never expose highlights or the grid while the header
            // rebuilds.
            instagramOverlay.updateStrictProfilePieceGuards(emptyList())
            supportCurtainReason = "profile"
            showInstagramCurtain(bounds, InstagramScreen.PROFILE)
            return
        }
        val bottom = stableMainNavigationTop(root, window, InstagramScreen.PROFILE)
            .takeIf { it > window.centerY() } ?: window.bottom
        val tray = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/highlights_tray")
            ?.takeIf { it.intersect(window) && it.height() in 1..dp(220) }
        val rowTop = rowBottom.coerceIn(floor, bottom - 1)
        if (tray != null && tray.top < rowTop) {
            // Highlights sit above the Follow/Message row: cover the tray with
            // its own opaque band and continue the curtain below the row, so
            // both "highlights covered" and "buttons native" hold at once.
            val trayBand = Rect(window.left, tray.top.coerceIn(floor, bottom - 1),
                window.right, tray.bottom.coerceIn(floor + 1, bottom))
            if (!trayBand.isEmpty) {
                instagramOverlay.updateStrictProfilePieceGuards(listOf(trayBand))
            } else {
                instagramOverlay.updateStrictProfilePieceGuards(emptyList())
            }
            supportCurtainReason = "profile"
            showInstagramCurtain(Rect(window.left, rowTop, window.right, bottom),
                InstagramScreen.PROFILE)
            return
        }
        // No tray above the row (or the tray renders below it): a single
        // curtain from the row's bottom covers the tray and the grid together.
        instagramOverlay.updateStrictProfilePieceGuards(emptyList())
        supportCurtainReason = "profile"
        showInstagramCurtain(Rect(window.left, rowTop, window.right, bottom),
            InstagramScreen.PROFILE)
    }

    /**
     * Bottom edge of the Follow/Message row anchors as the settled curtain
     * top; null while the row is unmeasured (full-cover period). The tab
     * container is the stable anchor in collapsed poses where the row id
     * leaves the tree.
     */
    private fun instagramStrictProfileRowBottom(
        root: AccessibilityNodeInfo,
        window: Rect
    ): Int? {
        var bottom: Int? = null
        for (id in listOf(
            "profile_header_actions_top_row", "row_profile_header_button_chaining"
        )) {
            findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/$id")?.let { found ->
                if (found.intersect(window) && found.height() in 1..dp(96)) {
                    bottom = minOf(bottom ?: found.bottom, found.bottom)
                }
            }
        }
        if (bottom != null) return bottom
        findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/profile_tabs_container")?.let { tabs ->
            if (tabs.intersect(window) && tabs.height() in 1..dp(150)) {
                bottom = tabs.top
            }
        }
        return bottom
    }

    /**
     * Strict must not expose the profile grid while Instagram has not yet
     * measured the pager. When the destination is already classified as
     * PROFILE and the header shell is visible, mount a conservative
     * application-space cover immediately and let the ensure loop refine it to
     * exact grid geometry. The wait-for-grid retries never cover the screen;
     * they only keep the curtain from lifting.
     */
    private fun coverStrictProfileBeforeGrid(root: AccessibilityNodeInfo, window: Rect): Boolean {
        if (!instagramProfilePostsBlocked()) return false
        if (!hasVisibleProfileHeaderMarkers(root)) return false
        if (hasVisibleProfileNativeSheet(root) || hasVisibleAboutAccountSurface(root)) return false
        if (hasFastStoryViewer(root) || hasFastMainReelsTabDestination(root) ||
            hasFastReelsViewer(root) || hasFastSinglePostViewer(root) ||
            hasFastNotificationsSurface(root)) return false
        profileWindowId = root.windowId
        val bounds = conservativeInstagramResumeBounds(root, window, InstagramScreen.PROFILE) ?: return false
        applyStrictProfileCurtain(root, window, bounds)
        armProfileCurtainEnsure()
        return instagramOverlay.visibleProfileBounds() != null
    }

    private var instagramSearchProfileProbeAt = 0L

    /**
     * Instagram reports the account-row click only 450-600 ms after the finger,
     * so the click path cannot precover the destination. While Search is the
     * verified surface, poll the profile header shell at a coarse cadence: if
     * the new fragment has already started building, the curtain goes up before
     * its grid publishes. Click events keep their normal routing; this only
     * reads three cached ids at most twice per second.
     */
    private fun probeInstagramSearchForProfile(root: AccessibilityNodeInfo, now: Long): Boolean {
        if (lastInstagramScreen != InstagramScreen.SEARCH_RESULTS ||
            instagramProfileIngress.pending || instagramProfileIngress.awaitingCurtainDraw) return false
        if (!instagramProfilePostsBlocked()) return false
        if (now - instagramSearchProfileProbeAt < 150L) return false
        instagramSearchProfileProbeAt = now
        val detected = igVisible(root, "row_profile_header_button_chaining") ||
            igVisible(root, "profile_header_follow_button")
        if (!detected) return false
        return coverStrictProfileBeforeGrid(root, instagramWindowBounds(root))
    }

    private fun profileGridBounds(root: AccessibilityNodeInfo, window: Rect): Rect? {
        val pager = cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/profile_viewpager")
            .filter { it.isVisibleToUser }
            .map { Rect().also(it::getBoundsInScreen) }.firstOrNull { !it.isEmpty } ?: return null
        if (!pager.intersect(window)) return null
        val headerBottom = listOf("profile_header_container", "profile_tabs_container", "profile_action_bar")
            .mapNotNull { findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/$it")?.bottom }.maxOrNull()
        val navigationTop = stableMainNavigationTop(root, window, InstagramScreen.PROFILE)
        // The grid container spans the full window width in every profile state; partial
        // widths are slide-in artifacts and would leave an uncovered side gap. Same for
        // the bottom edge: a partially laid-out pager measures short during rebuilds, so
        // the curtain always runs down to the navigation bar instead of trusting it.
        pager.left = window.left
        pager.right = window.right
        val vertical = InstagramProfileGeometry.clip(pager.top, pager.bottom, headerBottom, navigationTop)
            ?: return null
        pager.top = vertical.first
        pager.bottom = maxOf(vertical.second, navigationTop)
        return pager
    }

    private fun calculateProfileScrollFloor(
        root: AccessibilityNodeInfo,
        window: Rect
    ): Int {
        val actionBarBottom = listOf(
            "profile_action_bar", "profile_action_bar_container", "action_bar_root"
        ).mapNotNull { id ->
            findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/$id")
        }.filter { bounds ->
            bounds.width() >= window.width() / 2 &&
                bounds.height() in 1..dp(96) &&
                bounds.top < window.top + window.height() / 4 &&
                bounds.bottom <= window.top + window.height() / 3
        }.maxOfOrNull { it.bottom }
        return InstagramProfileGeometry.scrollFloor(
            window.top, actionBarBottom, statusBarInset(), dp(56))
            .coerceIn(window.top, window.bottom)
    }

    private fun refreshFastMainProtectedSurface(
        root: AccessibilityNodeInfo,
        window: Rect
    ): Boolean {
        fun visible(id: String): Boolean = cachedNodeLookup(root,
            "$INSTAGRAM_PACKAGE:id/$id").any { it.isVisibleToUser }
        fun selected(id: String): Boolean = cachedNodeLookup(root,
            "$INSTAGRAM_PACKAGE:id/$id").any { it.isVisibleToUser && isSelectedRecursive(it, 2) }
        fun tabBounds(id: String): Rect? = cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
            .firstOrNull { it.isVisibleToUser }?.let { Rect().also(it::getBoundsInScreen) }

        // Home is the leading tab and Profile the trailing one.
        tabBounds("feed_tab")?.let { home ->
            tabBounds("profile_tab")?.let { profile ->
                noteLayoutDirection(INSTAGRAM_PACKAGE, home, profile)
            }
        }
        val screen = InstagramFastSurfacePolicy.classify(
            homeSelected = selected("feed_tab"),
            searchSelected = selected("search_tab"),
            hasBackNavigation = visible("action_bar_button_back"),
            hasHomeHeader = visible("main_feed_action_bar"),
            hasExploreHeader = visible("explore_action_bar"),
            hasExploreGrid = visible("grid_card_layout_container")
        ) ?: return false

        clearDirectConversationEntryGuard()
        clearDirectDetailsScrollGuard()
        lastDirectConversationGuards.clear()
        directReelLaunchPendingUntil = 0L
        directDetailsLaunchPendingUntil = 0L
        directDetailsFallbackBackAt = 0L
        directNavigationUntil = 0L
        directNavigationSourceWindowId = -1
        profileAllowedDepartureUntil = 0L
        profileScrollPositions.clear()
        profileScrollCover.reset()
        profileWindowId = -1

        val mainReelsGuard = cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/clips_tab")
            .firstNotNullOfOrNull { node ->
                if (!node.isVisibleToUser) return@firstNotNullOfOrNull null
                Rect().also(node::getBoundsInScreen).takeIf { bounds ->
                    !bounds.isEmpty && bounds.intersect(window) && bounds.top >= window.centerY()
                }
            }
        instagramEntryTargets.clear()
        mainReelsGuard?.let { instagramEntryTargets.add(Rect(it) to true) }
        instagramOverlay.updateEntryGuards(mainReelsGuard?.let(::listOf) ?: emptyList(), isEnglish())
        cancelInstagramExit()
        observeInstagramScreen(screen, root.windowId)
        if (screen == InstagramScreen.HOME_FEED && instagramAlternateFeedActive) {
            // This shortcut is reached only when the selected Home tab and its
            // visible main header are both present and no visible Back exists.
            // Clear Following/Favorites geometry before measuring Home; the
            // shortcut returns before the general snapshot can clear it.
            instagramAlternateFeedActive = false
        }
        when (screen) {
            InstagramScreen.HOME_FEED ->
                showInstagramCurtain(calculateHomeFeedBounds(root, window), screen)
            InstagramScreen.EXPLORE ->
                showInstagramCurtain(calculateExploreBounds(root, window), screen)
            else -> return false
        }
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
        return true
    }

    private fun hasFastReelsViewer(
        root: AccessibilityNodeInfo,
        directLaunchPending: Boolean = false
    ): Boolean {
        if (!igVisible(root, "root_clips_layout") && !igVisible(root, "clips_viewer") &&
            !igVisible(root, "clips_viewer_view_pager") && !igVisible(root, "clips_view_pager")) return false
        val controlsVisible = igVisible(root, "clips_ufi") || igVisible(root, "clips_viewer_action_bar")
        val deliberateProfileOrigin = lastInstagramScreen in setOf(
            InstagramScreen.PROFILE, InstagramScreen.SAVED_COLLECTION) ||
            SystemClock.uptimeMillis() < instagramBalancedProfileReelIntentUntil ||
            SystemClock.uptimeMillis() < instagramBalancedCollectionReelIntentUntil
        if (!controlsVisible && !directLaunchPending && !deliberateProfileOrigin) return false
        // Instagram briefly clears the selected state of feed_tab while an
        // embedded feed video replaces its player tree. The Home action bar is
        // the more stable host signal. Requiring the selected tab here made a
        // normal feed video look like a full-screen Reel at the end of playback
        // and caused an erroneous GLOBAL_ACTION_BACK.
        val homeHostVisible = igVisible(root, "main_feed_action_bar")
        return InstagramEntryPolicy.isFastViewer(
            playerVisible = true,
            controlsVisible = controlsVisible,
            storyVisible = hasFastStoryViewer(root),
            homeHostVisible = homeHostVisible,
            backVisible = hasFastActionBarBack(root),
            directLaunchPending = directLaunchPending
        )
    }

    private fun isFreshNotificationViewerEvent(event: AccessibilityEvent): Boolean {
        val viewerIds = setOf(
            "root_clips_layout", "clips_viewer", "clips_viewer_view_pager",
            "clips_view_pager", "video_container", "clips_ufi",
            "clips_viewer_action_bar", "bottom_sheet_container",
            "layout_comment_thread_edittext_multiline", "comment_thread"
        )
        var node = event.source
        repeat(10) {
            val current = node ?: return false
            if (compactId(current.viewIdResourceName) in viewerIds) return true
            node = current.parent
        }
        return false
    }

    private fun dispatchNotificationViewerBackFromEvent(
        event: AccessibilityEvent,
        now: Long
    ) {
        // A single Instagram notification launch can publish several delayed
        // Reel/comment window events over a few seconds. Treat them as one
        // attempt; otherwise a late event starts a second Back sequence on
        // the next video.
        if (instagramNotificationEventLocked) return
        if (now - instagramNotificationLastEventExitAt < 5_000L) return
        if (instagramExitInProgress) return
        instagramNotificationLastEventExitAt = now
        instagramNotificationEventLocked = true
        instagramNotificationExitGeneration++
        var node = event.source
        var commentLayer = false
        repeat(10) {
            val current = node ?: return@repeat
            val id = compactId(current.viewIdResourceName)
            if (id in setOf(
                    "bottom_sheet_container", "layout_comment_thread_edittext_multiline",
                    "comment_composer_parent_updated", "comment_thread")) {
                commentLayer = true
            }
            node = current.parent
        }
        instagramNotificationContentLaunchUntil = 0L
        instagramNotificationExitHoldUntil = now + 10_000L
        instagramNotificationReelExitIssued = true
        // A first GLOBAL_ACTION_BACK can be accepted while Instagram's
        // player animation is still settling, even when no comment sheet is
        // visible. Keep one guarded fallback for every event-proven viewer;
        // the worker cancels as soon as Notifications is the active root.
        instagramNotificationReelSecondBackIssued = false
        instagramNotificationCommentLayerObserved = commentLayer
        instagramNotificationViewerDetectedAt = now
        instagramExitInProgress = true
        instagramExitFromNotifications = true
        instagramExitFromDirectConversation = false
        instagramExitTreeQuietUntil = now + INSTAGRAM_EXIT_TREE_QUIET_MS
        val clickedViewerBack = performViewerBackFromEvent(event)
        val accepted = clickedViewerBack
        instagramNotificationBackCount = if (accepted) 1 else 0
        Log.d(TAG, "IG_NOTIFICATION_EVENT_REEL_EXIT commentLayer=$commentLayer " +
            "viewerBack=$clickedViewerBack eventAgeMs=${now - event.eventTime}")
        // Always schedule one fresh-window verification. ACTION_CLICK may
        // return true while Instagram is still animating and has not changed
        // the viewer state; the worker performs at most one more targeted
        // click and never uses global Back.
        scheduleFastNotificationSecondBack(initialDelayMs = if (commentLayer) 90L else 300L)
        queueInstagramScan(INSTAGRAM_EXIT_TREE_QUIET_MS)
    }

    private fun performViewerBackFromEvent(event: AccessibilityEvent): Boolean {
        rootInActiveWindow?.takeIf {
            it.packageName?.toString() == INSTAGRAM_PACKAGE &&
                !hasFastNotificationsSurface(it) &&
                (hasFastReelsViewer(it, directLaunchPending = true) ||
                    hasFastCommentSheetInRoot(it) || hasFastSinglePostViewer(it))
        }?.let {
            if (performViewerBackFromRoot(it)) return true
        }
        var node = event.source
        repeat(12) {
            val current = node ?: return false
            val back = runCatching {
                current.findAccessibilityNodeInfosByViewId(
                    "$INSTAGRAM_PACKAGE:id/action_bar_button_back")
                    .firstOrNull { candidate ->
                        candidate.isVisibleToUser && candidate.isClickable
                    }
            }.getOrNull()
            if (back?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            node = current.parent
        }
        return false
    }

    private fun performViewerBackFromRoot(root: AccessibilityNodeInfo): Boolean {
        val byId = runCatching {
            root.findAccessibilityNodeInfosByViewId(
                "$INSTAGRAM_PACKAGE:id/action_bar_button_back")
                .firstOrNull { candidate ->
                    candidate.isVisibleToUser && candidate.isClickable
                }
        }.getOrNull()
        val back = byId ?: findInstagramTopLeftBack(root, instagramWindowBounds(root))
        if (back?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
        val bounds = back?.let { Rect().also(it::getBoundsInScreen) }
            ?.takeIf { !it.isEmpty }
            ?: return false
        val path = Path().apply {
            moveTo(bounds.exactCenterX(), bounds.exactCenterY())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        return runCatching { dispatchGesture(gesture, null, null) }.getOrDefault(false)
    }

    /**
     * Instagram's profile Reel viewer uses a semantic ImageView labelled
     * "Back" on some builds instead of the action_bar_button_back id. Treat
     * both forms as the same navigation affordance; otherwise a valid
     * Profile -> Reel launch is mistaken for the blocked Reels tab.
     */
    /**
     * The id-less Back arrow of a single-Reel viewer, found through its
     * button group. Used only as Balanced ingress evidence; exit decisions
     * keep [hasFastActionBarBack].
     */
    private fun hasReelViewerStartBack(root: AccessibilityNodeInfo): Boolean {
        val window = instagramWindowBounds(root)
        val windowSample = window.toInstagramGeometrySample()
        return cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/${InstagramReelViewerBack.startButtonsId}")
            .filter { it.isVisibleToUser }
            .any { group ->
                // The arrow is a direct child or wrapped once (LinearLayout > ImageView).
                val pending = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
                for (i in 0 until minOf(group.childCount, 6)) group.getChild(i)?.let { pending.add(it to 1) }
                var found = false
                while (pending.isNotEmpty() && !found) {
                    val (node, depth) = pending.removeFirst()
                    if (!node.isVisibleToUser) continue
                    val bounds = Rect().also(node::getBoundsInScreen)
                    found = InstagramReelViewerBack.isBack(
                        clickable = node.isClickable,
                        hasText = !node.text.isNullOrBlank(),
                        bounds = leftToRight(bounds, window, INSTAGRAM_PACKAGE).toInstagramGeometrySample(),
                        window = windowSample)
                    if (!found && depth < 2) {
                        for (i in 0 until minOf(node.childCount, 6)) node.getChild(i)?.let { pending.add(it to depth + 1) }
                    }
                }
                found
            }
    }

    private fun hasFastActionBarBack(root: AccessibilityNodeInfo): Boolean =
        igVisible(root, "action_bar_button_back") ||
            findInstagramTopLeftBack(root, instagramWindowBounds(root)) != null

    private fun hasFastSavedCollectionReelList(root: AccessibilityNodeInfo): Boolean =
        igVisible(root, "layout_listview_parent_container") &&
            igVisible(root, "video_container") &&
            !igVisible(root, "clips_viewer_view_pager") &&
            !igVisible(root, "clips_view_pager")

    private fun hasFastMainReelsTabDestination(root: AccessibilityNodeInfo): Boolean {
        val reelsSelected = igSelected(root, "clips_tab")
        if (!reelsSelected) return false
        val anotherMainTabSelected = listOf(
            "feed_tab", "direct_tab", "search_tab", "profile_tab"
        ).any { igSelected(root, it) }
        return InstagramEntryPolicy.isMainReelsTabDestination(
            reelsSelected = true,
            anotherMainTabSelected = anotherMainTabSelected,
            hasBackNavigation = igVisible(root, "action_bar_button_back")
        )
    }

    private fun hasFastStoryViewer(root: AccessibilityNodeInfo): Boolean =
        InstagramStoryIdentity.isViewer { id ->
            cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
                .any { it.isVisibleToUser }
        }

    private var instagramStoryLaunchUntil = 0L
    private var instagramStoryLaunchEventDeadline = 0L
    private var profileWatchQuietUntil = 0L
    private var instagramModalViewerWindowId = -1
    private var instagramModalViewerSeenAt = 0L

    /**
     * Strict Story exit without remote queries. The tapped avatar's label says
     * it opens a Story, and the viewer arrives as a modal-activity window
     * event. While that window starts, Instagram's UI thread answers no
     * accessibility query for 1-2 s, so the tree-based classifier saw the Story
     * only after it had played for that long. Back is sent on the window event.
     */
    private fun handleStrictInstagramStoryLaunch(event: AccessibilityEvent, now: Long): Boolean {
        if (!instagramStoriesBlocked()) return false
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val fresh = now - event.eventTime in 0L..1_500L
                // The avatar's own id is the evidence (one source read, the
                // same click-time read the account-entry path already does);
                // its localized label ("X's story") is never read.
                val storySource = fresh &&
                    lastInstagramScreen in setOf(InstagramScreen.PROFILE, InstagramScreen.SEARCH_RESULTS) &&
                    InstagramStoryIdentity.isStoryLaunchSource(compactId(event.source?.viewIdResourceName))
                instagramStoryLaunchUntil = if (storySource) {
                    now + INSTAGRAM_STORY_LAUNCH_WINDOW_MS
                } else 0L
                instagramStoryLaunchEventDeadline = if (instagramStoryLaunchUntil != 0L) {
                    event.eventTime + INSTAGRAM_STORY_LAUNCH_WINDOW_MS
                } else 0L
                // Keep the profile geometry watch off the starting viewer window.
                if (instagramStoryLaunchUntil != 0L) profileWatchQuietUntil = instagramStoryLaunchUntil
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (event.className?.toString()?.endsWith("TransparentModalActivity") == true) {
                    // Story and Reel viewers open in this window. Avatars in
                    // the Direct inbox send no click event (no label), so the
                    // classifier verifies the window now; its arrival also
                    // proves the transition is far enough for Back to land.
                    instagramModalViewerWindowId = event.windowId
                    instagramModalViewerSeenAt = now
                    armDirectModalCover(event.windowId, now)
                    queueInstagramScan(0L)
                }
                // Compare event timestamps: a late-delivered window event still
                // belongs to the tap that produced it.
                if (event.eventTime >= instagramStoryLaunchEventDeadline) return false
                if (!InstagramStoryIdentity.isStoryViewerWindowClass(event.className)) {
                    // Something else opened (expired Story -> profile, a chat):
                    // stop deferring scans so that surface is classified now.
                    instagramStoryLaunchUntil = 0L
                    instagramStoryLaunchEventDeadline = 0L
                    profileWatchQuietUntil = 0L
                    return false
                }
                instagramStoryLaunchUntil = 0L
                instagramStoryLaunchEventDeadline = 0L
                profileWatchQuietUntil = now + 400L
                val accepted = performGlobalAction(GLOBAL_ACTION_BACK)
                if (instagramBlockedAttempt.acceptedIntervention(accepted)) {
                    recordIntervention(INSTAGRAM_PACKAGE, System.currentTimeMillis())
                }
                Log.d(TAG, "IG_STORY_FAST_EXIT accepted=$accepted window=${event.windowId}")
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
                    this, "instagram.story.fast-exit", "accepted=$accepted window=${event.windowId}")
                // The regular classifier still verifies the return (and exits a
                // Story that survived Back) once the modal window settles.
                queueInstagramScan(250L)
                return true
            }
        }
        return false
    }

    private var directModalCoverWindowId = -1
    private var directModalCoverUntil = 0L
    private var directModalCoverExiting = false
    private val directModalCoverTimeout = Runnable { releaseDirectModalCover("timeout") }

    /**
     * A shared Reel in a Strict chat sends no click event, so there is no label
     * to act on before its viewer appears. The modal window event arrives with
     * the first viewer frames, ~160 ms before the classifier can query the
     * frozen viewer tree. Cover the display at once (no remote query); the
     * classifier then either exits the viewer or proves an allowed surface.
     */
    private fun armDirectModalCover(windowId: Int, now: Long) {
        if (!instagramStoriesBlocked() ||
            lastInstagramScreen != InstagramScreen.DIRECT_MESSAGES) return
        instagramOverlay.showReelsSlipCover(currentDisplayBounds())
        directModalCoverWindowId = windowId
        directModalCoverUntil = now + DIRECT_MODAL_COVER_MAX_MS
        directModalCoverExiting = false
        mainHandler.removeCallbacks(directModalCoverTimeout)
        mainHandler.postDelayed(directModalCoverTimeout, DIRECT_MODAL_COVER_MAX_MS)
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.dm.modal-cover", "armed window=$windowId")
    }

    private fun observeDirectModalCover(screen: InstagramScreen, windowId: Int) {
        if (directModalCoverWindowId == -1) return
        when {
            screen == InstagramScreen.REELS || screen == InstagramScreen.STORY ||
                screen == InstagramScreen.COMMENTS_OR_DETAIL -> directModalCoverExiting = true
            screen == InstagramScreen.UNKNOWN -> Unit
            // The modal itself is an allowed surface (profile, camera...).
            windowId == directModalCoverWindowId -> releaseDirectModalCover("allowed")
            // Back from the blocked viewer landed on the chat again.
            directModalCoverExiting -> releaseDirectModalCover("returned")
            // A stale chat frame right after the modal event proves nothing.
            SystemClock.uptimeMillis() >= directModalCoverUntil -> releaseDirectModalCover("expired")
        }
    }

    private fun releaseDirectModalCover(reason: String) {
        if (directModalCoverWindowId == -1) return
        directModalCoverWindowId = -1
        directModalCoverUntil = 0L
        directModalCoverExiting = false
        mainHandler.removeCallbacks(directModalCoverTimeout)
        instagramOverlay.hideReelsSlipCover()
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.dm.modal-cover", "released reason=$reason")
    }

    private fun instagramStoriesBlocked(): Boolean =
        InstagramProfileInteractionPolicy.exitsStoryViewer(
            ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))

    private fun instagramProfilePostsBlocked(): Boolean =
        InstagramProfileInteractionPolicy.blocksProfilePosts(
            ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))

    private fun allowBalancedInstagramProfilePost(root: AccessibilityNodeInfo): Boolean {
        val mode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        val now = SystemClock.uptimeMillis()
        var confirmed = instagramBalancedProfilePost.confirm(mode, now)
        // Some Instagram builds replace the grid without publishing a click
        // event for the thumbnail. A verified Profile -> static Post transition
        // is still an intentional profile selection; no other source receives
        // this fallback because its last confirmed screen is not PROFILE.
        if (!confirmed && InstagramProfileInteractionPolicy.allowsProfilePostFallback(
                mode, lastInstagramScreen)) {
            instagramBalancedProfilePost.arm(
                mode, verifiedProfile = true, profileThumbnail = true, now = now)
            confirmed = instagramBalancedProfilePost.confirm(mode, now)
            if (confirmed) Log.d(TAG, "IG_BALANCED_PROFILE_POST_PROFILE_FALLBACK")
        }
        if (!confirmed) return false
        stopProfileCurtainEnsure()
        clearDirectConversationEntryGuard()
        clearDirectDetailsScrollGuard()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        hideInstagramContentOverlay()
        cancelInstagramExit()
        observeInstagramScreen(InstagramScreen.COMMENTS_OR_DETAIL, root.windowId)
        Log.d(TAG, "IG_BALANCED_PROFILE_POST_ALLOWED")
        return true
    }

    private fun allowBalancedInstagramNotificationViewer(
        root: AccessibilityNodeInfo,
        screen: InstagramScreen
    ): Boolean {
        if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) !=
            ProtectionMode.BALANCED) return false
        if (screen != InstagramScreen.REELS && screen != InstagramScreen.COMMENTS_OR_DETAIL) {
            return false
        }
        if (screen == InstagramScreen.REELS) {
            if (instagramReelsSession.exiting) return false
            val wasWatching = instagramReelsSession.watching
            if (instagramReelsSession.observe(ProtectionMode.BALANCED, viewerVisible = true) ==
                InstagramReelsDecision.EXIT) return false
            // Same as every other single-Reel entry: the next-video scroll
            // gate only accepts pager events after this verification time.
            // Without it every swipe was treated as foreign and the user
            // could scroll a notification Reel endlessly.
            if (!wasWatching) instagramReelsVerifiedAt = SystemClock.uptimeMillis()
            instagramReelsVerifiedWindowId = root.windowId
            instagramBalancedReelOrigin = InstagramScreen.NOTIFICATIONS
        } else {
            instagramBalancedNotificationPostWatching = true
        }
        // The notification entry grants exactly this one destination. It does
        // not grant a feed, pager continuation, or any later notification row.
        instagramNotificationContentLaunchUntil = 0L
        instagramNotificationExitHoldUntil = 0L
        clearDirectConversationEntryGuard()
        clearDirectDetailsScrollGuard()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        hideInstagramContentOverlay()
        cancelInstagramExit()
        observeInstagramScreen(screen, root.windowId)
        Log.d(TAG, "IG_BALANCED_NOTIFICATION_ITEM_ALLOWED screen=$screen")
        return true
    }

    private fun allowBalancedInstagramReel(root: AccessibilityNodeInfo): Boolean {
        val mode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        // A latched next-video exit needs no additional native tree queries.
        if (instagramReelsSession.exiting) return false
        // Instagram publishes the selected main-Reels chrome after the first
        // frame even for a Reel deliberately opened from DM or a profile. Once
        // that first frame has positive ingress identity, retain the session;
        // its pager-motion gate remains responsible for exiting on video two.
        val rebind = SystemClock.uptimeMillis() < instagramReelWindowRebindUntil
        if (InstagramBalancedReelIngressPolicy.keepsVerifiedSession(
                mode, instagramReelsSession.watching, instagramReelsSession.exiting,
                viewerWindowId = root.windowId, verifiedWindowId = instagramReelsVerifiedWindowId,
                rebindAllowed = rebind)) {
            if (root.windowId != instagramReelsVerifiedWindowId) {
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                    "instagram.balanced.reel",
                    "rebound from=$instagramReelsVerifiedWindowId to=${root.windowId}")
                instagramReelsVerifiedWindowId = root.windowId
                instagramReelWindowRebindUntil = 0L
                // The next-video gate matches pager events against the state
                // machine's window; move it to the recreated viewer as well.
                observeInstagramScreen(InstagramScreen.REELS, root.windowId)
            } else if (instagramStateMachine.currentWindowId != root.windowId) {
                // Back from a viewer that was blocked on top (an audio-page
                // Reel): the state machine still points at that window, so
                // the next-video gate would skip every pager event here.
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                    "instagram.balanced.reel", "resumed from=${instagramStateMachine.currentWindowId} " +
                        "to=${root.windowId}")
                observeInstagramScreen(InstagramScreen.REELS, root.windowId)
            }
            return true
        }
        // A Reel's own bottom sheet (options, audio row) can open in a window
        // of its own that still reports the Reel's player underneath. It is a
        // layer over the allowed Reel, not another Reel: keep the session and
        // leave the verified window as it is.
        if (mode == ProtectionMode.BALANCED && instagramReelsSession.watching &&
            !instagramReelsSession.exiting && InstagramReelsIdentity.isSheetOverViewer(
                bottomSheetVisible = igVisible(root, "bottom_sheet_container") ||
                    igVisible(root, "layout_container_bottom_sheet"),
                ownPagerVisible = InstagramReelsIdentity.pagerIds.any { igVisible(root, it) })) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.balanced.reel", "sheet-over verified=$instagramReelsVerifiedWindowId " +
                    "viewer=${root.windowId}")
            return true
        }
        if (instagramReelsSession.watching && ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "instagram.balanced.reel",
                "other-viewer verified=$instagramReelsVerifiedWindowId viewer=${root.windowId}")
        }
        val shadeOrigin = if (instagramReelShadeHold.isHeld && mode == ProtectionMode.BALANCED) {
            instagramReelShadeHold.take(root.windowId, SystemClock.uptimeMillis())
        } else {
            instagramReelShadeHold.clear()
            null
        }
        if (shadeOrigin == null && !instagramReelsSession.watching &&
            InstagramNotificationShadePolicy.isProtectedFeedOrigin(lastInstagramScreen)) {
            instagramReelsSession.observe(mode,
                viewerVisible = true, feedEntry = true)
            SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_REEL_DENIED,
                mapOf("reason" to "feed-origin", "from" to lastInstagramScreen))
            return false
        }
        if (instagramStoriesBlocked() || hasFastMainReelsTabDestination(root)) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.balanced.reel", "denied=main-reels-tab last=$lastInstagramScreen")
            if (!instagramStoriesBlocked()) SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_REEL_DENIED,
                mapOf("reason" to "main-reels-tab", "from" to lastInstagramScreen))
            return false
        }
        val now = SystemClock.uptimeMillis()
        val originWindowId = if (lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES) {
            directConversationSurfaceWindowId.takeIf { it >= 0 }
                ?: instagramStateMachine.currentWindowId
        } else {
            instagramStateMachine.currentWindowId
        }
        val tabBarVisible = igVisible(root, "tab_bar")
        val selectedTab = if (tabBarVisible) selectedInstagramMainTab(root) else null
        val mainTabBarVisible = tabBarVisible &&
            !InstagramBalancedReelIngressPolicy.tabBarHostsSingleReel(selectedTab, lastInstagramScreen)
        // A late profile-grid tap stands in for the profile the service could
        // not classify in time; only for a viewer other than the allowed one.
        val lateProfileTap = instagramBalancedLateProfileTap &&
            now < instagramBalancedProfileReelIntentUntil &&
            lastInstagramScreen == InstagramScreen.REELS &&
            root.windowId != instagramReelsVerifiedWindowId
        if (now >= instagramBalancedProfileReelIntentUntil) instagramBalancedLateProfileTap = false
        val ingressOrigin = if (lateProfileTap) InstagramScreen.PROFILE else lastInstagramScreen
        val ingress = if (shadeOrigin != null) null else InstagramBalancedReelIngressPolicy.resolve(
            mode = mode,
            previousScreen = ingressOrigin,
            originWindowId = originWindowId,
            viewerWindowId = root.windowId,
            profileReelIntentWindowId = instagramBalancedProfileReelIntentWindowId,
            profileReelIntentPending = now < instagramBalancedProfileReelIntentUntil,
            collectionReelIntentWindowId = instagramBalancedCollectionReelIntentWindowId,
            collectionReelIntentPending = now < instagramBalancedCollectionReelIntentUntil,
            reelsTabTapLatched = now < instagramReelsTabTapUntil,
            mainTabBarVisible = mainTabBarVisible,
            actionBarBackVisible = hasFastActionBarBack(root) || hasReelViewerStartBack(root),
            directIntentPending = now < directReelLaunchPendingUntil,
            notificationItemWatching = instagramBalancedNotificationPostWatching
        )
        if (ingress == InstagramBalancedReelIngress.NONE) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.balanced.reel", "denied=no-ingress last=$lastInstagramScreen " +
                    "tabBar=$tabBarVisible selectedTab=$selectedTab back=${hasFastActionBarBack(root)} " +
                    "startBack=${hasReelViewerStartBack(root)} " +
                    "viewer=${root.windowId} intent=$instagramBalancedProfileReelIntentWindowId")
            SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_REEL_DENIED, mapOf(
                "reason" to "no-ingress", "from" to ingressOrigin, "tabbar" to tabBarVisible,
                "back" to (hasFastActionBarBack(root) || hasReelViewerStartBack(root)),
                "tab" to selectedTab))
            return false
        }
        val wasWatching = instagramReelsSession.watching
        if (instagramReelsSession.observe(mode, viewerVisible = true) ==
            InstagramReelsDecision.EXIT) return false
        if (!wasWatching) instagramReelsVerifiedAt = now
        instagramReelsVerifiedWindowId = root.windowId
        instagramBalancedReelOrigin = when {
            shadeOrigin != null -> shadeOrigin
            ingress == InstagramBalancedReelIngress.NOTIFICATION_COMMENT_SHEET -> InstagramScreen.NOTIFICATIONS
            else -> ingressOrigin
        }
        instagramBalancedLateProfileTap = false
        clearDirectConversationEntryGuard()
        clearDirectDetailsScrollGuard()
        lastDirectConversationGuards.clear()
        instagramEntryTargets.clear()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        hideInstagramContentOverlay()
        cancelInstagramExit()
        directReelLaunchPendingUntil = 0L
        instagramBalancedProfileReelIntentWindowId = -1
        instagramBalancedProfileReelIntentUntil = 0L
        instagramBalancedCollectionReelIntentWindowId = -1
        instagramBalancedCollectionReelIntentUntil = 0L
        Log.d(TAG, "IG_BALANCED_REEL_ALLOWED ingress=${ingress ?: "return"}")
        SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_REEL_ALLOWED,
            mapOf("via" to (ingress?.name ?: "return"), "from" to (shadeOrigin ?: ingressOrigin)))
        if (shadeOrigin != null && ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(
            this, "instagram.balanced.reel", "restored=return origin=$shadeOrigin")
        observeInstagramScreen(InstagramScreen.REELS, root.windowId)
        return true
    }

    private fun handleBalancedInstagramReelScroll(event: AccessibilityEvent): Boolean {
        if (instagramStoriesBlocked() || !instagramReelsSession.watching) {
            if (ProtectionFlightRecorder.ENABLED && !instagramStoriesBlocked()) ProtectionFlightRecorder.record(this,
                "instagram.balanced.reel.scroll", "skipped=no-session last=$lastInstagramScreen")
            return false
        }
        val started = SystemClock.uptimeMillis()
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE ||
            (lastInstagramScreen != InstagramScreen.REELS &&
                !(instagramBalancedReelOrigin == InstagramScreen.SAVED_COLLECTION &&
                    instagramReelsSession.watching && hasFastSavedCollectionReelList(root))) ||
            // The allowed Reel's own window, not the state machine's: a viewer
            // blocked on top may have moved the latter, and then every swipe
            // here would have been skipped (endless scrolling).
            !InstagramReelsIdentity.isCurrentSessionEvent(allowedReelWindowId(),
                event.windowId, root.windowId, event.eventTime, instagramReelsVerifiedAt, started)) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.balanced.reel.scroll", "skipped=session-mismatch last=$lastInstagramScreen " +
                    "state=${instagramStateMachine.currentWindowId} event=${event.windowId} root=${root.windowId} " +
                    "eventAt=${event.eventTime} verifiedAt=$instagramReelsVerifiedAt")
            return false
        }
        val ids = linkedSetOf<String>()
        var node = event.source
        var depth = 0
        while (node != null && depth++ < 12) {
            val current = node
            val id = compactId(current.viewIdResourceName)
            ids.add(id)
            // Exact pager or comment ancestry is sufficient; walking up to the
            // window root adds remote calls but no stronger identity evidence.
            if (id in InstagramReelsIdentity.pagerIds || id in InstagramReelsIdentity.safeSheetIds ||
                id == "bottom_sheet_container" || id == "layout_container_bottom_sheet") break
            node = current.parent
        }
        val savedCollectionListScroll = instagramBalancedReelOrigin ==
            InstagramScreen.SAVED_COLLECTION &&
            (InstagramReelsIdentity.isSavedCollectionListPath(ids) ||
                hasFastSavedCollectionReelList(root))
        if (!savedCollectionListScroll && !InstagramReelsIdentity.isVideoPagerPath(ids)) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.balanced.reel.scroll", "skipped=not-pager origin=$instagramBalancedReelOrigin " +
                    "class=${event.className} ids=${ids.joinToString(",")}")
            return false
        }
        if (instagramReelsMotionGeneration != instagramReelsSession.generation) {
            instagramReelsPagerMotion.reset()
            instagramReelsMotionGeneration = instagramReelsSession.generation
        }
        val dx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaX else 0
        val dy = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaY else 0
        val movement = if (savedCollectionListScroll) {
            // Saved's feed-style viewer reports a normal RecyclerView scroll,
            // so it has no clips pager identity. Any vertical movement here is
            // the attempted advance to another saved item and must close the
            // single-Reel session instead.
            true
        } else {
            instagramReelsPagerMotion.observe(dx, dy, event.fromIndex, event.scrollY)
        }
        if (!movement && !instagramReelsSession.exiting) return true
        // Retain fresh comment-layer checks even on the low-latency path. A
        // closing sheet may move its background player without a video swipe.
        val safeSheetOpen = InstagramReelsIdentity.safeSheetIds.any { id ->
            root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").any { it.isVisibleToUser }
        }
        val decision = instagramReelsSession.observe(ProtectionMode.BALANCED, viewerVisible = true,
            safeSheetOpen = safeSheetOpen, pagerScroll = true, verticalMovement = movement)
        if (decision == InstagramReelsDecision.EXIT) {
            Log.d(TAG, "IG_SINGLE_REEL_NEXT_VIDEO_EXIT generation=${instagramReelsSession.generation} " +
                "eventAgeMs=${started - event.eventTime} decisionMs=${SystemClock.uptimeMillis() - started}")
            SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_REEL_NEXT_VIDEO)
            // The verified pager belongs to the already-confirmed foreground
            // Reel. Issue Back directly instead of querying an absent control.
            exitBlockedViewer(root, instagramWindowBounds(root), InstagramScreen.REELS, useGlobalBackOnly = true)
        }
        return true
    }

    private fun hasFastNotificationsSurface(root: AccessibilityNodeInfo): Boolean =
        listOf(
            // Instagram 454 has activity_feed_root: check it first.
            "activity_feed_root", "activity_feed", "newsfeed_you",
            "newsfeed_recycler", "notifications_recycler",
            "follow_requests_header"
        ).any { id -> igVisible(root, id) }

    private fun hasFastSinglePostViewer(
        root: AccessibilityNodeInfo,
        chosenFromProfile: Boolean = false
    ): Boolean {
        // Without a deliberate origin a post list cannot be told from the
        // Following feed in a language-free way; skip the remote lookups.
        if (!chosenFromProfile) return false
        return InstagramPostIdentity.isFastViewer(
            chosen = true,
            hasBack = igVisible(root, "action_bar_button_back"),
            hasHomeHeader = igVisible(root, "main_feed_action_bar"),
            hasPostHeader = igVisible(root, "row_feed_profile_header"),
            hasPostMedia = igVisible(root, "row_feed_photo_imageview") || igVisible(root, "media_group") ||
                igVisible(root, "row_feed_view_group_buttons"))
    }

    /**
     * Balanced only: the user chose a thumbnail on a verified profile or
     * collection (or the profile -> post fallback applies), or opened a post
     * from a notification. This is how a localized post page is told apart
     * from the Following/Favorites feeds without reading its title.
     */
    private fun instagramProfilePostChosen(now: Long): Boolean {
        val mode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        if (mode != ProtectionMode.BALANCED) return false
        return instagramBalancedProfilePost.isChosen(now) || instagramBalancedNotificationPostWatching ||
            InstagramProfileInteractionPolicy.allowsProfilePostFallback(mode, lastInstagramScreen)
    }

    private fun hasFastCommentSheet(root: AccessibilityNodeInfo): Boolean {
        if (hasFastCommentSheetInRoot(root)) return true
        return windows.any { window ->
            runCatching { window.root?.let(::hasFastCommentSheetInRoot) == true }
                .getOrDefault(false)
        }
    }

    private fun hasFastCommentSheetInRoot(candidate: AccessibilityNodeInfo): Boolean {
        // Current Instagram builds expose the notification comment sheet with
        // stable composer IDs while the underlying video remains a generic
        // main_list_view. Prefer these IDs over text matching: it avoids a
        // full tree walk and makes the second Back event immediate.
        val hasCommentComposer =
            igVisible(candidate, "layout_comment_thread_edittext_multiline") ||
                igVisible(candidate, "comment_composer_parent_updated") ||
                igVisible(candidate, "comment_composer_animated_image_picker_button")
        if (igVisible(candidate, "bottom_sheet_container") && hasCommentComposer) return true
        if (listOf(
                "comments_recycler_view", "comments_recycler", "comment_thread",
                "layout_comment_thread", "comment_list"
            ).any { id -> igVisible(candidate, id) }) return true
        // Comment ids only; the reply composer's localized hint ("Replying to")
        // matched Turkish/English alone.
        return false
    }

    private fun findInstagramNotificationViewerRoot(
        fallback: AccessibilityNodeInfo
    ): Pair<AccessibilityNodeInfo, InstagramScreen>? {
        val candidates = buildList {
            // Prefer the currently focused/active application window. The
            // Notifications tree can remain in AccessibilityWindows after a
            // Reel viewer has been opened; choosing it first creates a false
            // "returned" result and makes later retries race the new viewer.
            windows.filter { window ->
                window.type == AccessibilityWindowInfo.TYPE_APPLICATION &&
                    (window.isFocused || window.isActive)
            }.forEach { window ->
                runCatching { window.root }.getOrNull()?.let { root ->
                    if (root.packageName?.toString() == INSTAGRAM_PACKAGE) add(root)
                }
            }
            windows.filter { window ->
                window.type == AccessibilityWindowInfo.TYPE_APPLICATION &&
                    !window.isFocused && !window.isActive
            }.forEach { window ->
                runCatching { window.root }.getOrNull()?.let { root ->
                    if (root.packageName?.toString() == INSTAGRAM_PACKAGE) add(root)
                }
            }
            add(fallback)
        }.distinctBy { it.windowId }
        return candidates.firstNotNullOfOrNull { candidate ->
            when {
                hasFastReelsViewer(candidate, directLaunchPending = true) ->
                    candidate to InstagramScreen.REELS
                hasFastPostViewer(candidate) || hasFastCommentSheetInRoot(candidate) ->
                    candidate to InstagramScreen.COMMENTS_OR_DETAIL
                else -> null
            }
        }
    }

    private fun hasFastReelPreview(root: AccessibilityNodeInfo): Boolean {
        val previewChrome = igVisible(root, "feed_preview_keep_watching_backdrop") ||
            igVisible(root, "feed_preview_keep_watching_button") ||
            igVisible(root, "feed_preview_bottom_cta_container")
        return previewChrome && igVisible(root, "video_container") &&
            igVisible(root, "action_bar_button_back")
    }

    private fun hasVisibleDirectDetailsGrid(root: AccessibilityNodeInfo): Boolean =
        igVisible(root, "thread_details_pager") && igVisible(root, "tab_layout") &&
            igVisible(root, "shared_media_list")

    private fun isDirectDetailsMediaIntent(source: AccessibilityNodeInfo?): Boolean {
        if (lastInstagramScreen != InstagramScreen.DIRECT_SHARED_MEDIA) return false
        if (sourcePathContains(source, "image_button", "media_set_row_content_identifier")) return true
        val curtain = instagramOverlay.visibleCurtain()
            ?.takeIf { it.first == InstagramScreen.DIRECT_SHARED_MEDIA }?.second ?: return false
        val sourceBounds = source?.let { Rect().also(it::getBoundsInScreen) } ?: return false
        return !sourceBounds.isEmpty && curtain.contains(sourceBounds.centerX(), sourceBounds.centerY())
    }

    private fun isDirectReelIntent(source: AccessibilityNodeInfo?): Boolean {
        if (lastInstagramScreen != InstagramScreen.DIRECT_MESSAGES) return false
        val sourceBounds = source?.let { Rect().also(it::getBoundsInScreen) }
        val insideKnownGuard = sourceBounds?.takeUnless(Rect::isEmpty)?.let { bounds ->
            val display = currentDisplayBounds()
            lastDirectConversationGuards.any { guard ->
                val expandedGuard = Rect(guard).apply {
                    inset(-dp(8), -dp(8))
                }
                expandedGuard.intersect(display) &&
                    expandedGuard.contains(bounds.centerX(), bounds.centerY())
            }
        } == true
        val ancestryIds = linkedSetOf<String>()
        val ancestryLabels = linkedSetOf<String>()
        var hasReelDescendant = false
        var current = source
        repeat(8) {
            val node = current ?: return@repeat
            val id = compactId(node.viewIdResourceName)
            val text = node.text?.toString().orEmpty()
            val description = node.contentDescription?.toString().orEmpty()
            if (id.isNotEmpty()) ancestryIds.add(id)
            if (text.isNotBlank()) ancestryLabels.add(text)
            if (description.isNotBlank()) ancestryLabels.add(description)
            if (id in setOf("message_content_portrait_xma_container",
                    "message_content_generic_xma_container")) {
                hasReelDescendant = hasReelDescendant ||
                    node.findAccessibilityNodeInfosByViewId(
                        "$INSTAGRAM_PACKAGE:id/reel_share_item_view")
                        .any { it.isVisibleToUser }
            }
            hasReelDescendant = hasReelDescendant ||
                node.findAccessibilityNodeInfosByViewId(
                    "$INSTAGRAM_PACKAGE:id/direct_reel_share_legibility_gradient_footer")
                    .any { it.isVisibleToUser }
            current = node.parent
        }
        return InstagramEntryPolicy.isDirectReelIntent(
            ancestryIds, ancestryLabels, insideKnownGuard, hasReelDescendant)
    }

    /**
     * The Direct inbox's thread list: the old id, or Instagram 454's generic
     * list_container under the inbox's own header (InstagramSurfacePolicy).
     */
    private fun instagramInboxListBounds(
        root: AccessibilityNodeInfo,
        // The renamed list costs two header lookups. Callers outside the inbox
        // (every Home/Explore scan passes through the inbox shortcut) skip it,
        // so those scans keep their previous cost.
        lookForRenamedList: Boolean = true
    ): Rect? =
        findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/${InstagramSurfacePolicy.INBOX_LIST_ID}")
            ?: if (lookForRenamedList &&
                InstagramSurfacePolicy.INBOX_HEADER_IDS.any { igVisible(root, it) }) {
                findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/list_container")
            } else null

    private fun hasFastDirectSafeReturn(
        root: AccessibilityNodeInfo,
        // Off for the search-left precover: leaving Explore's search never
        // lands on the inbox, and the extra lookups would delay that cover.
        lookForRenamedList: Boolean = false
    ): Boolean {
        val inbox = instagramInboxListBounds(root, lookForRenamedList) != null &&
            (igVisible(root, "direct_inbox_action_bar") || igVisible(root, "direct_inbox_search_bar") ||
                igVisible(root, "search_row"))
        val conversation = igVisible(root, "direct_thread_header") && igVisible(root, "message_list")
        return inbox || conversation
    }

    private fun refreshDirectDetailsSurface(root: AccessibilityNodeInfo, window: Rect): Boolean {
        val pager = findVisibleNodeBounds(root,
            "$INSTAGRAM_PACKAGE:id/thread_details_pager") ?: return false
        val tabLayout = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/tab_layout")
        val hasDetailsChrome = findVisibleNodeBounds(root,
            "$INSTAGRAM_PACKAGE:id/thread_details_header") != null ||
            findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/shared_section") != null
        if (!hasDetailsChrome || !pager.intersect(window)) return false
        if (tabLayout != null) {
            pager.top = InstagramDirectDetailsPolicy.curtainTop(
                pager.top, tabLayout.bottom, dp(12)).coerceAtLeast(window.top)
        }
        mainHandler.removeCallbacks(homeScrollSettled)
        scrollCoverTop = null
        scrollCoverUntil = 0L
        profileScrollPositions.clear()
        profileScrollCover.reset()
        profileWindowId = -1
        profileAllowedDepartureUntil = 0L
        instagramEntryTargets.clear()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        cancelInstagramExit()
        directReelLaunchPendingUntil = 0L

        val selectedTab = selectedDirectDetailsTab(root)
        val mediaGridAlreadyVisible = findVisibleNodeBounds(root,
            "$INSTAGRAM_PACKAGE:id/shared_media_list") != null
        val protect = InstagramDirectDetailsPolicy.shouldProtect(
            selectedTab, lastInstagramScreen == InstagramScreen.DIRECT_SHARED_MEDIA ||
                mediaGridAlreadyVisible)
        if (protect) {
            // Use the stable pager, not the tab-specific list. Instagram removes
            // shared_media_list while animating between Media and Reposts.
            supportCurtainReason = "chatmedia"
            showInstagramCurtain(pager, InstagramScreen.DIRECT_SHARED_MEDIA)
            val nextGuard = directDetailsTouchGuardBounds(window, pager)
            val previousGuard = directDetailsInteractionBounds
            directDetailsInteractionBounds = if (SystemClock.uptimeMillis() <
                directDetailsGuardHoldUntil && previousGuard != null && nextGuard != null) {
                Rect(previousGuard).apply { union(nextGuard) }
            } else nextGuard
            directDetailsInteractionBounds?.let { instagramOverlay.showTransientTouchGuard(it, isEnglish()) }
            observeInstagramScreen(InstagramScreen.DIRECT_SHARED_MEDIA, root.windowId)
        } else {
            clearDirectDetailsScrollGuard()
            clearInstagramResumeProtection()
            instagramOverlay.hide()
            observeInstagramScreen(InstagramScreen.DIRECT_MESSAGES, root.windowId)
        }
        exitGate.observe(InstagramScreen.DIRECT_MESSAGES, SystemClock.uptimeMillis(),
            verifiedConversationReturn = true)
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
        return true
    }

    private fun directDetailsTouchGuardBounds(
        window: Rect,
        pager: Rect
    ): Rect? {
        val bottom = pager.bottom.coerceAtMost(window.bottom)
        // The black curtain already overlaps the tab/pager seam by 12dp. The
        // transparent guard adds only a small extra lead and must not cover the
        // centre of the tab buttons.
        val top = (pager.top - dp(4)).coerceAtLeast(window.top)
        if (top >= bottom) return null
        return Rect(window.left, top, window.right, bottom)
    }

    private fun clearDirectDetailsScrollGuard() {
        mainHandler.removeCallbacks(directDetailsGuardSettled)
        directDetailsGuardHoldUntil = 0L
        directDetailsInteractionBounds = null
        instagramOverlay.hideTransientTouchGuard()
    }

    private fun hasFastPostViewer(root: AccessibilityNodeInfo): Boolean {
        val window = instagramWindowBounds(root)
        val fullPhotoViewer = listOf(
            "direct_media_viewer", "direct_visual_media_viewer", "media_viewer",
            "media_viewer_container", "photo_viewer", "image_viewer",
            "zoomable_view_container", "fullscreen_media_container"
        ).any { id ->
            cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
                .any { node ->
                    if (!node.isVisibleToUser) false else {
                        val bounds = Rect().also(node::getBoundsInScreen)
                        bounds.intersect(window) && bounds.width() >= window.width() * 3 / 4 &&
                            bounds.height() >= window.height() / 2
                    }
                }
        }
        if (fullPhotoViewer) return true
        // Home contains row_feed_* and carousel IDs too. Treating them as a
        // detail viewer removes the feed curtain and tries a nonexistent Back.
        val hasHomeHeader = igVisible(root, "main_feed_action_bar")
        if (hasHomeHeader) return false
        val postChrome = listOf(
            "media_view_pager", "carousel_media_group", "post_detail", "feed_detail",
            "single_media_view", "row_feed_profile_header", "row_feed_button_comment",
            "row_feed_comment_textview_layout"
        ).any { igVisible(root, it) }
        if (!postChrome) return false
        val hasBack = igVisible(root, "action_bar_button_back")
        val detailsTabsStillForeground = igVisible(root, "tab_layout")
        return InstagramPostIdentity.isGenericViewer(
            fullPhotoViewer = fullPhotoViewer,
            hasHomeHeader = hasHomeHeader,
            postChrome = postChrome,
            hasBack = hasBack,
            detailsTabsVisible = detailsTabsStillForeground
        )
    }

    private fun selectedDirectDetailsTab(root: AccessibilityNodeInfo): Int? {
        val tabs = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/icon_view")
            .filter { it.isVisibleToUser }
            .map { node -> node to Rect().also(node::getBoundsInScreen) }
            .filter { (_, bounds) -> !bounds.isEmpty }
            // In reading order: from the right when the app is mirrored.
            .sortedBy { (_, bounds) ->
                if (isRightToLeft(INSTAGRAM_PACKAGE)) -bounds.right else bounds.left
            }
        val selectedIndex = tabs.indexOfFirst { (node, _) ->
            node.isSelected || hasSelectedAncestor(node, 2)
        }
        return InstagramDirectDetailsPolicy.selectedTabIndex(tabs.size, selectedIndex)
    }

    private fun hasSelectedAncestor(node: AccessibilityNodeInfo, depth: Int): Boolean {
        var current = node.parent
        repeat(depth) {
            val ancestor = current ?: return false
            if (ancestor.isSelected) return true
            current = ancestor.parent
        }
        return false
    }

    private fun refreshDirectDetailsTabIntent(source: AccessibilityNodeInfo?) {
        val node = source ?: return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        val pager = findVisibleNodeBounds(root,
            "$INSTAGRAM_PACKAGE:id/thread_details_pager") ?: return
        val tabLayout = findVisibleNodeBounds(root,
            "$INSTAGRAM_PACKAGE:id/tab_layout") ?: return
        val sourceBounds = Rect().also(node::getBoundsInScreen)
        if (sourceBounds.isEmpty || !tabLayout.contains(sourceBounds.centerX(), sourceBounds.centerY())) return

        val relativeX = leftToRight(sourceBounds, tabLayout, INSTAGRAM_PACKAGE).centerX() - tabLayout.left
        val tabIndex = (relativeX * 3 / tabLayout.width().coerceAtLeast(1)).coerceIn(0, 2)
        val window = instagramWindowBounds(root)
        if (!pager.intersect(window)) return
        instagramEntryTargets.clear()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        if (InstagramDirectDetailsPolicy.shouldProtect(tabIndex, false)) {
            supportCurtainReason = "chatmedia"
            showInstagramCurtain(pager, InstagramScreen.DIRECT_SHARED_MEDIA)
            directDetailsInteractionBounds = directDetailsTouchGuardBounds(window, pager)
            directDetailsInteractionBounds?.let { instagramOverlay.showTransientTouchGuard(it, isEnglish()) }
            observeInstagramScreen(InstagramScreen.DIRECT_SHARED_MEDIA, root.windowId)
        } else {
            clearDirectDetailsScrollGuard()
            clearInstagramResumeProtection()
            instagramOverlay.hide()
            observeInstagramScreen(InstagramScreen.DIRECT_MESSAGES, root.windowId)
        }
        Log.d(TAG, "IG_DIRECT_DETAILS_TAB_INTENT index=$tabIndex")
    }

    private fun hasVisibleProfileNativeSheet(root: AccessibilityNodeInfo): Boolean {
        val ids = setOf(
            "bottom_sheet_container", "layout_container_bottom_sheet",
            "bottom_sheet_container_view", "action_sheet_container",
            "action_sheet_row_text_view"
        )
        return ids.any { id -> igVisible(root, id) }
    }

    private fun hasVisibleAboutAccountSurface(root: AccessibilityNodeInfo): Boolean {
        val explicitIds = listOf(
            "about_this_account_container", "account_transparency_container",
            "account_transparency_root", "about_account_fragment"
        )
        // Ids only: the page's localized title matched Turkish/English alone.
        // The page has no profile header, so the profile curtain is never
        // applied over it in any language.
        return explicitIds.any { id -> igVisible(root, id) }
    }

    /** Null means this is not an allowed departure; Boolean says whether it is About Account. */
    private fun allowedProfileDeparture(source: AccessibilityNodeInfo?): Boolean? {
        val ids = linkedSetOf<String>()
        val labels = linkedSetOf<String>()
        var current = source
        repeat(8) {
            val node = current ?: return@repeat
            compactId(node.viewIdResourceName).takeIf(String::isNotEmpty)?.let(ids::add)
            node.text?.toString()?.trim()?.lowercase(Locale.US)
                ?.takeIf(String::isNotEmpty)?.let(labels::add)
            node.contentDescription?.toString()?.trim()?.lowercase(Locale.US)
                ?.takeIf(String::isNotEmpty)?.let(labels::add)
            current = node.parent
        }
        if (!InstagramProfileSurfacePolicy.isAllowedDeparture(ids, labels)) return null
        return InstagramProfileSurfacePolicy.isAboutAccountDeparture(ids, labels)
    }

    private fun isProfileThumbnailIntent(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(8) {
            val node = current ?: return false
            if (compactId(node.viewIdResourceName) in InstagramEntryPolicy.profileThumbnailIds) {
                return true
            }
            current = node.parent
        }
        return false
    }

    private fun isProfileReelThumbnailIntent(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(10) {
            val node = current ?: return false
            if (compactId(node.viewIdResourceName) == "preview_clip_thumbnail") return true
            current = node.parent
        }
        return false
    }

    private fun isCollectionThumbnailIntent(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(10) {
            val node = current ?: return false
            val id = compactId(node.viewIdResourceName)
            if (id in InstagramEntryPolicy.profileThumbnailIds ||
                id.contains("media_grid") || id.contains("grid_media") ||
                id.contains("thumbnail") || id.contains("clips_grid")) return true
            current = node.parent
        }
        return false
    }

    private fun isCollectionReelThumbnailIntent(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(10) {
            val node = current ?: return false
            val id = compactId(node.viewIdResourceName)
            if (id.contains("clip") || id.contains("reel")) return true
            current = node.parent
        }
        return false
    }

    // One exact lookup: Saved's pager is mounted for every Saved tab.
    private fun hasVisibleUserCollectionIds(root: AccessibilityNodeInfo): Boolean =
        igVisible(root, "saved_view_pager")

    /**
     * The post list a collection item opens (Saved "All posts", a liked post)
     * has the ids of any feed list; its localized title differs per language.
     * Context identifies it everywhere: it follows a verified collection or a
     * collection thumbnail tap, and shows a single post's chrome with Back.
     */
    private fun isBalancedCollectionPostList(root: AccessibilityNodeInfo, now: Long): Boolean {
        if (lastInstagramScreen != InstagramScreen.SAVED_COLLECTION &&
            !instagramBalancedProfilePost.isChosenFromCollection(now)) return false
        return igVisible(root, "action_bar_button_back") && !igVisible(root, "main_feed_action_bar") &&
            igVisible(root, "row_feed_profile_header")
    }

    /** The notification's own post or Reel is still the open item (Balanced). */
    private fun keepsBalancedNotificationItem(
        root: AccessibilityNodeInfo,
        classified: InstagramScreen,
        signals: InstagramUiSignals
    ): Boolean {
        if (classified != InstagramScreen.HOME_FEED) return false
        val itemActive = (lastInstagramScreen == InstagramScreen.COMMENTS_OR_DETAIL &&
            instagramBalancedNotificationPostWatching) ||
            // Opened straight from a notification: a single post page with
            // its own Back (Home never shows Back without a tab bar).
            (lastInstagramScreen == InstagramScreen.NOTIFICATIONS && signals.hasBackNavigation &&
                "row_feed_profile_header" in signals.ids) ||
            (lastInstagramScreen == InstagramScreen.REELS &&
                instagramBalancedReelOrigin == InstagramScreen.NOTIFICATIONS &&
                instagramReelsSession.watching && !instagramReelsSession.exiting)
        if (!itemActive) return false
        val mode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        val tabBarVisible = signals.selectedTabs.isNotEmpty() || igVisible(root, "tab_bar")
        val visiblePosts = maxOf(
            cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/row_feed_view_group_buttons")
                .count { it.isVisibleToUser },
            cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/media_group")
                .count { it.isVisibleToUser })
        return InstagramSurfacePolicy.keepsNotificationItem(
            mode = mode,
            classified = classified,
            notificationItemActive = true,
            sameWindow = root.windowId == instagramStateMachine.currentWindowId,
            tabBarVisible = tabBarVisible,
            homeHeaderVisible = "main_feed_action_bar" in signals.ids,
            visiblePosts = visiblePosts)
    }

    /** Balanced only: a user collection (Saved, Likes, archive) or its post list stays open. */
    private fun refreshBalancedInstagramCollection(
        root: AccessibilityNodeInfo,
        collectionIds: Boolean? = null
    ): Boolean {
        if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) != ProtectionMode.BALANCED) return false
        val isCollection = collectionIds ?: hasVisibleUserCollectionIds(root)
        if (!isCollection && !isBalancedCollectionPostList(root, SystemClock.uptimeMillis())) return false
        clearDirectConversationEntryGuard()
        clearDirectDetailsScrollGuard()
        clearInstagramResumeProtection()
        profileAllowedDepartureUntil = 0L
        profileScrollPositions.clear()
        profileScrollCover.reset()
        profileWindowId = -1
        instagramEntryTargets.clear()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        instagramOverlay.updateNavigationGuards(emptyMap())
        instagramOverlay.hide()
        cancelInstagramExit()
        observeInstagramScreen(InstagramScreen.SAVED_COLLECTION, root.windowId)
        Log.d(TAG, "IG_BALANCED_COLLECTION_ALLOWED list=${!isCollection}")
        return true
    }

    private fun releaseAllowedProfileSurface() {
        clearDirectDetailsScrollGuard()
        clearInstagramResumeProtection()
        instagramOverlay.updateProfileChromeGuard(null)
        instagramOverlay.hide()
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        profileScrollPositions.clear()
        profileScrollCover.reset()
        profileWindowId = -1
        cancelInstagramExit()
        directDetailsLaunchPendingUntil = 0L
        directDetailsFallbackBackAt = 0L
        directReelLaunchPendingUntil = 0L
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
    }

    private fun armInstagramProfileReturn(root: AccessibilityNodeInfo?, now: Long) {
        if (!instagramProfilePostsBlocked() || root?.packageName?.toString() != INSTAGRAM_PACKAGE) {
            clearInstagramProfileReturn()
            return
        }
        instagramProfileReturn.observeAllowedLayer(now)
        val window = instagramWindowBounds(root)
        val backBounds = findInstagramTopLeftBack(root, window)?.let {
            Rect().also(it::getBoundsInScreen)
        }
        instagramOverlay.updateProfileReturnGuard(backBounds, ::onInstagramProfileReturnBack)
        if (backBounds != null) scheduleOverlayForegroundCheck()
    }

    private fun refreshEarlyInstagramProfileReturn(event: AccessibilityEvent, now: Long) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        if (!instagramProfilePostsBlocked() || !instagramProfileReturn.isArmed(now)) {
            clearInstagramProfileReturn()
            return
        }
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        if (hasVisibleProfileNativeSheet(root) || hasVisibleAboutAccountSurface(root)) {
            armInstagramProfileReturn(root, now)
            return
        }
        if (!instagramProfileReturn.canPrecoverReturn(now) ||
            (!hasVisibleProfileHeaderMarkers(root) &&
                profileGridBounds(root, instagramWindowBounds(root)) == null)) return

        if (precoverStrictProfileReturn(root)) {
            clearInstagramProfileReturn()
            armProfileCurtainEnsure()
            queueInstagramScan(0L)
            Log.d(TAG, "IG_PROFILE_RETURN_PRECOVER source=structure")
        }
    }

    private fun onInstagramProfileReturnBack() {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            !instagramProfilePostsBlocked()) return
        val now = SystemClock.uptimeMillis()
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE ||
            (!hasVisibleProfileNativeSheet(root) && !hasVisibleAboutAccountSurface(root))) return
        val token = instagramProfileReturn.begin(now) ?: return
        val windowId = root.windowId
        instagramOverlay.updateProfileReturnGuard(null)
        if (!precoverStrictProfileReturn(root)) {
            instagramProfileReturn.clear()
            val accepted = findInstagramTopLeftBack(root, instagramWindowBounds(root))
                ?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            if (!accepted) performGlobalAction(GLOBAL_ACTION_BACK)
            queueInstagramScan(0L)
            return
        }
        instagramOverlay.afterCurtainDraw {
            if (!instagramProfileReturn.accepts(token, SystemClock.uptimeMillis()) ||
                !ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) {
                return@afterCurtainDraw
            }
            val current = rootInActiveWindow ?: return@afterCurtainDraw
            if (current.packageName?.toString() != INSTAGRAM_PACKAGE ||
                current.windowId != windowId) return@afterCurtainDraw
            val accepted = findInstagramTopLeftBack(current, instagramWindowBounds(current))
                ?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            if (!accepted) performGlobalAction(GLOBAL_ACTION_BACK)
            Log.d(TAG, "IG_PROFILE_RETURN_PRECOVER source=back accepted=$accepted")
            queueInstagramScan(0L)
        }
        queueInstagramScan(32L)
    }

    private fun precoverStrictProfileReturn(root: AccessibilityNodeInfo): Boolean {
        val window = instagramWindowBounds(root)
        val retained = lastVerifiedInstagramCurtain
            ?.takeIf { it.first == InstagramScreen.PROFILE }
            ?.second
            ?.let(::Rect)
        val bounds = retained ?: conservativeInstagramResumeBounds(
            root, window, InstagramScreen.PROFILE) ?: return false
        profileAllowedDepartureUntil = 0L
        clearInstagramResumeProtection()
        currentInstagramWindowId = root.windowId
        return applyStrictProfileCurtainResult(root, window, bounds).also { shown ->
            if (shown) {
                strictProfilePrecoverAtMs = SystemClock.uptimeMillis()
                scheduleOverlayForegroundCheck()
            }
        }
    }

    /** Split-aware variant of the profile curtain mount with a Boolean result. */
    private fun applyStrictProfileCurtainResult(
        root: AccessibilityNodeInfo,
        window: Rect,
        bounds: Rect
    ): Boolean {
        applyStrictProfileCurtain(root, window, bounds)
        return instagramOverlay.visibleProfileBounds() != null
    }

    private fun clearInstagramProfileReturn() {
        instagramProfileReturn.clear()
        instagramOverlay.updateProfileReturnGuard(null)
    }

    private fun findInstagramTopLeftBack(
        root: AccessibilityNodeInfo,
        window: Rect
    ): AccessibilityNodeInfo? {
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(root)
        var visited = 0
        // A Back control sits in the leading third of the upper half (top-left,
        // or top-right when mirrored). Subtrees that are invisible or never
        // touch that region cannot contain it; expanding them spent one remote
        // call per child on every scan.
        val region = leftToRight(Rect(window.left, window.top, window.left + window.width() / 3,
            window.centerY()), window, INSTAGRAM_PACKAGE)
        while (pending.isNotEmpty() && visited++ < 140) {
            val node = pending.removeFirst()
            val bounds = Rect().also(node::getBoundsInScreen)
            if (node !== root && (!node.isVisibleToUser || !Rect.intersects(bounds, region))) continue
            val id = compactId(node.viewIdResourceName)
            val semanticBack = id == "action_bar_button_back"
            if (semanticBack && node.isVisibleToUser && node.isClickable && !bounds.isEmpty &&
                bounds.top >= window.top && bounds.bottom < window.centerY() &&
                leftToRight(bounds, window, INSTAGRAM_PACKAGE).let {
                    it.left >= window.left && it.right <= window.left + window.width() / 3
                }) return node
            for (index in 0 until minOf(node.childCount, 24)) {
                node.getChild(index)?.let(pending::addLast)
            }
        }
        return null
    }

    private fun refreshStrictProfileChromeGuard() {
        // The profile top bar (Back, Threads, username/account switch, menu)
        // stays fully native: these are intentional, useful controls, and the
        // layers they open (profile menu, About, account switcher) are now
        // recognised allowed surfaces that the curtain yields to and re-covers
        // after. No guard window is mounted over the bar any more.
        instagramOverlay.updateProfileChromeGuard(null)
    }

    private fun releaseVerifiedInstagramInbox(root: AccessibilityNodeInfo,
        requireSelectedMainTab: Boolean = false): Boolean {
        val probeStarted = SystemClock.uptimeMillis()
        fun reject(reason: String): Boolean {
            val now = SystemClock.uptimeMillis()
            if (requireSelectedMainTab && now - lastInboxProbeLogAt >= 250L &&
                applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0) {
                lastInboxProbeLogAt = now
                Log.d(TAG, "IG_INBOX_EARLY_REJECT reason=$reason window=${root.windowId} " +
                    "probeMs=${now - probeStarted}")
            }
            return false
        }
        fun visible(id: String): Boolean = igVisible(root, id)
        if (requireSelectedMainTab) {
            // This path precedes viewer probes: require current native inbox
            // navigation and reject mounted inboxes underneath any back stack.
            if (!igSelected(root, "direct_tab")) return reject("direct-not-selected")
            if (igSelected(root, "clips_tab")) return reject("reels-selected")
            if (visible("action_bar_button_back")) return reject("back-present")
        }
        // The renamed list is only looked for where the inbox is plausible:
        // the inbox itself, a Messages tab tap in progress, or (with
        // requireSelectedMainTab) the Direct tab already found selected.
        val inboxPlausible = requireSelectedMainTab ||
            lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES ||
            SystemClock.uptimeMillis() < directNavigationUntil
        val listBounds = instagramInboxListBounds(root, lookForRenamedList = inboxPlausible)
            ?: return reject("list-missing")
        val display = currentDisplayBounds()
        if (!InstagramInboxPolicy.isStableInboxLayout(
                listBounds.toInstagramGeometrySample(),
                display.toInstagramGeometrySample())) return reject("list-transient")
        val header = visible("direct_inbox_action_bar") || visible("direct_inbox_search_bar") ||
            visible("search_row")
        if (!header) return reject("header-missing")
        // Even a partially opened viewer must not take this inbox-only bypass.
        // Fast Reel and Story checks run before this path. Keep only the two
        // layers which can otherwise leave a full-width inbox mounted behind
        // an opened media/details surface.
        val blockedTopLayerId = listOf(
            "root_clips_layout", "clips_viewer", "clips_viewer_view_pager",
            "clips_view_pager", "thread_details_pager", "story_viewer_container",
            "reel_item_toolbar_container", "reel_viewer_root", "reel_viewer_content_layout"
        ).firstOrNull(::visible)
        if (!InstagramInboxPolicy.isInbox(true, header, blockedTopLayerId != null)) {
            return reject("layer-$blockedTopLayerId")
        }
        verifiedInstagramInboxWindowId = root.windowId
        verifiedInstagramInboxListBounds = Rect(listBounds)
        directConversationSurfaceWindowId = -1
        clearDirectConversationEntryGuard()
        cancelInstagramExit()
        clearDirectDetailsScrollGuard()
        clearInstagramResumeProtection()
        instagramOverlay.hide()
        directNavigationUntil = 0L
        directNavigationSourceWindowId = -1
        instagramEntryTargets.clear()
        // Do not carry Home/media touch regions onto the inbox. Preserve only a
        // currently visible main Reels tab, if this Instagram layout exposes one.
        val window = instagramWindowBounds(root)
        cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/clips_tab")
            .filter { it.isVisibleToUser }.forEach { node ->
                val bounds = Rect().also(node::getBoundsInScreen)
                if (bounds.intersect(window) && bounds.height() in 1 until window.height() / 2) {
                    instagramEntryTargets.add(bounds to true)
                }
            }
        lastDirectConversationGuards.clear()
        instagramOverlay.updateEntryGuards(instagramEntryTargets.map { it.first }, isEnglish())
        clearNonMessagingTouchGuards()
        if (lastInstagramScreen != InstagramScreen.DIRECT_MESSAGES) {
            Log.d(TAG, "IG_INBOX_RELEASE scanMs=${SystemClock.uptimeMillis() - lastInstagramScanTime}")
        }
        observeInstagramScreen(InstagramScreen.DIRECT_MESSAGES, root.windowId)
        directDetailsLaunchPendingUntil = 0L
        directDetailsFallbackBackAt = 0L
        directReelLaunchPendingUntil = 0L
        if (exitGate.observe(InstagramScreen.DIRECT_MESSAGES, SystemClock.uptimeMillis())) queueInstagramScan(450L)
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
        return true
    }

    private fun refreshDirectConversationGuards(root: AccessibilityNodeInfo): Boolean {
        val header = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/direct_thread_header") ?: return false
        val list = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/message_list") ?: return false
        // Mounted conversation chrome must not override a viewer transition.
        if (listOf("thread_details_pager", "reel_item_toolbar_container",
                "root_clips_layout", "clips_viewer_view_pager", "clips_view_pager",
                "reel_viewer_root", "story_viewer_container").any {
                findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/$it") != null }) return false
        val viewport = Rect(list)
        viewport.top = maxOf(viewport.top, header.bottom)
        findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/message_composer_bar")?.let {
            viewport.bottom = minOf(viewport.bottom, it.top)
        }
        if (viewport.isEmpty) return false
        val dmMode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        if (!InstagramDmInteractionPolicy.interceptsChatTouches(dmMode) &&
            !InstagramDmInteractionPolicy.blocksSharedMedia(dmMode)) {
            clearDirectConversationEntryGuard()
            clearDirectDetailsScrollGuard()
            lastDirectConversationGuards.clear()
            directConversationGuardHoldUntil = 0L
            instagramEntryTargets.clear()
            instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
            instagramOverlay.updateNavigationGuards(emptyMap())
            clearNonMessagingTouchGuards()
            hideInstagramContentOverlay()
            cancelInstagramExit()
            verifiedInstagramInboxWindowId = -1
            verifiedInstagramInboxListBounds = null
            directConversationSurfaceWindowId = root.windowId
            observeInstagramScreen(InstagramScreen.DIRECT_MESSAGES, root.windowId)
            exitGate.observe(InstagramScreen.DIRECT_MESSAGES, SystemClock.uptimeMillis(),
                verifiedConversationReturn = true)
            return true
        }
        // The verified conversation remains completely native.  In particular,
        // do not mount the provisional full-viewport entry guard here.
        clearDirectConversationEntryGuard()
        verifiedInstagramInboxWindowId = -1
        verifiedInstagramInboxListBounds = null
        // Everything in the conversation stays native except, in Strict, the
        // shared Reel cards themselves. A tapped card sends no click event and
        // Instagram stops publishing accessibility events for 1.5-2 s while
        // its Reel viewer starts and already plays, so a viewer-side exit can
        // never be earlier than that. The card guard consumes the tap; drags
        // and long presses (react/reply menu) are replayed underneath it.
        val now = SystemClock.uptimeMillis()
        lastDirectConversationGuards.clear()
        if (InstagramDmInteractionPolicy.blocksSharedMedia(dmMode)) {
            lastDirectConversationGuards.addAll(directReelCardGuards(root, viewport))
        }
        // The bottom Reels tab stays guarded in the conversation too: the tab
        // bar can remain visible above the composer, and an unguarded tab lets
        // a fast tap enter Reels natively.
        val reelsTabGuards = mutableListOf<Rect>()
        val conversationWindow = instagramWindowBounds(root)
        root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/clips_tab")
            .filter { it.isVisibleToUser }.forEach { node ->
                val bounds = Rect().also(node::getBoundsInScreen)
                if (bounds.intersect(conversationWindow) &&
                    bounds.height() in 1 until conversationWindow.height() / 2) {
                    reelsTabGuards.add(bounds)
                }
            }
        val renderedGuards = (lastDirectConversationGuards + reelsTabGuards).distinct()
        clearDirectDetailsScrollGuard()
        clearInstagramResumeProtection()
        instagramOverlay.updateEntryGuards(
            renderedGuards,
            isEnglish(),
            forceRelayout = false)
        // Keep the persistent Reels-tab guard consistent with this surface:
        // find it when the tab bar is visible, force-retire it when it is
        // not - the conversation composer shares the bottom strip, so a
        // transition hold must never linger here.
        refreshMainReelsTabGuard(root, force = true)
        instagramOverlay.hide()
        instagramEntryTargets.clear()
        instagramEntryTargets.addAll(renderedGuards.map { it to false })
        cancelInstagramExit()
        directDetailsLaunchPendingUntil = 0L
        directDetailsFallbackBackAt = 0L
        directNavigationUntil = 0L
        directNavigationSourceWindowId = -1
        observeInstagramScreen(InstagramScreen.DIRECT_MESSAGES, root.windowId)
        // This path has verified the conversation header and message viewport,
        // and rejected mounted Reel viewers. Rearm before another card tap;
        // no click delivery or 400 ms safe-screen dwell is required.
        exitGate.observe(InstagramScreen.DIRECT_MESSAGES, SystemClock.uptimeMillis(),
            verifiedConversationReturn = true)
        val remaining = directReelLaunchPendingUntil - now
        if (remaining > 0L) {
            // A card click that escaped its region gets a short fast-player
            // polling burst. This avoids waiting for Instagram's next delayed
            // content event before issuing the viewer Back action.
            queueInstagramScan(if (remaining > 1_150L) 16L else minOf(48L, remaining))
        }
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
        return true
    }

    /**
     * A DM conversation window exists before Instagram publishes message_list.
     * Use the previously verified inbox viewport to attach the input surface as
     * soon as WindowManager announces that new window. This path deliberately
     * performs no accessibility-tree query, so it cannot sit behind the slow
     * Instagram IPC calls observed on a cold conversation open.
     */
    private fun armDirectWindowTransition(
        event: AccessibilityEvent,
        now: Long
    ): Boolean {
        if (!InstagramDmInteractionPolicy.interceptsChatTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) return false
        val verifiedInboxContext = lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES &&
            verifiedInstagramInboxWindowId != -1
        val homeToDirectContext = now < directNavigationUntil &&
            directNavigationSourceWindowId != -1 &&
            event.windowId != directNavigationSourceWindowId
        if ((!verifiedInboxContext && !homeToDirectContext) || event.windowId == -1 ||
            (verifiedInboxContext && event.windowId == verifiedInstagramInboxWindowId) ||
            isDirectConversationEntryGuardArmed()) return false
        val windowChanges = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            event.windowChanges
        } else {
            0
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val relevantChanges = AccessibilityEvent.WINDOWS_CHANGE_ADDED or
                AccessibilityEvent.WINDOWS_CHANGE_ACTIVE or
                AccessibilityEvent.WINDOWS_CHANGE_FOCUSED
            if (windowChanges and relevantChanges == 0) return false
        }
        val display = currentDisplayBounds()
        val retainedBottom = lastVerifiedInstagramCurtain?.second?.bottom
            ?.takeIf { it in (display.centerY() + 1)..display.bottom }
            ?: (display.bottom - dp(48))
        val cached = verifiedInstagramInboxListBounds
        val viewport = Rect(cached ?: Rect(
            display.left,
            display.top + statusBarInset() + dp(56),
            display.right,
            retainedBottom
        )).apply {
            left = display.left
            right = display.right
        }
        if (!viewport.intersect(display) || viewport.isEmpty ||
            !instagramOverlay.showConversationEntryGuard(viewport)) return false
        directConversationSurfaceWindowId = event.windowId
        directConversationEntryGuardArmedAt = now
        directConversationEntryGuardUntil = now + DIRECT_CONVERSATION_ENTRY_GUARD_TIMEOUT_MS
        mainHandler.removeCallbacks(directConversationEntryGuardRelease)
        mainHandler.removeCallbacks(directConversationEntryGuardTimeout)
        mainHandler.postDelayed(
            directConversationEntryGuardTimeout,
            DIRECT_CONVERSATION_ENTRY_GUARD_TIMEOUT_MS)
        Log.d(TAG, "IG_CONVERSATION_WINDOW_GUARD armed window=${event.windowId} " +
            "type=${event.eventType} changes=$windowChanges " +
            "eventAgeMs=${now - event.eventTime} bounds=$viewport")
        return true
    }

    private fun prearmDirectConversationSurface(
        root: AccessibilityNodeInfo,
        now: Long,
        knownViewport: Rect? = null
    ): Boolean {
        if (!InstagramDmInteractionPolicy.interceptsChatTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) return false
        if (root.windowId == directConversationSurfaceWindowId) return false
        fun bounds(id: String): Rect? = findVisibleNodeBounds(
            root, "$INSTAGRAM_PACKAGE:id/$id")
        // Stories are allowed. Test that one exceptional surface first, then
        // arm from message_list before doing any other remote node queries.
        // Reel/media layers are intentionally not an exception: if they mount
        // over a conversation, this transparent guard is useful until the fast
        // viewer path sends Back.
        if (bounds("story_viewer_container") != null) return false
        // message_list is published before direct_thread_header on the first
        // open after process start. Waiting for both left a real 200-400 ms
        // interval in which a Reel card could receive the next tap.
        val list = knownViewport?.let(::Rect) ?: bounds("message_list") ?: return false
        val header = bounds("direct_thread_header")
        if (header == null && lastInstagramScreen != InstagramScreen.DIRECT_MESSAGES) return false
        val display = currentDisplayBounds()
        val viewport = Rect(list).apply {
            top = maxOf(top, header?.bottom ?: top)
            bounds("message_composer_bar")?.let { composer ->
                bottom = minOf(bottom, composer.top)
            }
            // Guard the whole message plane while the ModalActivity slides in;
            // the reported list is horizontally clipped during that animation.
            left = display.left
            right = display.right
        }
        if (!viewport.intersect(display) || viewport.isEmpty ||
            !instagramOverlay.showConversationEntryGuard(viewport)) return false
        directConversationSurfaceWindowId = root.windowId
        directConversationEntryGuardArmedAt = now
        directConversationEntryGuardUntil = now + DIRECT_CONVERSATION_SURFACE_GUARD_TIMEOUT_MS
        mainHandler.removeCallbacks(directConversationEntryGuardRelease)
        mainHandler.removeCallbacks(directConversationEntryGuardTimeout)
        mainHandler.postDelayed(
            directConversationEntryGuardTimeout,
            DIRECT_CONVERSATION_SURFACE_GUARD_TIMEOUT_MS)
        Log.d(TAG, "IG_CONVERSATION_SURFACE_GUARD armed bounds=$viewport")
        return true
    }

    private fun armDirectConversationEntryGuard(
        event: AccessibilityEvent,
        now: Long
    ): Boolean {
        if (!InstagramDmInteractionPolicy.interceptsChatTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) return false
        val source = event.source ?: return false
        val ids = linkedSetOf<String>()
        val ancestryBounds = mutableListOf<Rect>()
        var ancestryListBounds: Rect? = null
        var current: AccessibilityNodeInfo? = source
        repeat(10) {
            val node = current ?: return@repeat
            val id = compactId(node.viewIdResourceName)
            id.takeIf(String::isNotEmpty)?.let(ids::add)
            val bounds = Rect().also(node::getBoundsInScreen)
            if (!bounds.isEmpty) ancestryBounds.add(bounds)
            // Only the old, inbox-specific id proves the list from the
            // ancestry alone; list_container is confirmed on the live tree
            // below, where its inbox header can be checked.
            if (id == InstagramSurfacePolicy.INBOX_LIST_ID) {
                ancestryListBounds = Rect(bounds)
            }
            current = node.parent
        }
        val liveRoot = rootInActiveWindow
        val liveListBounds = if (ancestryListBounds == null &&
            liveRoot?.packageName?.toString() == INSTAGRAM_PACKAGE &&
            liveRoot.windowId == event.windowId) {
            val candidate = instagramInboxListBounds(liveRoot)
            val hasHeader = listOf(
                "direct_inbox_action_bar", "direct_inbox_search_bar", "search_row"
            ).any { id ->
                findVisibleNodeBounds(liveRoot, "$INSTAGRAM_PACKAGE:id/$id") != null
            }
            candidate?.takeIf { hasHeader &&
                findVisibleNodeBounds(liveRoot, "$INSTAGRAM_PACKAGE:id/root_clips_layout") == null }
        } else null
        val listBounds = ancestryListBounds ?: liveListBounds ?:
            verifiedInstagramInboxListBounds ?: return false
        val sourceBounds = ancestryBounds.asSequence()
            .filter { bounds ->
                bounds.centerX() in listBounds.left until listBounds.right &&
                    bounds.centerY() in listBounds.top until listBounds.bottom &&
                    bounds.height() < listBounds.height() / 2
            }
            .maxByOrNull { it.width() }
            ?: Rect().also(source::getBoundsInScreen)
        val structurallyVerified = ancestryListBounds != null || liveListBounds != null
        val shouldArm = InstagramInboxPolicy.isThreadOpenIntent(
            ids,
            sourceBounds.takeUnless(Rect::isEmpty)?.toInstagramGeometrySample(),
            listBounds.toInstagramGeometrySample(),
            structurallyVerified || event.windowId == verifiedInstagramInboxWindowId)
        if (!shouldArm) return false

        val guardedBounds = Rect(listBounds)
        if (!guardedBounds.intersect(currentDisplayBounds()) || guardedBounds.isEmpty ||
            !instagramOverlay.showConversationEntryGuard(guardedBounds)) return false

        directConversationEntryGuardArmedAt = now
        directConversationEntryGuardUntil = now + DIRECT_CONVERSATION_ENTRY_GUARD_TIMEOUT_MS
        mainHandler.removeCallbacks(directConversationEntryGuardRelease)
        mainHandler.removeCallbacks(directConversationEntryGuardTimeout)
        mainHandler.postDelayed(
            directConversationEntryGuardTimeout,
            DIRECT_CONVERSATION_ENTRY_GUARD_TIMEOUT_MS)
        directReelLaunchPendingUntil = 0L
        Log.d(TAG, "IG_CONVERSATION_ENTRY_GUARD armed bounds=$guardedBounds")
        queueInstagramScan(16L)
        return true
    }

    private fun isDirectConversationEntryGuardArmed(): Boolean =
        directConversationEntryGuardUntil > SystemClock.uptimeMillis()

    private fun clearDirectConversationEntryGuard() {
        mainHandler.removeCallbacks(directConversationEntryGuardTimeout)
        mainHandler.removeCallbacks(directConversationEntryGuardRelease)
        directConversationEntryGuardArmedAt = 0L
        directConversationEntryGuardUntil = 0L
        instagramOverlay.hideConversationEntryGuard()
    }

    /** A verified messaging surface cannot inherit another screen's touch windows. */
    private fun clearNonMessagingTouchGuards() {
        instagramProfileIngress.reset()
        instagramOverlay.updateProfileIngressGuard(null)
        instagramOverlay.updateAccountSearchGuard(null, ::onInstagramAccountSearchTap, {})
        instagramOverlay.updateStoryEntryGuards(emptyList())
        clearInstagramNotificationIngress()
        instagramOverlay.updateNotificationLaunchGuard(null)
        instagramOverlay.updateNotificationBackGuard(null)
    }

    /**
     * Visible shared-Reel cards (reel_share_item_view; portrait XMA in current
     * layouts), clipped to the message viewport so the guard never reaches the
     * header or the composer. Two exact lookups, no tree walk.
     */
    private fun directReelCardGuards(root: AccessibilityNodeInfo, viewport: Rect): List<Rect> =
        // The long-press message menu (react, reply, pin, delete) is drawn over
        // the cards; while it is open no card guard may cover its rows.
        if (igVisible(root, "message_actions_container")) emptyList()
        else listOf("reel_share_item_view", "message_content_portrait_xma_container")
            .flatMap { id -> cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id") }
            .filter { it.isVisibleToUser }
            .mapNotNull { node ->
                Rect().also(node::getBoundsInScreen).takeIf {
                    it.intersect(viewport) && it.width() >= dp(48) && it.height() >= dp(48)
                }
            }
            .distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }

    private fun directReelLabelTargets(root: AccessibilityNodeInfo, viewport: Rect): List<Rect> {
        val evidence = mutableListOf<AccessibilityNodeInfo>()
        for (query in listOf("Reels Videosu", "Reels video", "instagram.com/reel")) {
            evidence += root.findAccessibilityNodeInfosByText(query)
                .filter { it.isVisibleToUser }
                .take(32)
        }
        evidence += root.findAccessibilityNodeInfosByViewId(
            "$INSTAGRAM_PACKAGE:id/direct_reel_share_legibility_gradient_footer")
            .filter { it.isVisibleToUser }
            .take(32)
        return evidence.mapNotNull { directReelCardBounds(it, viewport) }.distinct()
    }

    private fun directReelCardBounds(node: AccessibilityNodeInfo, viewport: Rect): Rect? {
        var current: AccessibilityNodeInfo? = node
        var best: Rect? = null
        repeat(7) {
            val candidate = current ?: return@repeat
            val id = compactId(candidate.viewIdResourceName)
            if (id in setOf("message_list", "message_content", "direct_thread_content_below_action_bar")) {
                return best
            }
            val bounds = Rect().also(candidate::getBoundsInScreen)
            if (bounds.intersect(viewport) && bounds.width() >= dp(48) && bounds.height() >= dp(48) &&
                bounds.width() <= viewport.width() * 9 / 10 &&
                bounds.height() <= viewport.height() * 3 / 4) {
                best = bounds
            }
            current = candidate.parent
        }
        return best
    }

    /*
    private fun directSharedMediaCardBounds(
        root: AccessibilityNodeInfo,
        viewport: Rect
    ): List<Rect> {
        val results = mutableListOf<Rect>()
        // Older Instagram layouts expose shared photos/Reels through the
        // stable media_container id even when the outer message row is not
        // clickable in the accessibility tree.
        val mediaNodes = root.findAccessibilityNodeInfosByViewId(
            "$INSTAGRAM_PACKAGE:id/media_container"
        ).take(32)
        val messageLists = root.findAccessibilityNodeInfosByViewId(
            "$INSTAGRAM_PACKAGE:id/message_list"
        )
        mediaNodes.forEach { node ->
            val bounds = Rect().also(node::getBoundsInScreen)
            if (bounds.intersect(viewport) && bounds.width() >= dp(100) &&
                bounds.height() >= dp(100)) results.add(bounds)
        }
        val pending = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        val traversalRoot = messageLists.firstOrNull() ?: root
        pending.add(traversalRoot to 0)
        var visited = 0
        while (pending.isNotEmpty() && visited++ < 700) {
            val (node, depth) = pending.removeFirst()
            val rawBounds = Rect().also(node::getBoundsInScreen)
            val isMediaSizedRow = rawBounds.width() >= viewport.width() * 2 / 3 &&
                rawBounds.height() >= dp(260) &&
                rawBounds.height() <= viewport.height() * 3 / 4
            if (isMediaSizedRow) {
                val bounds = Rect(rawBounds)
                if (!bounds.intersect(viewport)) {
                    if (depth < 8) {
                        for (index in 0 until minOf(node.childCount, 24)) {
                            node.getChild(index)?.let { pending.add(it to depth + 1) }
                        }
                    }
                    continue
                }
                var best: Rect? = null
                val descendants = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
                descendants.add(node to 0)
                var descendantCount = 0
                while (descendants.isNotEmpty() && descendantCount++ < 180) {
                    val (child, childDepth) = descendants.removeFirst()
                    val childBounds = Rect().also(child::getBoundsInScreen)
                    val betterThanBest = best?.let {
                        childBounds.width() * childBounds.height() >
                            it.width() * it.height()
                    } ?: true
                    if (childDepth > 0 &&
                        childBounds.intersect(viewport) &&
                        childBounds.width() >= dp(120) && childBounds.height() >= dp(120) &&
                        childBounds.width() <= viewport.width() * 9 / 10 &&
                        betterThanBest) {
                        best = childBounds
                    }
                    if (childDepth < 4) {
                        for (index in 0 until minOf(child.childCount, 24)) {
                            child.getChild(index)?.let { descendants.add(it to childDepth + 1) }
                        }
                    }
                }
                val card = best ?: bounds.takeIf { it.width() <= viewport.width() * 9 / 10 }
                if (card != null && !card.isEmpty && card.intersect(viewport)) {
                    // In Strict mode every point on a shared-media card must
                    // be blocked.  The overlay replays vertical drags through
                    // AccessibilityService after deciding they are movement,
                    // so the full card can be protected without reopening the
                    // Reel viewer (or allowing a one-frame black flash).
                    results.add(card)
                }
            }
            if (depth < 8) {
                for (index in 0 until minOf(node.childCount, 24)) {
                    node.getChild(index)?.let { pending.add(it to depth + 1) }
                }
            }
        }
        return results.distinct()
    }
    */

    private fun exitBlockedViewer(
        root: AccessibilityNodeInfo,
        windowBounds: Rect,
        screen: InstagramScreen,
        useGlobalBackOnly: Boolean = false,
        preserveObservedOrigin: Boolean = false,
        keepOriginCover: Boolean = false
    ) {
        // Support log: why this viewer is being closed (set by the caller).
        val exitReason = supportExitReason
        supportExitReason = "screen"
        if (screen == InstagramScreen.REELS && allowBalancedInstagramReel(root)) return
        val wasDirectConversation = lastInstagramScreen == InstagramScreen.DIRECT_MESSAGES
        val wasNotificationSurface = lastInstagramScreen == InstagramScreen.NOTIFICATIONS
        val now = SystemClock.uptimeMillis()
        val notificationOrigin = wasNotificationSurface ||
            instagramExitFromNotifications ||
            now < instagramNotificationContentLaunchUntil ||
            now < instagramNotificationExitHoldUntil
        val fromDirectConversation = wasDirectConversation ||
            (instagramExitInProgress && instagramExitFromDirectConversation)
        val fromNotificationSurface = notificationOrigin ||
            (instagramExitInProgress && instagramExitFromNotifications)
        if (fromNotificationSurface && screen == InstagramScreen.REELS &&
            instagramExitInProgress && instagramNotificationReelExitIssued &&
            instagramNotificationBackCount > 0) {
            if (instagramFastExitDeadlineAt == 0L) {
                scheduleFastNotificationSecondBack()
            }
            return
        }
        if (notificationOrigin && screen == InstagramScreen.REELS) {
            // The fast Reel path can win the race before the notification
            // viewer-root helper publishes its markers. Latch the origin here
            // as well, so the first exit is still the only exit.
            if (!instagramNotificationReelExitIssued) {
                instagramNotificationReelExitIssued = true
                instagramNotificationReelSecondBackIssued = false
                instagramNotificationCommentLayerObserved = hasFastCommentSheetInRoot(root)
            }
            instagramNotificationExitHoldUntil = now + 10_000L
            instagramNotificationViewerDetectedAt = now
            val attemptElapsed = instagramNotificationAttemptStartedAt
                .takeIf { it > 0L }
                ?.let { now - it }
            Log.d(TAG, "IG_NOTIFICATION_VIEWER_DETECTED elapsedMs=$attemptElapsed")
        }
        if (notificationOrigin && screen == InstagramScreen.COMMENTS_OR_DETAIL &&
            !instagramExitInProgress) {
            // Notification comment entries have two layers: comments first,
            // then the underlying Reel. Keep that second Back scoped to this
            // origin so direct notification Reels remain one-shot.
            instagramNotificationCommentNeedsSecondBack = true
            instagramNotificationCommentWaitStartedAt = now
        }
        if (instagramNotificationBackCount >= INSTAGRAM_NOTIFICATION_MAX_BACKS &&
            SystemClock.uptimeMillis() < instagramNotificationExitHoldUntil) return
        // A tab-slip entry must not reveal the feed: the feed never carries an
        // action-bar Back control, so this frames-exact signal separates it
        // from a verified single viewer. Cover first, then run the one-shot
        // exit; the cover is retired when the next surface is verified.
        if (screen == InstagramScreen.REELS && !fromDirectConversation &&
            !fromNotificationSurface &&
            (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) == ProtectionMode.STRICT ||
                instagramReelsSession.exiting || !hasFastActionBarBack(root))) {
            // A verified single-Reel pager can still publish its old footer
            // while Back is transitioning to Home. Cover the complete display
            // before dispatching Back so the footer cannot leak through the
            // smaller Home-feed curtain during that hand-off.
            armReelsSlipCover()
            reelsSlipCoverExit = true
        }
        clearDirectConversationEntryGuard()
        // A DM conversation has no touch overlay.  Preserve no card regions
        // while the viewer is being closed; otherwise the old transparent
        // window survives the Back transition and becomes the visible black
        // flash the user sees over the native conversation.
        val preservedConversationGuards = emptyList<Rect>()
        if (!preserveObservedOrigin) observeInstagramScreen(screen, root.windowId)
        directDetailsLaunchPendingUntil = 0L
        directDetailsFallbackBackAt = 0L
        directReelLaunchPendingUntil = 0L
        clearDirectDetailsScrollGuard()
        clearInstagramResumeProtection()
        exitGate.observe(screen, now)
        // No full-screen exit curtain. Keep the one-shot exit, not a black window.
        // Profile-menu collections also return to an allowed menu, so a curtain
        // retained from an older feed must be removed before Back is dispatched.
        mainHandler.removeCallbacks(homeScrollSettled)
        scrollCoverTop = null
        scrollCoverUntil = 0L
        if (!keepOriginCover) instagramOverlay.hide()
        // Never keep a DM card window mounted while the viewer closes.  The
        // conversation remains fully native; the next scan only checks for a
        // newly mounted viewer and exits it again if needed.
        instagramOverlay.updateEntryGuards(preservedConversationGuards, isEnglish())
        val newViewerEncounter = !instagramExitInProgress
        if (newViewerEncounter) {
            if (fromNotificationSurface) instagramNotificationExitGeneration++
            instagramBlockedAttempt.reset()
            instagramExitInProgress = true
            instagramExitFromDirectConversation = fromDirectConversation
            instagramExitFromNotifications = notificationOrigin
            Log.d(TAG, "IG_VIEWER screen=$screen detected scanMs=${now - lastInstagramScanTime}")
            instagramDetailExitChecksRemaining = if (screen == InstagramScreen.COMMENTS_OR_DETAIL) 3 else 0
            if (screen == InstagramScreen.REELS || screen == InstagramScreen.STORY ||
                screen == InstagramScreen.COMMENTS_OR_DETAIL) {
                mainHandler.removeCallbacks(instagramViewerExitRetry)
                mainHandler.postDelayed(
                    instagramViewerExitRetry,
                    if (notificationOrigin) 120L else INSTAGRAM_VIEWER_EXIT_RETRY_MS)
            }
        }
        if (exitGate.requestBack(now, if (fromNotificationSurface) 120L else
            InstagramExitGate.VIEWER_FAILSAFE_REARM_MS)) {
            // Prefer the viewer's own Back control when present. Never click a tab
            // or send a second action after an accepted click in the same attempt.
            val back = if (useGlobalBackOnly) null else
                root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/action_bar_button_back")
                    .firstOrNull { node ->
                        val bounds = Rect().also(node::getBoundsInScreen)
                        node.isVisibleToUser && node.isClickable && !bounds.isEmpty &&
                            bounds.top >= windowBounds.top &&
                            bounds.bottom <= windowBounds.top + windowBounds.height() / 4
                    }
            val clickedBack = back?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            val accepted = if (fromNotificationSurface) {
                // Notification viewers are exited only through an Instagram
                // control or a tap on that control. A global Back can escape
                // the app when Instagram accepts the command late.
                clickedBack || performViewerBackFromRoot(root)
            } else {
                clickedBack || performGlobalAction(GLOBAL_ACTION_BACK)
            }
            if (accepted) instagramExitTreeQuietUntil = now + INSTAGRAM_EXIT_TREE_QUIET_MS
            if (accepted && fromNotificationSurface) {
                instagramNotificationBackCount++
                // The comment sheet is already proven in the same accessibility
                // tree.  Its first Back only dismisses the sheet; dispatch the
                // Reel-closing Back from an independent queue so a slow tree
                // scan cannot turn a 120 ms retry into a 5–6 second delay.
                if (screen == InstagramScreen.REELS &&
                    !instagramNotificationReelSecondBackIssued) {
                    scheduleFastNotificationSecondBack()
                }
            }
            val attemptElapsed = instagramNotificationAttemptStartedAt
                .takeIf { it > 0L && fromNotificationSurface }
                ?.let { now - it }
            Log.d(TAG, "IG_VIEWER_EXIT screen=$screen singleAction viewerBack=$clickedBack " +
                "accepted=$accepted notificationElapsedMs=$attemptElapsed")
            SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_VIEWER_EXIT,
                mapOf("screen" to screen, "ok" to accepted, "why" to exitReason))
            // Failsafe exit retries belong to the same viewer encounter and
            // must not inflate the user-facing or API block count.
            if (instagramBlockedAttempt.acceptedIntervention(accepted)) {
                recordIntervention(INSTAGRAM_PACKAGE, System.currentTimeMillis())
            }
        }
        // Do not force a tree walk after BACK. During rapid re-entry Instagram
        // can invalidate that tree while it is being queried, blocking the
        // accessibility main thread for roughly its two-second IPC timeout.
        // The actual return/window events schedule the next scan; if those are
        // missed, InstagramExitGate's viewer-only failsafe remains available.
    }

    private fun resolveReelsEntry(
        node: AccessibilityNodeInfo, id: String, text: String, description: String
    ): AccessibilityNodeInfo? {
        if (id == "clips_tab") return node
        if (id == "reel_share_item_view") {
            val parentId = compactId(node.parent?.viewIdResourceName)
            val hasFooter = node.findAccessibilityNodeInfosByViewId(
                "$INSTAGRAM_PACKAGE:id/direct_reel_share_legibility_gradient_footer").isNotEmpty()
            return node.takeIf { InstagramEntryPolicy.isDirectReelCard(id, parentId, hasFooter) }
        }
        if (!InstagramEntryPolicy.hasReelEvidence(id, text) &&
            !InstagramEntryPolicy.hasReelEvidence(id, description)) return null
        if (node.isClickable) return node
        // The Reel marker can be a non-clickable child of the shared media card.
        // Never expand to the conversation row, entire list, or profile navigation.
        var parent = node.parent
        repeat(4) {
            val candidate = parent ?: return null
            val parentId = compactId(candidate.viewIdResourceName)
            if (candidate.isClickable) {
                return candidate.takeIf { it.isVisibleToUser && InstagramEntryPolicy.isCardContainer(parentId) }
            }
            if (parentId.contains("thread") || parentId.contains("inbox") ||
                parentId.contains("recycler") || parentId.contains("story") || parentId.contains("profile")) return null
            parent = candidate.parent
        }
        return null
    }

    private fun collectInstagramSnapshot(
        root: AccessibilityNodeInfo,
        source: AccessibilityNodeInfo?,
        protectedProfileGrid: Boolean = false,
        yieldProtectedFeed: Boolean = false
    ): InstagramUiSignals? {
        val snapshotStarted = SystemClock.uptimeMillis()
        val ids = linkedSetOf<String>()
        instagramEntryTargets.clear()
        val selectedTabs = linkedSetOf<InstagramTab>()
        val titles = linkedSetOf<String>()
        var searchFieldFocused = false
        var hasBackNav = false
        var hasCameraAction = false
        var hasClipsInteractionBar = false
        var hasFullscreenReelsViewer = false
        var idlessMediaTiles = 0
        val rootBounds = instagramWindowBounds(root)
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(root)
        var visited = 0

        while (pending.isNotEmpty() && visited < MAX_TREE_NODES) {
            if (yieldProtectedFeed && InstagramSurfacePolicy.yieldFeedSnapshot(
                    SystemClock.uptimeMillis() - snapshotStarted, instagramFeedSnapshotYields)) {
                instagramEntryTargets.clear()
                return null
            }
            val node = pending.removeFirst()
            visited++
            var shouldPruneSubtree = false
            // Android visibility propagates: a subtree under an invisible node
            // can never expose a visible descendant. Expanding those nodes
            // spends every child on binder IPC only to discard the result.
            val nodeVisible = node.isVisibleToUser

            if (nodeVisible) {
                val id = compactId(node.viewIdResourceName)
                if (id.isNotEmpty()) ids.add(id)

                val text = node.text?.toString()?.trim()?.lowercase(Locale.US).orEmpty()
                val desc = node.contentDescription?.toString()?.trim()?.lowercase(Locale.US).orEmpty()

                val bounds = Rect().also(node::getBoundsInScreen)
                if (id.isEmpty() && InstagramProfileSurfacePolicy.isIdlessMediaTile(
                        className = node.className?.toString().orEmpty(),
                        width = bounds.width(), height = bounds.height(),
                        windowWidth = rootBounds.width())) idlessMediaTiles++
                val entry = if (instagramEntryTargets.size < 32) {
                    resolveReelsEntry(node, id, text, desc)
                } else null
                if (entry != null) {
                    val clipped = Rect().also(entry::getBoundsInScreen)
                    if (id == "reel_share_item_view") {
                        // A scrolled card can extend behind the composer/header.
                        // Never carry its input shield onto those safe controls.
                        val viewport = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/message_list")
                        if (viewport == null || !clipped.intersect(viewport)) clipped.setEmpty()
                        findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/message_composer_bar")?.let {
                            clipped.bottom = minOf(clipped.bottom, it.top)
                        }
                    }
                    if (clipped.intersect(rootBounds) && clipped.width() > 0 && clipped.height() > 0 &&
                        clipped.height() < rootBounds.height() / 2) {
                        instagramEntryTargets.add(clipped to (id == "clips_tab"))
                    }
                }
                if (id in setOf("root_clips_layout", "clips_viewer", "clips_viewer_view_pager", "clips_view_pager") &&
                    bounds.height() >= rootBounds.height() * 0.6 &&
                    bounds.width() >= rootBounds.width() * 0.8) {
                    hasFullscreenReelsViewer = true
                }
                val isTopHeaderArea = bounds.top <= rootBounds.top + (rootBounds.height() / 4)


                // 1. Back button detection: must be an explicit back action/button, not "backdrop" or "background"
                val isExplicitBackId = id == "action_bar_button_back" ||
                    id.contains("action_bar_back") ||
                    id.contains("back_button") ||
                    id.contains("navigation_back") ||
                    (id.contains("back") && !id.contains("background") && !id.contains("backdrop"))
                // Ids only: a localized "Back" description matched TR/EN alone.
                if (isExplicitBackId) {
                    hasBackNav = true
                }

                // 2. Camera action icon in header
                if (isTopHeaderArea && id.contains("camera")) {
                    hasCameraAction = true
                }

                // 3. Titles / header text in action bar title views or text views with title/header id
                val isTitleView = id.contains("action_bar_title") ||
                    id.contains("clips_viewer_action_bar_title") ||
                    id == "title_text" || id == "action_bar_title_view" ||
                    (id.contains("title") && !id.contains("container") && !id.contains("tray") && !id.contains("holder"))
                if (isTitleView) {
                    if (text.isNotEmpty()) titles.add(text)
                    if (desc.isNotEmpty()) titles.add(desc)
                }
                // 4. Clips / Reels interaction bar buttons
                if (id.contains("clips_ufi") || id.contains("clips_viewer_action_bar")) {
                    hasClipsInteractionBar = true
                }

                if (node.isSelected || (tabForId(id) != null && isSelectedRecursive(node, 2))) {
                    // Tab ids only; a tab's localized description is never read.
                    tabForId(id)?.let(selectedTabs::add)
                }

                val className = node.className?.toString().orEmpty()
                if (InstagramSurfacePolicy.isFocusedSearchField(id, className, node.isFocused)) {
                    searchFieldFocused = true
                }

                // Skip post/tray descendants; their chrome is sufficient for classification.
                if (InstagramSurfacePolicy.skipInboxRows(id,
                        inboxHeaderSeen = InstagramSurfacePolicy.INBOX_HEADER_IDS.any(ids::contains)) ||
                    InstagramSurfacePolicy.skipProtectedProfileGridChildren(id,
                        measuredProfileGrid = protectedProfileGrid,
                        profileHeaderVisible = protectedProfileGrid) ||
                    id.startsWith("row_feed_") ||
                    id == "carousel_media_group" ||
                    id.startsWith("feed_item_") ||
                    id == "reels_tray_container" ||
                    id.contains("reels_tray") ||
                    id.contains("tray_recycler_view") ||
                    id.contains("comments_recycler") ||
                    id.contains("comment_thread") ||
                    id.contains("comment_list")
                ) {
                    shouldPruneSubtree = true
                }
            }

            if (!shouldPruneSubtree && nodeVisible) {
                for (index in 0 until node.childCount) {
                    node.getChild(index)?.let(pending::addLast)
                }
            }
        }

        val sourceIds = linkedSetOf<String>()
        val sourceLabels = linkedSetOf<String>()
        var explicitSourceTab: InstagramTab? = null
        var current = source
        var depth = 0
        while (current != null && depth < 8) {
            val id = compactId(current.viewIdResourceName)
            if (id.isNotEmpty()) sourceIds.add(id)
            current.text?.toString()?.trim()?.lowercase(Locale.US)
                ?.takeIf(String::isNotEmpty)
                ?.let(sourceLabels::add)
            current.contentDescription?.toString()?.trim()?.lowercase(Locale.US)
                ?.takeIf(String::isNotEmpty)
                ?.let(sourceLabels::add)
            if (explicitSourceTab == null) explicitSourceTab = tabForId(id)
            current = current.parent
            depth++
        }
        val sourceTab = explicitSourceTab

        val signals = InstagramUiSignals(
            ids = ids,
            selectedTabs = selectedTabs,
            sourceIds = sourceIds,
            sourceLabels = sourceLabels,
            sourceTab = sourceTab,
            searchFieldFocused = searchFieldFocused,
            titles = titles,
            hasBackNavigation = hasBackNav,
            hasCameraAction = hasCameraAction,
            hasClipsInteractionBar = hasClipsInteractionBar,
            hasFullscreenReelsViewer = hasFullscreenReelsViewer,
            idlessMediaTiles = idlessMediaTiles
        )
        return signals
    }

    private fun handleTikTok(event: AccessibilityEvent) {
        if (ProtectionFlightRecorder.ENABLED && event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val path = sourcePathIds(event.source, 6).joinToString(">")
            val bounds = Rect().also { event.source?.getBoundsInScreen(it) }
            // Scroll deltas exist from Android 9; minSdk is 8.0.
            val deltas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                "dx=${event.scrollDeltaX} dy=${event.scrollDeltaY}"
            } else "dx=? dy=?"
            ProtectionFlightRecorder.record(this, "tiktok.scroll",
                "class=${event.className} path=$path bounds=$bounds $deltas " +
                    "from=${event.fromIndex} to=${event.toIndex} " +
                    "count=${event.itemCount} direction=${scrollDirection(event)}")
        }
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> maybeSnapBackFromBlockedTopTab(force = true)
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                val direction = scrollDirection(event)
                if (!ScrollEventPolicy.mayBeVertical(direction) || !handleTikTokScroll(event, direction)) {
                    maybeSnapBackFromBlockedTopTab()
                }
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> maybeSnapBackFromBlockedTopTab()
            else -> Unit
        }
    }

    /** Returns true when the event was a feed swipe (exited or still in cooldown). */
    private fun handleTikTokScroll(event: AccessibilityEvent, direction: ScrollDirection): Boolean {
        val protectionEnabled = ProtectionPreferences.isEnabled(this, ProtectedApp.TIKTOK)
        if (!protectionEnabled) return false
        // The scrolled container itself identifies a feed swipe; no label or
        // obfuscated id is read, so this works in every UI language.
        val source = event.source ?: return false
        val bounds = Rect().also(source::getBoundsInScreen)
        val screen = currentDisplayBounds()
        val feedSwipe = TikTokSurfacePolicy.isFeedSwipe(
            className = event.className,
            idFragment = compactId(source.viewIdResourceName),
            direction = direction,
            top = bounds.top,
            width = bounds.width(),
            height = bounds.height(),
            screenWidth = screen.width(),
            screenHeight = screen.height()
        )
        if (!feedSwipe) return false
        val packageInForeground = ProtectedApp.TIKTOK.owns(rootInActiveWindow?.packageName?.toString())
        if (!TikTokInterventionPolicy.shouldExit(
                protectionEnabled = protectionEnabled,
                isScrollEvent = true,
                packageInForeground = packageInForeground,
                isVerticalScroll = true,
                isSafeSurface = false
            )
        ) {
            return false
        }

        val now = System.currentTimeMillis()
        if (!TikTokInterventionPolicy.cooldownElapsed(now, lastTikTokExitTime)) return true

        val accepted = performGlobalAction(GLOBAL_ACTION_BACK)
        SupportDiagnostics.record(this, SupportEvent.TIKTOK, mapOf("what" to "feed", "ok" to accepted))
        if (accepted) {
            lastTikTokExitTime = now
            recordIntervention(TIKTOK_PACKAGE, now)
            scheduleTikTokFeedExitRetry()
        } else {
            // Do not count a block that Android rejected; the next scroll event may retry.
            Log.w(TAG, "TIKTOK_EXIT_REJECTED")
        }
        return true
    }

    private fun scheduleTikTokFeedExitRetry() {
        mainHandler.removeCallbacks(tikTokFeedExitRetry)
        mainHandler.postDelayed(tikTokFeedExitRetry, TikTokInterventionPolicy.EXIT_RETRY_DELAY_MS)
    }

    // TikTok may swallow the first Back as an "exit app" confirmation; verify the feed is
    // still foregrounded and press Back once more so the first scroll deterministically exits.
    // A video opened from a profile or search returns there after the first Back instead.
    private val tikTokFeedExitRetry = Runnable {
        val root = rootInActiveWindow ?: return@Runnable
        if (!ProtectedApp.TIKTOK.owns(root.packageName?.toString())) return@Runnable
        if (scanTikTokLayout(root).feedPagerVisible) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    // Only For You may be browsed among the Home top tabs. Clicks and surface changes are
    // checked with a small throttle; when another top tab ends up selected, select For You.
    private fun maybeSnapBackFromBlockedTopTab(force: Boolean = false) {
        val root = rootInActiveWindow ?: return
        if (!ProtectedApp.TIKTOK.owns(root.packageName?.toString())) return
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.TIKTOK)) return
        val now = System.currentTimeMillis()
        if (!force && !TikTokInterventionPolicy.topTabCheckElapsed(now, lastTikTokTopTabCheckMs)) {
            return
        }
        lastTikTokTopTabCheckMs = now

        val layout = scanTikTokLayout(root)
        val target = TikTokSurfacePolicy.snapBackTarget(
            layout.selectedTopTab, layout.topTabs.size, layout.homeTabSelected) ?: return
        var current: AccessibilityNodeInfo? = layout.topTabs[target]
        repeat(3) {
            val candidate = current ?: return
            if (candidate.isClickable) {
                if (candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    SupportDiagnostics.record(this, SupportEvent.TIKTOK, mapOf("what" to "tab"))
                    recordIntervention(TIKTOK_PACKAGE, System.currentTimeMillis())
                    Log.d(TAG, "TIKTOK_TOP_TAB_SNAP_BACK from=${layout.selectedTopTab} to=$target")
                }
                return
            }
            current = candidate.parent
        }
    }

    private class TikTokLayout(
        val feedPagerVisible: Boolean,
        val homeTabSelected: Boolean,
        val topTabs: List<AccessibilityNodeInfo>,
        val selectedTopTab: Int
    )

    /**
     * One bounded walk for the structure both checks need: whether a fullscreen
     * short-video pager is visible, whether the bottom bar's first item (Home)
     * is selected, and the top feed tab strip (the horizontal scroller near the
     * top of the screen) with its selected position.
     */
    private fun scanTikTokLayout(root: AccessibilityNodeInfo): TikTokLayout {
        val started = SystemClock.uptimeMillis()
        val screen = currentDisplayBounds()
        val bounds = Rect()
        var feedPagerVisible = false
        var homeTabSelected = false
        var bottomBarSeen = false
        var tabs: List<AccessibilityNodeInfo> = emptyList()
        var selected = -1
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(root)
        var visited = 0

        while (pending.isNotEmpty() && visited < MAX_TREE_NODES) {
            val node = pending.removeFirst()
            visited++
            if (!node.isVisibleToUser) continue
            node.getBoundsInScreen(bounds)
            if (!bottomBarSeen && node.childCount in 4..6 &&
                bounds.top >= screen.height() * 0.85
            ) {
                val items = (0 until node.childCount).mapNotNull(node::getChild)
                if (TikTokSurfacePolicy.isBottomBar(bounds.top, bounds.width(),
                        items.count { it.isClickable }, screen.width(), screen.height())
                ) {
                    bottomBarSeen = true
                    homeTabSelected = items.firstOrNull()?.let(::isTikTokTabSelected) == true
                }
            }
            // Class only: the horizontal tab pagers share the readable
            // `viewpager` id but report an obfuscated class.
            val isFeedPager = node.isScrollable &&
                TikTokSurfacePolicy.isPagerClass(node.className) &&
                TikTokSurfacePolicy.isFeedPagerBounds(
                    bounds.top, bounds.width(), bounds.height(), screen.width(), screen.height())
            if (isFeedPager) feedPagerVisible = true
            if (tabs.isEmpty() && node.className?.toString()?.contains("HorizontalScrollView") == true &&
                TikTokSurfacePolicy.isTopTabStrip(bounds.top, screen.height())
            ) {
                val row = if (node.childCount == 1) node.getChild(0) else node
                if (row != null) {
                    tabs = (0 until row.childCount).mapNotNull(row::getChild)
                    selected = tabs.indexOfFirst(::isTikTokTabSelected)
                }
            }
            // Every child read waits for TikTok's UI thread while a video plays
            // (up to 2 s per walk on a Galaxy S9+), so stop once all three are
            // known and never enter the video pages: they hold each video's own
            // controls, not the top tabs or the bottom bar.
            if (TikTokSurfacePolicy.layoutWalkComplete(feedPagerVisible, bottomBarSeen, tabs.size)) break
            if (isFeedPager) continue
            for (index in 0 until node.childCount) {
                node.getChild(index)?.let(pending::addLast)
            }
        }
        if (ProtectionFlightRecorder.ENABLED) {
            val elapsed = SystemClock.uptimeMillis() - started
            if (elapsed >= 24L) ProtectionFlightRecorder.record(this, "tiktok.layout",
                "visited=$visited elapsedMs=$elapsed pager=$feedPagerVisible bar=$bottomBarSeen tabs=${tabs.size}")
        }
        return TikTokLayout(feedPagerVisible, homeTabSelected, tabs, selected)
    }

    private fun isTikTokTabSelected(tab: AccessibilityNodeInfo): Boolean {
        if (tab.isSelected) return true
        for (index in 0 until tab.childCount) {
            if (tab.getChild(index)?.isSelected == true) return true
        }
        return false
    }

    /**
     * Balanced leaves Subscriptions open, and in YouTube's 2026 layout it is a
     * page of the same horizontal pager as Home and Music. Its curtain only
     * follows a settled tab, so a sideways drag held halfway showed the Home
     * feed beside it. The pager's first scroll covers the feed at once; a drag
     * that settles back on Subscriptions lifts it again.
     */
    private fun coverYouTubeFeedPagerSwipe(event: AccessibilityEvent, now: Long) {
        if (youtubeObservedScreen != YouTubeCurtainScreen.SUBSCRIPTIONS || youtubeSubscriptionsProtected()) return
        if (event.className?.toString()?.endsWith("ViewPager") != true) return
        // Arriving on Subscriptions (tab tap or a finished swipe) ends with
        // the pager's own settle scroll; that is not a new drag.
        if (now - youtubeSubscriptionsSince < YOUTUBE_FEED_PAGER_SETTLE_MS ||
            now - youtubeLastClickAt < YOUTUBE_FEED_PAGER_SETTLE_MS) return
        // Without deltas (Android 8) a settling page scroll looks the same.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P || event.scrollDeltaX == 0) return
        if (youtubeCurtainState.pendingDestination == YouTubeCurtainScreen.HOME) return
        youtubeCurtainState.request(YouTubeCurtainScreen.HOME, now)
        youtubeOverlay.showCurtain(null, youtubeCurtainState.currentSurface, isEnglish(), preserveBounds = true)
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
            "youtube.feed.pager", "covered from=SUBSCRIPTIONS")
        queueYouTubeSurfaceScan(0L)
    }

    private fun handleYouTube(event: AccessibilityEvent) {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.YOUTUBE)) {
            resetYouTubeProtection()
            youtubeShortsSession.clear()
            return
        }
        val now = SystemClock.uptimeMillis()
        val isClickEvent = event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED
        val isScrollEvent = event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED
        // Content and window-state events only schedule classification. Fetching
        // the root or the event source here costs a remote call per event that
        // waits for YouTube's UI thread; during a transition those calls queued
        // the following events for hundreds of milliseconds.
        if (!isClickEvent) {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                // Bursts of 3-6 per transition coalesce into one scan behind
                // the events already queued on the main looper.
                queueYouTubeSurfaceScan(0L)
            } else queueYouTubeContentScan()
            scheduleYouTubeOverlayForegroundCheck()
            if (isScrollEvent) coverYouTubeFeedPagerSwipe(event, now)
            if (!isScrollEvent ||
                ProtectionPreferences.getMode(this, ProtectedApp.YOUTUBE) == ProtectionMode.STRICT
            ) return
            // Feed, results and comment scrolls far outnumber Shorts swipes, and
            // walking each source's ancestors cost up to 160 ms. Only a scroll
            // inside a known or freshly classified Shorts viewer can end a session.
            if (youtubeShortsSession.state == YouTubeShortsSessionState.OUTSIDE &&
                youtubeObservedScreen != YouTubeCurtainScreen.SHORTS &&
                youtubeLastVerifiedScreen != YouTubeCurtainScreen.SHORTS
            ) return
        }
        val source = event.source
        if (isClickEvent) {
            youtubeLastClickAt = now
            val root = currentYouTubeRoot() ?: return
            // Both modes cover Home the same way; Balanced leaves Subscriptions
            // open (youtubeFeedSurface). Shorts viewing also differs: strict
            // rejects entry, balanced runs the session below.
            val destination = youtubeNavigationIntent(source)
            val selected = collectYouTubeNavigationSignals(root).selectedDestination
            val dispatchFeedback = destination == youtubeLastDispatchedTab &&
                now - youtubeLastDispatchedTabAt < 700L
            if (destination != YouTubeNavigationDestination.UNKNOWN &&
                destination == selected && !dispatchFeedback && !youtubeCurtainState.isPending
            ) {
                youtubeCurtainState.request(destination.curtainScreen(), now)
                youtubeAllowedReturnSurface = null
            } else if (!youtubeCurtainState.isPending &&
                // Only a launch from a protected feed records where Back must
                // return. The search page reports a click on its own search
                // field; treating that as a new launch replaced HOME with the
                // search page's null surface and dropped the Back guard.
                youtubeCurtainState.currentSurface != null &&
                isYouTubeExplicitlyAllowedNavigationSource(source, root)) {
                youtubeAllowedReturnSurface = youtubeCurtainState.currentSurface
                youtubeCurtainState.request(youtubeAllowedLaunchScreen(source, root), now)
            }
            // A click must classify against the tree that produced it.
            refreshYouTubeSurfaceProtection(root)
            scheduleYouTubeOverlayForegroundCheck()
            if (ProtectionPreferences.getMode(this, ProtectedApp.YOUTUBE) == ProtectionMode.STRICT) return
        }
        val launchRequested = isClickEvent && isYouTubeShortsLaunchSource(source)
        // One ancestor walk serves both questions; each step can be a remote call.
        val sourcePath = sourcePathIds(source, YOUTUBE_SOURCE_PATH_DEPTH)
        val safeBottomSheetOpen = sourcePath.any { id ->
            listOf("comment", "reply", "bottom_sheet", "results").any(id::contains)
        }
        // The reel source proves the Shorts context, but not user intent: YouTube emits a
        // zero-delta reel_recycler scroll while merely opening a Short and closing a sheet.
        val sourceIsShortsPager = sourcePath.any { id ->
            listOf("reel_recycler", "reel_watch", "reel_player", "shorts_player", "shorts_video")
                .any(id::contains)
        }
        val direction = if (isScrollEvent) scrollDirection(event) else ScrollDirection.NONE
        // Without a direction, the page filling the pager tells whether the
        // viewer moved on. Read only then: each child is a remote call.
        val visiblePagerRow = if (isScrollEvent && sourceIsShortsPager && source != null &&
            (direction == ScrollDirection.UNDEFINED || direction == ScrollDirection.NONE)
        ) youtubeShortsPagerRow(source) else null
        if (ProtectionFlightRecorder.ENABLED && isScrollEvent) {
            val deltas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                "dx=${event.scrollDeltaX} dy=${event.scrollDeltaY}"
            } else "dx=? dy=?"
            ProtectionFlightRecorder.record(this, "youtube.shorts.scroll",
                "path=${sourcePath.take(2).joinToString(">")} $deltas from=${event.fromIndex} " +
                    "to=${event.toIndex} direction=$direction row=$visiblePagerRow " +
                    "session=${youtubeShortsSession.state}")
        }
        val feedTabEntry = isClickEvent && YouTubeShortsPolicy.shouldBlockEntry(
            ProtectionMode.BALANCED,
            youtubeNavigationIntent(source) == YouTubeNavigationDestination.SHORTS
        )
        if (feedTabEntry) {
            // A real tab tap. The tab guard normally consumes the touch before
            // YouTube sees it; this latch covers the frames where one slips
            // through so later scans can distinguish it from a Short opened
            // via a link, search result or notification.
            youtubeShortsTabClickUntil = now + YOUTUBE_SHORTS_TAB_CLICK_LATCH_MS
        }
        val decision = youtubeShortsSession.observe(YouTubeShortsObservation(
            nowMs = now,
            shortsStructureVisible = false,
            launchRequested = launchRequested,
            definitelyOutsideShorts = false,
            safeBottomSheetOpen = safeBottomSheetOpen,
            isScrollEvent = isScrollEvent,
            hasVerticalMovement = isScrollEvent && ScrollEventPolicy.isShortsMovement(direction),
            sourceIsShortsPager = sourceIsShortsPager,
            feedTabEntry = feedTabEntry,
            visiblePagerRow = visiblePagerRow
        ))
        queueYouTubeContentScan()
        // Entering and watching the first Short stays allowed. Only a real vertical movement
        // outside a safe bottom sheet can move the session to EXITING.
        if (decision != YouTubeShortsDecision.EXIT) return
        performYouTubeShortsExit()
    }

    private fun youtubeShortsPagerRow(pager: AccessibilityNodeInfo): Int? {
        val pagerBounds = Rect().also(pager::getBoundsInScreen)
        val childBounds = Rect()
        val rows = (0 until pager.childCount.coerceAtMost(4)).mapNotNull { index ->
            val child = pager.getChild(index) ?: return@mapNotNull null
            val row = child.collectionItemInfo?.rowIndex ?: return@mapNotNull null
            child.getBoundsInScreen(childBounds)
            YouTubeShortsPolicy.PagerRow(row, childBounds.top, childBounds.bottom)
        }
        return YouTubeShortsPolicy.dominantRow(rows, pagerBounds.top, pagerBounds.bottom)
    }

    private fun performYouTubeShortsExit() {
        val token = youtubeShortsSession.generation
        val accepted = performGlobalAction(GLOBAL_ACTION_BACK)
        SupportDiagnostics.record(this, SupportEvent.YOUTUBE_SHORTS, mapOf("what" to "next", "ok" to accepted))
        recordYouTubeViewerIntervention(accepted)

        mainHandler.postDelayed({
            // The user may already have returned to results and opened another Short.
            // An old attempt must neither close that viewer nor clear its new session.
            if (!youtubeShortsSession.isExitPending(token, SystemClock.uptimeMillis())) {
                return@postDelayed
            }
            if (!ProtectionPreferences.isEnabled(this, ProtectedApp.YOUTUBE) ||
                ProtectionPreferences.getMode(this, ProtectedApp.YOUTUBE) != ProtectionMode.BALANCED
            ) {
                youtubeShortsSession.finishExit(token)
                return@postDelayed
            }
            val root = rootInActiveWindow
            if (root?.packageName?.toString() != YOUTUBE_PACKAGE) {
                youtubeShortsSession.finishExit(token)
                return@postDelayed
            }

            val signals = collectYouTubeSignals(root)
            if (youtubeShortsSession.isExitPending(token, SystemClock.uptimeMillis()) &&
                signals.shortsVisible && !signals.safeBottomSheetOpen
            ) {
                val accepted = performGlobalAction(GLOBAL_ACTION_BACK)
                SupportDiagnostics.record(this, SupportEvent.YOUTUBE_SHORTS, mapOf("what" to "retry", "ok" to accepted))
                recordYouTubeViewerIntervention(accepted)
            }
            // Always acknowledge completion, even if the returned results page lacks the
            // expected browse IDs. EXITING must never become an unbounded allow-all state.
            youtubeShortsSession.finishExit(token)
        }, YouTubeShortsPolicy.EXIT_RETRY_DELAY_MS)
    }

    private data class YouTubeUiSignals(
        val shortsVisible: Boolean,
        val safeBottomSheetOpen: Boolean,
        val definiteBrowseSurface: Boolean,
        val protectedSurface: YouTubeProtectedSurface?,
        val feedViewportBounds: Rect?,
        val shortsTabBounds: Rect?,
        val homeTabBounds: Rect?,
        val subscriptionsTabBounds: Rect?,
        val youTabBounds: Rect?,
        val allowedBackBounds: Rect?,
        val selectedDestination: YouTubeNavigationDestination,
        val searchSurfaceVisible: Boolean,
        val allowedSecondarySurfaceVisible: Boolean,
        val screen: YouTubeCurtainScreen = YouTubeCurtainScreen.UNKNOWN,
        val windowBounds: Rect? = null,
        val allowedLaunchBounds: Map<YouTubeCurtainScreen, Rect> = emptyMap(),
        val miniplayerBounds: Rect? = null,
        /** The toolbar and the bottom tabs both scrolled away with the feed. */
        val barsScrolledAway: Boolean = false
    )

    private fun collectYouTubeSignals(root: AccessibilityNodeInfo): YouTubeUiSignals {
        val navigation = collectYouTubeNavigationSignals(root)
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(root)
        var visited = 0
        var shortsVisible = listOf(
            "shorts_player",
            "reel_recycler",
            "shorts_video",
            "reel_watch_sequence",
            "reel_watch_fragment_root"
        ).any { id ->
            root.findAccessibilityNodeInfosByViewId("$YOUTUBE_PACKAGE:id/$id")
                .orEmpty()
                .isNotEmpty()
        }
        var bottomSheetHandleVisible = findVisibleNodeBounds(
            root,
            "$YOUTUBE_PACKAGE:id/arrow_drag_handle"
        ) != null
        var sheetCloseControlVisible = findVisibleNodeBounds(
            root,
            "$YOUTUBE_PACKAGE:id/close_button"
        ) != null
        val homeToolbarVisible = hasQuickYouTubeHomeToolbar(root)
        var definiteBrowseSurface = homeToolbarVisible
        var searchSurfaceVisible = false
        var allowedSecondarySurfaceVisible = false
        var allowedBackCandidate: Rect? = null
        val selectedDestination = navigation.selectedDestination
        // The selected Shorts tab is the fullscreen Shorts player.
        if (selectedDestination == YouTubeNavigationDestination.SHORTS) shortsVisible = true
        var bottomBarTop: Int? = navigation.bottomBarTop
        val shortsTabCandidate: Rect? = navigation.shortsTabBounds
        val rootBounds = Rect().also(root::getBoundsInScreen)
        val toolbarBounds = findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/toolbar")
        val toolbarContainerBounds = findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/toolbar_container")

        while (pending.isNotEmpty() && visited < MAX_TREE_NODES) {
            val node = pending.removeFirst()
            visited++
            var pruneSubtree = false

            val id = compactId(node.viewIdResourceName)
            // Structural reel ids may temporarily report not-visible while the pager settles.
            // They still belong to the active window and are stronger evidence than visibility.
            if (id.contains("shorts_player") ||
                id.contains("reel_recycler") ||
                id.contains("shorts_video") ||
                id.contains("reel_watch_sequence") ||
                id.contains("reel_watch_fragment_root")
            ) {
                shortsVisible = true
            }

            if (node.isVisibleToUser) {
                val bounds = Rect().also(node::getBoundsInScreen)
                val isSearchSurfaceId = YouTubeUiIdentity.isSearchSurfaceId(id)
                val isSearchSurfaceNode = isSearchSurfaceId &&
                    YouTubeUiIdentity.hasMeaningfulHorizontalPresence(
                        left = bounds.left,
                        right = bounds.right,
                        windowLeft = rootBounds.left,
                        windowRight = rootBounds.right
                    )
                if (id.contains("youtube_logo") || isSearchSurfaceNode) {
                    definiteBrowseSurface = true
                }
                if (isSearchSurfaceNode) searchSurfaceVisible = true
                if (YouTubeUiIdentity.isAllowedSecondarySurfaceId(id) &&
                    YouTubeUiIdentity.isHorizontallyOnScreen(
                        left = bounds.left,
                        right = bounds.right,
                        windowLeft = rootBounds.left,
                        windowRight = rootBounds.right
                    )
                ) {
                    allowedSecondarySurfaceVisible = true
                }
                val leading = leftToRight(bounds, rootBounds, YOUTUBE_PACKAGE)
                if (YouTubeUiIdentity.isLeadingToolbarButton(
                        node.className, node.isClickable, leading.left, leading.right,
                        rootBounds.left, rootBounds.right, dp(8)) &&
                    bounds.height() > 0 &&
                    bounds.top < rootBounds.top + rootBounds.height() / 4
                ) {
                    allowedBackCandidate = Rect(bounds)
                }
                if (id.contains("arrow_drag_handle")) bottomSheetHandleVisible = true
                if (id.contains("close_button")) sheetCloseControlVisible = true
                if (id.contains("bottom_bar_container") && bounds.height() > 0) {
                    bottomBarTop = bottomBarTop?.coerceAtMost(bounds.top) ?: bounds.top
                }
            }

            // The feed/results subtree contains hundreds of remote nodes and none of their
            // descendants are needed to classify Home, Subscriptions, Search or the bottom
            // navigation. Traversing it for every content event was measured at up to two
            // seconds on a real Samsung device. Its own bounds were already consumed above;
            // Shorts/comment intent is handled from exact IDs and the originating event path.
            if (id == "results" || id == "bottom_bar_container") {
                pruneSubtree = true
            }

            if (!pruneSubtree) {
                for (index in 0 until node.childCount) {
                    node.getChild(index)?.let(pending::addLast)
                }
            }
        }

        if (hasQuickYouTubeNotificationsSurface(root)) {
            allowedSecondarySurfaceVisible = true
        }
        if (hasQuickYouTubeSearchSurface(root)) {
            searchSurfaceVisible = true
        }
        if (homeToolbarVisible || selectedDestination == YouTubeNavigationDestination.YOU) {
            // YouTube leaves the outgoing Notifications/Search toolbar in the same tree while
            // Home is already on screen. Its live logo wins over those stale allowed IDs.
            // On the You tab, toolbar buttons like menu_search are part of the account header,
            // never a secondary overlay surface that should return to feed.
            searchSurfaceVisible = false
            allowedSecondarySurfaceVisible = false
            // Embedded Shorts shelf, ads, or preview videos on the Home feed must never treat
            // the Home feed as the fullscreen Shorts player.
            shortsVisible = false
        }
        val protectedSurface = YouTubeSurfacePolicy.strictProtectedSurface(
            destination = selectedDestination,
            searchSurfaceVisible = searchSurfaceVisible,
            shortsVisible = shortsVisible,
            allowedSecondarySurfaceVisible = allowedSecondarySurfaceVisible
        )
        val feedViewportBounds = YouTubeFeedGeometry.calculateFeedViewport(
            rootBounds = rootBounds,
            statusBarInset = statusBarInset(),
            toolbarBottom = toolbarBounds?.bottom,
            toolbarContainerBottom = toolbarContainerBounds?.bottom,
            bottomBarTop = bottomBarTop,
            dp56 = dp(56),
            dp48 = dp(48),
            dp16 = dp(16),
            toolbarScrolledAway = YouTubeFeedGeometry.toolbarScrolledAway(
                toolbarBounds != null || toolbarContainerBounds != null,
                bottomBarTop != null, selectedDestination),
            bottomBarScrolledAway = YouTubeFeedGeometry.bottomBarScrolledAway(
                bottomBarTop != null),
            tappableBottomInset = tappableBottomInset()
        )
        val shortsTabBounds = shortsTabCandidate?.takeIf { tab ->
            // YouTube may retain a hidden reel tree briefly after leaving Shorts. The live
            // navigation selection is the authoritative signal for whether this entry guard
            // belongs over the visible bottom bar.
            selectedDestination != YouTubeNavigationDestination.SHORTS &&
                bottomBarTop?.let { tab.centerY() >= it } == true
        }

        return YouTubeUiSignals(
            shortsVisible = shortsVisible,
            safeBottomSheetOpen = bottomSheetHandleVisible && sheetCloseControlVisible,
            definiteBrowseSurface = definiteBrowseSurface && !shortsVisible,
            protectedSurface = protectedSurface,
            feedViewportBounds = feedViewportBounds,
            shortsTabBounds = shortsTabBounds,
            homeTabBounds = navigation.homeTabBounds,
            subscriptionsTabBounds = navigation.subscriptionsTabBounds,
            youTabBounds = navigation.youTabBounds,
            allowedBackBounds = allowedBackCandidate,
            selectedDestination = selectedDestination,
            searchSurfaceVisible = searchSurfaceVisible,
            allowedSecondarySurfaceVisible = allowedSecondarySurfaceVisible
        )
    }

    private data class YouTubeNavigationSignals(
        val selectedDestination: YouTubeNavigationDestination,
        val bottomBarTop: Int?,
        val shortsTabBounds: Rect?,
        val homeTabBounds: Rect?,
        val subscriptionsTabBounds: Rect?,
        val youTabBounds: Rect?,
        /** Tab buttons in the bottom bar (0 when it is hidden). */
        val itemCount: Int = 0
    )

    private fun collectYouTubeNavigationSignals(
        root: AccessibilityNodeInfo
    ): YouTubeNavigationSignals {
        val bars = visibleYouTubeNavigationBars(root)
        var selectedDestination = YouTubeNavigationDestination.UNKNOWN
        var bottomBarTop: Int? = null
        var shortsTabBounds: Rect? = null
        var homeTabBounds: Rect? = null
        var subscriptionsTabBounds: Rect? = null
        var youTabBounds: Rect? = null
        var itemCount = 0

        for (bar in bars) {
            val barBounds = Rect().also(bar::getBoundsInScreen)
            if (barBounds.width() <= 0 || barBounds.height() <= 0) continue
            bottomBarTop = bottomBarTop?.coerceAtMost(barBounds.top) ?: barBounds.top

            val items = youtubeNavigationItems(bar, barBounds)
            itemCount = maxOf(itemCount, items.size)
            if (items.size >= 2) noteLayoutDirection(YOUTUBE_PACKAGE,
                Rect().also(items.first()::getBoundsInScreen), Rect().also(items.last()::getBoundsInScreen))
            items.forEachIndexed { index, node ->
                val destination = YouTubeSurfacePolicy.navigationDestinationAt(index, items.size)
                if (destination == YouTubeNavigationDestination.UNKNOWN) return@forEachIndexed
                if (isSelectedItem(node)) selectedDestination = destination
                val bounds = Rect().also(node::getBoundsInScreen)
                if (bounds.width() <= 0 || bounds.height() <= 0) return@forEachIndexed
                when (destination) {
                    YouTubeNavigationDestination.SHORTS -> shortsTabBounds = bounds
                    YouTubeNavigationDestination.HOME -> homeTabBounds = bounds
                    YouTubeNavigationDestination.SUBSCRIPTIONS -> subscriptionsTabBounds = bounds
                    YouTubeNavigationDestination.YOU -> youTabBounds = bounds
                    YouTubeNavigationDestination.UNKNOWN -> Unit
                }
            }
        }

        return YouTubeNavigationSignals(
            selectedDestination = selectedDestination,
            bottomBarTop = bottomBarTop,
            shortsTabBounds = shortsTabBounds,
            homeTabBounds = homeTabBounds,
            subscriptionsTabBounds = subscriptionsTabBounds,
            youTabBounds = youTabBounds,
            itemCount = itemCount
        )
    }

    private fun findYouTubeNavigationNode(
        root: AccessibilityNodeInfo,
        destination: YouTubeNavigationDestination
    ): AccessibilityNodeInfo? {
        for (bar in visibleYouTubeNavigationBars(root)) {
            val items = youtubeNavigationItems(bar, Rect().also(bar::getBoundsInScreen))
            items.forEachIndexed { index, node ->
                if (YouTubeSurfacePolicy.navigationDestinationAt(index, items.size) == destination) {
                    return node
                }
            }
        }
        return null
    }

    private fun visibleYouTubeNavigationBars(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> =
        cachedNodeLookup(root, "$YOUTUBE_PACKAGE:id/bottom_bar_container")
            .filter { it.isVisibleToUser }.ifEmpty {
                cachedNodeLookup(root, "$YOUTUBE_PACKAGE:id/pivot_bar")
                    .filter { it.isVisibleToUser }
            }

    /**
     * The bottom navigation's tab buttons in layout order: the first visible
     * clickable nodes inside the bar that span most of its height. Their
     * position, not their localized label, names the destination.
     */
    private fun youtubeNavigationItems(
        bar: AccessibilityNodeInfo,
        barBounds: Rect
    ): List<AccessibilityNodeInfo> {
        val items = ArrayList<AccessibilityNodeInfo>(5)
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(bar)
        var visited = 0
        val bounds = Rect()
        while (pending.isNotEmpty() && visited < 60) {
            val node = pending.removeFirst()
            visited++
            // An invisible node cannot own a visible descendant.
            if (!node.isVisibleToUser) continue
            if (node !== bar && node.isClickable) {
                node.getBoundsInScreen(bounds)
                if (bounds.width() > 0 && bounds.height() * 2 >= barBounds.height() &&
                    barBounds.contains(bounds.centerX(), bounds.centerY())
                ) {
                    items += node
                    continue
                }
            }
            for (index in 0 until node.childCount) {
                node.getChild(index)?.let(pending::addLast)
            }
        }
        return items
    }

    private fun isSelectedItem(node: AccessibilityNodeInfo): Boolean {
        if (node.isSelected) return true
        for (index in 0 until node.childCount) {
            if (node.getChild(index)?.isSelected == true) return true
        }
        return false
    }

    private data class YouTubeToolbarSnapshot(
        val bounds: Rect?,
        val homeLogo: Boolean,
        val search: Boolean,
        /** A settled title next to Back: Notifications or another secondary page. */
        val titled: Boolean,
        val backNode: AccessibilityNodeInfo?,
        val loadingBackPresent: Boolean,
        /** Search/Notifications buttons by slot; only meaningful on a feed toolbar. */
        val launchNodes: Map<YouTubeCurtainScreen, AccessibilityNodeInfo>
    )

    private fun collectYouTubeToolbar(root: AccessibilityNodeInfo, window: Rect): YouTubeToolbarSnapshot {
        val toolbar = cachedNodeLookup(root, "$YOUTUBE_PACKAGE:id/toolbar")
            .firstOrNull { it.isVisibleToUser }
        val toolbarBounds = toolbar?.let { Rect().also(it::getBoundsInScreen) }
        var home = false
        var search = false
        var titled = false
        var back: AccessibilityNodeInfo? = null
        var loadingBackPresent = false
        val menuSlots = sortedMapOf<Int, AccessibilityNodeInfo>()
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        toolbar?.let(pending::addLast)
        var visited = 0
        while (pending.isNotEmpty() && visited++ < 40) {
            val node = pending.removeFirst()
            val bounds = Rect().also(node::getBoundsInScreen)
            // Back can still be sliding in (or not yet visible) while the page
            // loads; its class and size identify it before its position settles.
            if (node.isClickable && node.className?.contains("ImageButton") == true &&
                bounds.width() in 1..window.width() / 5
            ) loadingBackPresent = true
            if (node.isVisibleToUser) {
                val id = compactId(node.viewIdResourceName)
                val slot = YouTubeUiIdentity.menuItemIndex(id)
                if (slot >= 0) menuSlots[slot] = node
                val leading = leftToRight(bounds, window, YOUTUBE_PACKAGE)
                if (id == "youtube_logo" &&
                    YouTubeUiIdentity.isHomeToolbarLogo(
                        leading.left, leading.right, window.left, window.right, dp(72)
                    )
                ) {
                    home = true
                }
                if (YouTubeUiIdentity.isSearchSurfaceId(id) &&
                    YouTubeUiIdentity.isSettledSearchSurface(
                        id, leading.left, leading.right, window.left, window.right, dp(8)
                    )
                ) search = true
                if (YouTubeUiIdentity.isSettledToolbarTitle(
                        node.className, node.text, node.isClickable, bounds.top - window.top,
                        window.height(), leading.left, leading.right, window.left, window.right, dp(8)
                    )
                ) titled = true
                if (YouTubeUiIdentity.isLeadingToolbarButton(
                        node.className, node.isClickable, leading.left, leading.right,
                        window.left, window.right, dp(8)
                    )
                ) back = node
                // An invisible toolbar node cannot own a visible descendant.
                for (index in 0 until node.childCount) node.getChild(index)?.let(pending::addLast)
            }
        }
        val launchNodes = mutableMapOf<YouTubeCurtainScreen, AccessibilityNodeInfo>()
        val lastSlot = menuSlots.keys.lastOrNull() ?: -1
        for ((slot, container) in menuSlots) {
            val target = YouTubeUiIdentity.feedToolbarLaunchScreen(slot, lastSlot) ?: continue
            // The slot is a FrameLayout around the clickable menu_item_view.
            val button = if (container.isClickable) container else
                (0 until container.childCount).firstNotNullOfOrNull { index ->
                    container.getChild(index)?.takeIf { it.isClickable && it.isVisibleToUser }
                }
            button?.let { launchNodes[target] = it }
        }
        // A secondary page's title only counts beside its Back control; the
        // Home and Subscriptions toolbars show the logo there.
        return YouTubeToolbarSnapshot(toolbarBounds, home, search, titled && back != null && !home,
            back, loadingBackPresent, launchNodes)
    }

    /** An expanded or full-screen watch page (not the minimized player). */
    private fun youtubeWatchSurfaceVisible(root: AccessibilityNodeInfo): Boolean =
        // watch_player alone also exists for the miniplayer; only then
        // are the two confirming lookups worth their remote cost.
        findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/watch_player") != null &&
            YouTubeUiIdentity.isConfirmedWatchSurface(
                watchPlayerVisible = true,
                watchPanelVisible = findVisibleNodeBounds(
                    root, "$YOUTUBE_PACKAGE:id/watch_panel") != null,
                inlinePlayerVisible = findVisibleNodeBounds(
                    root, "$YOUTUBE_PACKAGE:id/inline_player_container") != null
            )

    private data class YouTubeFeedTabsSnapshot(val bounds: Rect, val selected: YouTubeFeedTab)

    /** The Home feed's top tab strip and its selected page; null on any other page. */
    private fun collectYouTubeFeedTabs(
        root: AccessibilityNodeInfo,
        window: Rect,
        toolbar: YouTubeToolbarSnapshot,
        selectedDestination: YouTubeNavigationDestination,
        bottomBarItems: Int
    ): YouTubeFeedTabsSnapshot? {
        // A channel page's strip sits under Back and the channel name.
        val backPresent = toolbar.backNode != null || toolbar.loadingBackPresent || toolbar.titled
        if (backPresent && !ProtectionFlightRecorder.ENABLED) return null
        val strip = cachedNodeLookup(root, "$YOUTUBE_PACKAGE:id/tabs_bar_view")
            .firstOrNull { it.isVisibleToUser } ?: return null
        if (backPresent) {
            ProtectionFlightRecorder.record(this, "youtube.feed.strip",
                "rejected back=${toolbar.backNode != null} loadingBack=${toolbar.loadingBackPresent} " +
                    "titled=${toolbar.titled}")
            return null
        }
        val bounds = Rect().also(strip::getBoundsInScreen)
        // The strip starts at most one toolbar height below the status bar.
        // While the toolbar slides back in its reported bounds lag the strip
        // (toolbar [0,0][1080,136] above a strip at 217 on a Galaxy S23), so
        // the live toolbar edge is no limit.
        val topLimit = maxOf(window.top, statusBarInset()) + dp(56) + dp(24)
        if (!YouTubeFeedTabs.isFeedStrip(
                bounds.left, bounds.top, bounds.right, bounds.bottom,
                window.left, window.right, window.height(), topLimit,
                backPresent = false, selectedDestination = selectedDestination
            )) {
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "youtube.feed.strip", "rejected strip=$bounds toolbar=${toolbar.bounds} " +
                    "limit=$topLimit selected=$selectedDestination")
            return null
        }
        // The tabs are siblings, so breadth-first order is their layout order.
        // Tabs scrolled out of the strip are still in the tree and still count.
        var tabCount = 0
        var selectedIndex = -1
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.addLast(strip)
        var visited = 0
        while (pending.isNotEmpty() && visited++ < 80) {
            val node = pending.removeFirst()
            if (compactId(node.viewIdResourceName) == "tabs_bar_text_tab_view") {
                if (node.isSelected && selectedIndex < 0) selectedIndex = tabCount
                tabCount++
                continue
            }
            for (index in 0 until node.childCount) node.getChild(index)?.let(pending::addLast)
        }
        return YouTubeFeedTabsSnapshot(bounds,
            YouTubeFeedTabs.tabAt(selectedIndex, tabCount, bottomBarItems))
    }

    private fun collectYouTubeCurtainSignals(root: AccessibilityNodeInfo): YouTubeUiSignals {
        val navigation = collectYouTubeNavigationSignals(root)
        val window = Rect().also(root::getBoundsInScreen)
        val toolbarSnapshot = collectYouTubeToolbar(root, window)
        val homeToolbar = toolbarSnapshot.homeLogo
        val search = toolbarSnapshot.search
        // Every exact-ID lookup is a full remote traversal that waits for
        // YouTube's UI thread, which is busiest exactly during transitions.
        // Evaluate them lazily in classifier order: a settled Home toolbar or
        // a settled secondary page never needs the player/profile/camera
        // probes, and those used to queue 15+ IPCs per scan.
        val shorts = !homeToolbar && listOf(
            "reel_recycler", "reel_watch_fragment_root", "shorts_player"
        ).any { id ->
            findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/$id")?.let {
                YouTubeUiIdentity.hasMeaningfulHorizontalPresence(
                    it.left, it.right, window.left, window.right
                ) && it.height() >= window.height() / 2
            } == true
        }
        // YouTube's 2026 layout: the feed's top tab strip names Home and
        // Subscriptions, and outlives the logo when a drag collapses the
        // toolbar. Without it that frame read as a channel page and the
        // curtain lifted off the Home feed.
        val feedTabs = if (!shorts && !search) {
            collectYouTubeFeedTabs(root, window, toolbarSnapshot, navigation.selectedDestination,
                navigation.itemCount)
        } else null
            // An expanded player hides the bottom bar and covers the feed, whose
            // strip still reports visible underneath. Only then is the bar
            // missing, so only then are the watch lookups worth their cost.
            ?.takeUnless {
                navigation.selectedDestination == YouTubeNavigationDestination.UNKNOWN &&
                    youtubeWatchSurfaceVisible(root)
            }
        val feedFrame = homeToolbar || feedTabs != null
        val needsSecondaryProbe = !feedFrame && !shorts && !search
        val profileVisible = needsSecondaryProbe &&
            navigation.selectedDestination == YouTubeNavigationDestination.YOU &&
            findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/collapsing_header_container")?.let {
                YouTubeUiIdentity.isConfirmedYouSurface(
                    navigation.selectedDestination, false,
                    it.left, it.top, it.right, it.bottom,
                    window.left, window.top, window.right, window.bottom
                )
            } == true
        val structurallyOtherAllowed = needsSecondaryProbe && !profileVisible && (
                // Channel and playlist pages share a collapsing header under a
                // toolbar titled with the channel or playlist name. Home and
                // Subscriptions have no such header. A channel's tab strip
                // (Home/Videos/Shorts/...) stays pinned if the header ever
                // scrolls out of view. The Home feed's own strip never gets
                // here: it already made this a feed frame above.
                listOf("collapsing_header_container", "tabs_bar_view").any { id ->
                    findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/$id")?.let {
                        YouTubeUiIdentity.hasMeaningfulHorizontalPresence(
                            it.left, it.right, window.left, window.right)
                    } == true
                } ||
                youtubeWatchSurfaceVisible(root) ||
                // The Shorts creation flow (camera, mode switcher, post-record
                // editor) is an allowed surface. Its window replaces the feed,
                // so the curtain must lift instead of being retained for an
                // unclassified tree (the + button opened the camera under it).
                // Those full-screen pages hide the bottom navigation; while the
                // bar is visible the five lookups cannot match and are skipped.
                // YouTube's own "Update your app" page (NewVersionAvailableActivity)
                // also has no bottom bar. Unclassified, it kept the Home curtain,
                // stretched to the bottom, over its Update button. Only its
                // description id is used: install buttons also appear in feed ads.
                (navigation.bottomBarTop == null && listOf(
                    "reel_camera_layout", "camera_preview", "record_button_view",
                    "creation_modes_container", "editor_tool_button_icon",
                    "upgrade_details"
                ).any { findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/$it") != null })
            )
        // A titled page is told apart by how it was reached, never by its
        // localized title: Notifications opens from a feed toolbar.
        val notifications = needsSecondaryProbe && !profileVisible &&
            YouTubeUiIdentity.isNotificationsPage(
                titledPage = toolbarSnapshot.titled,
                structurallyOtherAllowed = structurallyOtherAllowed,
                notificationsRequested =
                    youtubeCurtainState.pendingDestination == YouTubeCurtainScreen.NOTIFICATIONS,
                lastVerifiedScreen = youtubeLastVerifiedScreen,
                withinNotificationsVisit = youtubeNotificationsVisit
            )
        val otherAllowed = needsSecondaryProbe && !profileVisible && !notifications &&
            (toolbarSnapshot.titled || structurallyOtherAllowed)
        // A minimized long video stays usable above a covered feed: the user
        // must be able to expand, pause or close what they chose to watch.
        val miniplayer = if (feedFrame) {
            YouTubeFeedGeometry.miniplayerCutout(
                controls = findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/floaty_bar_controls_view"),
                window = window
            )
        } else null
        val screen = YouTubeScreenClassifier.classify(
            navigation.selectedDestination, homeToolbar, profileVisible,
            search, notifications, otherAllowed, shorts, feedTabs?.selected
        )
        if (ProtectionFlightRecorder.ENABLED) {
            val signature = "$screen|$search|$notifications|$otherAllowed|$homeToolbar|" +
                "${navigation.selectedDestination}|${feedTabs?.selected}|${feedTabs?.bounds}"
            if (signature != lastYouTubeSignalsSignature) {
                lastYouTubeSignalsSignature = signature
                ProtectionFlightRecorder.record(this, "youtube.signals",
                    "screen=$screen search=$search notif=$notifications other=$otherAllowed " +
                        "home=$homeToolbar selected=${navigation.selectedDestination} " +
                        "shorts=$shorts feedTab=${feedTabs?.selected} strip=${feedTabs?.bounds}")
            }
        }
        val toolbar = toolbarSnapshot.bounds
        val viewport = YouTubeFeedGeometry.calculateFeedViewport(
            window, statusBarInset(), toolbar?.bottom, null,
            navigation.bottomBarTop, dp(56), dp(48), dp(16),
            toolbarScrolledAway = YouTubeFeedGeometry.toolbarScrolledAway(
                toolbar != null, navigation.bottomBarTop != null, navigation.selectedDestination),
            bottomBarScrolledAway = YouTubeFeedGeometry.bottomBarScrolledAway(
                navigation.bottomBarTop != null),
            tappableBottomInset = tappableBottomInset(),
            // Strict covers Subscriptions as well, so the strip stays covered.
            openFeedTabsBottom = feedTabs?.bounds?.bottom?.takeIf { !youtubeSubscriptionsProtected() }
        )
        val backBounds = if (screen == YouTubeCurtainScreen.SEARCH ||
            screen == YouTubeCurtainScreen.NOTIFICATIONS ||
            (screen == YouTubeCurtainScreen.UNKNOWN && !feedFrame)
        ) toolbarSnapshot.backNode?.let {
            Rect().also(it::getBoundsInScreen)
        } ?: toolbar?.takeIf {
            screen == YouTubeCurtainScreen.UNKNOWN && !feedFrame && toolbarSnapshot.loadingBackPresent
        }?.let { leftToRight(Rect(window.left, it.top, window.left + dp(56), it.bottom), window, YOUTUBE_PACKAGE) }
            // The search-suggestions page (before a query is submitted) draws
            // its Back arrow outside the "toolbar" view; without this its
            // touch-first return guard was never mounted.
            ?: if (screen == YouTubeCurtainScreen.SEARCH) {
                findYouTubeBackNavigationNode(root)?.let { Rect().also(it::getBoundsInScreen) }
                    ?.takeIf {
                        leftToRight(it, window, YOUTUBE_PACKAGE).left <= window.left + dp(8) &&
                            it.width() <= dp(96)
                    }
            } else null
        else null
        return YouTubeUiSignals(
            shortsVisible = shorts,
            safeBottomSheetOpen = shorts &&
                findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/arrow_drag_handle") != null &&
                findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/close_button") != null,
            definiteBrowseSurface = !shorts && screen != YouTubeCurtainScreen.UNKNOWN,
            protectedSurface = when (screen) {
                YouTubeCurtainScreen.HOME -> YouTubeProtectedSurface.HOME
                YouTubeCurtainScreen.SUBSCRIPTIONS ->
                    youtubeFeedSurface(YouTubeNavigationDestination.SUBSCRIPTIONS)
                else -> null
            },
            feedViewportBounds = viewport,
            shortsTabBounds = navigation.shortsTabBounds,
            homeTabBounds = navigation.homeTabBounds,
            subscriptionsTabBounds = navigation.subscriptionsTabBounds,
            youTabBounds = navigation.youTabBounds,
            allowedBackBounds = backBounds,
            allowedLaunchBounds = toolbarSnapshot.launchNodes.mapValues { (_, node) ->
                Rect().also(node::getBoundsInScreen)
            }.filterValues { bounds ->
                // A top-docked miniplayer covers these toolbar icons; a guard
                // left above it turned a tap on the player's Close button
                // into opening Search.
                miniplayer == null || !Rect.intersects(bounds, miniplayer)
            }.takeIf {
                // Only a covered feed needs its toolbar taps captured first.
                screen == YouTubeCurtainScreen.HOME || (screen == YouTubeCurtainScreen.SUBSCRIPTIONS &&
                    youtubeFeedSurface(YouTubeNavigationDestination.SUBSCRIPTIONS) != null)
            } ?: emptyMap(),
            selectedDestination = navigation.selectedDestination,
            searchSurfaceVisible = search,
            allowedSecondarySurfaceVisible = notifications || otherAllowed,
            screen = screen,
            windowBounds = window,
            miniplayerBounds = miniplayer,
            barsScrolledAway = YouTubeFeedGeometry.bottomBarScrolledAway(
                navigation.bottomBarTop != null)
        )
    }

    /** [root] is a YouTube pop-up (offer, menu, dialog) above YouTube's main window. */
    private fun isYouTubePopUpOverMain(root: AccessibilityNodeInfo): Boolean {
        if (root.packageName?.toString() != YOUTUBE_PACKAGE) return false
        val hasTabBar = findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/pivot_bar") != null
        if (hasTabBar) return false
        val others = windows.count { window ->
            window.type == AccessibilityWindowInfo.TYPE_APPLICATION && window.id != root.windowId &&
                (windowPackages[window.id] ?: window.root?.packageName?.toString()
                    ?.also { windowPackages[window.id] = it }) == YOUTUBE_PACKAGE
        }
        return YouTubeSurfacePolicy.isPopUpOverMain(hasTabBar, others)
    }

    private fun refreshYouTubeSurfaceProtection(root: AccessibilityNodeInfo) {
        if (youtubeOverlay.isSystemUiSuspended) {
            // An unreadable focused dialog (permission prompt) also reports
            // YouTube here through its active-window fallback; YouTube's own
            // pop-ups keep the windows hidden until they close.
            if (focusedNonOverlayPackage() != YOUTUBE_PACKAGE || focusedAppWindowUnreadable() ||
                isYouTubePopUpOverMain(root)) return
            youtubeOverlay.setSystemUiSuspended(false)
        }
        if (root.packageName?.toString() != YOUTUBE_PACKAGE ||
            !ProtectionPreferences.isEnabled(this, ProtectedApp.YOUTUBE)
        ) {
            resetYouTubeProtection()
            return
        }
        if (isYouTubePopUpOverMain(root)) {
            // Step aside like for the notification shade: the pop-up is modal,
            // the dimmed feed behind it cannot be scrolled, and its own
            // dismissal brings YouTube's main window back into focus.
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "youtube.popup", "suspended window=${root.windowId}")
            SupportDiagnostics.record(this, SupportEvent.STEPPED_ASIDE,
                mapOf("app" to "youtube", "why" to "popup"))
            youtubeOverlay.setSystemUiSuspended(true)
            scheduleYouTubeOverlayForegroundCheck()
            return
        }
        val collectStarted = SystemClock.uptimeMillis()
        val signals = collectYouTubeCurtainSignals(root)
        val applyStarted = SystemClock.uptimeMillis()
        applyYouTubeSurfaceProtection(signals)
        if (ProtectionFlightRecorder.ENABLED) {
            val done = SystemClock.uptimeMillis()
            if (done - collectStarted >= 40L) ProtectionFlightRecorder.record(this, "youtube.scan.split",
                "collectMs=${applyStarted - collectStarted} applyMs=${done - applyStarted}")
        }
        if (ProtectionPreferences.getMode(this, ProtectedApp.YOUTUBE) == ProtectionMode.STRICT) return
        val decision = youtubeShortsSession.observe(
            YouTubeShortsObservation(
                nowMs = SystemClock.uptimeMillis(),
                shortsStructureVisible = signals.shortsVisible,
                launchRequested = false,
                definitelyOutsideShorts = signals.definiteBrowseSurface,
                safeBottomSheetOpen = signals.safeBottomSheetOpen,
                isScrollEvent = false,
                hasVerticalMovement = false,
                sourceIsShortsPager = false,
                feedTabEntry = YouTubeShortsPolicy.shouldBlockEntry(
                    ProtectionMode.BALANCED,
                    fromShortsTab = YouTubeShortsPolicy.isShortsTabEntry(
                        recentTabClick = SystemClock.uptimeMillis() < youtubeShortsTabClickUntil,
                        selected = signals.selectedDestination,
                        shortsVisible = signals.shortsVisible)
                )
            )
        )
        if (decision == YouTubeShortsDecision.EXIT) {
            performYouTubeShortsExit()
        }
        if (youtubeOverlay.hasVisibleWindows) scheduleYouTubeOverlayForegroundCheck()
    }

    private fun applyYouTubeSurfaceProtection(signals: YouTubeUiSignals) {
        val now = SystemClock.uptimeMillis()
        // Empty/oscillating trees or an exit timeout must not create a new
        // count. Only a verified return outside Shorts rearms the encounter.
        if (signals.definiteBrowseSurface && !signals.shortsVisible && !signals.safeBottomSheetOpen) {
            youtubeBlockedAttempt.reset()
        }
        signals.windowBounds?.let(youtubeOverlay::updateWindowBounds)
        if (signals.selectedDestination != YouTubeNavigationDestination.UNKNOWN) {
            youtubeLastSelectedDestination = signals.selectedDestination
        }
        val previousScreen = youtubeObservedScreen
        youtubeObservedScreen = signals.screen
        if (signals.screen == YouTubeCurtainScreen.SUBSCRIPTIONS &&
            previousScreen != YouTubeCurtainScreen.SUBSCRIPTIONS
        ) youtubeSubscriptionsSince = now
        if (signals.screen == YouTubeCurtainScreen.OTHER_ALLOWED &&
            youtubeLastVerifiedScreen == YouTubeCurtainScreen.NOTIFICATIONS
        ) youtubeNotificationChildOpen = true
        if (signals.screen !in setOf(YouTubeCurtainScreen.UNKNOWN, YouTubeCurtainScreen.OTHER_ALLOWED)) {
            youtubeNotificationChildOpen = false
        }
        val returningWithinAllowedPages = signals.screen == YouTubeCurtainScreen.UNKNOWN &&
            youtubeNotificationChildOpen &&
            YouTubeSurfacePolicy.preserveAllowedSecondaryDuringLoading(
                youtubeLastVerifiedScreen, signals.allowedBackBounds != null
            )
        if (signals.screen == YouTubeCurtainScreen.UNKNOWN &&
            signals.allowedBackBounds != null && youtubeAllowedReturnSurface == null &&
            !returningWithinAllowedPages
        ) {
            // The Back arrow can be usable before the secondary page title has settled.
            // Arm its return guard during loading too, not only after Notifications is named.
            youtubeAllowedReturnSurface = youtubeFeedSurface(youtubeLastStableDestination)
        }
        // Conservative coverage while a Home/Subscriptions tab is selected is
        // only safe when the feed itself was the last verified surface. If the
        // last verified surface was an allowed one (a watch page, search,
        // notifications, the You tab), an UNKNOWN frame is a loading step of
        // that allowed page - covering it would drop the curtain onto a video
        // the user is watching. Tab-initiated feed returns are guarded by the
        // protection latches instead.
        val lastVerifiedAllowedSurface =
            youtubeLastVerifiedScreen == YouTubeCurtainScreen.OTHER_ALLOWED ||
                youtubeLastVerifiedScreen == YouTubeCurtainScreen.SEARCH ||
                youtubeLastVerifiedScreen == YouTubeCurtainScreen.NOTIFICATIONS ||
                youtubeLastVerifiedScreen == YouTubeCurtainScreen.YOU
        // Leaving Search/Notifications with system Back produces no click and no
        // touch on the back guard, and the feed slides in for 300-700 ms before
        // its toolbar settles. Opening anything from those pages always starts
        // with a click, so an unclassified frame without a recent click is the
        // feed coming back. A false guess lasts one frame: the next verified
        // secondary page lifts the curtain without a settle delay.
        // YouTube reports the page change of a tapped notification or search
        // result before the tap's click event (Galaxy S23: the click arrived
        // ~20 ms after the first unclassified frame, so a notification's pop-up
        // got the Home curtain). The guess is confirmed on a re-scan, after
        // the events already queued behind this frame have been handled.
        val clicklessCandidate =
            signals.screen == YouTubeCurtainScreen.UNKNOWN &&
                (youtubeLastVerifiedScreen == YouTubeCurtainScreen.SEARCH ||
                    youtubeLastVerifiedScreen == YouTubeCurtainScreen.NOTIFICATIONS) &&
                !youtubeNotificationChildOpen &&
                now - youtubeLastClickAt >= YOUTUBE_CLICK_INTENT_MS
        if (!clicklessCandidate) {
            youtubeClicklessReturnSince = 0L
        } else if (youtubeClicklessReturnSince == 0L) {
            youtubeClicklessReturnSince = now
            queueYouTubeSurfaceScan(YouTubeSurfacePolicy.CLICKLESS_RETURN_CONFIRM_MS + 16L)
        }
        val clicklessSecondaryReturn = clicklessCandidate &&
            YouTubeSurfacePolicy.clicklessReturnConfirmed(youtubeClicklessReturnSince, now)
        if (!youtubeCurtainState.isPending && signals.screen == YouTubeCurtainScreen.UNKNOWN &&
            !returningWithinAllowedPages &&
            (!lastVerifiedAllowedSurface || clicklessSecondaryReturn) &&
            signals.selectedDestination in setOf(
                YouTubeNavigationDestination.HOME, YouTubeNavigationDestination.SUBSCRIPTIONS
            )
        ) {
            // The selected tab also survives behind Search/Notifications while their toolbar
            // loads. Cover UNKNOWN conservatively, but do not invent a navigation request:
            // the next verified secondary page must release coverage without a timeout.
            // Subscriptions in the feed's top strip keeps the bottom Home tab
            // selected: a video opening from it must not flash the Home curtain.
            val feedScreen = if (signals.selectedDestination == YouTubeNavigationDestination.HOME &&
                youtubeLastVerifiedScreen == YouTubeCurtainScreen.SUBSCRIPTIONS
            ) YouTubeCurtainScreen.SUBSCRIPTIONS else signals.selectedDestination.curtainScreen()
            youtubeCurtainState.observe(feedScreen, now)
        }
        if (signals.screen == YouTubeCurtainScreen.SHORTS && youtubeCurtainState.isPending) {
            youtubeCurtainState.clear()
        }
        val surface = youtubeCurtainState.observe(signals.screen, now, signals.selectedDestination)
        if (ProtectionFlightRecorder.ENABLED) {
            val signature = "${youtubeCurtainState.pendingDestination}|" +
                "${youtubeCurtainState.currentSurface}|${youtubeCurtainState.isPending}|" +
                "${signals.allowedBackBounds}|$youtubeAllowedReturnSurface"
            if (signature != lastYouTubeCurtainStateSignature) {
                lastYouTubeCurtainStateSignature = signature
                ProtectionFlightRecorder.record(this, "youtube.curtain.state",
                    "pending=${youtubeCurtainState.pendingDestination} " +
                        "surface=${youtubeCurtainState.currentSurface} screen=${signals.screen} " +
                        "selected=${signals.selectedDestination} " +
                        "outgoing=${youtubeCurtainState.lastRequestOutgoingScreen} " +
                        "back=${signals.allowedBackBounds} returnTo=$youtubeAllowedReturnSurface")
            }
        }
        if (signals.screen != YouTubeCurtainScreen.UNKNOWN) youtubeLastVerifiedScreen = signals.screen
        when (signals.screen) {
            YouTubeCurtainScreen.NOTIFICATIONS -> youtubeNotificationsVisit = true
            YouTubeCurtainScreen.HOME, YouTubeCurtainScreen.SUBSCRIPTIONS, YouTubeCurtainScreen.YOU,
            YouTubeCurtainScreen.SEARCH, YouTubeCurtainScreen.SHORTS -> youtubeNotificationsVisit = false
            else -> Unit
        }
        when (signals.screen) {
            YouTubeCurtainScreen.HOME, YouTubeCurtainScreen.SUBSCRIPTIONS -> {
                // The page, not the bottom tab: Subscriptions in the feed's top
                // strip keeps the bottom Home tab selected.
                youtubeLastStableDestination = if (signals.screen == YouTubeCurtainScreen.HOME)
                    YouTubeNavigationDestination.HOME else YouTubeNavigationDestination.SUBSCRIPTIONS
                youtubeAllowedReturnBounds = signals.feedViewportBounds?.let(::Rect)
            }
            YouTubeCurtainScreen.YOU -> {
                youtubeLastStableDestination = YouTubeNavigationDestination.YOU
                youtubeAllowedReturnSurface = null
            }
            YouTubeCurtainScreen.SEARCH, YouTubeCurtainScreen.NOTIFICATIONS -> {
                if (previousScreen != signals.screen && youtubeAllowedReturnSurface == null) {
                    youtubeAllowedReturnSurface = youtubeFeedSurface(youtubeLastStableDestination)
                }
            }
            else -> Unit
        }
        youtubeOverlay.rememberCurtainViewport(
            signals.feedViewportBounds,
            overwriteExisting = !youtubeCurtainState.isPending
        )
        // A Shorts entry is covered in strict mode and when a real tab tap just
        // slipped through the guard; an intentionally opened link/search Short
        // stays uncovered in balanced mode and runs the single-video session.
        val shortsTabEntry = YouTubeShortsPolicy.isShortsTabEntry(
            recentTabClick = now < youtubeShortsTabClickUntil,
            selected = signals.selectedDestination,
            shortsVisible = signals.shortsVisible)
        val blockedShorts = signals.screen == YouTubeCurtainScreen.SHORTS &&
            YouTubeShortsPolicy.shouldBlockEntry(
                ProtectionPreferences.getMode(this, ProtectedApp.YOUTUBE),
                fromShortsTab = shortsTabEntry
            )
        val effectiveSurface = if (blockedShorts) YouTubeProtectedSurface.HOME else surface
        // Anti-flap: while the active window flips between a leaving allowed
        // page (camera, watch) and the feed, the curtain must not be removed
        // and re-added per frame. Hiding waits until the allowed surface has
        // held for a short settle window; showing is immediate. Verified
        // secondary pages (Notifications, Search) are definitive: their curtain
        // lifts on the first verified frame so the return never feels late.
        // The You page with its own tab selected is a main tab, not a window
        // flipping away; the settle window kept the Home curtain over it for
        // 0.6 s (Galaxy S23).
        val definitiveSecondary = signals.screen == YouTubeCurtainScreen.SEARCH ||
            signals.screen == YouTubeCurtainScreen.NOTIFICATIONS ||
            youtubeCurtainState.resolvedOnFullScreenAllowedPage ||
            (signals.screen == YouTubeCurtainScreen.YOU &&
                signals.selectedDestination == YouTubeNavigationDestination.YOU)
        val showSurface = if (effectiveSurface == null) {
            if (definitiveSecondary) {
                youtubeAllowedFlipSince = 0L
                null
            } else {
                if (youtubeAllowedFlipSince == 0L) youtubeAllowedFlipSince = now
                if (now - youtubeAllowedFlipSince < YOUTUBE_ALLOWED_FLIP_SETTLE_MS) {
                    youtubeOverlay.currentCurtainSurface
                } else null
            }
        } else {
            youtubeAllowedFlipSince = 0L
            effectiveSurface
        }
        if (showSurface != null && effectiveSurface == null) {
            // Hiding waits for the settle window, but no further event is
            // guaranteed once the allowed page is still. Re-check right after.
            queueYouTubeSurfaceScan(
                (YOUTUBE_ALLOWED_FLIP_SETTLE_MS - (now - youtubeAllowedFlipSince)).coerceAtLeast(0L) + 8L)
        }
        // Transitional frames never prove the player went away; only a verified
        // feed frame may restore or remove the minimized-player hole.
        if (signals.screen == YouTubeCurtainScreen.HOME ||
            signals.screen == YouTubeCurtainScreen.SUBSCRIPTIONS) {
            youtubeOverlay.updateMiniplayerCutout(signals.miniplayerBounds)
        } else if (blockedShorts) {
            youtubeOverlay.updateMiniplayerCutout(null)
        }
        // Dragging from under the logo collapses the toolbar; while the logo is
        // half off screen the frame is unverified and the viewport falls back
        // to its default top, which uncovered a strip of the feed below the
        // collapsed toolbar. An unverified frame may never lower the curtain.
        val feedVerified = signals.screen == YouTubeCurtainScreen.HOME ||
            signals.screen == YouTubeCurtainScreen.SUBSCRIPTIONS
        val curtainBounds = YouTubeFeedGeometry.retainCurtainTop(
            proposed = signals.feedViewportBounds,
            mounted = youtubeOverlay.currentCurtainBounds.takeIf {
                showSurface != null && showSurface == youtubeOverlay.currentCurtainSurface
            },
            frameVerified = feedVerified
        )
        youtubeOverlay.showCurtain(
            curtainBounds, showSurface, isEnglish(),
            preserveBounds = youtubeCurtainState.isPending
        )
        // A drag that starts on the bottom tabs hides them and the toolbar.
        // They only return on a scroll toward the top, which the curtain now
        // stops, so the covered feed lost its way to the other tabs.
        if (signals.barsScrolledAway && showSurface != null && !blockedShorts &&
            signals.screen != YouTubeCurtainScreen.SHORTS && youtubeOverlay.isCurtainVisible
        ) restoreYouTubeBars(now)
        val inFlight = youtubeTabGestureDestination.takeIf {
            youtubeTabGestureGeneration == youtubeCurtainState.generation
        }
        youtubeOverlay.updateYouNavigationGuard(
            signals.youTabBounds,
            active = youtubeOverlay.isCurtainVisible && inFlight != YouTubeNavigationDestination.YOU,
            isEnglish = isEnglish(),
            preserveBounds = youtubeCurtainState.isPending
        )
        youtubeOverlay.updateShortsGuard(signals.shortsTabBounds, isEnglish())
        youtubeOverlay.updateAllowedLaunchGuards(signals.allowedLaunchBounds, isEnglish())
        youtubeOverlay.updateProtectedNavigationGuards(
            signals.homeTabBounds, signals.subscriptionsTabBounds, isEnglish(),
            active = true,
            preserveBounds = youtubeCurtainState.isPending,
            suspendedSurface = when (inFlight) {
                YouTubeNavigationDestination.HOME -> YouTubeProtectedSurface.HOME
                YouTubeNavigationDestination.SUBSCRIPTIONS -> YouTubeProtectedSurface.SUBSCRIPTIONS
                else -> null
            }
        )
        if (youtubeCurtainState.pendingDestination !in
            setOf(YouTubeCurtainScreen.HOME, YouTubeCurtainScreen.SUBSCRIPTIONS)
        ) {
            // ACTION_DOWN pre-arms the feed curtain. Keep the touch window alive until
            // ACTION_UP delivers Back; its callback releases it after consuming the gesture.
            val waitingForSecondary = youtubeCurtainState.pendingDestination in
                setOf(YouTubeCurtainScreen.SEARCH, YouTubeCurtainScreen.NOTIFICATIONS)
            if (!waitingForSecondary || signals.allowedBackBounds != null || youtubeAllowedReturnSurface == null) {
                youtubeOverlay.updateAllowedBackGuard(
                    signals.allowedBackBounds.takeIf {
                        youtubeAllowedReturnSurface != null && !returningWithinAllowedPages
                    }, isEnglish()
                )
            }
        }
        traceYouTubeProtection("observed")
        if (blockedShorts && now - youtubeStrictShortsExitAt >= 600L) {
            youtubeStrictShortsExitAt = now
            val accepted = performGlobalAction(GLOBAL_ACTION_BACK)
            SupportDiagnostics.record(this, SupportEvent.YOUTUBE_SHORTS, mapOf("what" to "blocked", "ok" to accepted, "fromtab" to shortsTabEntry))
            recordYouTubeViewerIntervention(accepted)
            queueYouTubeSurfaceScan(96L)
        }
        scheduleYouTubeOverlayForegroundCheck()
    }

    private fun resetYouTubeProtection() {
        youtubeBlockedAttempt.reset()
        clearYouTubePendingProtectedNavigation()
        cancelYouTubeSurfaceScan()
        mainHandler.removeCallbacks(youtubeOverlayForegroundCheck)
        youtubeOverlayForegroundCheckScheduled = false
        youtubeOverlayForegroundCheckAt = 0L
        youtubeObservedScreen = YouTubeCurtainScreen.UNKNOWN
        youtubeLastVerifiedScreen = YouTubeCurtainScreen.UNKNOWN
        youtubeNotificationsVisit = false
        youtubeAllowedFlipSince = 0L
        youtubeNotificationChildOpen = false
        youtubeLastStableDestination = YouTubeNavigationDestination.UNKNOWN
        youtubeLastSelectedDestination = YouTubeNavigationDestination.UNKNOWN
        youtubeAllowedReturnSurface = null
        youtubeAllowedReturnBounds = null
        youtubeTabGestureDestination = null
        youtubeTabGestureGeneration = null
        youtubeOverlay.hideAll()
        traceYouTubeProtection("reset")
    }

    private fun clearYouTubePendingProtectedNavigation() {
        youtubeCurtainState.clear()
    }

    /**
     * Scrolls the covered feed back one step so YouTube shows its toolbar and
     * bottom tabs again. The feed stays under the curtain; only the bars return.
     */
    private fun restoreYouTubeBars(now: Long) {
        if (now - youtubeBarsRestoredAt < YOUTUBE_BARS_RESTORE_INTERVAL_MS) return
        val root = currentYouTubeRoot() ?: return
        val feed = cachedNodeLookup(root, "$YOUTUBE_PACKAGE:id/results")
            .firstOrNull { it.isVisibleToUser && it.isScrollable } ?: return
        youtubeBarsRestoredAt = now
        val restored = feed.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        if (ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "youtube.bars.restore", "accepted=$restored")
        }
    }

    private fun currentYouTubeRoot(): AccessibilityNodeInfo? {
        val activeRoot = rootInActiveWindow
        val activePackage = activeRoot?.packageName?.toString()
        if (activePackage == YOUTUBE_PACKAGE) return activeRoot
        val visibleWindows = windows
        // An active soft keyboard (IME) or our own accessibility overlay can temporarily make its
        // window the active root while YouTube remains the visible foreground application underneath.
        val foremostAppPackage = visibleWindows.asSequence()
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root?.packageName?.toString() }
            .firstOrNull()
        if (foremostAppPackage == YOUTUBE_PACKAGE) {
            return visibleWindows.asSequence()
                .mapNotNull { it.root }
                .firstOrNull { it.packageName?.toString() == YOUTUBE_PACKAGE }
        }
        return null
    }

    private fun isInputMethodVisible(): Boolean =
        windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }

    private fun isYouTubeNotificationShade(): Boolean {
        if (lastPackage != YOUTUBE_PACKAGE && !youtubeOverlay.hasVisibleWindows) return false
        val systemRoot = windows.asSequence().mapNotNull { it.root }
            .firstOrNull { it.packageName?.toString() == "com.android.systemui" } ?: return false
        return listOf("notification_panel", "notification_stack_scroller", "quick_settings_container")
            .any { id -> systemRoot.findAccessibilityNodeInfosByViewId("com.android.systemui:id/$id")
                .orEmpty().any { it.isVisibleToUser } }
    }

    private fun retainInstagramCurtainUnderNotificationShade(activePackage: String?,
        knownActiveRoot: AccessibilityNodeInfo? = null): Boolean {
        if (activePackage != "com.android.systemui") return false
        // Resolved only after the cheap package check: a default argument of
        // rootInActiveWindow was evaluated at every call site, which meant a
        // blocking remote root query for every event of every protected app.
        val activeRoot = knownActiveRoot ?: rootInActiveWindow
        if (activeRoot?.packageName?.toString() == "com.android.systemui" &&
            InstagramNotificationShadePolicy.canReuseShadeWindow(
                instagramOverlay.isNotificationShadeSuspended, activeRoot.windowId,
                instagramNotificationShadeWindowId) &&
            ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) {
            scheduleInstagramShadeCheck()
            return true
        }
        if (focusedNonOverlayPackage() != "com.android.systemui" &&
            rootInActiveWindow?.packageName?.toString() != "com.android.systemui") return false
        val foremostApp = windows.asSequence()
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root?.packageName?.toString() }.firstOrNull()
        val systemRoot = windows.asSequence().mapNotNull { it.root }
            .firstOrNull { it.packageName?.toString() == "com.android.systemui" }
        val shadeVisible = systemRoot != null && listOf(
            "notification_panel", "notification_stack_scroller", "quick_settings_container"
        ).any { id -> systemRoot.findAccessibilityNodeInfosByViewId("com.android.systemui:id/$id")
            .orEmpty().any { it.isVisibleToUser } }
        if (!InstagramNotificationShadePolicy.canRetain(
                enabled = ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM),
                screen = lastInstagramScreen,
                curtainAttached = instagramOverlay.hasVisibleWindows,
                instagramUnderneath = InstagramNotificationShadePolicy.hasInstagramContext(
                    foremostApp, previouslyInstagram = lastPackage == INSTAGRAM_PACKAGE),
                shadeVisible = shadeVisible)) return false
        if (!instagramOverlay.isNotificationShadeSuspended) {
            instagramNotificationShadeWindowId = systemRoot?.windowId ?: -1
            instagramOverlay.suspendForNotificationShade()
            Log.d(TAG, "IG_SHADE_RETAIN screen=$lastInstagramScreen")
        }
        // Poll only during the shade session; do not wait for a new app event
        // or perform the general Instagram tree scan on each SystemUI update.
        scheduleInstagramShadeCheck()
        return true
    }

    private fun scheduleInstagramShadeCheck() {
        mainHandler.removeCallbacks(overlayForegroundCheck)
        overlayForegroundCheckScheduled = true
        mainHandler.postDelayed(overlayForegroundCheck, 32L)
    }

    private fun matchesRetainedInstagramFeed(root: AccessibilityNodeInfo, screen: InstagramScreen): Boolean {
        if (igVisible(root, "action_bar_button_back")) return false
        return when (screen) {
            InstagramScreen.HOME_FEED -> igVisible(root, "main_feed_action_bar") && igSelected(root, "feed_tab")
            InstagramScreen.EXPLORE -> igVisible(root, "explore_action_bar") && igSelected(root, "search_tab") &&
                igVisible(root, "grid_card_layout_container")
            else -> false
        }
    }

    private fun resumeInstagramNotificationShade(root: AccessibilityNodeInfo) {
        if (!instagramOverlay.isNotificationShadeSuspended ||
            root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        val started = SystemClock.uptimeMillis()
        val display = currentDisplayBounds()
        val retained = lastVerifiedInstagramCurtain?.takeIf { (screen, bounds) ->
            screen == lastInstagramScreen && root.windowId == currentInstagramWindowId &&
                bounds.width() == display.width() && display.contains(bounds)
        }
        if (ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) && retained != null &&
            matchesRetainedInstagramFeed(root, retained.first)) {
            clearInstagramResumeProtection()
            instagramOverlay.supportReason = "shade"
            if (instagramOverlay.show(retained.second, retained.first, isEnglish())) {
                Log.d(TAG, "IG_SHADE_FAST_RETURN screen=${retained.first} " +
                    "elapsedMs=${SystemClock.uptimeMillis() - started}")
                queueInstagramScan(0L)
                return
            }
        }
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            !refreshFastMainProtectedSurface(root, instagramWindowBounds(root))) {
            // A notification can open a chat/search/player, even in the same
            // activity window. Never restore merely from the old screen/window.
            instagramOverlay.hideAll()
        }
        Log.d(TAG, "IG_SHADE_RETURN screen=$lastInstagramScreen")
        queueInstagramScan(0L)
    }

    private fun focusedNonOverlayPackage(): String? {
        val visibleWindows = windows
        // Only our accessibility overlays are skipped. AwayDoomscrollin's own
        // activity is a real foreground app: treating it as an overlay kept the
        // YouTube tab guards mounted above it, where they swallowed taps on the
        // app's own bottom bar and counted them as blocked Shorts attempts.
        fun ownOverlay(window: AccessibilityWindowInfo) =
            window.type == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY
        for (window in visibleWindows) {
            if (!window.isFocused) continue
            if (window.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD || ownOverlay(window)) continue
            val foregroundPackage = window.root?.packageName?.toString() ?: continue
            return foregroundPackage
        }
        for (window in visibleWindows) {
            if (!window.isActive) continue
            if (window.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD || ownOverlay(window)) continue
            val foregroundPackage = window.root?.packageName?.toString() ?: continue
            return foregroundPackage
        }
        return null
    }

    /**
     * Window id -> package of windows that published events. Lets the task
     * switcher probe skip the protected apps' own windows: their remote root
     * query can block for seconds while Instagram opens a Story or modal.
     */
    private val windowPackages = object : LinkedHashMap<Int, String>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, String>?) = size > 32
    }

    private val taskSwitcherPackages: Set<String> by lazy {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        TaskSwitcherPolicy.switcherPackages(
            packageManager.queryIntentActivities(home, android.content.pm.PackageManager.MATCH_ALL)
                .mapNotNull { it.activityInfo?.packageName })
    }

    /** The protected app whose curtains were removed for the task switcher. */
    private var taskSwitcherOwner: String? = null
    /** Debug flight log: the last pop-up/split Instagram root, logged once per change. */
    private var lastWindowedInstagramRoot: Rect? = null

    /** The window covers the display from its top-left corner (not a pop-up). */
    private fun isFullscreenWindow(bounds: Rect): Boolean {
        val display = currentDisplayBounds()
        return TaskSwitcherPolicy.isFullscreen(bounds.left - display.left, bounds.top - display.top,
            bounds.right - display.left, bounds.bottom - display.top, display.width(), display.height())
    }

    private fun isTaskSwitcherShowing(activeRoot: AccessibilityNodeInfo?): Boolean {
        val switchers = taskSwitcherPackages
        if (switchers.isEmpty() || activeRoot == null) return false
        val fullscreen = isFullscreenWindow(Rect().also(activeRoot::getBoundsInScreen))
        if (!fullscreen) return false
        val packages = windows.filter {
            it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.id != activeRoot.windowId
        }.map { window ->
            windowPackages[window.id] ?: window.root?.packageName?.toString()
                ?.also { windowPackages[window.id] = it }
        }
        return TaskSwitcherPolicy.isShowing(fullscreen, packages, switchers)
    }

    private fun enterTaskSwitcher(owner: String) {
        if (ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "task.switcher", "enter owner=$owner")
        }
        taskSwitcherOwner = owner
        SupportDiagnostics.record(this, SupportEvent.RECENTS_OPENED,
            mapOf("app" to supportAppName(owner)))
        when (owner) {
            INSTAGRAM_PACKAGE -> {
                suspendInstagramProtection()
                mainHandler.removeCallbacks(instagramShadeRecovery)
            }
            YOUTUBE_PACKAGE -> resetYouTubeProtection()
        }
        trackPackageTransition("")
        mainHandler.removeCallbacks(taskSwitcherReturnCheck)
        mainHandler.postDelayed(taskSwitcherReturnCheck, OVERLAY_FOREGROUND_CHECK_MS)
    }

    /**
     * Polls only while the switcher hides a live protected app. Returning to
     * the live card may publish no event at all, so resume is started here.
     */
    private val taskSwitcherReturnCheck: Runnable = object : Runnable {
        override fun run() {
            val owner = taskSwitcherOwner ?: return
            val root = rootInActiveWindow
            val activePkg = root?.packageName?.toString()
            if (activePkg == owner && isTaskSwitcherShowing(root)) {
                mainHandler.postDelayed(this, OVERLAY_FOREGROUND_CHECK_MS)
                return
            }
            if (activePkg == null) {
                mainHandler.postDelayed(this, OVERLAY_FOREGROUND_CHECK_MS)
                return
            }
            taskSwitcherOwner = null
            if (ProtectionFlightRecorder.ENABLED) {
                ProtectionFlightRecorder.record(this@AntiScrollService, "task.switcher",
                    "leave owner=$owner active=$activePkg")
            }
            SupportDiagnostics.record(this@AntiScrollService, SupportEvent.RECENTS_CLOSED,
                mapOf("app" to supportAppName(owner), "back" to (activePkg == owner)))
            // Another app: its own events route normally from here.
            if (activePkg != owner) return
            trackPackageTransition(owner)
            when (owner) {
                INSTAGRAM_PACKAGE -> {
                    instagramResumePending = true
                    beginInstagramResumeProtection(root)
                    queueInstagramScan(0L)
                }
                YOUTUBE_PACKAGE -> if (ProtectionPreferences.isEnabled(
                        this@AntiScrollService, ProtectedApp.YOUTUBE)) {
                    scheduleYouTubeOverlayForegroundCheck()
                }
            }
        }
    }

    private fun queueYouTubeSurfaceScan(delayMs: Long = YOUTUBE_SURFACE_SCAN_DELAY_MS) {
        val now = SystemClock.uptimeMillis()
        val requestedAt = now + delayMs
        if (youtubeSurfaceScanScheduled && youtubeSurfaceScanAt <= requestedAt) return
        if (youtubeSurfaceScanScheduled) mainHandler.removeCallbacks(youtubeSurfaceScan)
        youtubeSurfaceScanScheduled = true
        youtubeSurfaceScanAt = requestedAt
        mainHandler.postDelayed(youtubeSurfaceScan, delayMs)
    }

    /**
     * Content-change events stream continuously while a video, preview or
     * timer is playing. Each one used to request a scan 24 ms later, which
     * kept the main looper permanently busy with remote traversals and made
     * the decisive window-state events wait behind them. Structural events
     * still scan immediately; content events are rate limited.
     */
    private fun queueYouTubeContentScan() {
        val now = SystemClock.uptimeMillis()
        val earliest = youtubeLastScanFinishedAt + YOUTUBE_CONTENT_SCAN_SPACING_MS
        queueYouTubeSurfaceScan(maxOf(YOUTUBE_SURFACE_SCAN_DELAY_MS, earliest - now))
    }

    private fun cancelYouTubeSurfaceScan() {
        mainHandler.removeCallbacks(youtubeSurfaceScan)
        youtubeSurfaceScanScheduled = false
        youtubeSurfaceScanAt = 0L
    }

    private fun scheduleYouTubeOverlayForegroundCheck() {
        // The loop is a safety net for a missing final event, not the primary
        // detector. On a still allowed page (watch page, You, search) a full
        // classification every 200 ms only competed with real events.
        val delay = if (youtubeCurtainState.isPending || youtubeOverlay.isSystemUiSuspended) 32L
        else 250L
        val requestedAt = SystemClock.uptimeMillis() + delay
        if (youtubeOverlayForegroundCheckScheduled &&
            youtubeOverlayForegroundCheckAt <= requestedAt
        ) return
        if (youtubeOverlayForegroundCheckScheduled) {
            mainHandler.removeCallbacks(youtubeOverlayForegroundCheck)
        }
        youtubeOverlayForegroundCheckScheduled = true
        youtubeOverlayForegroundCheckAt = requestedAt
        mainHandler.postDelayed(youtubeOverlayForegroundCheck, delay)
    }

    private fun hasQuickYouTubeHomeToolbar(root: AccessibilityNodeInfo): Boolean {
        val logo = findVisibleNodeBounds(root, "$YOUTUBE_PACKAGE:id/youtube_logo")
            ?: return false
        val window = Rect().also(root::getBoundsInScreen)
        val leading = leftToRight(logo, window, YOUTUBE_PACKAGE)
        return YouTubeUiIdentity.isHomeToolbarLogo(
            leading.left, leading.right, window.left, window.right, dp(16)
        )
    }

    private fun hasQuickYouTubeSearchSurface(root: AccessibilityNodeInfo): Boolean {
        val rootBounds = Rect().also(root::getBoundsInScreen)
        val tolerance = dp(16)
        val searchFieldMaxLeft = rootBounds.left + (rootBounds.width() / 6) + (tolerance / 2)
        return YouTubeUiIdentity.exactAllowedSurfaceIds.asSequence()
            .filter(YouTubeUiIdentity::isSearchSurfaceId)
            .any { compactId ->
                root.findAccessibilityNodeInfosByViewId("$YOUTUBE_PACKAGE:id/$compactId")
                    .orEmpty()
                    .any nodeLoop@ { node ->
                        if (!node.isVisibleToUser) return@nodeLoop false
                        val bounds = leftToRight(Rect().also(node::getBoundsInScreen), rootBounds, YOUTUBE_PACKAGE)
                        val maxLeft = if (compactId == "search_layout") rootBounds.left + tolerance else searchFieldMaxLeft
                        if (bounds.left > maxLeft || bounds.right > rootBounds.right + tolerance) {
                            return@nodeLoop false
                        }
                        YouTubeUiIdentity.isSettledSearchSurface(
                            compactId,
                            bounds.left,
                            bounds.right,
                            rootBounds.left,
                            rootBounds.right,
                            tolerance
                        )
                    }
            }
    }

    /** A settled secondary page: a title beside Back in the toolbar, no Home logo. */
    private fun hasQuickYouTubeNotificationsSurface(root: AccessibilityNodeInfo): Boolean {
        if (hasQuickYouTubeHomeToolbar(root)) {
            return false
        }
        val window = Rect().also(root::getBoundsInScreen)
        return collectYouTubeToolbar(root, window).titled
    }

    private fun findYouTubeBackNavigationNode(
        root: AccessibilityNodeInfo
    ): AccessibilityNodeInfo? {
        val rootBounds = Rect().also(root::getBoundsInScreen)
        val topLimit = rootBounds.top + rootBounds.height() / 4
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(root)
        var visited = 0
        val bounds = Rect()
        while (pending.isNotEmpty() && visited < YOUTUBE_QUICK_IDENTITY_MAX_NODES) {
            val node = pending.removeFirst()
            visited++
            if (node.isVisibleToUser) {
                node.getBoundsInScreen(bounds)
                // Search's suggestions page draws Back outside "toolbar"; the
                // leading ImageButton is Back on every page, in any language.
                val leading = leftToRight(bounds, rootBounds, YOUTUBE_PACKAGE)
                if (bounds.height() > 0 && bounds.top < topLimit &&
                    YouTubeUiIdentity.isLeadingToolbarButton(
                        node.className, node.isClickable, leading.left, leading.right,
                        rootBounds.left, rootBounds.right, dp(8))
                ) {
                    return node
                }
            }
            for (index in 0 until node.childCount) {
                node.getChild(index)?.let(pending::addLast)
            }
        }
        return null
    }

    private fun youtubeNavigationIntent(
        source: AccessibilityNodeInfo?
    ): YouTubeNavigationDestination {
        val sourceBounds = Rect().also { source?.getBoundsInScreen(it) }
        if (sourceBounds.isEmpty) return YouTubeNavigationDestination.UNKNOWN
        var current = source
        var depth = 0
        while (current != null && depth < YOUTUBE_SOURCE_PATH_DEPTH) {
            val id = compactId(current.viewIdResourceName)
            if (id == "bottom_bar_container" || id == "pivot_bar") {
                val items = youtubeNavigationItems(current, Rect().also(current::getBoundsInScreen))
                val index = items.indexOfFirst { item ->
                    Rect().also(item::getBoundsInScreen)
                        .contains(sourceBounds.centerX(), sourceBounds.centerY())
                }
                return YouTubeSurfacePolicy.navigationDestinationAt(index, items.size)
            }
            current = current.parent
            depth++
        }
        return YouTubeNavigationDestination.UNKNOWN
    }

    /** The feed toolbar's Search or Notifications button the click came from, if any. */
    private fun youtubeToolbarLaunchTarget(
        source: AccessibilityNodeInfo?,
        root: AccessibilityNodeInfo
    ): YouTubeCurtainScreen? {
        val sourceBounds = Rect().also { source?.getBoundsInScreen(it) }
        if (sourceBounds.isEmpty) return null
        val window = Rect().also(root::getBoundsInScreen)
        return collectYouTubeToolbar(root, window).launchNodes.entries.firstOrNull { (_, node) ->
            Rect().also(node::getBoundsInScreen).contains(sourceBounds.centerX(), sourceBounds.centerY())
        }?.key
    }

    private fun isYouTubeExplicitlyAllowedNavigationSource(
        source: AccessibilityNodeInfo?,
        root: AccessibilityNodeInfo
    ): Boolean {
        var current = source
        var depth = 0
        while (current != null && depth++ < 8) {
            if (compactId(current.viewIdResourceName) in YouTubeUiIdentity.exactAllowedSurfaceIds) {
                return true
            }
            current = current.parent
        }
        return youtubeToolbarLaunchTarget(source, root) != null
    }

    private fun youtubeAllowedLaunchScreen(
        source: AccessibilityNodeInfo?,
        root: AccessibilityNodeInfo
    ): YouTubeCurtainScreen =
        youtubeToolbarLaunchTarget(source, root) ?: YouTubeCurtainScreen.SEARCH

    private fun isYouTubeShortsLaunchSource(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        var depth = 0
        while (current != null && depth < 8) {
            val id = compactId(current.viewIdResourceName)
            val text = current.text?.toString()?.trim().orEmpty()
            val description = current.contentDescription?.toString()?.trim().orEmpty()
            if (id.contains("short") || id.contains("reel") ||
                text.equals("Shorts", ignoreCase = true) ||
                description.equals("Shorts", ignoreCase = true) ||
                description.contains("play Short", ignoreCase = true) ||
                description.contains("Short oynat", ignoreCase = true) ||
                description.contains("Short'u oynat", ignoreCase = true)
            ) {
                return true
            }
            current = current.parent
            depth++
        }
        return false
    }

    private fun scrollDirection(event: AccessibilityEvent): ScrollDirection {
        // Scroll deltas exist from Android 9; minSdk is 8.0, where only the
        // item indexes can tell a move.
        val hasDeltas = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
        return ScrollEventPolicy.direction(
            dx = if (hasDeltas) event.scrollDeltaX else 0,
            dy = if (hasDeltas) event.scrollDeltaY else 0,
            fromIndex = event.fromIndex,
            toIndex = event.toIndex)
    }

    private fun sourcePathIds(source: AccessibilityNodeInfo?, maxDepth: Int): List<String> {
        val ids = ArrayList<String>(maxDepth)
        var current = source
        while (current != null && ids.size < maxDepth) {
            ids += compactId(current.viewIdResourceName)
            current = current.parent
        }
        return ids
    }

    private fun sourcePathContains(
        source: AccessibilityNodeInfo?,
        vararg fragments: String,
        maxDepth: Int = 8
    ): Boolean {
        var current = source
        var depth = 0
        while (current != null && depth < maxDepth) {
            val id = compactId(current.viewIdResourceName)
            if (fragments.any(id::contains)) return true
            current = current.parent
            depth++
        }
        return false
    }

    private fun isInstagramNotificationContentIntent(source: AccessibilityNodeInfo?): Boolean =
        sourcePathContains(
            source,
            "activity_feed_newsfeed_story_row",
            "activity_feed_story_row",
            "notification_row"
        ) && !sourcePathContains(source, "action_bar_button_back", "navigation_back")

    private fun isMainTabClick(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(6) {
            val node = current ?: return false
            val id = compactId(node.viewIdResourceName)
            if (id in setOf(
                    "feed_tab", "clips_tab", "direct_tab", "search_tab", "profile_tab"
                )) return true
            current = node.parent
        }
        return false
    }

    private fun isReelsTabClick(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(6) {
            val node = current ?: return false
            if (compactId(node.viewIdResourceName) == "clips_tab") return true
            current = node.parent
        }
        return false
    }

    private fun isBackNavigationIntent(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(6) {
            val node = current ?: return false
            val id = compactId(node.viewIdResourceName)
            if (id == "action_bar_button_back" || id.contains("action_bar_back") ||
                id == "back_button" || id.contains("navigation_back")) return true
            current = node.parent
        }
        return false
    }

    private fun isNotificationsIntent(source: AccessibilityNodeInfo?): Boolean {
        var current = source
        repeat(8) {
            val node = current ?: return false
            val id = compactId(node.viewIdResourceName)
            if (id.contains("notification") || id.contains("activity_feed")) return true
            current = node.parent
        }
        return false
    }

    private fun sourceAncestorIds(source: AccessibilityNodeInfo?): Set<String> {
        val ids = linkedSetOf<String>()
        var current = source
        repeat(8) {
            val node = current ?: return@repeat
            compactId(node.viewIdResourceName).takeIf(String::isNotEmpty)?.let(ids::add)
            current = node.parent
        }
        return ids
    }

    private fun isExploreNavigationIntent(source: AccessibilityNodeInfo?): Boolean =
        InstagramEntryPolicy.isExploreTabIntent(sourceAncestorIds(source))

    private fun isHomeNavigationIntent(source: AccessibilityNodeInfo?): Boolean =
        InstagramEntryPolicy.isHomeTabIntent(sourceAncestorIds(source))

    private fun releaseProfileCurtainToAccountSearch(root: AccessibilityNodeInfo, window: Rect): Boolean {
        if (instagramOverlay.visibleProfileBounds() == null) return false
        val probeStarted = SystemClock.uptimeMillis()
        val trace = applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0
        fun visible(id: String): Boolean = igVisible(root, id)
        val editor = visible("action_bar_search_edit_text")
        val row = editor && visible("row_search_user_container")
        if (!editor || !row) {
            if (trace) Log.d(TAG, "IG_PROFILE_RETURN_PROBE startedAt=$probeStarted " +
                "editor=$editor row=$row result=wait_search elapsedMs=${SystemClock.uptimeMillis() - probeStarted}")
            return false
        }
        // Outgoing search nodes can coexist with a sliding profile. Never treat
        // them as a completed departure while profile content is still mounted.
        val profileVisible = visible("profile_viewpager") || hasVisibleProfileHeaderMarkers(root)
        if (trace) Log.d(TAG, "IG_PROFILE_RETURN_PROBE startedAt=$probeStarted " +
            "editor=true row=true profile=$profileVisible elapsedMs=${SystemClock.uptimeMillis() - probeStarted}")
        if (!InstagramSurfacePolicy.canReleaseProfileToAccountSearch(
                profileCurtainVisible = true, searchEditorVisible = true, accountRowVisible = true,
                profileSurfaceVisible = profileVisible)) return false
        instagramProfileIngress.reset()
        instagramOverlay.updateProfileIngressGuard(null)
        instagramOverlay.updateStoryEntryGuards(emptyList())
        releaseAllowedProfileSurface()
        observeInstagramScreen(InstagramScreen.SEARCH_RESULTS, root.windowId)
        refreshInstagramAccountSearchGuard(root, window)
        Log.d(TAG, "IG_PROFILE_SEARCH_RETURN released=true")
        queueInstagramScan(48L)
        return true
    }

    private fun refreshSettledInstagramProfile(root: AccessibilityNodeInfo, window: Rect, now: Long): Boolean {
        if (profileGeometryWatchActive && profileWatchedFullCover &&
            instagramProfilePostsBlocked()) {
            // During a protective watch hold, curtain geometry belongs to the
            // watch; a settled re-mount here would flash the row-based cover.
            return false
        }
        if (!instagramProfilePostsBlocked() && hasVisibleProfileHeaderMarkers(root) &&
            profileGridBounds(root, window) != null) {
            releaseBalancedInstagramProfile(root, window)
            return true
        }
        if (lastInstagramScreen != InstagramScreen.PROFILE || instagramProfileIngress.pending ||
            instagramResumePending || now < profileAllowedDepartureUntil ||
            instagramOverlay.visibleProfileBounds() == null) return false
        if (!hasVisibleProfileHeaderMarkers(root)) return false
        val bounds = profileGridBounds(root, window) ?: return false
        val mounted = instagramOverlay.visibleProfileBounds()
        if (mounted != null && root.windowId == profileWindowId &&
            bounds.top < mounted.top - PROFILE_COVER_JITTER_PX) {
            // The grid climbed above the curtain edge (a header fling). Raise
            // the edge first: the viewer probes below cost 100-200 ms, during
            // which the first grid row was visible. Exact geometry follows.
            supportCurtainReason = "profile"
            showInstagramCurtain(Rect(mounted.left, maxOf(bounds.top, window.top), mounted.right,
                mounted.bottom), InstagramScreen.PROFILE)
        }
        // A retained profile can sit behind a viewer or native sheet. These
        // exact foreground checks remain authoritative, not the previous state.
        if (hasFastStoryViewer(root) || hasFastMainReelsTabDestination(root) ||
            hasVisibleProfileNativeSheet(root) || hasVisibleAboutAccountSurface(root) ||
            hasFastReelsViewer(root, directLaunchPending = now < directReelLaunchPendingUntil) ||
            hasFastReelPreview(root) || hasFastSinglePostViewer(root) ||
            hasFastNotificationsSurface(root)) return false
        if (hasVisibleUserCollectionIds(root)) return false
        profileWindowId = root.windowId
        profileScrollFloor = calculateProfileScrollFloor(root, window)
        bounds.top = profileScrollCover.measure(bounds.top, profileScrollFloor, now)
        applyStrictProfileCurtain(root, window, bounds)
        observeInstagramScreen(InstagramScreen.PROFILE, root.windowId)
        refreshProtectedNavigationGuards(root, window)
        cancelInstagramExit()
        val fingerprint = bounds.flattenToString()
        if (fingerprint != lastProfileCurtainFingerprint) armProfileCurtainEnsure()
        lastProfileCurtainFingerprint = fingerprint
        if (profileScrollCover.isHolding) queueInstagramScan(48L)
        scheduleOverlayForegroundCheck()
        // Do not walk message/media subtrees or the general snapshot after a
        // fully measured profile. Leave the looper available for native Back.
        return true
    }

    private fun refreshEnteringInstagramProfile(root: AccessibilityNodeInfo, window: Rect): Boolean {
        // Only the explicitly armed search -> profile transition uses this path.
        // Normal sheets, DM, balanced viewers and settled profile scrolling retain
        // their existing classification and geometry owners.
        if (!instagramProfileIngress.pending) return false
        if (!instagramProfilePostsBlocked()) {
            val bounds = profileGridBounds(root, window)
            if (bounds != null && hasVisibleProfileHeaderMarkers(root)) {
                releaseBalancedInstagramProfile(root, window)
                return true
            }
        }
        if (instagramProfileIngress.awaitingCurtainDraw) {
            queueInstagramScan(48L)
            return true
        }
        val bounds = profileGridBounds(root, window)
        if (bounds == null) {
            if (instagramProfileIngress.waitForInitialGrid(SystemClock.uptimeMillis())) {
                // Strict: cover the profile shell as soon as header markers
                // publish, ahead of the grid pager appearing. Covering via the
                // conservative mount keeps thumbnails hidden while the pager
                // measures; the ensure loop refines to exact geometry.
                coverStrictProfileBeforeGrid(root, window)
                // The source search tree is being replaced. A full scan of it
                // can occupy the looper just as the destination grid appears.
                queueInstagramScan(32L)
                return true
            }
            return false
        }
        if (!hasVisibleProfileHeaderMarkers(root) || hasVisibleProfileNativeSheet(root) ||
            hasVisibleAboutAccountSurface(root) ||
            SystemClock.uptimeMillis() < profileAllowedDepartureUntil) return false
        if (instagramProfileIngress.requestCurtainDraw()) {
            val token = instagramProfileIngress.generation
            instagramOverlay.updateAccountSearchGuard(null, ::onInstagramAccountSearchTap, {})
            applyStrictProfileCurtain(root, window, bounds)
            if (instagramOverlay.visibleProfileBounds() != null) {
                observeInstagramScreen(InstagramScreen.PROFILE, root.windowId)
                instagramOverlay.afterCurtainDraw {
                    if (!instagramProfileIngress.isCurrent(token)) return@afterCurtainDraw
                    instagramProfileIngress.confirmCurtainDraw(token)
                    Log.d(TAG, "IG_PROFILE_FIRST_CURTAIN drawn=true")
                    queueInstagramScan(0L)
                }
                mainHandler.postDelayed({
                    // A cancelled draw callback must not strand the scanner.
                    // This resumes verification only; it never uncovers input.
                    if (instagramProfileIngress.isCurrent(token) &&
                        instagramProfileIngress.awaitingCurtainDraw) {
                        instagramProfileIngress.confirmCurtainDraw(token)
                        queueInstagramScan(0L)
                    }
                }, 250L)
                // Yield for grid drawing. Profile header touches stay native;
                // foreground Story detection owns Strict viewer exits.
                queueInstagramScan(48L)
                return true
            }
            instagramProfileIngress.confirmCurtainDraw(token)
            return false
        }
        profileWindowId = root.windowId
        profileScrollFloor = calculateProfileScrollFloor(root, window)
        bounds.top = profileScrollCover.measure(bounds.top, profileScrollFloor, SystemClock.uptimeMillis())
        applyStrictProfileCurtain(root, window, bounds)
        observeInstagramScreen(InstagramScreen.PROFILE, root.windowId)
        // Complete the grid's actual-draw handoff without blocking native
        // profile header gestures or probing unrelated message/media trees.
        refreshInstagramStoryEntryGuards(root, window)
        queueInstagramScan(48L)
        scheduleOverlayForegroundCheck()
        return true
    }

    private fun releaseBalancedInstagramProfile(root: AccessibilityNodeInfo, window: Rect) {
        stopProfileCurtainEnsure()
        instagramProfileIngress.reset()
        instagramOverlay.updateProfileIngressGuard(null)
        instagramOverlay.updateStoryEntryGuards(emptyList())
        profileAllowedDepartureUntil = 0L
        releaseAllowedProfileSurface()
        observeInstagramScreen(InstagramScreen.PROFILE, root.windowId)
        refreshMainReelsTabGuard(root)
        refreshProtectedNavigationGuards(root, window)
        cancelInstagramExit()
        Log.d(TAG, "IG_BALANCED_PROFILE_ALLOWED")
    }

    private fun refreshProtectedNavigationGuards(
        root: AccessibilityNodeInfo,
        window: Rect
    ) {
        refreshInstagramAccountSearchGuard(root, window)
        refreshInstagramStoryEntryGuards(root, window)
        val targets = linkedMapOf<InstagramTab, Rect>()
        listOf(
            InstagramTab.HOME to "feed_tab",
            InstagramTab.SEARCH to "search_tab"
        ).forEach { (tab, id) ->
            root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
                .firstNotNullOfOrNull { node ->
                    if (!node.isVisibleToUser) return@firstNotNullOfOrNull null
                    Rect().also(node::getBoundsInScreen).takeIf { bounds ->
                        !bounds.isEmpty && bounds.intersect(window) &&
                            bounds.top >= window.centerY() &&
                            bounds.height() < window.height() / 3
                    }
                }?.let { targets[tab] = it }
        }
        instagramOverlay.updateNavigationGuards(targets)
        // Visible nodes only: a Story camera/editor opened over the main
        // activity keeps Home's header and heart in its tree, hidden. Guarding
        // that heart put a touch window over the editor's text (Aa) button.
        val notificationBounds = if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) == ProtectionMode.STRICT &&
            root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/main_feed_action_bar")
                .any { it.isVisibleToUser }) {
            root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/notification")
                .firstNotNullOfOrNull { node ->
                    Rect().also(node::getBoundsInScreen).takeIf {
                        node.isClickable && node.isVisibleToUser && !it.isEmpty && it.intersect(window) &&
                            it.bottom < window.centerY()
                    }
                }
        } else null
        if (notificationBounds != null) lastInstagramNotificationLaunchBounds = Rect(notificationBounds)
        if (notificationBounds != null || !instagramNotificationReturn.isPending(SystemClock.uptimeMillis())) {
            instagramOverlay.updateNotificationLaunchGuard(notificationBounds, ::onInstagramNotificationLaunch)
        }
    }

    private var lastInstagramNotificationLaunchBounds: Rect? = null
    private val instagramProfileIngress = InstagramProfileIngress()

    private fun armInstagramNativeAccountEntry(event: AccessibilityEvent): Boolean {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            !instagramStoriesBlocked() || instagramProfileIngress.pending ||
            SystemClock.uptimeMillis() - event.eventTime !in 0L..1_500L) return false
        val source = event.source ?: return false
        if (!InstagramAccountEntryIdentity.isPossibleSearchAccountSource(
                compactId(source.viewIdResourceName))) return false
        val ids = linkedSetOf<String>()
        var node: AccessibilityNodeInfo? = source
        var depth = 0
        while (node != null && depth++ < 6) {
            val current = node
            val id = compactId(current.viewIdResourceName)
            ids.add(id)
            if (id == "row_search_user_follow_button") return false
            if (InstagramAccountEntryIdentity.isProfileEntry(ids)) break
            node = current.parent
        }
        if (!InstagramAccountEntryIdentity.isProfileEntry(ids)) return false
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return false
        if (!InstagramProfileInteractionPolicy.interceptsProfileTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
            // Observe the native row click for fast grid drawing, without
            // intercepting the source row or the destination profile body.
            instagramProfileIngress.begin(SystemClock.uptimeMillis())
            instagramOverlay.updateProfileIngressGuard(null)
            updateInstagramStructuralNodeAccess(true)
            resetYouTubeProtection()
            trackPackageTransition(INSTAGRAM_PACKAGE)
            exitGate.userClick(event.eventTime)
            lastInstagramUserInputAt = event.eventTime
            Log.d(TAG, "IG_PROFILE_SEARCH_ENTRY nativeTouch=true")
            queueInstagramScan(0L)
            return true
        }
        val window = instagramWindowBounds(root)
        val body = Rect(window).apply {
            top += dp(56)
            bottom = stableMainNavigationTop(root, window, InstagramScreen.PROFILE)
        }
        if (!instagramOverlay.updateProfileIngressGuard(body)) return false
        // Draw the profile curtain the moment the account-row click is known,
        // before Instagram replaces the fragment. Otherwise the outgoing search
        // surface fades into unmeasured thumbnails that stay exposed until the
        // post-classification scan. A misclassified tap retreats to the search
        // surface through releaseProfileCurtainToAccountSearch within one scan.
        conservativeInstagramResumeBounds(root, window, InstagramScreen.PROFILE)?.let {
            applyStrictProfileCurtainResult(root, window, it)
        }
        val token = instagramProfileIngress.begin(SystemClock.uptimeMillis())
        updateInstagramStructuralNodeAccess(true)
        resetYouTubeProtection()
        trackPackageTransition(INSTAGRAM_PACKAGE)
        exitGate.userClick(event.eventTime)
        lastInstagramUserInputAt = event.eventTime
        Log.d(TAG, "IG_PROFILE_SEARCH_ENTRY nativeArmed=true eventAgeMs=${SystemClock.uptimeMillis() - event.eventTime}")
        // Let the new input window get its first layout before remote profile
        // queries can occupy the main thread. The fallback only requests a
        // scan; it never releases the ingress guard on a timer.
        mainHandler.removeCallbacks(instagramScan)
        scanSchedule.clear()
        instagramOverlay.afterProfileIngressDraw {
            if (instagramProfileIngress.isCurrent(token)) queueInstagramScan(0L)
        }
        mainHandler.postDelayed({
            if (instagramProfileIngress.isCurrent(token)) queueInstagramScan(0L)
        }, 250L)
        scheduleOverlayForegroundCheck()
        return true
    }

    private fun refreshInstagramAccountSearchGuard(root: AccessibilityNodeInfo, window: Rect) {
        if (!InstagramProfileInteractionPolicy.interceptsProfileTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
            instagramOverlay.updateAccountSearchGuard(null, ::onInstagramAccountSearchTap, {})
            instagramOverlay.updateProfileIngressGuard(null)
            return
        }
        val rows = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/row_search_user_container")
            .filter { it.isVisibleToUser && it.isClickable }
        val list = if (instagramStoriesBlocked() && rows.isNotEmpty()) {
            root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/recycler_view")
                // A single-result account list is not scrollable, but its
                // clickable row still needs the same pre-navigation guard.
                .firstOrNull { node ->
                    val viewport = Rect().also(node::getBoundsInScreen)
                    node.isVisibleToUser && !viewport.isEmpty && rows.any { row ->
                        Rect().also(row::getBoundsInScreen).let(viewport::contains)
                    }
                }
        } else null
        val bounds = list?.let { Rect().also(it::getBoundsInScreen) }
            ?.takeIf { !it.isEmpty && it.intersect(window) }
            ?.apply {
                // The list's native rectangle can extend underneath both the
                // editor and IME. Only account-row territory needs a proxy.
                top = maxOf(top, rows.minOf { Rect().also(it::getBoundsInScreen).top })
                bottom = minOf(bottom, rows.maxOf { Rect().also(it::getBoundsInScreen).bottom },
                    stableMainNavigationTop(root, window, InstagramScreen.SEARCH_RESULTS))
            }
        instagramOverlay.updateAccountSearchGuard(bounds, ::onInstagramAccountSearchTap) { forward ->
            val current = rootInActiveWindow
            if (current?.packageName?.toString() == INSTAGRAM_PACKAGE &&
                current.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/row_search_user_container")
                    .any { it.isVisibleToUser }) {
                current.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/recycler_view")
                    .firstOrNull { it.isVisibleToUser && it.isScrollable }
                    ?.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                queueInstagramScan(0L)
            }
        }
        if (!instagramStoriesBlocked()) {
            instagramProfileIngress.reset()
            instagramOverlay.updateProfileIngressGuard(null)
        }
    }

    private fun onInstagramAccountSearchTap(x: Float, y: Float) {
        if (!InstagramProfileInteractionPolicy.interceptsProfileTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) return
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            !instagramStoriesBlocked() || instagramProfileIngress.pending) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        fun contains(node: AccessibilityNodeInfo) = node.isVisibleToUser &&
            Rect().also(node::getBoundsInScreen).contains(x.toInt(), y.toInt())
        val row = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/row_search_user_container")
            .firstOrNull { it.isClickable && contains(it) }
        if (row == null) {
            // Mixed search results keep their verified native click targets.
            val list = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/recycler_view")
                .firstOrNull { contains(it) } ?: return
            var target: AccessibilityNodeInfo? = null
            val nodes = java.util.ArrayDeque<AccessibilityNodeInfo>()
            nodes.add(list)
            var visited = 0
            while (nodes.isNotEmpty() && visited++ < 200) {
                val node = nodes.removeFirst()
                if (!contains(node)) continue
                if (node.isClickable) target = node
                for (index in 0 until node.childCount) node.getChild(index)?.let(nodes::add)
            }
            target?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return
        }
        val follow = row.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/row_search_user_follow_button")
            .firstOrNull { it.isClickable && contains(it) }
        if (follow != null) {
            follow.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return
        }
        val window = instagramWindowBounds(root)
        val body = Rect(window).apply {
            top += dp(56)
            bottom = stableMainNavigationTop(root, window, InstagramScreen.PROFILE)
        }
        val token = instagramProfileIngress.begin(SystemClock.uptimeMillis())
        if (!instagramOverlay.updateProfileIngressGuard(body)) {
            instagramProfileIngress.reset()
            return
        }
        instagramOverlay.afterProfileIngressDraw {
            if (!instagramProfileIngress.isCurrent(token)) return@afterProfileIngressDraw
            val current = rootInActiveWindow
            if (current?.packageName?.toString() != INSTAGRAM_PACKAGE ||
                current.windowId != root.windowId || !row.refresh() || !row.isVisibleToUser ||
                !row.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                instagramProfileIngress.reset()
                instagramOverlay.updateProfileIngressGuard(null)
            } else {
                Log.d(TAG, "IG_PROFILE_SEARCH_ENTRY armed=true")
                queueInstagramScan(0L)
            }
        }
    }

    private fun refreshInstagramStoryEntryGuards(root: AccessibilityNodeInfo, window: Rect) {
        if (!InstagramProfileInteractionPolicy.interceptsProfileTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
            instagramOverlay.updateStoryEntryGuards(emptyList())
            instagramOverlay.updateProfileIngressGuard(null)
            if (instagramProfileIngress.pending) {
                val grid = profileGridBounds(root, window)
                if (grid != null && hasVisibleProfileHeaderMarkers(root)) {
                    val token = instagramProfileIngress.generation
                    instagramOverlay.afterCurtainDraw {
                        if (instagramProfileIngress.isCurrent(token)) instagramProfileIngress.reset()
                    }
                }
            }
            return
        }
        val targets = mutableListOf<Rect>()
        if (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0 &&
            debugProfileScrollActionWindowId != root.windowId && hasVisibleProfileHeaderMarkers(root)) {
            debugProfileScrollActionWindowId = root.windowId
            for (id in listOf("coordinator_root_layout", "tab_appbar", "profile_header_container",
                    "profile_header_fixed_list", "profile_viewpager",
                    "swipeable_nav_view_pager_inner_recycler_view", "highlights_reel_tray_recycler_view")) {
                root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
                    .filter { it.isVisibleToUser }.forEach { node ->
                        Log.d(TAG, "IG_PROFILE_SCROLL_CAPABILITY id=$id scrollable=${node.isScrollable} " +
                            "actions=${node.actionList.map { it.id }}")
                    }
            }
        }
        if (instagramStoriesBlocked()) {
            val headers = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/profile_header_container")
            for (header in headers) {
                if (!header.isVisibleToUser) continue
                // An ordinary profile photo must remain usable. Only a real
                // Story ring in the verified profile header identifies entry.
                val headerBounds = Rect().also(header::getBoundsInScreen)
                // Query the window root: decorative nodes may not be exposed
                // as searchable descendants of the semantic profile header.
                for (ring in root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/reel_ring")) {
                    if (!ring.isVisibleToUser) continue
                    val bounds = Rect().also(ring::getBoundsInScreen)
                    if (!headerBounds.contains(bounds)) continue
                    if (InstagramStoryEntryPolicy.isProfileStoryRing(
                            hasProfileHeader = true, hasStoryRing = true,
                            bounds = bounds.toInstagramGeometrySample(), window = window.toInstagramGeometrySample()) &&
                        bounds.intersect(window)) targets.add(bounds)
                }
                for (tray in root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/highlights_tray")) {
                    if (!tray.isVisibleToUser) continue
                    val bounds = Rect().also(tray::getBoundsInScreen)
                    if (headerBounds.contains(bounds) && root.findAccessibilityNodeInfosByViewId(
                            "$INSTAGRAM_PACKAGE:id/highlights_reel_tray_recycler_view").any {
                            bounds.contains(Rect().also(it::getBoundsInScreen))
                        } &&
                        !bounds.isEmpty && bounds.intersect(window)) targets.add(bounds)
                }
            }
        }
        instagramOverlay.updateStoryEntryGuards(targets.distinct())
        if (instagramProfileIngress.pending) {
            val avatar = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/row_profile_header_imageview_frame_layout")
                .firstOrNull { it.isVisibleToUser }
            val grid = profileGridBounds(root, window)
            val fingerprint = if (avatar != null && grid != null && hasVisibleProfileHeaderMarkers(root)) {
                "${root.windowId}:${Rect().also(avatar::getBoundsInScreen)}:$grid:$targets"
            } else null
            if (instagramProfileIngress.ready(fingerprint)) {
                val token = instagramProfileIngress.generation
                applyStrictProfileCurtain(root, window, grid!!)
                instagramOverlay.afterCurtainDraw {
                    instagramOverlay.afterStoryEntryGuardsDraw(targets.distinct()) {
                        if (instagramProfileIngress.isCurrent(token)) {
                            instagramProfileIngress.reset()
                            instagramOverlay.updateProfileIngressGuard(null)
                            Log.d(TAG, "IG_PROFILE_SEARCH_ENTRY handoff=true")
                        }
                    }
                }
            }
            queueInstagramScan(48L)
        }
    }

    private var instagramStructuralNodesRequested: Boolean? = null

    private fun updateInstagramStructuralNodeAccess(instagramForeground: Boolean) {
        // getServiceInfo() is a synchronous binder call into the accessibility
        // manager, measured at 25-60 ms per event under load. It ran for every
        // event of every protected app; only a real change needs it.
        if (instagramStructuralNodesRequested == instagramForeground) return
        instagramStructuralNodesRequested = instagramForeground
        val info = serviceInfo ?: return
        val flag = android.accessibilityservice.AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        val wanted = if (instagramForeground) info.flags or flag else info.flags and flag.inv()
        if (wanted == info.flags) return
        info.flags = wanted
        serviceInfo = info
        Log.d(TAG, "IG_STRUCTURAL_NODES enabled=$instagramForeground")
    }

    private fun clearInstagramNotificationIngress() {
        instagramNotificationIngress.reset()
        notificationIngressToken = 0L
        instagramOverlay.updateNotificationIngressGuard(null)
    }

    private fun onInstagramNotificationLaunch() {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) != ProtectionMode.STRICT) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/notification")
            .none { it.isClickable && it.isVisibleToUser }) return
        val header = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/main_feed_action_bar")
            .firstOrNull { it.isVisibleToUser } ?: return
        val window = instagramWindowBounds(root)
        val headerBounds = Rect().also(header::getBoundsInScreen)
        if (headerBounds.bottom <= window.top || headerBounds.bottom >= window.bottom) return
        // A rapid re-entry can beat the Home scan. The verified native Home
        // button/header is sufficient to finish the preceding return here.
        if (instagramNotificationReturn.isPending(SystemClock.uptimeMillis())) {
            cancelInstagramExit()
            observeInstagramScreen(InstagramScreen.HOME_FEED, root.windowId)
        }
        // A previous Notifications visit may have been interrupted while its
        // rows were loading. Never reuse that generation: a stale callback
        // must not suppress the new visit's ingress guard.
        clearInstagramNotificationIngress()
        val token = instagramNotificationIngress.startNew()
        val windowId = root.windowId
        val covered = instagramOverlay.updateNotificationIngressGuard(
            Rect(window.left, headerBounds.bottom, window.right, window.bottom), ::onInstagramNotificationTap)
        if (!covered) {
            clearInstagramNotificationIngress()
            Log.w(TAG, "IG_NOTIFICATION_LAUNCH rejected=guard_unavailable")
            return
        }
        mainHandler.postDelayed({
            // A later generation must never be cleared by an old timeout.
            if (notificationIngressToken == token) {
                val current = rootInActiveWindow
                if (current?.packageName?.toString() != INSTAGRAM_PACKAGE ||
                    (!hasFastNotificationsSurface(current) &&
                        current.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/main_feed_action_bar")
                            .any { it.isVisibleToUser })) clearInstagramNotificationIngress()
                // A slow/loading notification list stays guarded; its header
                // and Back remain outside the input window.
            }
        }, 2000L)
        notificationIngressToken = token
        instagramOverlay.afterNotificationIngressDraw {
            if (!instagramNotificationIngress.accepts(token, SystemClock.uptimeMillis())) return@afterNotificationIngressDraw
            val current = rootInActiveWindow
            if (!instagramNotificationIngress.markDispatched(token)) return@afterNotificationIngressDraw
            val accepted = current?.takeIf { it.packageName?.toString() == INSTAGRAM_PACKAGE && it.windowId == windowId }
                ?.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/notification")
                ?.firstOrNull { it.isClickable }?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            Log.d(TAG, "IG_NOTIFICATION_LAUNCH precovered=true accepted=$accepted")
            if (!accepted) clearInstagramNotificationIngress()
            queueInstagramScan(0L)
        }
    }

    private var notificationIngressToken = 0L

    private fun notificationRowChildren(row: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        for (index in 0 until minOf(row.childCount, 32)) row.getChild(index)?.let(pending::addLast)
        while (pending.isNotEmpty() && result.size < 96) {
            val node = pending.removeFirst()
            result.add(node)
            for (index in 0 until minOf(node.childCount, 16)) node.getChild(index)?.let(pending::addLast)
        }
        return result
    }

    private fun onInstagramNotificationTap(x: Float, y: Float) {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) != ProtectionMode.STRICT) return
        // No row action is safe until the transition has handed input over to
        // the drawn row guards. In particular, never replay a loading tap on
        // a partially published row (which may later acquire a media child).
        if (instagramNotificationIngress.active(SystemClock.uptimeMillis())) {
            Log.d(TAG, "IG_NOTIFICATION_INPUT blocked=loading")
            return
        }
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE || !hasFastNotificationsSurface(root) ||
            instagramNotificationReturn.isPending(SystemClock.uptimeMillis()) ||
            instagramNotificationMotion.isHolding) return
        val nodes = instagramNotificationListNodes(root)
        val row = nodes.firstOrNull {
            compactId(it.viewIdResourceName) == "activity_feed_newsfeed_story_row" &&
                Rect().also(it::getBoundsInScreen).contains(x.toInt(), y.toInt())
        } ?: return // Loading/unknown geometry is not permission to enter media.
        val children = notificationRowChildren(row)
        val rowBounds = Rect().also(row::getBoundsInScreen)
        val avatar = children.firstOrNull { compactId(it.viewIdResourceName) == "igds_profile_picture" }
            ?.let { Rect().also(it::getBoundsInScreen) }
        val profile = avatar?.let { picture -> children.firstOrNull { child ->
            val bounds = Rect().also(child::getBoundsInScreen)
            child.isClickable && !bounds.isEmpty && rowBounds.contains(bounds) &&
                leftToRight(bounds, rowBounds, INSTAGRAM_PACKAGE).right <=
                    rowBounds.left + rowBounds.width() / 3 &&
                picture.contains(bounds.centerX(), bounds.centerY()) && bounds.contains(x.toInt(), y.toInt())
        } }
        val summaries = children.filter {
            val bounds = Rect().also(it::getBoundsInScreen)
            it.className?.toString() == "android.widget.TextView" && bounds.width() >= rowBounds.width() / 3
        }
            .mapNotNull { it.text?.toString()?.takeIf(String::isNotBlank) }
        val decision = InstagramNotificationEntryPolicy.routeTap(summaries, profile != null,
            hasMediaThumbnail = notificationRowMediaThumbnail(children, rowBounds) != null)
        when (decision) {
            InstagramNotificationTap.BLOCK -> {
                Log.d(TAG, "IG_NOTIFICATION_INPUT blocked=true")
                onInstagramOverlayTouched()
            }
            InstagramNotificationTap.WAIT -> {
                Log.d(TAG, "IG_NOTIFICATION_INPUT waiting=identity")
                queueInstagramScan(0L)
            }
            InstagramNotificationTap.PROFILE, InstagramNotificationTap.ALLOW -> {
                val target = if (decision == InstagramNotificationTap.PROFILE) profile else row
                val accepted = target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                Log.d(TAG, "IG_NOTIFICATION_INPUT allowed=$decision accepted=$accepted")
                queueInstagramScan(0L)
            }
        }
    }

    private fun onInstagramProtectedNavigation(tab: InstagramTab) {
        if (tab != InstagramTab.HOME && tab != InstagramTab.SEARCH) return
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return
        val now = SystemClock.uptimeMillis()
        if (isRecentProxiedNavigation(tab, now)) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return

        val armStarted = SystemClock.uptimeMillis()
        val covered = prearmProtectedNavigationCurtain(root, tab)
        val curtainReadyAt = SystemClock.uptimeMillis()
        val targetId = if (tab == InstagramTab.HOME) "feed_tab" else "search_tab"
        if (covered) {
            // Window attachment/layout is asynchronous. Preserve the mounted
            // curtain and wait for its destination rectangle to draw before
            // Instagram starts moving thumbnails underneath it.
            val sourceTab = selectedInstagramMainTab(root)
            Log.d(TAG, "IG_NAVIGATION_ARM tab=$tab curtainMs=${curtainReadyAt - armStarted} " +
                "sourceMs=${SystemClock.uptimeMillis() - curtainReadyAt} sourceTab=$sourceTab")
            val request = instagramProtectedNavigation.begin(
                tab = tab,
                sourceWindowId = root.windowId,
                sourceTab = sourceTab,
                nowMs = now)
            // A scan requested by the source surface may already be due ahead of
            // Choreographer. Let the destination curtain draw first; the retained
            // click event is consumed by the fresh scan queued after dispatch.
            mainHandler.removeCallbacks(instagramScan)
            scanSchedule.clear()
            instagramOverlay.afterCurtainDraw {
                dispatchInstagramProtectedNavigation(request, targetId, "draw")
            }
            // A WindowManager frame should normally win. This bounded fallback
            // preserves the tap if an OEM drops the pre-draw callback; it shares
            // the same generation token and therefore cannot dispatch twice.
            mainHandler.postDelayed({
                dispatchInstagramProtectedNavigation(request, targetId, "fallback")
            }, INSTAGRAM_PROTECTED_NAVIGATION_FALLBACK_MS)
        } else {
            // Preserve native navigation if WindowManager rejects the cover.
            val accepted = performInstagramTabAction(root, targetId)
            Log.d(TAG, "IG_NAVIGATION_PROXY tab=$tab precovered=false accepted=$accepted")
            queueInstagramScan(0L)
        }
    }

    private fun dispatchInstagramProtectedNavigation(
        request: InstagramProtectedNavigationRequest,
        targetId: String,
        source: String
    ) {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) {
            instagramProtectedNavigation.clear(request)
            return
        }
        val current = rootInActiveWindow ?: return
        if (current.packageName?.toString() != INSTAGRAM_PACKAGE ||
            current.windowId != request.sourceWindowId) {
            instagramProtectedNavigation.clear(request)
            return
        }
        val now = SystemClock.uptimeMillis()
        val selectedTab = selectedInstagramMainTab(current)
        if (!instagramProtectedNavigation.acceptsDispatch(
                request, now, current.windowId, selectedTab)) return
        val onTabRoot = lastInstagramScreen == when (request.tab) {
            InstagramTab.HOME -> InstagramScreen.HOME_FEED
            else -> InstagramScreen.EXPLORE
        }
        val accepted = !instagramProtectedNavigation.shouldForwardTap(request, selectedTab, onTabRoot) ||
            performInstagramTabAction(current, targetId)
        if (accepted) {
            instagramProtectedNavigation.markDispatched(request)
            if (request.tab == InstagramTab.HOME) {
                // Measuring Home before its native tab action is accepted walks
                // the still-selected DM tree and can occupy the main looper long
                // enough to swallow the user's first tap. The pre-armed rectangle
                // is already conservative; refine it only after navigation starts.
                mainHandler.removeCallbacks(homeScrollSettled)
                mainHandler.postDelayed(homeScrollSettled, 48L)
            } else if (request.tab == InstagramTab.SEARCH &&
                exploreTransitionCoverWindowId == current.windowId &&
                exploreTransitionCoverUntil > 0L) {
                exploreTransitionCoverUntil = now + 300L
                mainHandler.removeCallbacks(exploreChromeRestore)
                mainHandler.postDelayed(exploreChromeRestore, 300L)
            }
        } else {
            instagramProtectedNavigation.clear(request)
        }
        Log.d(TAG, "IG_NAVIGATION_PROXY tab=${request.tab} source=$source " +
            "precovered=true accepted=$accepted")
        queueInstagramScan(0L)
    }

    private fun refreshInstagramNotificationBackGuard(root: AccessibilityNodeInfo, window: Rect) {
        val bounds = if (instagramNotificationReturn.returnsHome) {
            root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/action_bar_button_back")
                .firstNotNullOfOrNull { node ->
                    Rect().also(node::getBoundsInScreen).takeIf {
                        node.isVisibleToUser && node.isClickable && !it.isEmpty &&
                            it.top >= window.top && it.bottom < window.centerY() &&
                            leftToRight(it, window, INSTAGRAM_PACKAGE).let { leading ->
                                leading.left >= window.left &&
                                    leading.right <= window.left + window.width() / 3
                            }
                    }
                }
        } else null
        instagramOverlay.updateNotificationBackGuard(bounds, ::onInstagramNotificationBack)
        if (bounds != null) scheduleOverlayForegroundCheck()
    }

    private fun instagramNotificationListNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val host = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/newsfeed_you")
            .firstOrNull() ?: return emptyList()
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(host)
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        while (pending.isNotEmpty() && nodes.size < 160) {
            val node = pending.removeFirst()
            // Off-screen subtrees hold no row the guards could cover.
            if (node !== host && !node.isVisibleToUser) continue
            nodes.add(node)
            for (index in 0 until minOf(node.childCount, 32)) node.getChild(index)?.let(pending::addLast)
        }
        return nodes
    }

    private fun refreshInstagramNotificationEntryGuards() {
        // The launch bridge is retired only after populated destination rows
        // have stable geometry AND their replacement input windows have drawn.
        val now = SystemClock.uptimeMillis()
        if (now < instagramNotificationGestureReplayUntil) {
            // Removal emits window events before the forwarded DOWN is sent.
            // Remounting from those events makes the overlay catch its own
            // synthetic swipe instead of delivering it to the native list.
            queueInstagramScan(instagramNotificationGestureReplayUntil - now)
            return
        }
        val root = rootInActiveWindow
        val mode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        if (mode != ProtectionMode.STRICT) {
            clearInstagramNotificationIngress()
            instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
            return
        }
        if (root?.packageName?.toString() != INSTAGRAM_PACKAGE || !hasFastNotificationsSurface(root)) return
        // One id query in Instagram's process. Walking the list node by node
        // (up to 160 remote getChild calls) took 0.6-1.1 s per scan on a
        // Galaxy S23 and ran on every scan in Strict, so a Back from
        // Notifications waited ~1 s with the Home feed visible.
        val rows = root.findAccessibilityNodeInfosByViewId(
            "$INSTAGRAM_PACKAGE:id/activity_feed_newsfeed_story_row").filter { it.isVisibleToUser }
        val targets = instagramNotificationMediaGuardBounds(rows)
        instagramNotificationMotion.reset()
        instagramNotificationGestureReplayUntil = 0L
        instagramOverlay.updateEntryGuards(targets, isEnglish())
        instagramOverlay.hideTransientTouchGuard()
        // The service receives no events from other apps; only this check
        // retires the row guards when the user leaves Instagram. Without it
        // they stayed above the next app (including AwayDoomscrollin itself)
        // and swallowed its taps.
        if (instagramOverlay.hasVisibleWindows) scheduleOverlayForegroundCheck()
        val token = notificationIngressToken
        if (instagramNotificationIngress.accepts(token, SystemClock.uptimeMillis())) {
            val populated = rows.isNotEmpty() && rows.all { row ->
                notificationRowChildren(row).any { !it.text.isNullOrBlank() }
            }
            val identity = "${root.windowId}:" + rows.joinToString { Rect().also(it::getBoundsInScreen).toString() } +
                ":" + targets.joinToString()
            if (instagramNotificationIngress.prepareHandoff(token, identity, populated)) {
                instagramOverlay.afterEntryGuardsDraw(targets) {
                    if (instagramNotificationIngress.completeHandoff(token, identity)) {
                        notificationIngressToken = 0L
                        instagramOverlay.updateNotificationIngressGuard(null)
                        Log.d(TAG, "IG_NOTIFICATION_HANDOFF drawn=true rows=${rows.size} targets=${targets.size}")
                    }
                }
            }
            queueInstagramScan(32L)
        }
    }

    /**
     * The media thumbnail at the end of a notification row, if any. Current
     * builds draw it as a non-clickable, text-less view (the whole row is the
     * click target), so it is recognized by shape and position only: never by
     * a button caption, which only matched Turkish/English UIs.
     */
    private fun notificationRowMediaThumbnail(children: List<AccessibilityNodeInfo>, rowBounds: Rect): Rect? =
        children.asSequence()
            .map { child -> child to Rect().also(child::getBoundsInScreen) }
            .filter { (child, bounds) ->
                // At the row's trailing end: its right edge, or its left when mirrored.
                val trailing = leftToRight(bounds, rowBounds, INSTAGRAM_PACKAGE)
                child.isVisibleToUser && !bounds.isEmpty &&
                    InstagramNotificationEntryPolicy.isMediaThumbnail(
                        id = compactId(child.viewIdResourceName),
                        className = child.className?.toString().orEmpty(),
                        hasText = !child.text.isNullOrBlank(),
                        bounds = InstagramGeometrySample(trailing.left, trailing.top, trailing.right, trailing.bottom),
                        row = InstagramGeometrySample(rowBounds.left, rowBounds.top, rowBounds.right, rowBounds.bottom),
                        minSidePx = dp(32))
            }
            .maxByOrNull { (_, bounds) -> bounds.width().toLong() * bounds.height() }
            ?.second

    private fun instagramNotificationMediaGuardBounds(rows: List<AccessibilityNodeInfo>): List<Rect> {
        return rows.asSequence()
            .mapNotNull { row ->
                val rowBounds = Rect().also(row::getBoundsInScreen)
                if (rowBounds.isEmpty || !row.isVisibleToUser) return@mapNotNull null
                val children = notificationRowChildren(row)
                val candidate = notificationRowMediaThumbnail(children, rowBounds)
                // Instagram makes the whole notification row clickable, even
                // when the visible media thumbnail is the only affordance.
                // Guarding only the thumbnail therefore lets a tap on the
                // notification text launch the viewer. Once a row is known to
                // contain media, consume the row's tap region. The overlay
                // replays vertical drags, so the list itself remains scrollable.
                if (candidate == null) return@mapNotNull null
                rowBounds.takeIf { !it.isEmpty && it.width() >= dp(48) }
            }
            .distinctBy { "${it.left}:${it.top}:${it.right}:${it.bottom}" }
            .toList()
    }

    private fun onInstagramNotificationBack() {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE ||
            instagramStateMachine.currentScreen != InstagramScreen.NOTIFICATIONS ||
            !hasFastNotificationsSurface(root)) return
        val token = instagramNotificationReturn.begin(SystemClock.uptimeMillis()) ?: return
        // Restore the Home header proxy before the native Back animation. A
        // rapid re-entry must not wait for the next Home accessibility scan.
        instagramOverlay.updateNotificationLaunchGuard(lastInstagramNotificationLaunchBounds,
            ::onInstagramNotificationLaunch)
        val windowId = root.windowId
        if (!prearmProtectedNavigationCurtain(root, InstagramTab.HOME)) {
            instagramNotificationReturn.reset()
            instagramOverlay.updateNotificationBackGuard(null)
            // Preserve navigation if WindowManager cannot attach the curtain.
            val back = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/action_bar_button_back")
                .firstOrNull { it.isVisibleToUser && it.isClickable }
            if (back?.performAction(AccessibilityNodeInfo.ACTION_CLICK) != true) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            queueInstagramScan(0L)
            return
        }
        instagramOverlay.afterCurtainDraw {
            if (!instagramNotificationReturn.accepts(token, SystemClock.uptimeMillis()) ||
                !ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return@afterCurtainDraw
            val current = rootInActiveWindow ?: return@afterCurtainDraw
            if (current.packageName?.toString() != INSTAGRAM_PACKAGE || current.windowId != windowId ||
                instagramStateMachine.currentScreen != InstagramScreen.NOTIFICATIONS) return@afterCurtainDraw
            // The curtain may occlude the notification list and change its
            // accessibility visibility. Verify the uncovered native Back control
            // in the same confirmed window, not visibility of the covered list.
            val back = current.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/action_bar_button_back")
                .firstOrNull { it.isVisibleToUser && it.isClickable }
                ?: return@afterCurtainDraw
            val accepted = back.performAction(AccessibilityNodeInfo.ACTION_CLICK) ||
                performGlobalAction(GLOBAL_ACTION_BACK)
            Log.d(TAG, "IG_NOTIFICATION_RETURN precovered=true accepted=$accepted")
            queueInstagramScan(0L)
        }
        // Also recover if the native Back action fails or the draw callback is cancelled.
        queueInstagramScan(32L)
    }

    private fun prearmProtectedNavigationCurtain(
        root: AccessibilityNodeInfo,
        tab: InstagramTab
    ): Boolean {
        val window = instagramWindowBounds(root)
        mainHandler.removeCallbacks(exploreChromeRestore)
        val bounds = if (tab == InstagramTab.SEARCH) {
            calculateExploreBounds(root, window).apply {
                top = maxOf(top, statusBarInset() + dp(56))
                top = top.coerceAtMost(bottom - 1)
            }
        } else {
            val bottom = stableMainNavigationTop(
                root, window, InstagramScreen.HOME_FEED)
            val conservativeTop = (statusBarInset() + dp(56)).coerceIn(window.top, bottom - 1)
            // Both modes: a Home left with its top bar hidden starts at the
            // window top in Strict too. Strict never starts below the header
            // cover (a top remembered from Balanced would show the Stories).
            val inMemory = lastHomeCurtainTop.takeIf {
                lastHomeCurtainWindowId == root.windowId && lastHomeCurtainWidth == window.width()
            }
            // Android renumbers windows when this service restarts (an app
            // update, an OEM restart), so the in-memory top no longer matches
            // and the first Home tap covered the Stories for ~0.9 s. The saved
            // top is used then, for the same screen width and Instagram build.
            val remembered = (inMemory ?: savedHomeCurtainTop(window.width()))?.takeIf {
                !instagramStoriesBlocked() || it <= conservativeTop
            }
            val top = InstagramHomeGeometry.tabPrecoverTop(
                window.top, conservativeTop, bottom, remembered, minHeight = dp(120))
            Rect(window.left, top, window.right, bottom)
        }
        if (tab == InstagramTab.SEARCH && lastInstagramScreen == InstagramScreen.HOME_FEED) {
            // API 34+ overlays move instantly: precover the destination grid,
            // not its usable search chrome. Keep the bounded hold so a stale
            // Home measurement cannot reopen the top row before navigation commits.
            // Older Android retains the conservative animation-region cover.
            exploreTransitionCoverTop = InstagramNavigationGeometry.transitionTop(
                maxOf(window.top, statusBarInset()), bounds.top,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
            exploreTransitionCoverWindowId = root.windowId
            exploreTransitionCoverUntil = SystemClock.uptimeMillis() + 300L
        } else {
            exploreTransitionCoverUntil = 0L
        }
        clearInstagramResumeProtection()
        stopProfileCurtainEnsure()
        // The Strict-profile geometry watch would otherwise remount the
        // profile rectangle over this destination curtain (see its loop).
        profileGeometryWatchActive = false
        mainHandler.removeCallbacks(profileGeometryWatch)
        currentInstagramWindowId = root.windowId
        // show() updates an existing window in place. Removing it here opens
        // a compositor frame between protected Home and Explore destinations.
        val screen = if (tab == InstagramTab.HOME) {
            InstagramScreen.HOME_FEED
        } else {
            InstagramScreen.EXPLORE
        }
        supportCurtainReason = "tab"
        val shown = showInstagramCurtain(bounds, screen)
        if (shown && tab == InstagramTab.HOME) {
            // Tab navigation is not a feed fling. Keep the conservative cover
            // until native Home is verified, then immediately use its tray bounds;
            // do not impose scroll quiet-time/stable-sample holds on Stories.
            scrollCoverTop = null
            scrollCoverUntil = 0L
            settledHomeTop = null
            stableHomeSamples = 0
            mainHandler.removeCallbacks(homeScrollSettled)
        }
        return shown
    }

    private fun performInstagramTabAction(root: AccessibilityNodeInfo, id: String): Boolean {
        root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            .filter { it.isVisibleToUser }
            .forEach { node ->
                var candidate: AccessibilityNodeInfo? = node
                var depth = 0
                while (candidate != null && depth++ < 4) {
                    if (candidate.isClickable &&
                        candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    candidate = candidate.parent
                }
            }
        return false
    }

    private fun selectedInstagramMainTab(root: AccessibilityNodeInfo): InstagramTab? = listOf(
        InstagramTab.HOME to "feed_tab",
        InstagramTab.REELS to "clips_tab",
        InstagramTab.DIRECT to "direct_tab",
        InstagramTab.SEARCH to "search_tab",
        InstagramTab.PROFILE to "profile_tab"
    ).firstOrNull { (_, id) ->
        root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            .any { it.isVisibleToUser && isSelectedRecursive(it, 2) }
    }?.first

    private fun isRecentProxiedNavigation(tab: InstagramTab, now: Long): Boolean {
        return instagramProtectedNavigation.isDuplicate(tab, now)
    }

    private fun recordIntervention(targetPackage: String, now: Long) {
        val prefs = getSharedPreferences(ProtectionPreferences.PREFS_NAME, Context.MODE_PRIVATE)
        val appName = when (targetPackage) {
            TIKTOK_PACKAGE -> "TikTok"
            YOUTUBE_PACKAGE -> "YouTube Shorts"
            else -> "Instagram Reels & Feed" // stored, read back only as "Instagram"
        }

        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
        val dailyBlocksKey = "blocks_$currentDate"
        val appBlocksKey = when (targetPackage) {
            TIKTOK_PACKAGE -> "blocks_tiktok"
            YOUTUBE_PACKAGE -> "blocks_youtube"
            else -> "blocks_instagram"
        }
        val dailyAppKey = when (targetPackage) {
            TIKTOK_PACKAGE -> "blocks_${currentDate}_tiktok"
            YOUTUBE_PACKAGE -> "blocks_${currentDate}_youtube"
            else -> "blocks_${currentDate}_instagram"
        }

        val currentBlocks = prefs.getInt("total_blocks", 0)
        val currentDailyBlocks = prefs.getInt(dailyBlocksKey, 0)
        val currentAppBlocks = prefs.getInt(appBlocksKey, 0)
        val currentDailyAppBlocks = prefs.getInt(dailyAppKey, 0)
        val currentXp = prefs.getLong("user_xp", 150L)

        val hour = SimpleDateFormat("HH", Locale.US).format(Date(now))
        val hourlyBlocksKey = "blocks_${currentDate}_hour_$hour"
        val currentHourlyBlocks = prefs.getInt(hourlyBlocksKey, 0)

        val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(now))
        val appDailyCount = currentDailyAppBlocks + 1
        // The 4th field (epoch ms) lets the list say which day; older
        // three-field entries are still read and shown with the time only.
        val newLog = "$time|$appName|$appDailyCount|$now"
        val previousLogs = prefs.getString("recent_shield_logs", "").orEmpty()
        val updatedLogs = buildList {
            add(newLog)
            if (previousLogs.isNotEmpty()) addAll(previousLogs.split(';'))
        }.take(10).joinToString(";")

        val editor = prefs.edit()
            .putInt("total_blocks", currentBlocks + 1)
            .putLong("user_xp", currentXp + 3L)
            .putInt(dailyBlocksKey, currentDailyBlocks + 1)
            .putInt(appBlocksKey, currentAppBlocks + 1)
            .putInt(dailyAppKey, currentDailyAppBlocks + 1)
            .putInt(hourlyBlocksKey, currentHourlyBlocks + 1)
            .putString("recent_shield_logs", updatedLogs)
            .putLong(AccessibilityStreakPolicy.KEY_LAST_ACCESSIBILITY_HEARTBEAT_MS, now)
            .remove(AccessibilityStreakPolicy.KEY_ACCESSIBILITY_DISABLED_SINCE_MS)
        // Blocks no longer drive the streak; this only counts today if nothing else has yet.
        AccessibilityStreakPolicy.putProtectedDay(prefs, editor, now)
        editor.apply()

        // This remains a no-op unless the user explicitly enabled telemetry.
        TelemetryManager.sendTelemetryAsync(this)
    }

    private fun trackPackageTransition(packageName: String) {
        if (packageName == lastPackage) return

        val now = System.currentTimeMillis()
        if (lastPackage == YOUTUBE_PACKAGE && packageName != YOUTUBE_PACKAGE) {
            youtubeShortsSession.clear()
        }
        if (lastPackage == INSTAGRAM_PACKAGE && instagramSessionStartedAt > 0L) {
            val prefs = getSharedPreferences(ProtectionPreferences.PREFS_NAME, Context.MODE_PRIVATE)
            val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
            val savedDate = prefs.getString("instagram_time_day", "")
            val previous = if (savedDate == currentDate) {
                prefs.getLong("instagram_daily_time_ms", 0L)
            } else {
                0L
            }
            prefs.edit()
                .putLong("instagram_daily_time_ms", previous + (now - instagramSessionStartedAt))
                .putString("instagram_time_day", currentDate)
                .apply()
            instagramSessionStartedAt = 0L
        }

        if (packageName == INSTAGRAM_PACKAGE) {
            instagramSessionStartedAt = now
        }

        lastPackage = packageName
    }

    private fun findVisibleNodeBounds(root: AccessibilityNodeInfo, viewId: String): Rect? {
        val nodes = cachedNodeLookup(root, viewId)
        var maxRect: Rect? = null
        var maxArea = 0L
        for (node in nodes) {
            if (node.isVisibleToUser) {
                val r = Rect()
                node.getBoundsInScreen(r)
                val area = r.width().toLong() * r.height().toLong()
                if (r.width() > 0 && r.height() > 0 && area > maxArea) {
                    maxArea = area
                    maxRect = r
                }
            }
        }
        return maxRect
    }

    private fun isSelectedRecursive(node: AccessibilityNodeInfo, depth: Int): Boolean {
        if (node.isSelected) return true
        if (depth > 0) {
            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null && isSelectedRecursive(child, depth - 1)) {
                    return true
                }
            }
        }
        return false
    }

    private fun refreshHomeScrollBounds(event: AccessibilityEvent?): Boolean {
        val previous = instagramOverlay.visibleHomeBounds() ?: return false
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE ||
            !ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return false
        if (event != null && (event.windowId != root.windowId ||
                SystemClock.uptimeMillis() - event.eventTime !in 0L..1_500L)) return false
        val window = instagramWindowBounds(root)
        val header = verifiedHomeHeaderBounds(root, window)
        val selectedHome = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/feed_tab")
            .any { it.isVisibleToUser && isSelectedRecursive(it, 2) }
        val homeNavigationPending = instagramProtectedNavigation.isPending(
            InstagramTab.HOME, SystemClock.uptimeMillis())
        if (!InstagramHomeGeometry.canMeasureDuringNavigation(homeNavigationPending, selectedHome) ||
            (header == null && !selectedHome)) return false
        // Never turn an old Home event into a new overlay on another screen.
        if (window.left != previous.left || window.right != previous.right) return false
        val heldTop = scrollCoverTop
        scrollCoverTop = null
        val measured = calculateHomeFeedBounds(root, window)
        val now = SystemClock.uptimeMillis()
        if (event != null) {
            val dx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaX else 0
            val dy = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaY else 0
            measured.top = InstagramScrollGeometry.top(previous.top, measured.top, header?.bottom ?: window.top, dx, dy, dp(48))
            lastHomeScrollAt = now
            settledHomeTop = null
            stableHomeSamples = 0
            scrollCoverTop = measured.top
            scrollCoverUntil = now + 300L
            mainHandler.removeCallbacks(homeScrollSettled)
            mainHandler.postDelayed(homeScrollSettled, 48L)
        } else if (heldTop != null) {
            // A fixed 140 ms timer could reopen the edge during fling inertia.
            // Release only after quiet input and repeated matching tray measurements.
            stableHomeSamples = if (settledHomeTop == measured.top) stableHomeSamples + 1 else 1
            settledHomeTop = measured.top
            if (now - lastHomeScrollAt < 200L || stableHomeSamples < 3) {
                scrollCoverTop = minOf(heldTop, measured.top)
                measured.top = scrollCoverTop!!
                scrollCoverUntil = now + 300L
                mainHandler.postDelayed(homeScrollSettled, 48L)
            } else {
                scrollCoverUntil = 0L
                // The measurement above was taken while the temporary cover was
                // still active, so it may contain that conservative top. Measure
                // once more after clearing the hold or the curtain can remain
                // unnecessarily expanded until another accessibility event.
                measured.set(calculateHomeFeedBounds(root, window))
                settledHomeTop = null
                stableHomeSamples = 0
            }
        }
        supportCurtainReason = "scroll"
        showInstagramCurtain(measured, InstagramScreen.HOME_FEED)
        return true
    }

    private fun calculateHomeFeedBounds(root: AccessibilityNodeInfo, displayBounds: Rect): Rect {
        if (instagramAlternateFeedActive) {
            val retained = instagramOverlay.visibleHomeBounds()
            val actionBarBottom = attachedInstagramBounds(
                root, displayBounds, "action_bar_container", requireWide = true)?.bottom
            val contentBottom = listOf(
                "layout_container_main_panel",
                "layout_container_main_wrapper",
                "layout_container_main"
            ).firstNotNullOfOrNull { id ->
                attachedInstagramBounds(root, displayBounds, id, requireWide = true)?.bottom
            }
            val top = InstagramHomeGeometry.alternateFeedTop(
                displayBounds.top, displayBounds.bottom, actionBarBottom, retained?.top)
            val bottom = InstagramHomeGeometry.alternateFeedBottom(
                top, displayBounds.bottom, contentBottom, retained?.bottom)
            return Rect(displayBounds.left, top.coerceAtMost(bottom - 1),
                displayBounds.right, bottom)
        }
        val stories = if (instagramStoriesBlocked()) null else {
            InstagramHomeGeometry.storiesTrayIds.firstNotNullOfOrNull { id ->
                findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/$id")
            }
            // A conservative navigation curtain can temporarily occlude the
            // Stories tray and make isVisibleToUser false. HOME has already
            // been structurally verified before this method is called, so an
            // attached, sane tray rectangle is safe to use without uncovering
            // the feed for a measurement frame.
            ?: findAttachedHomeStoriesBounds(root, displayBounds)
        }
        val header = verifiedHomeHeaderBounds(root, displayBounds)
        val anchor = stories?.let {
            InstagramHomeGeometry.storiesAnchor(it.top, it.bottom, header?.bottom)
        }
        if (ProtectionFlightRecorder.ENABLED && stories != null) {
            val key = "${stories.top}/${stories.bottom}/${header?.bottom}"
            if (key != lastHomeGeometryKey) {
                lastHomeGeometryKey = key
                ProtectionFlightRecorder.record(this, "instagram.home.geometry",
                    "tray=${stories.top}-${stories.bottom} header=${header?.bottom} anchor=$anchor")
            }
        }
        val bounds = contentBounds(root, displayBounds, anchor, home = true,
            knownHeader = header, headerKnown = true)
        if (SystemClock.uptimeMillis() < scrollCoverUntil && instagramOverlay.visibleHomeBounds() != null) {
            scrollCoverTop?.let { bounds.top = minOf(bounds.top, it) }
        }
        clampCurtainBottomToNavigation(root, bounds)
        return bounds
    }

    private fun attachedInstagramBounds(
        root: AccessibilityNodeInfo,
        window: Rect,
        id: String,
        requireWide: Boolean = false
    ): Rect? = cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
        .map { Rect().also(it::getBoundsInScreen) }
        .firstOrNull { bounds ->
            !bounds.isEmpty && bounds.left >= window.left && bounds.right <= window.right &&
                bounds.top >= window.top && bounds.bottom <= window.bottom &&
                (!requireWide || bounds.width() >= window.width() / 2)
        }

    private fun findAttachedHomeStoriesBounds(
        root: AccessibilityNodeInfo,
        window: Rect
    ): Rect? {
        val ids = InstagramHomeGeometry.storiesTrayIds
        return ids.firstNotNullOfOrNull { id ->
            cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
                .firstNotNullOfOrNull { node ->
                    Rect().also(node::getBoundsInScreen).takeIf { bounds ->
                        !bounds.isEmpty && bounds.intersect(window) &&
                            bounds.top >= window.top && bounds.bottom < window.centerY() &&
                            bounds.height() >= dp(32)
                    }
                }
        }
    }

    private fun verifiedHomeHeaderBounds(root: AccessibilityNodeInfo, window: Rect): Rect? {
        val header = cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/main_feed_action_bar")
            .firstOrNull { it.isVisibleToUser } ?: return null
        val bounds = Rect().also(header::getBoundsInScreen)
        if (bounds.isEmpty || bounds.top < window.top || bounds.bottom >= window.centerY()) return null
        // A cached/translated header container can remain in the tree after its
        // controls disappear. Reserve space only for an actually visible control.
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        for (i in 0 until minOf(header.childCount, 12)) header.getChild(i)?.let(pending::addLast)
        var visited = 0
        while (pending.isNotEmpty() && visited++ < 12) {
            val child = pending.removeFirst()
            val control = Rect().also(child::getBoundsInScreen)
            if (child.isVisibleToUser && child.isClickable && !control.isEmpty && bounds.contains(control)) {
                return bounds.takeIf { it.intersect(window) }
            }
            if (child.isVisibleToUser) {
                for (i in 0 until minOf(child.childCount, 12)) child.getChild(i)?.let(pending::addLast)
            }
        }
        return null
    }

    private fun calculateExploreBounds(root: AccessibilityNodeInfo, displayBounds: Rect): Rect {
        val search = attachedExploreHeaderBounds(root, displayBounds)
            ?: findVisibleNodeBounds(root, "com.instagram.android:id/action_bar_search_edit_text")
        val bounds = contentBounds(root, displayBounds, search?.bottom, home = false)
        clampCurtainBottomToNavigation(root, bounds)
        return bounds
    }

    private fun attachedExploreHeaderBounds(root: AccessibilityNodeInfo, window: Rect): Rect? =
        cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/explore_action_bar")
            .map { Rect().also(it::getBoundsInScreen) }
            .firstOrNull { bounds ->
                // Our temporary curtain can mark native chrome as occluded.
                // Require the exact header ID and sane, full-width window geometry.
                bounds.width() >= window.width() / 2 && bounds.height() in 1..dp(96) &&
                    bounds.left >= window.left && bounds.right <= window.right &&
                    bounds.top >= window.top && bounds.bottom < window.centerY()
            }

    private fun contentBounds(
        root: AccessibilityNodeInfo,
        window: Rect,
        anchor: Int?,
        home: Boolean,
        knownHeader: Rect? = null,
        headerKnown: Boolean = false
    ): Rect {
        val header = when {
            !home -> null
            headerKnown -> knownHeader
            else -> verifiedHomeHeaderBounds(root, window)
        }
        val screen = if (home) InstagramScreen.HOME_FEED else InstagramScreen.EXPLORE
        val bottom = stableMainNavigationTop(root, window, screen)
        // Only chrome/tray boundaries determine the mask. Never use a post/list's
        // moving bounds, and never reuse Explore coordinates for Home.
        val visibleAnchor = anchor?.takeIf { it > window.top && it < window.centerY() }
        val top = if (home) InstagramHomeGeometry.top(
            window.top, visibleAnchor, header?.bottom, blockStories = instagramStoriesBlocked())
            else visibleAnchor ?: (window.top + dp(56))
        return Rect(window.left, top.coerceAtMost(bottom - 1), window.right, bottom)
    }

    private fun stableMainNavigationTop(
        root: AccessibilityNodeInfo,
        window: Rect,
        screen: InstagramScreen
    ): Int {
        val retainedTop = instagramOverlay.visibleCurtain()
            ?.takeIf { (retainedScreen, bounds) ->
                retainedScreen == screen && bounds.left == window.left &&
                    bounds.right == window.right && bounds.bottom in
                    (window.centerY() + 1) until window.bottom
            }
            ?.second?.bottom

        fun attachedBounds(id: String): List<Rect> =
            cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
                .map { Rect().also(it::getBoundsInScreen) }
                .filter { bounds ->
                    !bounds.isEmpty && bounds.top > window.centerY() &&
                        bounds.top < window.bottom && bounds.bottom > bounds.top &&
                        bounds.bottom <= window.bottom + dp(8) &&
                        bounds.height() <= dp(120)
                }

        val barTop = attachedBounds("tab_bar")
            .filter { it.width() >= window.width() / 2 }
            .minOfOrNull { it.top }
        // Large-screen layout: the tabs live in a side rail, so the lower tabs
        // are not a bottom bar. Nothing but system buttons sits at the bottom.
        val sideRail = if (barTop == null) instagramSideRail(root, window) else null
        instagramOverlay.updateSideNavigation(sideRail)
        if (sideRail != null) {
            return InstagramSideNavigation.bottomWithoutBottomBar(window.bottom, tappableBottomInset())
                .coerceIn(window.centerY() + 1, window.bottom)
        }
        val tabTop = if (barTop == null) {
            listOf("feed_tab", "clips_tab", "direct_tab", "search_tab", "profile_tab")
                .flatMap(::attachedBounds)
                .minOfOrNull { it.top }
        } else null
        val detectedTop = barTop ?: tabTop
        val profileContentBottom = if (screen == InstagramScreen.PROFILE && detectedTop == null) {
            findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/layout_container_main")
                ?.bottom
                ?.takeIf { it > window.centerY() && it <= window.bottom }
        } else null

        return InstagramBottomNavigationGeometry.resolveTop(
            windowTop = window.top,
            windowBottom = window.bottom,
            retainedTop = retainedTop,
            detectedTop = detectedTop,
            fallbackInset = dp(48),
            contentBottom = profileContentBottom
        )
    }

    private val instagramSideRailProbe = InstagramSideRailProbe()

    /**
     * Instagram's large-screen tab rail, when this window shows one. Probed at
     * most every [InstagramSideRailProbe.MAX_AGE_MS] per window and size, so
     * phones whose tab bar is scrolled away pay almost nothing. Visibility is
     * not required: our own curtain makes the covered rail report invisible,
     * so its shape decides.
     */
    private fun instagramSideRail(root: AccessibilityNodeInfo, window: Rect): Rect? {
        val now = SystemClock.uptimeMillis()
        instagramSideRailProbe.cached(root.windowId, window.width(), window.height(), now)?.let {
            return it.rail?.let { r -> Rect(r.left, r.top, r.right, r.bottom) }
        }
        val windowSample = window.toInstagramGeometrySample()
        val rail = InstagramSideNavigation.railIds.firstNotNullOfOrNull { id ->
            cachedNodeLookup(root, "$INSTAGRAM_PACKAGE:id/$id")
                .map { Rect().also(it::getBoundsInScreen).toInstagramGeometrySample() }
                .firstNotNullOfOrNull { InstagramSideNavigation.rail(it, windowSample, dp(8)) }
        }
        instagramSideRailProbe.store(root.windowId, window.width(), window.height(), rail, now)
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this, "instagram.rail.probe",
            "window=${root.windowId} size=${window.width()}x${window.height()} rail=$rail")
        return rail?.let { Rect(it.left, it.top, it.right, it.bottom) }
    }

    private fun onInstagramOverlayTouched() {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return
        // Only explicit blocked entry guards call this. Plain content-curtain
        // touches are not proof of an attempt to open a video or Story.
        recordIntervention(INSTAGRAM_PACKAGE, System.currentTimeMillis())
    }

    /**
     * A downward swipe on the Strict profile curtain. The curtain consumes the
     * whole collapsed body, so without this a collapsed profile could never
     * show its header (name, bio, Follow/Message) again. Expanding only moves
     * the grid down, away from the curtain edge, so it is always safe; the
     * collapsing direction stays blocked.
     */
    private fun expandStrictProfileHeader() {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            !instagramProfilePostsBlocked() || lastInstagramScreen != InstagramScreen.PROFILE) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        for (id in listOf("tab_appbar", "profile_header_fixed_list", "coordinator_root_layout")) {
            candidates += root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
        }
        val target = candidates.firstOrNull { node ->
            node.isVisibleToUser && node.actionList.any {
                it.id == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
        }
        val accepted = target?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) == true
        Log.d(TAG, "IG_PROFILE_EXPAND target=${compactId(target?.viewIdResourceName)} accepted=$accepted")
        if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this, "instagram.profile.expand",
            "target=${compactId(target?.viewIdResourceName)} accepted=$accepted")
        kickProfileGeometryWatch()
        queueInstagramScan(0L)
    }

    private fun onInstagramStoryEntrySwipe(x: Float, y: Float, direction: InstagramStoryGuardSwipe) {
        if (!InstagramProfileInteractionPolicy.interceptsProfileTouches(
                ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) return
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) || !instagramStoriesBlocked()) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE || !hasVisibleProfileHeaderMarkers(root)) return
        val horizontal = direction == InstagramStoryGuardSwipe.HIGHLIGHTS_FORWARD ||
            direction == InstagramStoryGuardSwipe.HIGHLIGHTS_BACKWARD
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        val id = if (horizontal) "highlights_reel_tray_recycler_view" else "profile_header_fixed_list"
        candidates.addAll(root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id"))
        if (!horizontal) {
            // Only verified vertical ancestors, never the app's horizontal
            // main pager. ACTION_SCROLL_FORWARD on that pager changes tabs.
            for (anchorId in listOf("highlights_tray", "profile_header_container")) {
                var parent = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$anchorId")
                    .firstOrNull { it.isVisibleToUser }
                repeat(8) {
                    val node = parent ?: return@repeat
                    candidates.add(node)
                    parent = node.parent
                }
            }
        }
        val target = candidates
            .firstOrNull {
                it.isVisibleToUser && it.isScrollable && InstagramStoryEntryPolicy.isScrollTarget(
                    compactId(it.viewIdResourceName), it.className?.toString().orEmpty(), horizontal) &&
                    Rect().also(it::getBoundsInScreen).contains(x.toInt(), y.toInt())
            } ?: run {
                Log.d(TAG, "IG_STORY_ENTRY_SCROLL rejected=unverified_axis horizontal=$horizontal")
                queueInstagramScan(0L)
                return
            }
        val forward = direction == InstagramStoryGuardSwipe.PROFILE_FORWARD ||
            direction == InstagramStoryGuardSwipe.HIGHLIGHTS_FORWARD
        val accepted = target.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        Log.d(TAG, "IG_STORY_ENTRY_SCROLL direction=$direction accepted=$accepted")
        if (accepted) {
            // Keep both Story entry windows attached. Removing them to replay a
            // gesture would create a new fast-tap hole on the native avatar.
            val current = rootInActiveWindow
            if (!horizontal && current?.packageName?.toString() == INSTAGRAM_PACKAGE &&
                current.windowId == root.windowId && hasVisibleProfileHeaderMarkers(current)) {
                val window = instagramWindowBounds(current)
                profileGridBounds(current, window)?.let { bounds ->
                    bounds.top = profileScrollCover.measure(bounds.top,
                        calculateProfileScrollFloor(current, window), SystemClock.uptimeMillis())
                    applyStrictProfileCurtain(current, window, bounds)
                }
            }
            queueInstagramScan(0L)
        }
    }

    private fun onInstagramEntryGuardGesture(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ) {
        if (lastInstagramScreen == InstagramScreen.NOTIFICATIONS) {
            // Notification row guards protect comment-like media taps in
            // STRICT mode, but must not turn a finger drag into a coarse
            // accessibility page jump. Temporarily remove only the guards,
            // replay the measured gesture on Instagram's native list, then
            // remount the row regions after the list settles.
            instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
            instagramNotificationGestureReplayUntil =
                SystemClock.uptimeMillis() + durationMs.coerceIn(260L, 1_000L) + 200L
            mainHandler.postDelayed({
                val root = rootInActiveWindow
                if (root?.packageName?.toString() != INSTAGRAM_PACKAGE || !hasFastNotificationsSurface(root)) {
                    instagramNotificationGestureReplayUntil = 0L
                    queueInstagramScan(0L)
                    return@postDelayed
                }
                dispatchScreenSwipe(startX, startY, endX, endY, durationMs) { completed ->
                    instagramNotificationGestureReplayUntil = 0L
                    Log.d(TAG, "IG_NOTIFICATION_SWIPE completed=$completed")
                    refreshInstagramNotificationEntryGuards()
                    queueInstagramScan(16L)
                }
            }, 48L)
            mainHandler.postDelayed({
                scanSchedule.clear()
                queueInstagramScan(0L)
            }, durationMs.coerceIn(260L, 1_000L) + 200L)
            return
        }
        val dmMode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        if (lastInstagramScreen != InstagramScreen.DIRECT_MESSAGES ||
            !InstagramDmInteractionPolicy.blocksSharedMedia(dmMode)) {
            val direction = if (endY < startY) InstagramGuardScrollDirection.FORWARD
            else InstagramGuardScrollDirection.BACKWARD
            onInstagramEntryGuardVerticalSwipe(startX, startY, direction)
            return
        }
        // The exact Reel-card guard must not turn a finger drag into a coarse
        // ACTION_SCROLL page. Temporarily remove only this touch window, replay
        // the measured gesture underneath it, then let the next scan remount
        // the card guard at the new position.
        instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
        mainHandler.postDelayed({
            dispatchScreenSwipe(startX, startY, endX, endY, durationMs) {
                queueInstagramScan(16L)
            }
        }, 48L)
        // A gesture can finish while Instagram is still replacing the
        // Compose message rows.  In that case the normal scan scheduler may
        // still hold the pre-gesture deadline and reject the callback above.
        // Force one bounded follow-up scan so the card guard is remounted at
        // the new scroll position instead of disappearing after the drag.
        mainHandler.postDelayed({
            scanSchedule.clear()
            queueInstagramScan(0L)
        }, 360L)
    }

    private fun onInstagramEntryGuardVerticalSwipe(
        startX: Float,
        startY: Float,
        direction: InstagramGuardScrollDirection
    ) {
        if (lastInstagramScreen == InstagramScreen.NOTIFICATIONS) {
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() != INSTAGRAM_PACKAGE || !hasFastNotificationsSurface(root)) return
            val list = instagramNotificationListNodes(root).firstOrNull {
                compactId(it.viewIdResourceName) == "activity_feed_list" && it.isScrollable
            } ?: return
            val action = if (direction == InstagramGuardScrollDirection.FORWARD)
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            instagramNotificationMotion.arm(SystemClock.uptimeMillis())
            // The persistent notification input window already covers movement.
            val accepted = list.performAction(action)
            Log.d(TAG, "IG_NOTIFICATION_GUARD_SCROLL direction=$direction accepted=$accepted")
            if (accepted) {
                refreshInstagramNotificationEntryGuards()
                queueInstagramScan(16L)
            } else {
                instagramNotificationMotion.reset()
                instagramOverlay.hideTransientTouchGuard()
            }
            return
        }
        if (lastInstagramScreen != InstagramScreen.DIRECT_MESSAGES) return
        // Never replace native chat gestures with discrete accessibility pages.
        val dmMode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM)
        if (!InstagramDmInteractionPolicy.interceptsChatTouches(dmMode) &&
            !InstagramDmInteractionPolicy.blocksSharedMedia(dmMode)) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        val list = root.findAccessibilityNodeInfosByViewId(
            "$INSTAGRAM_PACKAGE:id/message_list")
            .firstOrNull { node ->
                val bounds = Rect().also(node::getBoundsInScreen)
                !bounds.isEmpty && bounds.contains(startX.toInt(), startY.toInt())
            } ?: return
        val action = when (direction) {
            InstagramGuardScrollDirection.FORWARD -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            InstagramGuardScrollDirection.BACKWARD -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        var accepted = false
        var scrollTarget: AccessibilityNodeInfo? = list
        repeat(4) {
            val candidate = scrollTarget ?: return@repeat
            if (!accepted) accepted = candidate.performAction(action)
            scrollTarget = candidate.parent
        }
        Log.d(TAG, "IG_DIRECT_GUARD_SCROLL direction=$direction accepted=$accepted")
        if (accepted) queueInstagramScan(16L)
    }

    private fun cancelInstagramExit() {
        instagramDetailExitChecksRemaining = 0
        val wasNotificationExit = instagramExitFromNotifications
        if (!instagramExitInProgress) {
            instagramExitFromDirectConversation = false
            instagramExitFromNotifications = false
            instagramNotificationCommentLayerObserved = false
            if (wasNotificationExit) {
                instagramNotificationEventLocked = false
                instagramNotificationLastEventExitAt = 0L
            }
            return
        }
        instagramExitInProgress = false
        instagramExitFromDirectConversation = false
        instagramExitFromNotifications = false
        instagramNotificationCommentLayerObserved = false
        if (wasNotificationExit) {
            instagramNotificationEventLocked = false
            instagramNotificationLastEventExitAt = 0L
        }
        instagramBlockedAttempt.reset()
        instagramExitTreeQuietUntil = 0L
        mainHandler.removeCallbacks(instagramViewerExitRetry)
        instagramFastExitHandler.removeCallbacks(instagramFastNotificationBack)
        instagramFastExitDeadlineAt = 0L
        instagramFastExitGeneration = 0L
        if (wasNotificationExit) instagramNotificationExitGeneration++
    }

    private fun scheduleFastNotificationSecondBack(initialDelayMs: Long = 90L) {
        instagramFastExitHandler.removeCallbacks(instagramFastNotificationBack)
        instagramFastExitGeneration = instagramNotificationExitGeneration
        // Let Instagram finish dismissing the comment sheet, but do not route
        // this through mainHandler: that queue is where the observed 4.57 s
        // delay originated. The worker checks the actual sheet state first.
        instagramFastExitDeadlineAt = SystemClock.uptimeMillis() + 1_800L
        instagramFastExitHandler.postDelayed(instagramFastNotificationBack, initialDelayMs)
    }

    private fun requeueFastNotificationBack() {
        instagramFastExitHandler.removeCallbacks(instagramFastNotificationBack)
        instagramFastExitHandler.postDelayed(instagramFastNotificationBack, 90L)
    }

    private fun scheduleInstagramViewerExitRetry(delayMs: Long = INSTAGRAM_VIEWER_EXIT_RETRY_MS) {
        mainHandler.removeCallbacks(instagramViewerExitRetry)
        mainHandler.postDelayed(instagramViewerExitRetry, delayMs)
    }

    private fun logSlowInstagramStage(stage: String, started: Long) {
        val elapsed = SystemClock.uptimeMillis() - started
        if (elapsed > 100L) Log.w(TAG, "IG_SLOW_STAGE stage=$stage elapsedMs=$elapsed")
    }

    private fun observeInstagramScreen(
        screen: InstagramScreen,
        windowId: Int
    ): InstagramProtectionDecision {
        val previous = instagramStateMachine.currentScreen
        if (screen == InstagramScreen.SAVED_COLLECTION &&
            (previous == InstagramScreen.EXPLORE || previous == InstagramScreen.HOME_FEED)) {
            // Its bookmark button opened Saved; Back returns to this feed.
            instagramCollectionFeedOrigin = previous
        }
        if (previous == InstagramScreen.NOTIFICATIONS &&
            screen == InstagramScreen.REELS) {
            // Notification thumbnails do not reliably emit TYPE_VIEW_CLICKED.
            // The verified state transition is therefore the authoritative
            // start of the attempt and gives us an honest end-to-end timer.
            instagramNotificationAttemptStartedAt = SystemClock.uptimeMillis()
            if (ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM) == ProtectionMode.STRICT) {
            // A second notification tap can arrive while the bounded exit from
            // the previous viewer is still pending. Treat this transition as
            // a fresh viewer encounter; otherwise the retry state is consumed
            // by the old attempt and the new Reel can remain open indefinitely.
            if (instagramExitInProgress) {
                cancelInstagramExit()
                Log.d(TAG, "IG_NOTIFICATION_NEW_VIEWER reset=true")
            }
            // Compose notification thumbnails may replace the surface without
            // publishing a click event. Latch the origin at the verified
            // state transition so exitBlockedViewer() cannot lose it.
            instagramNotificationExitHoldUntil = SystemClock.uptimeMillis() + 10_000L
            instagramNotificationBackCount = 0
            instagramNotificationReelExitIssued = false
            instagramNotificationReelSecondBackIssued = false
            instagramNotificationCommentNeedsSecondBack = false
            }
        }
        if (screen != previous) instagramFeedSnapshotYields = 0
        if (screen != InstagramScreen.STORY && screen != InstagramScreen.UNKNOWN) {
            instagramStoryExitReadiness.reset()
        }
        if (screen in setOf(InstagramScreen.HOME_FEED, InstagramScreen.EXPLORE,
                InstagramScreen.SEARCH_RESULTS, InstagramScreen.DIRECT_MESSAGES,
                InstagramScreen.DIRECT_SHARED_MEDIA, InstagramScreen.PROFILE,
                InstagramScreen.SAVED_COLLECTION, InstagramScreen.NOTIFICATIONS,
                InstagramScreen.CREATION, InstagramScreen.STORY)) {
            // A side trip from an allowed Reel (the viewer's "+" camera, the
            // author's profile) opens another window over the viewer; coming
            // back shows the same viewer window. Keep its ingress for that
            // return, exactly as for a visit outside Instagram.
            val viewerWindowId = allowedReelWindowId()
            if (InstagramReelShadeHold.holdsOnInAppSideTrip(
                    previous = previous,
                    viewerWindowId = viewerWindowId,
                    destinationWindowId = windowId,
                    watching = instagramReelsSession.watching,
                    exiting = instagramReelsSession.exiting,
                    mode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
                instagramReelShadeHold.hold(viewerWindowId, instagramBalancedReelOrigin,
                    SystemClock.uptimeMillis())
                if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                    "instagram.balanced.reel", "held=side-trip to=$screen window=$viewerWindowId")
            }
            instagramReelsSession.observe(ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM),
                viewerVisible = false, verifiedOutside = true)
        }
        if (instagramProfileIngress.pending && ((screen == InstagramScreen.SEARCH_RESULTS &&
                instagramProfileIngress.sawProfile) || (screen != InstagramScreen.PROFILE &&
                screen != InstagramScreen.SEARCH_RESULTS && screen != InstagramScreen.UNKNOWN))) {
            instagramProfileIngress.reset()
            instagramOverlay.updateProfileIngressGuard(null)
        }
        if (screen != InstagramScreen.NOTIFICATIONS && screen != InstagramScreen.UNKNOWN &&
            !instagramNotificationIngress.active(SystemClock.uptimeMillis())) {
            instagramOverlay.updateNotificationIngressGuard(null)
        }
        if (previous == InstagramScreen.NOTIFICATIONS && screen != InstagramScreen.NOTIFICATIONS &&
            screen != InstagramScreen.UNKNOWN) {
            instagramNotificationContentLaunchUntil = 0L
            instagramNotificationGestureReplayUntil = 0L
            clearInstagramNotificationIngress()
            instagramOverlay.updateEntryGuards(emptyList(), isEnglish())
            instagramOverlay.hideTransientTouchGuard()
            instagramNotificationMotion.reset()
        }
        instagramNotificationReturn.observe(screen, previous)
        if (screen != InstagramScreen.NOTIFICATIONS && screen != InstagramScreen.UNKNOWN) {
            instagramOverlay.updateNotificationBackGuard(null)
        }
        if (screen != InstagramScreen.PROFILE && screen != InstagramScreen.UNKNOWN) {
            clearInstagramProfileReturn()
        }
        if (screen != InstagramScreen.COMMENTS_OR_DETAIL && screen != InstagramScreen.UNKNOWN) {
            instagramBalancedNotificationPostWatching = false
        }
        // A tab-slip Reels cover must never outlive its exit: it is retired
        // once the return surface is verified (or when no feed followed the
        // arming within its bounded window).
        observeDirectModalCover(screen, windowId)
        if (screen == InstagramScreen.REELS) {
            if (reelsSlipCoverUntil != 0L) reelsSlipCoverExit = true
        } else if (screen != InstagramScreen.UNKNOWN) {
            val expired = reelsSlipCoverUntil != 0L &&
                SystemClock.uptimeMillis() >= reelsSlipCoverUntil
            if (reelsSlipCoverExit || expired) {
                reelsSlipCoverExit = false
                reelsSlipCoverUntil = 0L
                instagramOverlay.hideReelsSlipCover()
            }
        }
        instagramBalancedProfilePost.observeVerifiedSurface(screen, SystemClock.uptimeMillis())
        val decision = instagramStateMachine.observe(screen, windowId,
            // Strict never allows; Balanced allows only the viewer window the
            // chosen Reel was verified in (not a Reel opened on top of it).
            allowChosenReel = !instagramStoriesBlocked() &&
                InstagramBalancedReelIngressPolicy.keepsVerifiedSession(
                    ProtectionMode.BALANCED, instagramReelsSession.watching,
                    instagramReelsSession.exiting, viewerWindowId = windowId,
                    verifiedWindowId = instagramReelsVerifiedWindowId,
                    rebindAllowed = SystemClock.uptimeMillis() < instagramReelWindowRebindUntil),
            allowProfile = !instagramProfilePostsBlocked(),
            allowChosenProfilePost = instagramBalancedProfilePost.watching ||
                instagramBalancedNotificationPostWatching,
            allowUserCollection = ProtectionPreferences.getMode(
                this, ProtectedApp.INSTAGRAM) == ProtectionMode.BALANCED)
        if (decision.changed) {
            Log.d(TAG, "IG_V2_STATE $previous -> ${decision.screen} " +
                "window=$windowId revision=${decision.revision} action=${decision.action}")
            if (ProtectionFlightRecorder.ENABLED) {
                ProtectionFlightRecorder.record(this, "instagram.state",
                    "from=$previous to=${decision.screen} window=$windowId " +
                        "revision=${decision.revision} action=${decision.action}")
            }
            SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_SCREEN,
                mapOf("from" to previous, "to" to decision.screen, "action" to decision.action))
        }
        if (screen != InstagramScreen.UNKNOWN) {
            lastInstagramScreen = decision.screen
            instagramUnknownSince = 0L
        }
        if (decision.screen == InstagramScreen.NOTIFICATIONS && previous != InstagramScreen.NOTIFICATIONS) {
            instagramNotificationEventLocked = false
            instagramNotificationLastEventExitAt = 0L
        }
        // Gesture/native return from search results or notifications bypasses
        // the touch-first precovers: premount the blocked Reels-tab guard the
        // moment the destination main surface is classified, so the frames
        // before its own bottom bar is published stay covered.
        if ((previous == InstagramScreen.SEARCH_RESULTS || previous == InstagramScreen.NOTIFICATIONS) &&
            screen in setOf(InstagramScreen.HOME_FEED, InstagramScreen.EXPLORE,
                InstagramScreen.PROFILE, InstagramScreen.DIRECT_MESSAGES)) {
            premountReelsTabGuard()
        }
        handleInstagramOpenInMessages(screen, windowId)
        return decision
    }

    /** Set when Instagram comes to the front with "Open in Messages" on; 0 when idle. */
    private var instagramOpenInMessagesArmedAt = 0L

    /** The new Instagram window that armed the redirect; it acts only there. */
    private var instagramOpenInMessagesWindow = -1

    /** Instagram windows already seen; a few, since viewers open their own windows. */
    private val instagramWindowMemory = InstagramOpenInMessagesPolicy.WindowMemory()

    private fun bootCount(): Int =
        android.provider.Settings.Global.getInt(
            contentResolver, android.provider.Settings.Global.BOOT_COUNT, -1)

    // SharedPreferences "instagram_seen_windows": "bootCount|id,id,..." of the
    // Instagram windows already seen, so a restarted service keeps telling a
    // resumed Instagram from a fresh launch. Written only when a new window appears.
    private fun saveInstagramWindowMemory() {
        getSharedPreferences(ProtectionPreferences.PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_INSTAGRAM_SEEN_WINDOWS, instagramWindowMemory.save(bootCount()))
            .apply()
    }

    /** On (re)connect: restore what this boot has seen, plus the Instagram window on screen now. */
    private fun restoreInstagramWindowMemory() {
        val boot = bootCount()
        instagramWindowMemory.restore(
            getSharedPreferences(ProtectionPreferences.PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_INSTAGRAM_SEEN_WINDOWS, null), boot)
        var added = false
        runCatching {
            windows.filter { it.root?.packageName?.toString() == INSTAGRAM_PACKAGE }
                .forEach { if (instagramWindowMemory.add(it.id)) added = true }
        }
        if (added) saveInstagramWindowMemory()
    }

    private fun handleInstagramOpenInMessages(screen: InstagramScreen, windowId: Int) {
        if (instagramOpenInMessagesArmedAt == 0L) return
        when (InstagramOpenInMessagesPolicy.decide(
            instagramOpenInMessagesArmedAt, SystemClock.uptimeMillis(), screen,
            inArmedWindow = windowId == instagramOpenInMessagesWindow)) {
            InstagramOpenInMessagesPolicy.Decision.Wait -> Unit
            InstagramOpenInMessagesPolicy.Decision.Done -> instagramOpenInMessagesArmedAt = 0L
            InstagramOpenInMessagesPolicy.Decision.OpenMessages -> {
                instagramOpenInMessagesArmedAt = 0L
                // Not inside the scan that classified Home, but ahead of the
                // scans already queued: on a Galaxy S9+ they delayed the tap by
                // 870 ms while the Home curtain stayed up.
                mainHandler.postAtFrontOfQueue(openInstagramMessages)
            }
        }
    }

    /**
     * Opens Messages before the full scan has classified Home: the scan walks
     * the whole tree while the Home curtain is up. Acts only on the plain
     * Home feed; anything else is left to the scan, exactly as before.
     */
    private val instagramQuickHomeCheck: Runnable = object : Runnable {
        override fun run() {
            val armedAt = instagramOpenInMessagesArmedAt
            if (armedAt <= 0L) return
            val root = rootInActiveWindow
            if (root?.packageName?.toString() != INSTAGRAM_PACKAGE) {
                // The first event can arrive while the launcher is still the root.
                if (SystemClock.uptimeMillis() - armedAt < InstagramOpenInMessagesPolicy.QUICK_HOME_CHECK_MS) {
                    mainHandler.postDelayed(this, 16L)
                }
                return
            }
            if (!ProtectionPreferences.isEnabled(this@AntiScrollService, ProtectedApp.INSTAGRAM)) return
            // Only in the new window that armed it; the scan decides elsewhere.
            if (root.windowId != instagramOpenInMessagesWindow) return
            clearNodeLookupCache()
            val plainHome = InstagramOpenInMessagesPolicy.plainHomeAtEntry(
                isVisible = { igVisible(root, it) },
                feedTabSelected = { igSelected(root, "feed_tab") })
            clearNodeLookupCache()
            if (!plainHome) return
            instagramOpenInMessagesArmedAt = 0L
            if (ProtectionFlightRecorder.ENABLED) {
                ProtectionFlightRecorder.record(this@AntiScrollService, "instagram.open-messages",
                    "quick afterEntryMs=${SystemClock.uptimeMillis() - armedAt}")
            }
            openInstagramMessages.run()
        }
    }

    private val openInstagramMessages = Runnable {
        val root = rootInActiveWindow ?: return@Runnable
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return@Runnable
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return@Runnable
        // The same id in the bottom bar and in the large-screen side rail.
        val opened = performInstagramTabAction(root, "direct_tab")
        if (ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "instagram.open-messages", "ok=$opened")
        }
        SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_OPENED_MESSAGES, mapOf("ok" to opened))
        if (opened) {
            instagramMessagesProbeStartedAt = SystemClock.uptimeMillis()
            instagramMessagesInboxSeenAt = 0L
            mainHandler.postAtFrontOfQueue(instagramMessagesProbe)
        }
    }

    /**
     * After our own Messages tap the Home curtain stays until the inbox is
     * recognized. The full scan needs ~30 lookups (294 ms on a Galaxy S23),
     * so the curtain sat over the already drawn inbox. This asks only for the
     * inbox's own list and bar, ahead of queued scans, and lifts the curtain
     * the moment they are on screen. Until then the curtain stays: the feed
     * is never shown. Bounded; the regular scan takes over after it.
     */
    private var instagramMessagesProbeStartedAt = 0L

    private val instagramMessagesProbe: Runnable = object : Runnable {
        override fun run() {
            val started = instagramMessagesProbeStartedAt
            if (started == 0L) return
            val elapsed = SystemClock.uptimeMillis() - started
            if (elapsed > InstagramOpenInMessagesPolicy.RELEASE_PROBE_MS) {
                instagramMessagesProbeStartedAt = 0L
                instagramMessagesInboxSeenAt = 0L
                queueInstagramScan(0L)
                return
            }
            clearNodeLookupCache()
            val root = rootInActiveWindow
            // Home and Messages sit side by side in a pager: the inbox must
            // fill the window's width, not be sliding in beside the feed.
            val inboxSettled = root?.packageName?.toString() == INSTAGRAM_PACKAGE && run {
                val window = instagramWindowBounds(root)
                // Some Instagram versions (454 on a Galaxy Note 10 Lite) give
                // the inbox list no id; the inbox bar then shows the position.
                val list = findVisibleNodeBounds(root,
                    "$INSTAGRAM_PACKAGE:id/inbox_refreshable_thread_list_recyclerview")
                    ?: findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/direct_inbox_action_bar")
                // During the app-open animation the reported window bounds and
                // the nodes are scaled out of step: on a Note 10 Lite the window
                // stayed scaled while the nodes were full screen, on an S23 the
                // nodes were scaled. The root node is scaled with the list, so
                // any of the three references counts.
                val display = currentDisplayBounds()
                val rootNode = Rect().also(root::getBoundsInScreen)
                list != null && listOf(window, display, rootNode).any { ref ->
                    InstagramOpenInMessagesPolicy.inboxSettled(list.left, list.right, ref.left, ref.right, dp(4))
                } &&
                    (igVisible(root, "direct_inbox_action_bar") || igVisible(root, "direct_inbox_search_bar")) &&
                    !igVisible(root, "main_feed_action_bar")
            }
            // The tree switches as the tap returns; Instagram draws the inbox
            // on a following frame. It must still be there a few frames later,
            // so the curtain never leaves before the feed does. Re-asked ahead
            // of queued scans: a delayed check let a full scan run first.
            if (root != null && inboxSettled && instagramMessagesInboxSeenAt == 0L) {
                instagramMessagesInboxSeenAt = SystemClock.uptimeMillis()
            }
            if (root != null && inboxSettled &&
                SystemClock.uptimeMillis() - instagramMessagesInboxSeenAt <
                InstagramOpenInMessagesPolicy.RELEASE_CONFIRM_MS
            ) {
                clearNodeLookupCache()
                mainHandler.postAtFrontOfQueue(this)
                return
            }
            if (root != null && inboxSettled) {
                instagramMessagesInboxSeenAt = 0L
                instagramMessagesProbeStartedAt = 0L
                clearDirectDetailsScrollGuard()
                clearInstagramResumeProtection()
                instagramOverlay.hide()
                observeInstagramScreen(InstagramScreen.DIRECT_MESSAGES, root.windowId)
                clearNodeLookupCache()
                if (ProtectionFlightRecorder.ENABLED) {
                    ProtectionFlightRecorder.record(this@AntiScrollService,
                        "instagram.open-messages", "released afterMs=$elapsed")
                }
                return
            }
            // Not (or no longer) the settled inbox: start over.
            instagramMessagesInboxSeenAt = 0L
            clearNodeLookupCache()
            mainHandler.postAtFrontOfQueue(this)
        }
    }

    private var instagramMessagesInboxSeenAt = 0L

    /** Consecutive foreground checks that found a focused, unreadable app window. */
    private var unreadableForegroundChecks = 0

    /** The same count for YouTube's foreground check. */
    private var youtubeUnreadableForegroundChecks = 0

    /**
     * Protection was suspended for an unreadable dialog over Instagram. Instagram
     * keeps publishing content events behind it; no curtain may be redrawn over
     * the dialog until Instagram's own window has focus again.
     */
    private var instagramUnreadableForeground = false

    private fun focusedAppWindowUnreadable(): Boolean =
        windows.firstOrNull { it.isFocused && it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            ?.let { it.root == null } == true

    private fun scheduleOverlayForegroundCheck() {
        if (overlayForegroundCheckScheduled) return
        overlayForegroundCheckScheduled = true
        mainHandler.postDelayed(overlayForegroundCheck,
            if (instagramOverlay.isNotificationShadeSuspended) 32L else OVERLAY_FOREGROUND_CHECK_MS)
    }

    private fun showInstagramCurtain(bounds: Rect?, screen: InstagramScreen): Boolean {
        // Support log: why this curtain is shown. Callers that are not plain
        // screen recognition set supportCurtainReason right before calling.
        val reason = supportCurtainReason
        supportCurtainReason = "screen"
        if (bounds == null) return false
        if (isMeasuredInScaledInstagramTask(bounds)) {
            // Pixel's Recents shows Instagram as a live, scaled-down card and
            // reports its nodes at that size. A curtain laid out there stays
            // card-sized after returning (Pixel 11 Pro ticket). Wait until the
            // window is full size again; the foreground check handles Recents.
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.curtain.reject", "screen=$screen bounds=$bounds reason=scaled-task")
            scheduleOverlayForegroundCheck()
            return false
        }
        if (instagramUnreadableForeground) {
            if (focusedAppWindowUnreadable()) return false
            instagramUnreadableForeground = false
        }
        if (InstagramTabReleasePolicy.waitsForSwap(screen,
                SystemClock.uptimeMillis() < instagramTabReleaseUntil)) {
            // Every other show path (fast probes, reader fallbacks) obeys the
            // profile-tab release too; the recover runnable clears it first.
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.curtain.reject", "screen=$screen reason=tab-release")
            queueInstagramScan(32L)
            return false
        }
        if (screen == InstagramScreen.PROFILE) {
            if (ProtectionFlightRecorder.ENABLED) {
                val callers = Throwable().stackTrace.drop(1).take(3)
                    .joinToString(" <- ") { "${it.methodName}:${it.lineNumber}" }
                ProtectionFlightRecorder.record(this, "instagram.profile.mount",
                    "top=${bounds.top} caller=$callers")
            }
        }
        if (screen == InstagramScreen.PROFILE && instagramProfilePostsBlocked()) {
            val root = rootInActiveWindow
            if (root?.packageName?.toString() == INSTAGRAM_PACKAGE) {
                refreshStrictProfileChromeGuard()
                profileScrollFloor = calculateProfileScrollFloor(root, instagramWindowBounds(root))
                profileScrollCover.reset()
            }
        } else {
            instagramOverlay.updateProfileChromeGuard(null)
        }
        val now = SystemClock.uptimeMillis()
        val holdExploreTop = now < exploreTransitionCoverUntil &&
            currentInstagramWindowId == exploreTransitionCoverWindowId &&
            screen in setOf(InstagramScreen.EXPLORE, InstagramScreen.HOME_FEED)
        // Home can still be reported after Explore's precover is drawn but
        // before native navigation commits. That old geometry must not shrink
        // the precover back below Stories. The existing bounded transition
        // expires normally; settled Balanced Home restores its Stories area.
        bounds.top = InstagramNavigationGeometry.top(bounds.top, exploreTransitionCoverTop,
            screen, currentInstagramWindowId == exploreTransitionCoverWindowId, holdExploreTop)
        if (holdExploreTop) queueInstagramScan(minOf(48L, exploreTransitionCoverUntil - now))
        val retained = instagramOverlay.visibleCurtain()
        if (instagramResumeGeometryGate.isActive && retained != null && retained.first != screen) {
            // A real surface change after resume must not inherit the old
            // surface's geometry hold.
            clearInstagramResumeProtection()
        }
        if (!instagramResumeGeometryGate.accept(screen, currentInstagramWindowId,
                bounds.toInstagramGeometrySample(), now)) {
            // WindowManager can keep the Recents animation transform even when
            // the numeric LayoutParams did not change. Re-applying the last
            // verified rectangle each frame snaps the attached window back to
            // application coordinates without exposing the Instagram surface.
            return retained?.let { (retainedScreen, retainedBounds) ->
                instagramOverlay.supportReason = reason
                instagramOverlay.show(
                    retainedBounds, retainedScreen, isEnglish(), forceRelayout = true)
            } ?: false
        }
        mainHandler.removeCallbacks(instagramResumeRescan)
        instagramOverlay.supportReason = reason
        return instagramOverlay.show(bounds, screen, isEnglish()).also { shown ->
            if (shown) lastVerifiedInstagramCurtain = screen to Rect(bounds)
            if (shown && screen == InstagramScreen.HOME_FEED) {
                // Where Home was left; the Home tab precover starts there.
                lastHomeCurtainTop = bounds.top
                lastHomeCurtainWindowId = currentInstagramWindowId
                lastHomeCurtainWidth = bounds.width()
                // Saved once it stops changing (a scroll moves it many times).
                mainHandler.removeCallbacks(saveHomeCurtainTop)
                mainHandler.postDelayed(saveHomeCurtainTop, 1_000L)
            }
            if (shown) {
                setCurtainVerifiedAtMs = now
                setCurtainVerifiedWindowId = currentInstagramWindowId
            }
        }
    }

    private fun beginInstagramResumeProtection(root: AccessibilityNodeInfo? = rootInActiveWindow) {
        if (!ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM)) return
        root ?: return
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE) return
        val screen = lastInstagramScreen.takeIf(InstagramSurfacePolicy::needsCurtain) ?: run {
            instagramResumePending = false
            return
        }
        if (screen == InstagramScreen.PROFILE && !instagramProfilePostsBlocked()) {
            instagramResumePending = false
            releaseBalancedInstagramProfile(root, instagramWindowBounds(root))
            return
        }
        val window = instagramWindowBounds(root)
        val display = currentDisplayBounds()
        val retained = lastVerifiedInstagramCurtain
            ?.takeIf { (retainedScreen, retainedBounds) ->
                retainedScreen == screen && retainedBounds.width() == display.width() &&
                    display.contains(retainedBounds) &&
                    InstagramResumeCurtainPolicy.canReuse(screen, retainedBounds.bottom,
                        stableMainNavigationTop(root, window, screen), dp(24))
            }
            ?.second
        val bounds = retained ?: conservativeInstagramResumeBounds(root, window, screen) ?: return
        currentInstagramWindowId = root.windowId
        val now = SystemClock.uptimeMillis()
        instagramResumeGeometryGate.begin(screen, root.windowId, now)
        instagramOverlay.supportReason = "resume"
        if (instagramOverlay.show(bounds, screen, isEnglish(), forceRelayout = true)) {
            instagramResumePending = false
            mainHandler.removeCallbacks(instagramResumeRescan)
            mainHandler.postDelayed(instagramResumeRescan, INSTAGRAM_RESUME_RESCAN_MS)
            scheduleOverlayForegroundCheck()
            Log.d(TAG, "IG_V2_RESUME_GUARD screen=$screen window=${root.windowId} " +
                "retained=${retained != null} bounds=$bounds")
            SupportDiagnostics.record(this, SupportEvent.INSTAGRAM_RESUME_CURTAIN, mapOf("screen" to screen))
        }
    }

    private fun conservativeInstagramResumeBounds(
        root: AccessibilityNodeInfo,
        window: Rect,
        screen: InstagramScreen
    ): Rect? {
        val app = findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/layout_container_main")
            ?.takeIf { it.intersect(window) } ?: Rect(window)
        val actionBottom = findVisibleNodeBounds(root,
            "$INSTAGRAM_PACKAGE:id/action_bar_container")?.bottom
            ?: findVisibleNodeBounds(root, "$INSTAGRAM_PACKAGE:id/main_feed_action_bar")?.bottom
            ?: app.top + dp(56)
        val bottom = stableMainNavigationTop(root, window, screen)
            .takeIf { it > app.centerY() }
            ?: app.bottom
        val top = actionBottom.coerceIn(app.top, bottom)
        return Rect(app.left, top, app.right, bottom).takeUnless {
            it.width() <= 0 || it.height() <= dp(60)
        }
    }

    private fun Rect.toInstagramGeometrySample() = InstagramGeometrySample(
        left = left, top = top, right = right, bottom = bottom)

    private fun clearInstagramResumeProtection() {
        instagramResumePending = false
        instagramResumeGeometryGate.clear()
        mainHandler.removeCallbacks(instagramResumeRescan)
    }

    private fun hideInstagramContentOverlay() {
        clearDirectDetailsScrollGuard()
        clearInstagramResumeProtection()
        instagramOverlay.hide()
        if (instagramOverlay.hasVisibleWindows) {
            scheduleOverlayForegroundCheck()
        }
    }

    private fun resetInstagramProtectionState() {
        releaseDirectModalCover("reset")
        instagramCollectionFeedOrigin = null
        precoverDrawPendingUntil = 0L
        instagramReelsSession.clear()
        instagramBalancedReelOrigin = InstagramScreen.UNKNOWN
        instagramBalancedNotificationPostWatching = false
        instagramBalancedProfilePost.clear()
        instagramBalancedProfileReelIntentWindowId = -1
        instagramBalancedProfileReelIntentUntil = 0L
        instagramProfileIngress.reset()
        lastInstagramNotificationLaunchBounds = null
        clearInstagramNotificationIngress()
        instagramNotificationMotion.reset()
        instagramNotificationGestureReplayUntil = 0L
        instagramNotificationReturn.reset()
        clearInstagramProfileReturn()
        instagramProtectedNavigation.clear()
        clearDirectConversationEntryGuard()
        clearDirectDetailsScrollGuard()
        clearInstagramResumeProtection()
        currentInstagramWindowId = -1
        instagramUnknownSince = 0L
        instagramExploreSearchSeen = false
        instagramExitTreeQuietUntil = 0L
        profileAllowedDepartureUntil = 0L
        directDetailsLaunchPendingUntil = 0L
        directDetailsFallbackBackAt = 0L
        directReelLaunchPendingUntil = 0L
        directReelIntentDebounceUntil = 0L
        directConversationGuardHoldUntil = 0L
        directConversationSurfaceWindowId = -1
        verifiedInstagramInboxWindowId = -1
        verifiedInstagramInboxListBounds = null
        profileScrollPositions.clear()
        profileScrollExit.reset()
        profileScrollCover.reset()
        profileWindowId = -1
        exitGate.reset()
        scanSchedule.clear()
        directNavigationUntil = 0L
        directNavigationSourceWindowId = -1
        lastInstagramUserInputAt = Long.MIN_VALUE
        @Suppress("DEPRECATION")
        queuedClick?.recycle()
        queuedClick = null
        mainHandler.removeCallbacks(homeScrollSettled)
        scrollCoverTop = null
        scrollCoverUntil = 0L
        instagramAlternateFeedActive = false
        instagramEntryTargets.clear()
        lastDirectConversationGuards.clear()
        cancelInstagramExit()
        mainHandler.removeCallbacks(instagramViewerExitRetry)
        mainHandler.removeCallbacks(instagramScan)
        mainHandler.removeCallbacks(instagramResumeRescan)
        mainHandler.removeCallbacks(overlayForegroundCheck)
        overlayForegroundCheckScheduled = false
    }

    private fun suspendInstagramProtection(destination: String? = null) {
        stopSearchInputObservation()
        // Any visit outside Instagram (shade, Recents, home, another app) can
        // return to the same viewer; an allowed Balanced Reel must survive it.
        // On return its Back control is not yet published, so without the hold
        // the Reel had no ingress and was closed at once.
        if (InstagramReelShadeHold.holdsOnDeparture(
                screen = lastInstagramScreen,
                watching = instagramReelsSession.watching,
                exiting = instagramReelsSession.exiting,
                mode = ProtectionPreferences.getMode(this, ProtectedApp.INSTAGRAM))) {
            instagramReelShadeHold.hold(allowedReelWindowId(),
                instagramBalancedReelOrigin, SystemClock.uptimeMillis())
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.balanced.reel",
                "held=departure to=$destination window=${allowedReelWindowId()}")
        }
        if (instagramOverlay.isNotificationShadeSuspended) {
            Log.d(TAG, "IG_SHADE_FULL_SUSPEND root=${rootInActiveWindow?.packageName} " +
                "tracked=$lastPackage owner=${Throwable().stackTrace.drop(1).take(2).joinToString { it.methodName }}")
        }
        instagramStoryExitReadiness.reset()
        instagramOverlay.visibleCurtain()?.let { (screen, bounds) ->
            lastVerifiedInstagramCurtain = screen to Rect(bounds)
        }
        resetInstagramProtectionState()
        instagramStateMachine.leaveInstagram()
        // Samsung scales an attached accessibility window together with the
        // Recents task card. Remove the window entirely; resume recreates it
        // from the last verified application-space rectangle.
        instagramOverlay.hideAll()
        // The shade's closing frames can leave the tracked Instagram surface
        // foreground again without publishing any further event. One bounded
        // recovery appplies the last verified curtain from that rectangle; the
        // resume helpers only cover verified destinations.
        mainHandler.removeCallbacks(instagramShadeRecovery)
        mainHandler.postDelayed(instagramShadeRecovery, 350L)
    }

    private val instagramShadeRecovery = Runnable {
        val root = rootInActiveWindow ?: return@Runnable
        if (root.packageName?.toString() != INSTAGRAM_PACKAGE ||
            !ProtectionPreferences.isEnabled(this, ProtectedApp.INSTAGRAM) ||
            instagramOverlay.visibleCurtain() != null || taskSwitcherOwner != null) return@Runnable
        // A permission dialog still has focus: Instagram's own return event
        // restores protection once the dialog is answered.
        if (InstagramSurfacePolicy.foreignFocusedPackage(INSTAGRAM_PACKAGE,
                focusedNonOverlayPackage()) != null) return@Runnable
        instagramResumePending = true
        beginInstagramResumeProtection(root)
        scheduleOverlayForegroundCheck()
    }

    private fun hideInstagramProtection() {
        stopSearchInputObservation()
        instagramReelShadeHold.clear()
        instagramStoryExitReadiness.reset()
        resetInstagramProtectionState()
        instagramStateMachine.reset()
        lastInstagramScreen = InstagramScreen.UNKNOWN
        lastVerifiedInstagramCurtain = null
        instagramOverlay.hideAll()
    }

    /**
     * Instagram is being moved into Pixel's Recents (or shown there as a live
     * card): its nodes are reported at the shrinking card's size while the
     * curtain is still mounted. Moving the curtain to that geometry left it
     * card-sized after returning (Pixel 11 Pro ticket). Seen on the Android 16
     * emulator: the window itself stays full size, the home app becomes visible
     * behind it, and only the nodes shrink (tab bar 2248 -> 1965 -> 1903).
     */
    private fun isMeasuredInScaledInstagramTask(bounds: Rect): Boolean {
        val mounted = instagramOverlay.visibleCurtain()
        // Only a move of a mounted curtain is held back; a first curtain (e.g.
        // Instagram in a pop-up window over the home screen) still mounts.
        if (mounted == null || mounted.second == bounds) return false
        val root = rootInActiveWindow ?: return false
        val activePackage = root.packageName?.toString()
        if (activePackage in taskSwitcherPackages) {
            // Reproduced on the Pixel emulator: a slow scan that started on
            // Instagram finished after the home app took over, with the
            // card-sized geometry (0,787-1080,1606). Mounted and saved as the
            // last verified curtain, it came back card-sized on return.
            if (ProtectionFlightRecorder.ENABLED) ProtectionFlightRecorder.record(this,
                "instagram.recents.hold", "active=$activePackage mounted=${mounted.second} new=$bounds")
            return true
        }
        if (activePackage != INSTAGRAM_PACKAGE) return false
        // A pop-up window over the home screen also has the home app behind
        // it; only a fullscreen Instagram window with the home app visible is
        // the Recents transition. The pop-up's curtain must keep following it.
        val window = Rect().also(root::getBoundsInScreen)
        val homeBehind = isFullscreenWindow(window) && isHomeAppVisibleBehind(root)
        if (homeBehind && ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "instagram.recents.hold",
                "root=$window mounted=${mounted.second} new=$bounds")
        }
        return homeBehind
    }

    /** A home-app window is visible behind the active Instagram window. */
    private fun isHomeAppVisibleBehind(root: AccessibilityNodeInfo): Boolean {
        val switchers = taskSwitcherPackages
        if (switchers.isEmpty()) return false
        return windows.any { window ->
            window.type == AccessibilityWindowInfo.TYPE_APPLICATION && window.id != root.windowId &&
                (windowPackages[window.id] ?: window.root?.packageName?.toString()
                    ?.also { windowPackages[window.id] = it }) in switchers
        }
    }

    private fun instagramWindowBounds(root: AccessibilityNodeInfo): Rect {
        val bounds = Rect()
        root.window?.getBoundsInScreen(bounds)
        if (bounds.isEmpty) root.getBoundsInScreen(bounds)
        return bounds.takeUnless { it.isEmpty } ?: currentDisplayBounds()
    }

    private fun currentDisplayBounds(): Rect {
        val windowManager = getSystemService(WindowManager::class.java)
        if (windowManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return Rect(windowManager.maximumWindowMetrics.bounds)
            }
            @Suppress("DEPRECATION")
            val realMetrics = DisplayMetrics().also(windowManager.defaultDisplay::getRealMetrics)
            return Rect(0, 0, realMetrics.widthPixels, realMetrics.heightPixels)
        }
        val fallback = resources.displayMetrics
        return Rect(0, 0, fallback.widthPixels, fallback.heightPixels)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    /**
     * Per package: whether the app was last seen laid out right to left. Read
     * from its bottom tabs; until a bar has been seen, the system language
     * decides (the apps follow it unless set otherwise in-app).
     */
    private val rightToLeftPackages = HashMap<String, Boolean>()

    private fun noteLayoutDirection(packageName: String, firstItem: Rect, lastItem: Rect) {
        if (firstItem.isEmpty || lastItem.isEmpty || firstItem.centerX() == lastItem.centerX()) return
        rightToLeftPackages[packageName] =
            LayoutMirror.isRightToLeft(firstItem.centerX(), lastItem.centerX())
    }

    private fun isRightToLeft(packageName: String): Boolean =
        rightToLeftPackages[packageName] ?: (TextUtils.getLayoutDirectionFromLocale(
            Resources.getSystem().configuration.locales[0]) == View.LAYOUT_DIRECTION_RTL)

    /**
     * [bounds] as it would sit in the left-to-right layout of [packageName]'s
     * window. Leading-edge checks (Back, titles, the YouTube logo) read this;
     * overlays keep using the real bounds. Mirroring is its own inverse, so
     * this also turns a left-to-right guard rect into its real position.
     */
    private fun leftToRight(bounds: Rect, window: Rect, packageName: String): Rect =
        if (!isRightToLeft(packageName)) bounds else Rect(
            LayoutMirror.mirroredLeft(bounds.right, window.left, window.right), bounds.top,
            LayoutMirror.mirroredRight(bounds.left, window.left, window.right), bounds.bottom
        )

    @SuppressLint("InternalInsetResource", "DiscouragedApi")
    private fun statusBarInset(): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowManager = getSystemService(WindowManager::class.java)
            if (windowManager != null) {
                return windowManager.currentWindowMetrics.windowInsets
                    .getInsetsIgnoringVisibility(WindowInsets.Type.statusBars())
                    .top
                    .coerceAtLeast(0)
            }
        }
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id != 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    /** Height of tappable system buttons at the bottom: zero with gesture navigation. */
    private fun tappableBottomInset(): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getSystemService(WindowManager::class.java)?.let { windowManager ->
                return windowManager.currentWindowMetrics.windowInsets
                    .getInsets(WindowInsets.Type.tappableElement())
                    .bottom
                    .coerceAtLeast(0)
            }
        }
        return dp(48)
    }

    private fun compactId(resourceId: String?): String =
        resourceId.orEmpty().substringAfterLast('/').lowercase(Locale.US)

    private fun tabForId(id: String): InstagramTab? = when (id) {
        "feed_tab" -> InstagramTab.HOME
        "clips_tab" -> InstagramTab.REELS
        "direct_tab" -> InstagramTab.DIRECT
        "search_tab" -> InstagramTab.SEARCH
        "profile_tab" -> InstagramTab.PROFILE
        else -> null
    }


    private fun isEnglish(): Boolean {
        val prefs = getSharedPreferences(ProtectionPreferences.PREFS_NAME, Context.MODE_PRIVATE)
        return getAppLanguage(prefs) != "tr"
    }

    private var serviceShutdownNotified = false

    /** Keeps ProtectionWatchdog's alarm a minute ahead while protection runs. */
    private val watchdogHeartbeat = object : Runnable {
        override fun run() {
            ProtectionWatchdog.heartbeat(this@AntiScrollService)
            mainHandler.postDelayed(this, ProtectionWatchdog.HEARTBEAT_MS)
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "service.unbind")
        }
        SupportDiagnostics.record(this, SupportEvent.SERVICE_UNBOUND)
        ProtectionStopWatch.markStopped(this)
        mainHandler.removeCallbacks(watchdogHeartbeat)
        ProtectionWatchdog.disarm(this)
        hideInstagramProtection()
        youtubeOverlay.hideAll()
        AccessibilityStreakPolicy.onServiceDisconnected(this)
        notifyProtectionDisabled()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (searchInputDispatcher.isInitialized()) searchInputDispatcher.value.close()
        if (searchInputThread.isInitialized()) searchInputThread.value.quitSafely()
        if (ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "service.destroy")
        }
        SupportDiagnostics.record(this, SupportEvent.SERVICE_DESTROYED)
        ProtectionStopWatch.markStopped(this)
        ProtectionWatchdog.disarm(this)
        hideInstagramProtection()
        youtubeOverlay.hideAll()
        AccessibilityStreakPolicy.onServiceDisconnected(this)
        mainHandler.removeCallbacksAndMessages(null)
        instagramFastExitHandler.removeCallbacksAndMessages(null)
        instagramFastExitThread.quitSafely()
        notifyProtectionDisabled()
        super.onDestroy()
    }

    private fun notifyProtectionDisabled() {
        if (serviceShutdownNotified) return
        serviceShutdownNotified = true
        // Unbinding is mostly the user turning the switch off: say so, without
        // a buzz. Stops the user did not make are the watchdog's, and vibrate.
        NotificationHelper.showShieldStatusNotification(
            this,
            AppText.get(R.string.notif_protection_stopped_title),
            AppText.get(R.string.notif_protection_stopped_text),
            StatusNotificationPolicy.STOPPED_ID,
            quiet = true
        )
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted")
        if (ProtectionFlightRecorder.ENABLED) {
            ProtectionFlightRecorder.record(this, "service.interrupt")
        }
        SupportDiagnostics.record(this, SupportEvent.SERVICE_INTERRUPTED)
    }

    private fun supportAppName(packageName: String?): String = when (packageName) {
        INSTAGRAM_PACKAGE -> "instagram"
        YOUTUBE_PACKAGE -> "youtube"
        TIKTOK_PACKAGE -> "tiktok"
        else -> "other"
    }


}
