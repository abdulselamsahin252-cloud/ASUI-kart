package com.system.coreguard

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class FocusGuardAccessibilityService : AccessibilityService() {

    private var lastActionTimeMs: Long = 0L
    private val actionCooldownMs: Long = 650L
    private var lastInstagramAutoDmTimeMs: Long = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        val rootNode = rootInActiveWindow ?: return

        // Küçük açılır / kayan / dar pencereleri pas geçme; doğrudan ana ekrana atıp kapat
        if (isSmallOrFloatingWindow(rootNode)) {
            triggerHomeSafely()
            return
        }

        when (pkg) {
            "com.android.settings" -> {
                if (isProtectingSelfInSettings(rootNode)) {
                    triggerBackSafely()
                }
            }
            "com.instagram.android" -> {
                handleInstagram(rootNode)
            }
            "com.google.android.youtube" -> {
                if (isYouTubeShorts(rootNode)) {
                    triggerBackSafely()
                }
            }
            "com.facebook.katana" -> {
                if (shouldBlockFacebook(rootNode)) {
                    triggerBackSafely()
                }
            }
            "com.twitter.android" -> {
                if (shouldBlockTwitter(rootNode)) {
                    triggerBackSafely()
                }
            }
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill" -> {
                if (shouldBlockTikTok(rootNode)) {
                    triggerBackSafely()
                }
            }
        }
    }

    override fun onInterrupt() {}

    private fun isSmallOrFloatingWindow(root: AccessibilityNodeInfo): Boolean {
        val dm = resources.displayMetrics
        if (dm.widthPixels <= 0 || dm.heightPixels <= 0) return false

        val bounds = Rect()
        root.getBoundsInScreen(bounds)

        val widthRatio = bounds.width().toFloat() / dm.widthPixels.toFloat()
        val heightRatio = bounds.height().toFloat() / dm.heightPixels.toFloat()

        return widthRatio < 0.72f || heightRatio < 0.55f
    }

    private fun canTrigger(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionTimeMs < actionCooldownMs) return false
        lastActionTimeMs = now
        return true
    }

    private fun triggerBackSafely() {
        if (canTrigger()) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun triggerHomeSafely() {
        if (canTrigger()) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    private fun handleInstagram(root: AccessibilityNodeInfo) {
        val items = collectTextsAndIds(root)

        // Reels veya video akışındaysa anında geri çıkar
        val isReelsOrVideo = items.any { item ->
            item.contains("reels_viewer") ||
                item.contains("clips_viewer") ||
                item.contains("reel_recycler") ||
                item.contains("video_player") ||
                item.contains("reels")
        }
        if (isReelsOrVideo) {
            triggerBackSafely()
            return
        }

        // Zaten Instagram DM kutusu veya sohbet içindeyse dokunma
        val alreadyInInstagramDm = items.any { item ->
            item.contains("direct_thread") ||
                item.contains("direct_inbox") ||
                item.contains("direct_fragment") ||
                item.contains("message_list") ||
                item.contains("direct_share_sheet")
        }
        if (alreadyInInstagramDm) return

        // Instagram açıldığında üstteki uçak / DM simgesine basmayı dene
        val now = SystemClock.elapsedRealtime()
        if (now - lastInstagramAutoDmTimeMs > 2200L) {
            if (clickInstagramDmButton(root)) {
                lastInstagramAutoDmTimeMs = now
            }
        }
    }

    private fun clickInstagramDmButton(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0

        while (queue.isNotEmpty() && visited < 250) {
            val current = queue.removeFirst()
            visited++

            val id = current.viewIdResourceName?.lowercase().orEmpty()
            val desc = current.contentDescription?.toString()?.lowercase().orEmpty()
            val text = current.text?.toString()?.lowercase().orEmpty()

            val looksLikeDmOrPlaneIcon = id.contains("direct") ||
                id.contains("inbox") ||
                id.contains("action_bar_inbox") ||
                desc.contains("direct") ||
                desc.contains("dm") ||
                desc.contains("mesaj") ||
                desc.contains("uçak") ||
                desc.contains("plane") ||
                desc.contains("paper") ||
                text == "direct" ||
                text == "dm" ||
                text == "mesajlar" ||
                text == "messages"

            if (looksLikeDmOrPlaneIcon) {
                var target: AccessibilityNodeInfo? = current
                while (target != null && !target.isClickable) {
                    target = target.parent
                }
                if (target != null && target.isClickable) {
                    target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
            }

            for (i in 0 until current.childCount) {
                current.getChild(i)?.let { queue.add(it) }
            }
        }
        return false
    }

    private fun isYouTubeShorts(root: AccessibilityNodeInfo): Boolean {
        val items = collectTextsAndIds(root)
        return items.any { item ->
            item.contains("reel_watch_fragment") ||
                item.contains("shorts_player") ||
                item.contains("reel_player") ||
                item.contains("shorts")
        }
    }

    private fun isProtectingSelfInSettings(root: AccessibilityNodeInfo): Boolean {
        val texts = collectTextsAndIds(root)
        return texts.any { item ->
            item.contains("com.system.coreguard") ||
                item.contains("sistem çekirdek yöneticisi") ||
                item.contains("sistem arayüz bütünlüğü") ||
                item.contains("cihaz yöneticileri") ||
                item.contains("device admin") ||
                item.contains("erişilebilirlik") ||
                item.contains("accessibility")
        }
    }

    private fun shouldBlockFacebook(root: AccessibilityNodeInfo): Boolean {
        val items = collectTextsAndIds(root)
        return items.any { item ->
            item.contains("fb_shorts") ||
                item.contains("reels_viewer") ||
                item.contains("watch") ||
                item.contains("video_home")
        }
    }

    private fun shouldBlockTwitter(root: AccessibilityNodeInfo): Boolean {
        val items = collectTextsAndIds(root)
        return items.any { item ->
            item.contains("video_dock") ||
                item.contains("media_video") ||
                item.contains("explore") ||
                item.contains("keşfet")
        }
    }

    private fun shouldBlockTikTok(root: AccessibilityNodeInfo): Boolean {
        val items = collectTextsAndIds(root)
        val isInboxOrChat = items.any { item ->
            item.contains("inbox") ||
                item.contains("gelen kutusu") ||
                item.contains("chat") ||
                item.contains("mesaj")
        }
        if (isInboxOrChat) return false

        return items.any { item ->
            item.contains("viewpager") ||
                item.contains("feed") ||
                item.contains("player") ||
                item.contains("video")
        }
    }

    private fun collectTextsAndIds(node: AccessibilityNodeInfo?): List<String> {
        val results = mutableListOf<String>()
        if (node == null) return results

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(node)

        var visited = 0
        while (queue.isNotEmpty() && visited < 250) {
            val current = queue.removeFirst()
            visited++

            current.viewIdResourceName?.let { results.add(it.lowercase()) }
            current.text?.toString()?.let { if (it.isNotBlank()) results.add(it.lowercase()) }
            current.contentDescription?.toString()?.let { if (it.isNotBlank()) results.add(it.lowercase()) }

            for (i in 0 until current.childCount) {
                current.getChild(i)?.let { queue.add(it) }
            }
        }
        return results
    }
}
