package com.system.coreguard

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val btnAccessibility = Button(this).apply {
            text = "1. Erişilebilirlik Servisini Aç"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnDeviceAdmin = Button(this).apply {
            text = "2. Cihaz Yöneticisi Yetkisini İste"
            setOnClickListener {
                val adminComponent = ComponentName(this@SetupActivity, FocusDeviceAdminReceiver::class.java)
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Servisin sistem tarafından korunması için cihaz yöneticisi yetkisi gereklidir."
                    )
                }
                startActivity(intent)
            }
        }

        val btnFinish = Button(this).apply {
            text = "3. Kurulumu Tamamla ve Kapat"
            setOnClickListener {
                Toast.makeText(this@SetupActivity, "Koruma arka planda çalışıyor.", Toast.LENGTH_SHORT).show()
                finishAffinity()
            }
        }

        rootLayout.addView(btnAccessibility)
        rootLayout.addView(btnDeviceAdmin)
        rootLayout.addView(btnFinish)
        setContentView(rootLayout)
    }
}