package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.AutomationActionType
import com.example.data.AutomationMacroEntity
import com.example.data.AutomationStep
import com.example.data.CachedSiteEntity
import com.example.data.InstalledAppInfo
import com.example.data.ResearchSummaryResult
import com.example.data.SiteComparisonResult
import com.example.data.StepSerializer
import com.example.data.UserSettings
import com.example.engine.WorkspaceItem
import com.example.engine.ZipExtractionReport
import com.example.ui.theme.LocalYankiStatusColors

@Composable
fun AutomationResearchScreen(
    installedApps: List<InstalledAppInfo>,
    macros: List<AutomationMacroEntity>,
    cachedSites: List<CachedSiteEntity>,
    settings: UserSettings,
    accessibilityConnected: Boolean,
    automationLogs: List<String>,
    researchResult: ResearchSummaryResult?,
    comparisonResult: SiteComparisonResult?,
    isBusy: Boolean,
    workspaceItems: List<WorkspaceItem>,
    lastZipReport: ZipExtractionReport?,
    selectedZipName: String?,
    selectedTargetTreeName: String?,
    onRunCommand: (String) -> Unit,
    onOpenAccessibilityGuide: () -> Unit,
    onSaveAndRunMacro: (String, String, InstalledAppInfo, List<AutomationStep>, Boolean) -> Unit,
    onRunMacro: (AutomationMacroEntity) -> Unit,
    onDeleteMacro: (Int) -> Unit,
    onSummarizeSite: (CachedSiteEntity) -> Unit,
    onCompareSites: (CachedSiteEntity, CachedSiteEntity) -> Unit,
    onSavePastedSite: (String, String, String) -> Unit,
    onImportLocalDocument: (Uri) -> Unit,
    onFetchLiveSite: (String) -> Unit,
    onDeleteSite: (Int) -> Unit,
    onToggleOfflineShield: (Boolean) -> Unit,
    onPickZipFile: (Uri) -> Unit,
    onPickTargetFolder: (Uri) -> Unit,
    onExtractZip: (String, Boolean) -> Unit,
    onCreateWorkspaceFolder: (String) -> Unit,
    onCompressFolder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Otomasyon, 1 = Araştırma, 2 = Dosya & ZIP

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 3),
                    modifier = Modifier.testTag("tab_automation_segment")
                ) {
                    Text("Otomasyon", maxLines = 1)
                }
                SegmentedButton(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 3),
                    modifier = Modifier.testTag("tab_research_segment")
                ) {
                    Text("Araştırma", maxLines = 1)
                }
                SegmentedButton(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    shape = SegmentedButtonDefaults.itemShape(index = 2, count = 3),
                    modifier = Modifier.testTag("tab_files_segment")
                ) {
                    Text("Dosya & ZIP", maxLines = 1)
                }
            }
        }

        when (selectedTab) {
            0 -> AutomationLabPane(
                installedApps = installedApps,
                macros = macros,
                accessibilityConnected = accessibilityConnected,
                automationLogs = automationLogs,
                onRunCommand = onRunCommand,
                onOpenAccessibilityGuide = onOpenAccessibilityGuide,
                onSaveAndRunMacro = onSaveAndRunMacro,
                onRunMacro = onRunMacro,
                onDeleteMacro = onDeleteMacro,
                modifier = Modifier.weight(1f)
            )
            1 -> ResearchComparisonPane(
                cachedSites = cachedSites,
                settings = settings,
                researchResult = researchResult,
                comparisonResult = comparisonResult,
                isBusy = isBusy,
                onSummarizeSite = onSummarizeSite,
                onCompareSites = onCompareSites,
                onSavePastedSite = onSavePastedSite,
                onImportLocalDocument = onImportLocalDocument,
                onFetchLiveSite = onFetchLiveSite,
                onDeleteSite = onDeleteSite,
                onToggleOfflineShield = onToggleOfflineShield,
                modifier = Modifier.weight(1f)
            )
            else -> FileArchivePane(
                workspaceItems = workspaceItems,
                lastZipReport = lastZipReport,
                selectedZipName = selectedZipName,
                selectedTargetTreeName = selectedTargetTreeName,
                onPickZipFile = onPickZipFile,
                onPickTargetFolder = onPickTargetFolder,
                onExtractZip = onExtractZip,
                onCreateWorkspaceFolder = onCreateWorkspaceFolder,
                onCompressFolder = onCompressFolder,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun AutomationLabPane(
    installedApps: List<InstalledAppInfo>,
    macros: List<AutomationMacroEntity>,
    accessibilityConnected: Boolean,
    automationLogs: List<String>,
    onRunCommand: (String) -> Unit,
    onOpenAccessibilityGuide: () -> Unit,
    onSaveAndRunMacro: (String, String, InstalledAppInfo, List<AutomationStep>, Boolean) -> Unit,
    onRunMacro: (AutomationMacroEntity) -> Unit,
    onDeleteMacro: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColors = LocalYankiStatusColors.current
    var selectedApp by remember(installedApps) {
        mutableStateOf(installedApps.firstOrNull() ?: InstalledAppInfo("com.android.settings", "Ayarlar"))
    }
    var appMenuExpanded by remember { mutableStateOf(false) }
    var macroTitle by remember { mutableStateOf("") }
    var newStepText by remember { mutableStateOf("") }
    var newStepValue by remember { mutableStateOf("") }
    val draftSteps = remember { mutableStateListOf<AutomationStep>() }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Accessibility Status Banner
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(
                        containerColor = if (accessibilityConnected) statusColors.offlineShield.copy(alpha = 0.14f)
                        else MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.55f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                if (accessibilityConnected) Icons.Default.CheckCircle else Icons.Default.AccessibilityNew,
                                contentDescription = null,
                                tint = if (accessibilityConnected) statusColors.offlineShield else MaterialTheme.colorScheme.tertiary
                            )
                            Column {
                                Text(
                                    if (accessibilityConnected) "Erişilebilirlik Otomasyonu Aktif"
                                    else "Erişilebilirlik Servisi Kapalı",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    "Telefonu kapatma, Wi-Fi/BT anahtarlama ve uygulama içi tıklama/yazma için kullanılır.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (!accessibilityConnected) {
                            FilledTonalButton(onClick = onOpenAccessibilityGuide) {
                                Text("Aç")
                            }
                        }
                    }
                }
            }

            // Hardware Instant Controls
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sistem & Donanım Kontrolleri", style = MaterialTheme.typography.titleSmall)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HardwareActionPill(Icons.Default.Wifi, "Wi-Fi Aç") { onRunCommand("wifi aç") }
                        HardwareActionPill(Icons.Default.Bluetooth, "Bluetooth Aç") { onRunCommand("bluetooth aç") }
                        HardwareActionPill(Icons.Default.FlashlightOn, "Fener Aç") { onRunCommand("feneri aç") }
                        HardwareActionPill(Icons.Default.Lock, "Ekran Kilitle") { onRunCommand("ekranı kilitle") }
                        HardwareActionPill(Icons.Default.PowerSettingsNew, "Telefonu Kapat") { onRunCommand("telefonu kapat") }
                    }
                }
            }

            // Visual Multi-Step App Automation Builder ("Şu uygulamaya girip bunları bunları yap")
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Apps, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Çok Adımlı Uygulama Makrosu Oluştur", style = MaterialTheme.typography.titleMedium)
                        }

                        Box {
                            OutlinedButton(
                                onClick = { appMenuExpanded = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Hedef Uygulama: ${selectedApp.label} (${installedApps.size} yüklü uygulama)")
                            }
                            DropdownMenu(
                                expanded = appMenuExpanded,
                                onDismissRequest = { appMenuExpanded = false }
                            ) {
                                installedApps.take(30).forEach { app ->
                                    DropdownMenuItem(
                                        text = { Text("${app.label} — ${app.packageName}") },
                                        onClick = {
                                            selectedApp = app
                                            appMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = macroTitle,
                            onValueChange = { macroTitle = it },
                            label = { Text("Makro Adı (ör. Ayarlarda Bluetooth'u Aç)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newStepText,
                                onValueChange = { newStepText = it },
                                label = { Text("Tıklanacak Öğe / Hedef") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = newStepValue,
                                onValueChange = { newStepValue = it },
                                label = { Text("Yazılacak Metin") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    if (newStepText.isNotBlank()) {
                                        draftSteps += AutomationStep(AutomationActionType.CLICK_TEXT, target = newStepText.trim())
                                        newStepText = ""
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("Tıkla Adımı")
                            }
                            FilledTonalButton(
                                onClick = {
                                    if (newStepValue.isNotBlank()) {
                                        draftSteps += AutomationStep(
                                            AutomationActionType.INPUT_TEXT,
                                            target = newStepText.trim(),
                                            value = newStepValue.trim()
                                        )
                                        newStepValue = ""
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("Yaz Adımı")
                            }
                            FilledTonalButton(onClick = {
                                draftSteps += AutomationStep(AutomationActionType.SCROLL_DOWN)
                            }) {
                                Text("+ Aşağı Kaydır")
                            }
                            FilledTonalButton(onClick = {
                                draftSteps += AutomationStep(AutomationActionType.PRESS_BACK)
                            }) {
                                Text("+ Geri")
                            }
                        }

                        if (draftSteps.isNotEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(MaterialTheme.shapes.small)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text("Adım Sırası:", style = MaterialTheme.typography.labelMedium)
                                draftSteps.forEachIndexed { idx, s ->
                                    Text(
                                        "${idx + 1}. ${s.type.labelTr} ${s.target} ${s.value}".trim(),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val finalSteps = listOf(
                                    AutomationStep(AutomationActionType.OPEN_APP, target = selectedApp.label),
                                    AutomationStep(AutomationActionType.WAIT, delayMs = 1000L)
                                ) + draftSteps.toList()
                                onSaveAndRunMacro(
                                    macroTitle,
                                    "${selectedApp.label} girip işlem yap",
                                    selectedApp,
                                    finalSteps,
                                    true
                                )
                                draftSteps.clear()
                                macroTitle = ""
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_and_run_macro_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Makroyu Kaydet ve Şimdi Çalıştır")
                        }
                    }
                }
            }

            // Saved Macros
            item {
                Text("Kayıtlı Otomasyonlar (${macros.size})", style = MaterialTheme.typography.titleSmall)
            }

            items(macros, key = { it.id }) { macro ->
                val steps = remember(macro.stepsSerialized) { StepSerializer.decode(macro.stepsSerialized) }
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(macro.title, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${macro.targetAppLabel} • ${steps.size} adım • Sesli tetik: \"${macro.triggerPhrase}\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row {
                            IconButton(onClick = { onRunMacro(macro) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Makroyu Çalıştır", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = { onDeleteMacro(macro.id) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Makroyu Sil")
                            }
                        }
                    }
                }
            }

            if (automationLogs.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("Canlı Otomasyon Günlüğü", style = MaterialTheme.typography.labelMedium)
                            automationLogs.take(6).forEach { log ->
                                Text("• $log", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HardwareActionPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun ResearchComparisonPane(
    cachedSites: List<CachedSiteEntity>,
    settings: UserSettings,
    researchResult: ResearchSummaryResult?,
    comparisonResult: SiteComparisonResult?,
    isBusy: Boolean,
    onSummarizeSite: (CachedSiteEntity) -> Unit,
    onCompareSites: (CachedSiteEntity, CachedSiteEntity) -> Unit,
    onSavePastedSite: (String, String, String) -> Unit,
    onImportLocalDocument: (Uri) -> Unit,
    onFetchLiveSite: (String) -> Unit,
    onDeleteSite: (Int) -> Unit,
    onToggleOfflineShield: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColors = LocalYankiStatusColors.current
    var siteAIndex by remember { mutableStateOf(0) }
    var siteBIndex by remember { mutableStateOf(1) }
    var customTitle by remember { mutableStateOf("") }
    var customUrl by remember { mutableStateOf("") }
    var customContent by remember { mutableStateOf("") }
    var showSiteAMenu by remember { mutableStateOf(false) }
    var showSiteBMenu by remember { mutableStateOf(false) }

    val docPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onImportLocalDocument(uri)
    }

    val safeSiteA = cachedSites.getOrNull(siteAIndex.coerceIn(0, (cachedSites.size - 1).coerceAtLeast(0)))
    val safeSiteB = cachedSites.getOrNull(siteBIndex.coerceIn(0, (cachedSites.size - 1).coerceAtLeast(0)))

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Offline Shield Switch
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                if (settings.offlineShieldEnabled) Icons.Default.CloudOff else Icons.Default.Public,
                                contentDescription = null,
                                tint = if (settings.offlineShieldEnabled) statusColors.offlineShield else MaterialTheme.colorScheme.tertiary
                            )
                            Column {
                                Text("Tam Çevrimdışı Kalkanı", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    if (settings.offlineShieldEnabled) "Aktif — Tüm özet ve karşılaştırmalar %100 internetsiz arşivden çalışır."
                                    else "Kapalı — İsterseniz yeni bir web adresini tek seferlik önbelleğe çekebilirsiniz.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = settings.offlineShieldEnabled,
                            onCheckedChange = onToggleOfflineShield
                        )
                    }
                }
            }

            // Two-Site Comparator Card
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                            Text("İki Siteyi Karşılaştır & Özetle", style = MaterialTheme.typography.titleMedium)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { showSiteAMenu = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(safeSiteA?.domain ?: "Site A Seç", maxLines = 1)
                                }
                                DropdownMenu(
                                    expanded = showSiteAMenu,
                                    onDismissRequest = { showSiteAMenu = false }
                                ) {
                                    cachedSites.forEachIndexed { idx, site ->
                                        DropdownMenuItem(
                                            text = { Text("${site.domain} — ${site.title}") },
                                            onClick = {
                                                siteAIndex = idx
                                                showSiteAMenu = false
                                            }
                                        )
                                    }
                                }
                            }

                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { showSiteBMenu = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(safeSiteB?.domain ?: "Site B Seç", maxLines = 1)
                                }
                                DropdownMenu(
                                    expanded = showSiteBMenu,
                                    onDismissRequest = { showSiteBMenu = false }
                                ) {
                                    cachedSites.forEachIndexed { idx, site ->
                                        DropdownMenuItem(
                                            text = { Text("${site.domain} — ${site.title}") },
                                            onClick = {
                                                siteBIndex = idx
                                                showSiteBMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilledTonalButton(
                                onClick = { if (safeSiteA != null) onSummarizeSite(safeSiteA) },
                                enabled = safeSiteA != null,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("summarize_site_button")
                            ) {
                                Icon(Icons.Default.Summarize, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Site A Özetle")
                            }
                            Button(
                                onClick = {
                                    if (safeSiteA != null && safeSiteB != null) {
                                        onCompareSites(safeSiteA, safeSiteB)
                                    }
                                },
                                enabled = safeSiteA != null && safeSiteB != null,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("compare_two_sites_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Karşılaştır")
                            }
                        }
                    }
                }
            }

            if (researchResult != null) {
                item {
                    ResearchSummaryCard(summary = researchResult)
                }
            }

            if (comparisonResult != null) {
                item {
                    SiteComparisonCard(comparison = comparisonResult)
                }
            }

            // Add Local HTML/TXT or Paste Site Content
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Çevrimdışı Arşive Site veya Belge Ekle", style = MaterialTheme.typography.titleSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customTitle,
                                onValueChange = { customTitle = it },
                                label = { Text("Başlık") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = customUrl,
                                onValueChange = { customUrl = it },
                                label = { Text("Site Adresi / Alan Adı") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = customContent,
                            onValueChange = { customContent = it },
                            label = { Text("Site Metnini veya HTML İçeriğini Yapıştırın") },
                            minLines = 3,
                            maxLines = 5,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { docPicker.launch(arrayOf("text/*", "text/html", "*/*")) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("HTML/TXT Seç")
                            }
                            Button(
                                onClick = {
                                    if (customContent.isNotBlank()) {
                                        onSavePastedSite(customTitle, customUrl, customContent)
                                        customTitle = ""
                                        customUrl = ""
                                        customContent = ""
                                    } else if (customUrl.isNotBlank()) {
                                        onFetchLiveSite(customUrl)
                                    }
                                },
                                enabled = !isBusy && (customContent.isNotBlank() || customUrl.isNotBlank()),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (customContent.isNotBlank()) "Arşivle & Özetle" else "Sayfayı İndir")
                            }
                        }
                    }
                }
            }

            item {
                Text("Çevrimdışı Site Arşivi (${cachedSites.size})", style = MaterialTheme.typography.titleSmall)
            }

            items(cachedSites, key = { it.id }) { site ->
                Card(
                    shape = MaterialTheme.shapes.small,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(site.title, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${site.domain} • ${site.category}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row {
                            IconButton(onClick = { onSummarizeSite(site) }) {
                                Icon(Icons.Default.Summarize, contentDescription = "Özetle", tint = MaterialTheme.colorScheme.primary)
                            }
                            if (!site.isPreseeded) {
                                IconButton(onClick = { onDeleteSite(site.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Sil")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FileArchivePane(
    workspaceItems: List<WorkspaceItem>,
    lastZipReport: ZipExtractionReport?,
    selectedZipName: String?,
    selectedTargetTreeName: String?,
    onPickZipFile: (Uri) -> Unit,
    onPickTargetFolder: (Uri) -> Unit,
    onExtractZip: (String, Boolean) -> Unit,
    onCreateWorkspaceFolder: (String) -> Unit,
    onCompressFolder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColors = LocalYankiStatusColors.current
    var subFolderFilter by remember { mutableStateOf("belgeler") }
    var extractToRoot by remember { mutableStateOf(true) }
    var newFolderName by remember { mutableStateOf("") }

    val zipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) onPickZipFile(uri) }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri -> if (uri != null) onPickTargetFolder(uri) }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.FolderZip, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("ZIP Arşivi Aç & Klasörü Ana Dizine Çıkar", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Cihazınızdaki gerçek bir .zip dosyasını ve hedef ana dizini seçin ya da hazır örnek 'proje_yedek.zip' üzerinde sesli/yazılı komutla test edin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*")) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(selectedZipName ?: "ZIP Seç (Varsayılan: proje_yedek.zip)", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { folderPicker.launch(null) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(selectedTargetTreeName ?: "Hedef Ana Dizin Seç", maxLines = 1)
                            }
                        }

                        OutlinedTextField(
                            value = subFolderFilter,
                            onValueChange = { subFolderFilter = it },
                            label = { Text("Çıkarılacak Alt Klasör (boş bırakılırsa tümü)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Seçili klasörün içini doğrudan ana dizine çıkar", style = MaterialTheme.typography.bodySmall)
                            Switch(checked = extractToRoot, onCheckedChange = { extractToRoot = it })
                        }

                        Button(
                            onClick = { onExtractZip(subFolderFilter, extractToRoot) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("extract_zip_button")
                        ) {
                            Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ZIP'i Aç ve Ana Dizine Çıkar")
                        }
                    }
                }
            }

            if (lastZipReport != null) {
                item {
                    Surface(
                        color = statusColors.offlineShield.copy(alpha = 0.14f),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                "Son Çıkarma: ${lastZipReport.archiveName} → ${lastZipReport.destinationLabel}",
                                style = MaterialTheme.typography.titleSmall,
                                color = statusColors.offlineShield
                            )
                            Text(
                                "${lastZipReport.extractedCount} dosya çıkarıldı:",
                                style = MaterialTheme.typography.bodySmall
                            )
                            lastZipReport.extractedPaths.take(6).forEach { p ->
                                Text("• $p", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newFolderName,
                        onValueChange = { newFolderName = it },
                        label = { Text("Klasör Adı") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    FilledTonalButton(
                        onClick = {
                            if (newFolderName.isNotBlank()) {
                                onCreateWorkspaceFolder(newFolderName)
                                newFolderName = ""
                            }
                        }
                    ) {
                        Text("Oluştur")
                    }
                    OutlinedButton(
                        onClick = { onCompressFolder(newFolderName.ifBlank { "belgeler" }) }
                    ) {
                        Text("ZIP Yap")
                    }
                }
            }

            item {
                Text("Yerel Çalışma Alanı (${workspaceItems.size} öğe)", style = MaterialTheme.typography.titleSmall)
            }

            items(workspaceItems, key = { it.relativePath }) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.small)
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            if (item.isDirectory) Icons.Default.FolderOpen else Icons.Default.InsertDriveFile,
                            contentDescription = null,
                            tint = if (item.isDirectory) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(item.relativePath, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!item.isDirectory) {
                        Text(
                            "${item.sizeBytes} B",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
