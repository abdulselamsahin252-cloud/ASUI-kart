package com.example.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LanguageModelEntity
import com.example.data.ModelStatus
import com.example.data.ResearchSummaryResult
import com.example.data.SiteComparisonResult
import com.example.data.UserSettings
import com.example.engine.WakeServiceRuntimeState
import com.example.ui.theme.LocalYankiStatusColors

@Composable
fun AssistantScreen(
    models: List<LanguageModelEntity>,
    settings: UserSettings,
    wakeState: WakeServiceRuntimeState,
    accessibilityConnected: Boolean,
    isListeningMic: Boolean,
    conversation: List<ConversationEntry>,
    onSubmitCommand: (String) -> Unit,
    onToggleVoiceInput: () -> Unit,
    onSpeakText: (String) -> Unit,
    onOpenAccessibilityGuide: () -> Unit,
    onNavigateToModels: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val statusColors = LocalYankiStatusColors.current

    val activeModels = remember(models) {
        models.filter { it.status == ModelStatus.ACTIVE.name }
    }

    LaunchedEffect(conversation.size) {
        if (conversation.isNotEmpty()) {
            listState.animateScrollToItem(conversation.lastIndex)
        }
    }

    val quickCommands = remember {
        listOf(
            "Wi-Fi aç",
            "Bluetooth aç",
            "Feneri aç",
            "Telefonu kapat",
            "Şifreyi aç",
            "Ayarlar'a girip Bluetooth'a tıkla",
            "proje_yedek.zip içindeki belgeler klasörünü ana dizine çıkar",
            "kotlinlang.org sitesini araştır özetle",
            "kotlinlang.org ile python.org sitelerini karşılaştır"
        )
    }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .widthIn(max = 760.dp)
                .fillMaxWidth()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Hero Acoustic Core Card
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Image(
                                painter = painterResource(id = R.drawable.img_ai_core_banner),
                                contentDescription = "Axiom Çekirdeği",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(148.dp),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(148.dp)
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.94f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.55f)
                                            )
                                        )
                                    )
                                    .padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            StatusBadgeChip(
                                                icon = Icons.Default.CloudOff,
                                                text = if (settings.offlineShieldEnabled) "İnternetsiz" else "Önbellek Modu",
                                                tint = statusColors.offlineShield
                                            )
                                            StatusBadgeChip(
                                                icon = Icons.Default.Hearing,
                                                text = if (wakeState.isBackgroundServiceRunning) "Arka Plan Açık" else "Uyandırma Pasif",
                                                tint = if (wakeState.isBackgroundServiceRunning) statusColors.activeGlow else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Image(
                                                painter = painterResource(id = R.drawable.axiom_launcher_icon),
                                                contentDescription = "Axiom Logosu",
                                                modifier = Modifier
                                                    .size(38.dp)
                                                    .clip(RoundedCornerShape(10.dp)),
                                                contentScale = ContentScale.Crop
                                            )
                                            Text(
                                                "Axiom Komuta Merkezi",
                                                style = MaterialTheme.typography.titleLarge
                                            )
                                        }
                                        Text(
                                            text = if (activeModels.isEmpty()) {
                                                "Aktif model yok — Modeller sekmesinden TR/EN kurun"
                                            } else {
                                                "Aktif: ${activeModels.joinToString(" • ") { it.languageCode.uppercase() }} | Erişilebilirlik: ${if (accessibilityConnected) "Bağlı" else "Kapalı"}"
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.clickable { onNavigateToModels() }
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))
                                    VoicePulseOrb(
                                        isListening = isListeningMic || wakeState.isListeningForCommand,
                                        onClick = onToggleVoiceInput
                                    )
                                }
                            }
                        }
                    }
                }

                // Quick Command Chips
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "Hızlı Çevrimdışı Komutlar",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            quickCommands.forEach { cmd ->
                                Surface(
                                    shape = RoundedCornerShape(50.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .border(
                                            1.dp,
                                            MaterialTheme.colorScheme.outlineVariant,
                                            RoundedCornerShape(50.dp)
                                        )
                                        .clip(RoundedCornerShape(50.dp))
                                        .clickable { onSubmitCommand(cmd) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Bolt,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(cmd, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }

                // Empty State Onboarding Tip
                if (conversation.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    "Tamamen Cihaz İçi Yapay Zeka Hazır",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    "Hesap açmadan veya internet kullanmadan sesli ya da yazılı komut verin:\n" +
                                        "• Sistem: \"Telefonu kapat\", \"Wi-Fi aç\", \"Bluetooth aç\"\n" +
                                        "• Uygulama Otomasyonu: \"Ayarlar'a girip Bluetooth'a tıkla\"\n" +
                                        "• Araştırma: \"kotlinlang.org sitesini özetle\" veya \"iki siteyi karşılaştır\"",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Executed Command Stream
                items(conversation, key = { it.id }) { entry ->
                    ConversationCard(
                        entry = entry,
                        onSpeakText = { onSpeakText(entry.summaryText) },
                        onOpenAccessibilityGuide = onOpenAccessibilityGuide
                    )
                }
            }
        }

        // Bottom Command Input Bar
        Surface(
            tonalElevation = 4.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Komut yazın (TR / EN)…") },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (inputText.isNotBlank()) {
                            onSubmitCommand(inputText)
                            inputText = ""
                        }
                    }),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("command_input_field")
                )

                FilledIconButton(
                    onClick = onToggleVoiceInput,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isListeningMic) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.secondaryContainer
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("mic_command_button")
                ) {
                    Icon(
                        imageVector = if (isListeningMic) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = if (isListeningMic) "Dinlemeyi Durdur" else "Sesli Komut Ver"
                    )
                }

                FilledIconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            onSubmitCommand(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("send_command_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Komutu Çalıştır")
                }
            }
        }
    }
}

@Composable
private fun VoicePulseOrb(
    isListening: Boolean,
    onClick: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.18f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 550 else 1600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        modifier = Modifier
            .size(66.dp)
            .scale(pulse)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(
                        if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primaryContainer
                    )
                )
            )
            .clickable { onClick() }
            .testTag("voice_pulse_orb"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
            contentDescription = "Sesli Komut Orb",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(30.dp)
        )
    }
}

@Composable
private fun StatusBadgeChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    tint: androidx.compose.ui.graphics.Color
) {
    Surface(
        color = tint.copy(alpha = 0.16f),
        shape = RoundedCornerShape(50.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(12.dp))
            Text(text, style = MaterialTheme.typography.labelSmall, color = tint)
        }
    }
}

@Composable
private fun ConversationCard(
    entry: ConversationEntry,
    onSpeakText: () -> Unit,
    onOpenAccessibilityGuide: () -> Unit
) {
    val statusColors = LocalYankiStatusColors.current

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // User Query Bubble
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp),
                modifier = Modifier.widthIn(max = 520.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (entry.triggeredByWakeWord) {
                        Icon(
                            Icons.Default.Hearing,
                            contentDescription = "Uyandırma ile tetiklendi",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        entry.userQuery,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        // AI Execution Response Card
        Card(
            shape = RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    if (entry.success) MaterialTheme.colorScheme.outlineVariant
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
                    RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp)
                )
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            if (entry.success) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = if (entry.success) statusColors.offlineShield else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "[${entry.intentTag}]",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onSpeakText,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Yanıtı Sesli Oku",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Text(entry.summaryText, style = MaterialTheme.typography.bodyMedium)

                if (entry.steps.isNotEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.small)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        entry.steps.forEach { step ->
                            Text(
                                step,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (entry.requiresAccessibilityGuide) {
                    FilledTonalButton(
                        onClick = onOpenAccessibilityGuide,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AccessibilityNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Erişilebilirlik Otomasyonunu Aç")
                    }
                }

                entry.researchSummary?.let { summary ->
                    ResearchSummaryCard(summary = summary)
                }

                entry.siteComparison?.let { cmp ->
                    SiteComparisonCard(comparison = cmp)
                }
            }
        }
    }
}

@Composable
fun ResearchSummaryCard(summary: ResearchSummaryResult) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = MaterialTheme.shapes.small,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Summarize, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Text(summary.siteTitle, style = MaterialTheme.typography.titleSmall)
            }
            Text(
                "${summary.siteUrl} • ${summary.wordCount} kelime • ~${summary.readingMinutes} dk okuma",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            summary.bulletPoints.forEach { bullet ->
                Text(bullet, style = MaterialTheme.typography.bodySmall)
            }
            if (summary.keywords.isNotEmpty()) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    summary.keywords.forEach { kw ->
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "#$kw",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SiteComparisonCard(comparison: SiteComparisonResult) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = MaterialTheme.shapes.small,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                    Text("Karşılaştırma Analizi", style = MaterialTheme.typography.titleSmall)
                }
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(50.dp)
                ) {
                    Text(
                        "%${comparison.similarityPercent} Benzerlik",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(MaterialTheme.shapes.extraSmall)
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(comparison.siteATitle, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Text("${comparison.wordCountA} kelime", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "Özgün: ${comparison.uniqueToA.joinToString(", ")}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(MaterialTheme.shapes.extraSmall)
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(comparison.siteBTitle, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Text("${comparison.wordCountB} kelime", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "Özgün: ${comparison.uniqueToB.joinToString(", ")}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            if (comparison.sharedTopics.isNotEmpty()) {
                Text(
                    "Ortak Kavramlar: ${comparison.sharedTopics.joinToString(", ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
