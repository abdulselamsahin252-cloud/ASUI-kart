package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SettingsVoice
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LanguageModelEntity
import com.example.data.ModelLanguage
import com.example.data.ModelStatus
import com.example.data.UserSettings
import com.example.engine.HardwareCapabilityReport
import com.example.engine.PowerfulLlmProfile
import com.example.engine.TtsVoiceProfileStatus
import com.example.ui.theme.LocalYankiStatusColors
import java.util.Locale

@Composable
fun ModelSetupOnboardingScreen(
    models: List<LanguageModelEntity>,
    isBusy: Boolean,
    onInstallAllAndStart: () -> Unit,
    onInstallSingle: (String) -> Unit,
    onSkip: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColors = LocalYankiStatusColors.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface
                    )
                )
            ),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_ai_core_banner),
                            contentDescription = "Axiom Çevrimdışı Çekirdek",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
                                            MaterialTheme.colorScheme.background.copy(alpha = 0.45f)
                                        )
                                    )
                                )
                                .padding(20.dp)
                        ) {
                            Column(
                                modifier = Modifier.align(Alignment.CenterStart),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = statusColors.offlineShield.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(50.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.CloudOff,
                                            contentDescription = null,
                                            tint = statusColors.offlineShield,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            "%100 İNTERNETSİZ • HESAPSIZ",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = statusColors.offlineShield
                                        )
                                    }
                                }
                                Text(
                                    "Dil Modellerini Kur",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    "Türkçe ve İngilizce yerel yapay zeka çekirdeklerini cihazınıza yükleyin.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            items(models, key = { it.id }) { model ->
                LanguageModelCard(
                    model = model,
                    onInstall = { onInstallSingle(model.id) },
                    onToggleActive = {},
                    onUninstall = {}
                )
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onInstallAllAndStart,
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("install_all_models_button"),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (isBusy) "Yerel Modeller Kuruluyor…"
                        else "Türkçe + İngilizce Modelleri Yükle & Başla",
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                TextButton(
                    onClick = onSkip,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                        .testTag("skip_model_setup_button")
                ) {
                    Text("Şimdilik Geç (Sonra Modeller Sekmesinden Yükle)")
                }
            }
        }
    }
}

@Composable
fun ModelsHubScreen(
    models: List<LanguageModelEntity>,
    diagnostics: DeviceDiagnostics,
    settings: UserSettings,
    hardwareReport: HardwareCapabilityReport,
    powerfulCatalog: List<PowerfulLlmProfile>,
    llmDownloadProgress: Pair<String, Int>?,
    ttsStatus: TtsVoiceProfileStatus,
    onInstallModel: (String) -> Unit,
    onToggleActive: (String) -> Unit,
    onUninstallModel: (String) -> Unit,
    onImportExternalModel: (Uri, String) -> Unit,
    onSelectSpeechLocale: (String) -> Unit,
    onOpenOfflineVoiceSettings: () -> Unit,
    onToggleDarkTheme: (Boolean) -> Unit,
    onDownloadPowerfulLlm: (PowerfulLlmProfile) -> Unit,
    onSelectPowerfulLlm: (String) -> Unit,
    onToggleTtsAutoSpeak: (Boolean) -> Unit,
    onTestMaleVoice: () -> Unit,
    onToggleOfflineShield: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColors = LocalYankiStatusColors.current
    var importLangCode by remember { mutableStateOf(ModelLanguage.TURKISH.code) }

    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportExternalModel(uri, importLangCode)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Türkçe & İngilizce Modeller",
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Text(
                            "Tamamen cihaz içi NLU, akustik ve özetleme çekirdekleri",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Surface(
                        color = statusColors.offlineShield.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = statusColors.offlineShield,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                "Yerel",
                                style = MaterialTheme.typography.labelMedium,
                                color = statusColors.offlineShield
                            )
                        }
                    }
                }
            }

            // Hardware & Offline Speech Telemetry Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TelemetryPill(
                                icon = Icons.Default.Memory,
                                label = "RAM",
                                value = "${diagnostics.availableRamMb} / ${diagnostics.totalRamMb} MB"
                            )
                            TelemetryPill(
                                icon = Icons.Default.Storage,
                                label = "Boş Alan",
                                value = String.format(Locale.US, "%.1f GB", diagnostics.freeStorageGb)
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Aktif Konuşma Tanıma Dili", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Offline TTS: TR=${if (diagnostics.ttsTurkishReady) "Hazır" else "Sistemde Yok"} • EN=${if (diagnostics.ttsEnglishReady) "Hazır" else "Sistemde Yok"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val isTr = settings.activeSpeechLocale.startsWith("tr")
                                FilledTonalButton(
                                    onClick = { onSelectSpeechLocale("tr-TR") },
                                    colors = if (isTr) ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer
                                    ) else ButtonDefaults.filledTonalButtonColors(),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("locale_tr_button")
                                ) {
                                    Text("TR", style = MaterialTheme.typography.labelMedium)
                                }
                                FilledTonalButton(
                                    onClick = { onSelectSpeechLocale("en-US") },
                                    colors = if (!isTr) ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer
                                    ) else ButtonDefaults.filledTonalButtonColors(),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("locale_en_button")
                                ) {
                                    Text("EN", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = onOpenOfflineVoiceSettings,
                                modifier = Modifier.testTag("open_offline_tts_settings_button")
                            ) {
                                Icon(Icons.Default.SettingsVoice, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Android Çevrimdışı Ses Paketi")
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("Koyu Tema", style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = settings.darkTheme,
                                    onCheckedChange = onToggleDarkTheme
                                )
                            }
                        }
                    }
                }
            }

            // Natural Male Voice Engine Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    Icons.Default.RecordVoiceOver,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Column {
                                    Text(
                                        "Doğal Erkek Ses Motoru (Akıcı Okuma)",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        "${ttsStatus.selectedVoiceName} • ${if (ttsStatus.isOfflineVoice) "Çevrimdışı Hazır" else "Sistem Sesi"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = settings.ttsAutoSpeak,
                                onCheckedChange = onToggleTtsAutoSpeak,
                                modifier = Modifier.testTag("tts_auto_speak_switch")
                            )
                        }
                        Text(
                            "Cümleleri kelime kelime bölmek yerine ön-kuyruklu (QUEUE_ADD) doğal erkek bariton tonlamasıyla (0.85x–0.94x perde, 1.06x akıcı hız) takılmadan okur.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        FilledTonalButton(
                            onClick = onTestMaleVoice,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("test_male_voice_button")
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Doğal Erkek Sesiyle Örnek Oku")
                        }
                    }
                }
            }

            // Powerful Local LLMs Section Header + Honest Hardware Latency Benchmark
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f), MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Güçlü Yerel LLM Modelleri (Açık Ağırlıklar)", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${hardwareReport.cpuCores} Çekirdek • ${hardwareReport.primaryAbi} • Öneri: ${hardwareReport.recommendedMaxParams}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = statusColors.activeGlow, modifier = Modifier.size(18.dp))
                            Text(
                                "Cihaz İçi Hız Gerçeği:\n" +
                                    "• Komut / Wi-Fi / Bluetooth / ZIP / Uygulama: Anlık (< 50 ms)\n" +
                                    "• 1B Q4 Model (Gemma 3 1B): ${hardwareReport.estimated1BSpeed}\n" +
                                    "• 3B Q4 Model (Qwen 2.5 / Llama 3.2): ${hardwareReport.estimated3BSpeed}\n" +
                                    "• 7B+ Büyük Modeller: ${hardwareReport.estimated7BSpeed}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (settings.offlineShieldEnabled) "İndirmek için Çevrimdışı Kalkanını geçici kapatın (Hesapsız)"
                                else "Açık erişimli GGUF indirme açık (API anahtarsız)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            Switch(
                                checked = !settings.offlineShieldEnabled,
                                onCheckedChange = { allowNet -> onToggleOfflineShield(!allowNet) },
                                modifier = Modifier.testTag("toggle_gguf_download_net_switch")
                            )
                        }
                    }
                }
            }

            items(powerfulCatalog, key = { it.id }) { profile ->
                val installedEntity = models.find { it.id == profile.id }
                val isDownloading = llmDownloadProgress?.first == profile.id
                val downloadPct = if (isDownloading) llmDownloadProgress?.second ?: 0 else 0
                val isSelectedActive = settings.activePowerfulLlmId == profile.id
                val ramEnough = hardwareReport.totalRamMb >= profile.minRamMb

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelectedActive) MaterialTheme.colorScheme.surfaceContainerHigh
                        else MaterialTheme.colorScheme.surface
                    ),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (isSelectedActive) 1.5.dp else 1.dp,
                            color = if (isSelectedActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            shape = MaterialTheme.shapes.medium
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(profile.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${profile.family} • ${profile.paramsLabel} ${profile.quantLabel} • ${profile.sizeMb} MB",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Surface(
                                color = (if (ramEnough) statusColors.offlineShield else MaterialTheme.colorScheme.tertiary).copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50.dp)
                            ) {
                                Text(
                                    if (ramEnough) "RAM Uyumlu" else "Yüksek RAM İster",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (ramEnough) statusColors.offlineShield else MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text(
                            profile.strengthSummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (isDownloading) {
                            LinearProgressIndicator(
                                progress = { (downloadPct / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            )
                            Text(
                                "Açık erişimli GGUF indiriliyor… %$downloadPct",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                profile.languages,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (installedEntity != null) {
                                FilledTonalButton(
                                    onClick = { onSelectPowerfulLlm(profile.id) },
                                    colors = if (isSelectedActive) ButtonDefaults.filledTonalButtonColors(
                                        containerColor = statusColors.offlineShield.copy(alpha = 0.2f),
                                        contentColor = statusColors.offlineShield
                                    ) else ButtonDefaults.filledTonalButtonColors()
                                ) {
                                    if (isSelectedActive) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Text(if (isSelectedActive) "Seçili Çekirdek" else "Çekirdeği Seç")
                                }
                            } else {
                                Button(
                                    onClick = { onDownloadPowerfulLlm(profile) },
                                    enabled = llmDownloadProgress == null,
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("download_llm_${profile.id}")
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("İndir (${profile.sizeMb} MB)")
                                }
                            }
                        }
                    }
                }
            }

            // Built-in & Imported Models List
            items(models, key = { it.id }) { model ->
                LanguageModelCard(
                    model = model,
                    onInstall = { onInstallModel(model.id) },
                    onToggleActive = { onToggleActive(model.id) },
                    onUninstall = { onUninstallModel(model.id) }
                )
            }

            // External GGUF / TFLite / BIN Local Model Importer
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "Harici Yerel Model Yükle (.gguf / .tflite / .bin)",
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Text(
                            "İnternetsiz kullanım için telefonunuzda bulunan GGUF, TFLite veya Vosk dil modeli dosyasını doğrudan cihaz depolamasından içeri aktarın.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf("tr-TR" to "Türkçe", "en-US" to "English", "tr-en" to "TR+EN").forEach { (code, label) ->
                                FilledTonalButton(
                                    onClick = { importLangCode = code },
                                    colors = if (importLangCode == code) {
                                        ButtonDefaults.filledTonalButtonColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer
                                        )
                                    } else ButtonDefaults.filledTonalButtonColors(),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(label, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                        Button(
                            onClick = { modelPicker.launch(arrayOf("*/*")) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("import_external_model_button")
                        ) {
                            Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cihazdan Model Dosyası Seç")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        }
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun LanguageModelCard(
    model: LanguageModelEntity,
    onInstall: () -> Unit,
    onToggleActive: () -> Unit,
    onUninstall: () -> Unit
) {
    val statusColors = LocalYankiStatusColors.current
    val status = runCatching { ModelStatus.valueOf(model.status) }.getOrDefault(ModelStatus.NOT_INSTALLED)
    val langBadge = when (model.languageCode) {
        "tr-TR" -> "TÜRKÇE"
        "en-US" -> "ENGLISH"
        else -> "TR + EN"
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = if (status == ModelStatus.ACTIVE) {
                MaterialTheme.colorScheme.surfaceContainerHigh
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (status == ModelStatus.ACTIVE) 1.5.dp else 1.dp,
                color = if (status == ModelStatus.ACTIVE) MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
                else MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.medium
            )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            langBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        model.name,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }
                Text(
                    "${model.sizeMb} MB",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                model.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            AnimatedVisibility(visible = status == ModelStatus.INSTALLING) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    LinearProgressIndicator(
                        progress = { (model.progressPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                    Text(
                        "Yerel paket derleniyor… %${model.progressPercent}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Sürüm: ${model.version} • SHA: ${model.sha256}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (model.latencyMs > 0) {
                        Text(
                            "Ön-yükleme: ${model.latencyMs} ms",
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColors.offlineShield
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (status) {
                        ModelStatus.NOT_INSTALLED -> {
                            Button(
                                onClick = onInstall,
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("install_model_${model.id}")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Yükle")
                            }
                        }
                        ModelStatus.INSTALLING -> {
                            Text("Kuruluyor…", style = MaterialTheme.typography.labelMedium)
                        }
                        ModelStatus.INSTALLED -> {
                            FilledTonalButton(onClick = onToggleActive) {
                                Text("Aktif Et")
                            }
                            IconButton(onClick = onUninstall) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Modeli Kaldır")
                            }
                        }
                        ModelStatus.ACTIVE -> {
                            FilledTonalButton(
                                onClick = onToggleActive,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = statusColors.offlineShield.copy(alpha = 0.2f),
                                    contentColor = statusColors.offlineShield
                                )
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Aktif")
                            }
                            IconButton(onClick = onUninstall) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Modeli Kaldır")
                            }
                        }
                    }
                }
            }
        }
    }
}
