package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val YankiDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = OnElectricCyan,
    primaryContainer = ElectricCyanContainer,
    onPrimaryContainer = OnElectricCyanContainer,
    secondary = EmeraldTeal,
    onSecondary = OnEmeraldTeal,
    secondaryContainer = EmeraldTealContainer,
    onSecondaryContainer = OnEmeraldTealContainer,
    tertiary = WarmAmber,
    onTertiary = OnWarmAmber,
    tertiaryContainer = WarmAmberContainer,
    onTertiaryContainer = OnWarmAmberContainer,
    error = CoralError,
    onError = OnCoralError,
    errorContainer = CoralErrorContainer,
    onErrorContainer = OnCoralErrorContainer,
    background = ObsidianBg,
    onBackground = TextPrimaryDark,
    surface = ObsidianSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerLowest = ObsidianBg,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceElevated,
    surfaceContainerHigh = ObsidianSurfaceHighest,
    outline = ObsidianOutline,
    outlineVariant = ObsidianOutlineSubtle
)

private val YankiLightColorScheme = lightColorScheme(
    primary = DeepCyanLight,
    onPrimary = Color.White,
    primaryContainer = DeepCyanContainerLight,
    onPrimaryContainer = Color(0xFF001F26),
    secondary = DeepTealLight,
    onSecondary = Color.White,
    secondaryContainer = DeepTealContainerLight,
    onSecondaryContainer = Color(0xFF00201C),
    tertiary = DeepAmberLight,
    onTertiary = Color.White,
    tertiaryContainer = DeepAmberContainerLight,
    onTertiaryContainer = Color(0xFF2A1400),
    error = LightError,
    onError = Color.White,
    errorContainer = LightErrorContainer,
    onErrorContainer = Color(0xFF410002),
    background = LightBg,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = LightBg,
    surfaceContainer = LightSurfaceElevated,
    surfaceContainerHigh = LightSurfaceHighest,
    outline = LightOutline,
    outlineVariant = Color(0xFFD6E0EE)
)

val YankiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Immutable
data class YankiStatusColors(
    val activeGlow: Color,
    val offlineShield: Color,
    val warningAccent: Color,
    val cardBorder: Color
)

val LocalYankiStatusColors = staticCompositionLocalOf {
    YankiStatusColors(
        activeGlow = ElectricCyan,
        offlineShield = EmeraldTeal,
        warningAccent = WarmAmber,
        cardBorder = ObsidianOutline
    )
}

@Composable
fun YankiTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) YankiDarkColorScheme else YankiLightColorScheme
    val statusColors = if (darkTheme) {
        YankiStatusColors(
            activeGlow = ElectricCyan,
            offlineShield = EmeraldTeal,
            warningAccent = WarmAmber,
            cardBorder = ObsidianOutline
        )
    } else {
        YankiStatusColors(
            activeGlow = DeepCyanLight,
            offlineShield = DeepTealLight,
            warningAccent = DeepAmberLight,
            cardBorder = LightOutline
        )
    }

    CompositionLocalProvider(LocalYankiStatusColors provides statusColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = YankiTypography,
            shapes = YankiShapes,
            content = content
        )
    }
}
