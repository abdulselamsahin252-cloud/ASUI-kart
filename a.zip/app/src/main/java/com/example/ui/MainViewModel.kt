package com.example.ui

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppPreferences
import com.example.data.AutomationMacroEntity
import com.example.data.AutomationStep
import com.example.data.CachedSiteEntity
import com.example.data.CommandLogEntity
import com.example.data.InstalledAppInfo
import com.example.data.LanguageModelEntity
import com.example.data.ModelStatus
import com.example.data.ResearchSummaryResult
import com.example.data.SiteComparisonResult
import com.example.data.StepSerializer
import com.example.data.UserSettings
import com.example.data.WakeWordProfileEntity
import com.example.data.YankiDatabase
import com.example.data.YankiRepository
import com.example.engine.AcousticWakeWordEngine
import com.example.engine.AssistantRuntimeHub
import com.example.engine.DeviceControlExecutor
import com.example.engine.HardwareCapabilityReport
import com.example.engine.LocalLlmEngine
import com.example.engine.NaturalVoiceSpeaker
import com.example.engine.OfflineFileArchiveEngine
import com.example.engine.OfflineNluEngine
import com.example.engine.OfflineResearchEngine
import com.example.engine.PowerfulLlmProfile
import com.example.engine.SecurityVaultManager
import com.example.engine.TtsVoiceProfileStatus
import com.example.engine.WakeServiceRuntimeState
import com.example.engine.WorkspaceItem
import com.example.engine.ZipExtractionReport
import com.example.service.AssistantAccessibilityService
import com.example.service.WakeWordForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class ConversationEntry(
    val id: String,
    val userQuery: String,
    val intentTag: String,
    val summaryText: String,
    val steps: List<String>,
    val success: Boolean,
    val triggeredByWakeWord: Boolean = false,
    val requiresAccessibilityGuide: Boolean = false,
    val researchSummary: ResearchSummaryResult? = null,
    val siteComparison: SiteComparisonResult? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class DeviceDiagnostics(
    val freeStorageGb: Float = 0f,
    val availableRamMb: Long = 0L,
    val totalRamMb: Long = 0L,
    val speechRecognizerAvailable: Boolean = false,
    val ttsTurkishReady: Boolean = false,
    val ttsEnglishReady: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = YankiDatabase.getInstance(application)
    private val preferences = AppPreferences(application)
    private val repository = YankiRepository(application, db.yankiDao(), preferences)
    private val executor = DeviceControlExecutor(application)
    private val naturalSpeaker = NaturalVoiceSpeaker(application)

    private var activeSpeechRecognizer: SpeechRecognizer? = null

    val ttsStatus: StateFlow<TtsVoiceProfileStatus> = naturalSpeaker.status
    val powerfulLlmCatalog: List<PowerfulLlmProfile> = LocalLlmEngine.powerfulCatalog

    val languageModels: StateFlow<List<LanguageModelEntity>> = repository.languageModels
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val wakeWords: StateFlow<List<WakeWordProfileEntity>> = repository.wakeWords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val macros: StateFlow<List<AutomationMacroEntity>> = repository.macros
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cachedSites: StateFlow<List<CachedSiteEntity>> = repository.cachedSites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val commandLogs: StateFlow<List<CommandLogEntity>> = repository.commandLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<UserSettings> = preferences.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val wakeServiceState: StateFlow<WakeServiceRuntimeState> = AssistantRuntimeHub.wakeState
    val accessibilityConnected: StateFlow<Boolean> = AssistantRuntimeHub.accessibilityConnected

    private val _conversation = MutableStateFlow<List<ConversationEntry>>(emptyList())
    val conversation: StateFlow<List<ConversationEntry>> = _conversation.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _diagnostics = MutableStateFlow(DeviceDiagnostics())
    val diagnostics: StateFlow<DeviceDiagnostics> = _diagnostics.asStateFlow()

    private val _isListeningMic = MutableStateFlow(false)
    val isListeningMic: StateFlow<Boolean> = _isListeningMic.asStateFlow()

    private val _isRecordingWakeWord = MutableStateFlow(false)
    val isRecordingWakeWord: StateFlow<Boolean> = _isRecordingWakeWord.asStateFlow()

    private val _recordingWaveform = MutableStateFlow<List<Float>>(List(16) { 0.08f })
    val recordingWaveform: StateFlow<List<Float>> = _recordingWaveform.asStateFlow()

    private val _lastRecordedPreview = MutableStateFlow<List<Float>>(emptyList())
    val lastRecordedPreview: StateFlow<List<Float>> = _lastRecordedPreview.asStateFlow()

    private val _automationLogs = MutableStateFlow<List<String>>(emptyList())
    val automationLogs: StateFlow<List<String>> = _automationLogs.asStateFlow()

    private val _researchResult = MutableStateFlow<ResearchSummaryResult?>(null)
    val researchResult: StateFlow<ResearchSummaryResult?> = _researchResult.asStateFlow()

    private val _comparisonResult = MutableStateFlow<SiteComparisonResult?>(null)
    val comparisonResult: StateFlow<SiteComparisonResult?> = _comparisonResult.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _showAccessibilityDisclosure = MutableStateFlow(false)
    val showAccessibilityDisclosure: StateFlow<Boolean> = _showAccessibilityDisclosure.asStateFlow()

    private val _hasSavedPin = MutableStateFlow(false)
    val hasSavedPin: StateFlow<Boolean> = _hasSavedPin.asStateFlow()

    private val _isDeviceSecure = MutableStateFlow(false)
    val isDeviceSecure: StateFlow<Boolean> = _isDeviceSecure.asStateFlow()

    private val _revealedPin = MutableStateFlow<String?>(null)
    val revealedPin: StateFlow<String?> = _revealedPin.asStateFlow()

    private val _workspaceItems = MutableStateFlow<List<WorkspaceItem>>(emptyList())
    val workspaceItems: StateFlow<List<WorkspaceItem>> = _workspaceItems.asStateFlow()

    private val _lastZipReport = MutableStateFlow<ZipExtractionReport?>(null)
    val lastZipReport: StateFlow<ZipExtractionReport?> = _lastZipReport.asStateFlow()

    private val _selectedZipUri = MutableStateFlow<Uri?>(null)
    val selectedZipUri: StateFlow<Uri?> = _selectedZipUri.asStateFlow()

    private val _selectedZipName = MutableStateFlow<String?>(null)
    val selectedZipName: StateFlow<String?> = _selectedZipName.asStateFlow()

    private val _selectedTargetTreeUri = MutableStateFlow<Uri?>(null)
    val selectedTargetTreeUri: StateFlow<Uri?> = _selectedTargetTreeUri.asStateFlow()

    private val _selectedTargetTreeName = MutableStateFlow<String?>(null)
    val selectedTargetTreeName: StateFlow<String?> = _selectedTargetTreeName.asStateFlow()

    private val _hardwareReport = MutableStateFlow(LocalLlmEngine.profileHardware(application))
    val hardwareReport: StateFlow<HardwareCapabilityReport> = _hardwareReport.asStateFlow()

    private val _llmDownloadProgress = MutableStateFlow<Pair<String, Int>?>(null)
    val llmDownloadProgress: StateFlow<Pair<String, Int>?> = _llmDownloadProgress.asStateFlow()

    private val _previewRgbEdge = MutableStateFlow(false)
    val previewRgbEdge: StateFlow<Boolean> = _previewRgbEdge.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            refreshDiagnosticsAndApps()
            refreshVaultAndWorkspace()
        }
        viewModelScope.launch {
            naturalSpeaker.status.collect { st ->
                if (st.isReady) {
                    _diagnostics.value = _diagnostics.value.copy(
                        ttsTurkishReady = st.availableTurkishVoices > 0,
                        ttsEnglishReady = st.availableEnglishVoices > 0
                    )
                }
            }
        }
        viewModelScope.launch {
            AssistantRuntimeHub.automationLog.collect { log ->
                _automationLogs.value = (listOf(log) + _automationLogs.value).take(30)
            }
        }
        viewModelScope.launch {
            AssistantRuntimeHub.backgroundCommandResult.collect { spoken ->
                _toastMessage.value = "Arka plan komutu çalıştırıldı: \"$spoken\""
                refreshVaultAndWorkspace()
            }
        }
    }

    fun refreshDiagnosticsAndApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val apps = executor.listLaunchableApps()
            _installedApps.value = apps

            val hw = LocalLlmEngine.profileHardware(ctx)
            _hardwareReport.value = hw

            val st = naturalSpeaker.status.value
            _diagnostics.value = DeviceDiagnostics(
                freeStorageGb = hw.freeStorageGb,
                availableRamMb = hw.availableRamMb,
                totalRamMb = hw.totalRamMb,
                speechRecognizerAvailable = SpeechRecognizer.isRecognitionAvailable(ctx),
                ttsTurkishReady = st.availableTurkishVoices > 0,
                ttsEnglishReady = st.availableEnglishVoices > 0
            )
            AssistantRuntimeHub.setAccessibilityConnected(AssistantAccessibilityService.instance != null)
        }
    }

    fun installAllCoreModelsAndEnter() {
        viewModelScope.launch {
            _isBusy.value = true
            repository.installBuiltinModel("yanki_tr_core")
            repository.installBuiltinModel("yanki_en_core")
            repository.installBuiltinModel("yanki_bi_research")
            preferences.setModelOnboardingDismissed(true)
            _isBusy.value = false
            _toastMessage.value = "Türkçe ve İngilizce yerel modeller kuruldu."
        }
    }

    fun dismissOnboardingOnly() {
        viewModelScope.launch {
            preferences.setModelOnboardingDismissed(true)
        }
    }

    fun installSingleModel(modelId: String) {
        viewModelScope.launch {
            repository.installBuiltinModel(modelId)
            _toastMessage.value = "Model yerel depolamaya kuruldu."
        }
    }

    fun toggleModelActive(modelId: String) {
        viewModelScope.launch {
            repository.toggleModelActive(modelId)
        }
    }

    fun uninstallModel(modelId: String) {
        viewModelScope.launch {
            repository.uninstallModel(modelId)
            _toastMessage.value = "Model kaldırıldı."
        }
    }

    fun importExternalModel(uri: Uri, languageCode: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = repository.importExternalModelUri(uri, languageCode)
            _isBusy.value = false
            res.onSuccess {
                _toastMessage.value = "Yerel model içe aktarıldı: ${it.name}"
            }.onFailure {
                _toastMessage.value = "Model içe aktarılamadı: ${it.localizedMessage}"
            }
        }
    }

    fun submitCommand(rawQuery: String, triggeredByWakeWord: Boolean = false) {
        val query = rawQuery.trim()
        if (query.isBlank()) return

        viewModelScope.launch {
            val intent = OfflineNluEngine.parse(query)
            val macrosList = macros.value
            val sitesList = cachedSites.value
            val activeModels = languageModels.value
                .filter { it.status == ModelStatus.ACTIVE.name }
                .map { it.name }

            val outcome = executor.executeIntent(intent, macrosList, sitesList, activeModels)

            val entry = ConversationEntry(
                id = "${System.currentTimeMillis()}_${_conversation.value.size}",
                userQuery = query,
                intentTag = outcome.intentTag,
                summaryText = outcome.summaryText,
                steps = outcome.steps,
                success = outcome.success,
                triggeredByWakeWord = triggeredByWakeWord,
                requiresAccessibilityGuide = outcome.requiresAccessibilityGuide,
                researchSummary = outcome.researchSummary,
                siteComparison = outcome.siteComparison
            )
            _conversation.value = _conversation.value + entry

            if (outcome.researchSummary != null) _researchResult.value = outcome.researchSummary
            if (outcome.siteComparison != null) _comparisonResult.value = outcome.siteComparison

            repository.logCommand(
                CommandLogEntity(
                    userQuery = query,
                    intentTag = outcome.intentTag,
                    responseSummary = outcome.summaryText,
                    stepsJson = outcome.steps.joinToString("\n"),
                    executionSuccess = outcome.success,
                    triggeredByWakeWord = triggeredByWakeWord
                )
            )

            if (outcome.intentTag.startsWith("ZIP_") || outcome.intentTag.startsWith("FILE_")) {
                refreshVaultAndWorkspace()
            }

            if (settings.value.ttsAutoSpeak) {
                speakOut(outcome.summaryText)
            }
        }
    }

    fun startOfflineVoiceInput() {
        val ctx = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _toastMessage.value = "Sesli komut için önce mikrofon izni verin."
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            _toastMessage.value = "Cihazda yerel SpeechRecognizer servisi bulunamadı; metin kutusunu kullanabilirsiniz."
            return
        }

        // Temporarily pause background service mic hold if active
        val wasBgRunning = wakeServiceState.value.isBackgroundServiceRunning
        if (wasBgRunning) {
            WakeWordForegroundService.stop(ctx)
        }

        activeSpeechRecognizer?.destroy()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(ctx)
        activeSpeechRecognizer = recognizer
        val locale = settings.value.activeSpeechLocale

        val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        _isListeningMic.value = true

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                val norm = ((rmsdB + 2f) / 12f).coerceIn(0.08f, 1f)
                _recordingWaveform.value = List(16) { idx ->
                    (norm * (0.6f + 0.4f * kotlin.math.sin(idx + rmsdB).let { kotlin.math.abs(it) })).coerceIn(0.08f, 1f)
                }
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                _isListeningMic.value = false
            }

            override fun onError(error: Int) {
                _isListeningMic.value = false
                recognizer.destroy()
                _toastMessage.value = "Ses tanıma tamamlanamadı (Kod: $error). Tekrar deneyin veya yazarak komut verin."
                if (wasBgRunning) WakeWordForegroundService.start(ctx)
            }

            override fun onResults(results: Bundle?) {
                _isListeningMic.value = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                recognizer.destroy()
                if (text.isNotBlank()) {
                    submitCommand(text)
                }
                if (wasBgRunning) WakeWordForegroundService.start(ctx)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        recognizer.startListening(recIntent)
    }

    fun stopOfflineVoiceInput() {
        _isListeningMic.value = false
        activeSpeechRecognizer?.stopListening()
    }

    fun recordWakeWord(phrase: String, languageCode: String) {
        val ctx = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _toastMessage.value = "Kayıt için mikrofon izni gerekli."
            return
        }
        val cleanPhrase = phrase.trim().ifBlank { "Hey Axiom" }
        val wasBgRunning = wakeServiceState.value.isBackgroundServiceRunning
        if (wasBgRunning) WakeWordForegroundService.stop(ctx)

        viewModelScope.launch {
            _isRecordingWakeWord.value = true
            val result = AcousticWakeWordEngine.recordWakeWordSample(ctx, durationMs = 2200L) { rms, bins ->
                _recordingWaveform.value = bins.map { (it + rms * 0.4f).coerceIn(0.06f, 1f) }
            }
            _isRecordingWakeWord.value = false

            result.onSuccess { sample ->
                _lastRecordedPreview.value = sample.waveformPreview
                repository.saveWakeWordProfile(
                    WakeWordProfileEntity(
                        phrase = cleanPhrase,
                        languageCode = languageCode,
                        audioFilePath = sample.audioFilePath,
                        durationMs = sample.durationMs,
                        signatureCsv = sample.signatureCsv,
                        peakRms = sample.peakRms,
                        isActive = true
                    )
                )
                AssistantRuntimeHub.updateWakeState {
                    it.copy(activeWakePhrase = cleanPhrase)
                }
                _toastMessage.value = "\"$cleanPhrase\" ses kaydı akustik imzasıyla kaydedildi."
                if (wasBgRunning || settings.value.wakeWordServiceEnabled) {
                    WakeWordForegroundService.start(ctx)
                }
            }.onFailure { err ->
                _toastMessage.value = "Kayıt hatası: ${err.localizedMessage}"
                if (wasBgRunning) WakeWordForegroundService.start(ctx)
            }
        }
    }

    fun playWakeWord(profile: WakeWordProfileEntity) {
        viewModelScope.launch {
            val res = AcousticWakeWordEngine.playRecordedWakeWord(profile.audioFilePath)
            res.onFailure {
                _toastMessage.value = "Ses dosyası oynatılamadı: ${it.localizedMessage}"
            }
        }
    }

    fun activateWakeWord(id: Int, phrase: String) {
        viewModelScope.launch {
            repository.activateWakeWord(id)
            AssistantRuntimeHub.updateWakeState { it.copy(activeWakePhrase = phrase) }
        }
    }

    fun deleteWakeWord(profile: WakeWordProfileEntity) {
        viewModelScope.launch {
            repository.deleteWakeWord(profile)
        }
    }

    fun toggleBackgroundWakeService(enable: Boolean) {
        val ctx = getApplication<Application>()
        if (enable && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _toastMessage.value = "Arka plan dinleyici için mikrofon izni verin."
            return
        }
        viewModelScope.launch {
            preferences.setWakeWordServiceEnabled(enable)
            if (enable) {
                WakeWordForegroundService.start(ctx)
                _toastMessage.value = "Arka plan uyandırma servisi başlatıldı."
            } else {
                WakeWordForegroundService.stop(ctx)
                _toastMessage.value = "Arka plan uyandırma servisi durduruldu."
            }
        }
    }

    fun setAutoStartOnBoot(enable: Boolean) {
        viewModelScope.launch { preferences.setAutoStartOnBoot(enable) }
    }

    fun setWakeSensitivity(value: Float) {
        viewModelScope.launch { preferences.setWakeSensitivity(value) }
    }

    fun setIgnoreWakeDuringMedia(ignore: Boolean) {
        viewModelScope.launch { preferences.setIgnoreWakeDuringMedia(ignore) }
    }

    fun setStrictSpeakerVerification(strict: Boolean) {
        viewModelScope.launch { preferences.setStrictSpeakerVerification(strict) }
    }

    fun setSpeakerThreshold(value: Float) {
        viewModelScope.launch { preferences.setSpeakerThreshold(value) }
    }

    fun setSpeechLocale(locale: String) {
        viewModelScope.launch {
            preferences.setSpeechLocale(locale)
            naturalSpeaker.configureMaleVoice(if (locale.startsWith("en")) Locale.US else Locale("tr", "TR"))
        }
    }

    fun setOfflineShield(enabled: Boolean) {
        viewModelScope.launch { preferences.setOfflineShield(enabled) }
    }

    fun setTtsAutoSpeak(enabled: Boolean) {
        viewModelScope.launch { preferences.setTtsAutoSpeak(enabled) }
    }

    fun setDarkTheme(dark: Boolean) {
        viewModelScope.launch { preferences.setDarkTheme(dark) }
    }

    fun selectPowerfulLlm(id: String) {
        viewModelScope.launch {
            preferences.setActivePowerfulLlmId(id)
            _toastMessage.value = "Aktif güçlü LLM çekirdeği seçildi."
        }
    }

    fun downloadPowerfulLlm(profile: PowerfulLlmProfile) {
        if (settings.value.offlineShieldEnabled) {
            _toastMessage.value = "Tam Çevrimdışı Kalkanı açık! Modeli indirmek için kalkanı geçici olarak kapatın veya cihazdan .gguf dosyası seçin."
            return
        }
        viewModelScope.launch {
            _llmDownloadProgress.value = profile.id to 1
            val res = repository.downloadPublicGgufModel(profile) { pct ->
                _llmDownloadProgress.value = profile.id to pct
            }
            _llmDownloadProgress.value = null
            res.onSuccess {
                preferences.setActivePowerfulLlmId(profile.id)
                _toastMessage.value = "${profile.name} indirildi ve GGUF doğrulaması tamamlandı!"
            }.onFailure { err ->
                _toastMessage.value = "Model indirilemedi: ${err.localizedMessage}"
            }
        }
    }

    fun triggerRgbEdgePreview() {
        viewModelScope.launch {
            _previewRgbEdge.value = true
            AssistantAccessibilityService.instance?.showRgbEdgeBorder(true)
            delay(3200L)
            _previewRgbEdge.value = false
            AssistantAccessibilityService.instance?.showRgbEdgeBorder(false)
        }
    }

    fun testMaleVoiceReadout() {
        val sample = if (settings.value.activeSpeechLocale.startsWith("en")) {
            "Hello, I am Axiom. I run directly on your device with a natural, steady male voice and zero cloud lag."
        } else {
            "Merhaba, ben Axiom. Tamamen cihazında çalışıyorum; takılmadan, akıcı ve doğal bir erkek sesiyle tüm komutlarını anında yerine getirmeye hazırım."
        }
        naturalSpeaker.speakFluidly(sample, settings.value.activeSpeechLocale)
    }

    fun requestAccessibilityDisclosure(show: Boolean) {
        _showAccessibilityDisclosure.value = show
    }

    fun openAccessibilitySettings() {
        _showAccessibilityDisclosure.value = false
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        getApplication<Application>().startActivity(intent)
    }

    fun openSystemOfflineVoiceSettings() {
        val ctx = getApplication<Application>()
        val intent = Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(intent) }.onFailure {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun saveAndOptionallyRunMacro(
        title: String,
        triggerPhrase: String,
        app: InstalledAppInfo,
        steps: List<AutomationStep>,
        runImmediately: Boolean
    ) {
        viewModelScope.launch {
            val macro = AutomationMacroEntity(
                title = title.ifBlank { "${app.label} Otomasyonu" },
                triggerPhrase = triggerPhrase.ifBlank { "${app.label} aç" },
                targetPackageName = app.packageName,
                targetAppLabel = app.label,
                stepsSerialized = StepSerializer.encode(steps)
            )
            repository.saveMacro(macro)
            _toastMessage.value = "Otomasyon kaydedildi: ${macro.title}"
            if (runImmediately) {
                runMacro(macro)
            }
        }
    }

    fun runMacro(macro: AutomationMacroEntity) {
        val steps = StepSerializer.decode(macro.stepsSerialized)
        val a11y = AssistantAccessibilityService.instance
        if (a11y != null) {
            a11y.executeSteps(steps, launchPackageFirst = macro.targetPackageName)
            _toastMessage.value = "${macro.title} çalıştırılıyor…"
        } else {
            val launch = getApplication<Application>().packageManager
                .getLaunchIntentForPackage(macro.targetPackageName)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (launch != null) {
                getApplication<Application>().startActivity(launch)
            }
            _showAccessibilityDisclosure.value = true
        }
    }

    fun deleteMacro(id: Int) {
        viewModelScope.launch { repository.deleteMacro(id) }
    }

    fun summarizeOfflineSite(site: CachedSiteEntity) {
        _researchResult.value = OfflineResearchEngine.summarizeSite(site)
    }

    fun compareOfflineSites(siteA: CachedSiteEntity, siteB: CachedSiteEntity) {
        _comparisonResult.value = OfflineResearchEngine.compareSites(siteA, siteB)
    }

    fun savePastedSite(title: String, url: String, content: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            val cleanUrl = url.ifBlank { "yerel://${title.lowercase(Locale.US).replace(" ", "-")}" }
            val domain = cleanUrl.substringAfter("://").substringBefore("/").ifBlank { "yerel.belge" }
            val entity = CachedSiteEntity(
                url = cleanUrl,
                title = title.ifBlank { domain },
                domain = domain,
                language = if (content.contains(" ve ") || content.contains(" için ")) "tr" else "en",
                rawContent = OfflineResearchEngine.stripHtmlIfNeeded(content),
                category = "Kullanıcı Arşivi"
            )
            repository.saveCachedSite(entity)
            _researchResult.value = OfflineResearchEngine.summarizeSite(entity)
            _toastMessage.value = "Site/belge çevrimdışı arşive eklendi ve özetlendi."
        }
    }

    fun importLocalDocumentSite(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            runCatching {
                val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
                } ?: "yerel_sayfa.html"
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val cleaned = OfflineResearchEngine.stripHtmlIfNeeded(text).take(16_000)
                if (cleaned.length < 20) error("Dosya içeriği çok kısa")
                val site = CachedSiteEntity(
                    url = "file:///$name",
                    title = name.substringBeforeLast('.'),
                    domain = name,
                    language = if (cleaned.contains(" ve ") || cleaned.contains(" bir ")) "tr" else "en",
                    rawContent = cleaned,
                    category = "Yerel Dosya"
                )
                repository.saveCachedSite(site)
                withContext(Dispatchers.Main) {
                    _researchResult.value = OfflineResearchEngine.summarizeSite(site)
                    _toastMessage.value = "\"$name\" çevrimdışı özetlendi."
                }
            }.onFailure {
                withContext(Dispatchers.Main) {
                    _toastMessage.value = "Belge okunamadı: ${it.localizedMessage}"
                }
            }
        }
    }

    fun fetchAndCacheLiveSite(url: String) {
        if (settings.value.offlineShieldEnabled) {
            _toastMessage.value = "Çevrimdışı Kalkanı açık! Canlı sayfa çekmek için üstten kalkanı kapatabilir veya çevrimdışı arşivden özetleyebilirsiniz."
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            val res = OfflineResearchEngine.fetchLiveSiteToCache(url)
            _isBusy.value = false
            res.onSuccess { site ->
                repository.saveCachedSite(site)
                _researchResult.value = OfflineResearchEngine.summarizeSite(site)
                _toastMessage.value = "Sayfa çevrimdışı arşive alındı ve özetlendi."
            }.onFailure { err ->
                _toastMessage.value = "Sayfa indirilemedi (internetsiz mod): ${err.localizedMessage}"
            }
        }
    }

    fun deleteCachedSite(id: Int) {
        viewModelScope.launch { repository.deleteCachedSite(id) }
    }

    fun speakOut(text: String) {
        naturalSpeaker.speakFluidly(text, settings.value.activeSpeechLocale)
    }

    fun refreshVaultAndWorkspace() {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            _hasSavedPin.value = SecurityVaultManager.hasSavedPin(ctx)
            _isDeviceSecure.value = SecurityVaultManager.isDeviceLockConfigured(ctx)
            _workspaceItems.value = OfflineFileArchiveEngine.listWorkspaceItems(ctx)
        }
    }

    fun savePinToVault(pin: String) {
        val ctx = getApplication<Application>()
        SecurityVaultManager.saveEncryptedPin(ctx, pin)
            .onSuccess {
                _hasSavedPin.value = true
                _revealedPin.value = null
                _toastMessage.value = "Kilit şifresi Android Keystore AES-256 ile kasaya kaydedildi."
            }
            .onFailure { err ->
                _toastMessage.value = "Şifre kaydedilemedi: ${err.localizedMessage}"
            }
    }

    fun revealPinWithDeviceLock(activity: FragmentActivity) {
        SecurityVaultManager.authenticateWithDeviceLock(
            activity = activity,
            title = "Kayıtlı Ekran Kilidi Şifresi",
            subtitle = "Şifreyi görüntülemek için parmak izi, yüz veya cihaz kilidinizi doğrulayın",
            onAuthenticated = {
                val res = SecurityVaultManager.readDecryptedPin(activity)
                res.onSuccess { pin ->
                    _revealedPin.value = pin
                }.onFailure { err ->
                    _toastMessage.value = "Şifre okunamadı: ${err.localizedMessage}"
                }
            },
            onError = { errMsg ->
                _toastMessage.value = errMsg
            }
        )
    }

    fun hideRevealedPin() {
        _revealedPin.value = null
    }

    fun clearSavedPin() {
        val ctx = getApplication<Application>()
        SecurityVaultManager.clearSavedPin(ctx)
        _hasSavedPin.value = false
        _revealedPin.value = null
        _toastMessage.value = "Kayıtlı kilit şifresi silindi."
    }

    fun selectZipUri(uri: Uri) {
        val ctx = getApplication<Application>()
        _selectedZipUri.value = uri
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        } ?: "secilen_arsiv.zip"
        _selectedZipName.value = name
        _toastMessage.value = "ZIP seçildi: $name"
    }

    fun selectTargetFolderUri(uri: Uri) {
        val ctx = getApplication<Application>()
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        _selectedTargetTreeUri.value = uri
        _selectedTargetTreeName.value = DocumentFile.fromTreeUri(ctx, uri)?.name ?: "Seçilen Ana Dizin"
        _toastMessage.value = "Hedef ana dizin seçildi: ${_selectedTargetTreeName.value}"
    }

    fun extractSelectedZip(subFolderFilter: String, extractToRoot: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val res = OfflineFileArchiveEngine.extractZip(
                context = ctx,
                zipUri = _selectedZipUri.value,
                workspaceZipName = if (_selectedZipUri.value == null) "proje_yedek.zip" else null,
                subFolderFilter = subFolderFilter.takeIf { it.isNotBlank() },
                extractToRoot = extractToRoot,
                targetTreeUri = _selectedTargetTreeUri.value
            )
            withContext(Dispatchers.Main) {
                res.onSuccess { report ->
                    _lastZipReport.value = report
                    _workspaceItems.value = OfflineFileArchiveEngine.listWorkspaceItems(ctx)
                    _toastMessage.value = "${report.archiveName} içinden ${report.extractedCount} dosya çıkarıldı."
                }.onFailure { err ->
                    _toastMessage.value = "ZIP çıkarma hatası: ${err.localizedMessage}"
                }
            }
        }
    }

    fun createWorkspaceFolder(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            OfflineFileArchiveEngine.createFolderInWorkspace(ctx, name)
            _workspaceItems.value = OfflineFileArchiveEngine.listWorkspaceItems(ctx)
        }
    }

    fun compressWorkspaceFolder(folderName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val res = OfflineFileArchiveEngine.compressWorkspaceFolderToZip(
                ctx,
                folderName.trim(),
                "${folderName.ifBlank { "yedek" }}_paket.zip"
            )
            withContext(Dispatchers.Main) {
                res.onSuccess {
                    _workspaceItems.value = OfflineFileArchiveEngine.listWorkspaceItems(ctx)
                    _toastMessage.value = "ZIP oluşturuldu: ${it.name}"
                }.onFailure {
                    _toastMessage.value = "Sıkıştırma hatası: ${it.localizedMessage}"
                }
            }
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        activeSpeechRecognizer?.destroy()
        naturalSpeaker.shutdown()
        super.onCleared()
    }
}
