package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Acoustic Core — Dark Palette
val ObsidianBg = Color(0xFF0A0E17)
val ObsidianSurface = Color(0xFF121621)
val ObsidianSurfaceElevated = Color(0xFF182032)
val ObsidianSurfaceHighest = Color(0xFF212B42)
val ObsidianOutline = Color(0xFF2D3954)
val ObsidianOutlineSubtle = Color(0xFF1E273B)

val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanContainer = Color(0xFF003B47)
val OnElectricCyan = Color(0xFF001F26)
val OnElectricCyanContainer = Color(0xFFA2F4FF)

val EmeraldTeal = Color(0xFF14B8A6)
val EmeraldTealContainer = Color(0xFF083A35)
val OnEmeraldTeal = Color(0xFF00201C)
val OnEmeraldTealContainer = Color(0xFF99F6EA)

val WarmAmber = Color(0xFFF59E0B)
val WarmAmberContainer = Color(0xFF422A00)
val OnWarmAmber = Color(0xFF261700)
val OnWarmAmberContainer = Color(0xFFFFDEA6)

val CoralError = Color(0xFFFF5C77)
val CoralErrorContainer = Color(0xFF4D101D)
val OnCoralError = Color(0xFF33000B)
val OnCoralErrorContainer = Color(0xFFFFD9DF)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)

// Light Palette (clean high-contrast slate & deep cyan)
val LightBg = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE9EFF7)
val LightSurfaceHighest = Color(0xFFDDE6F2)
val LightOutline = Color(0xFFBAC7DC)

val DeepCyanLight = Color(0xFF006879)
val DeepCyanContainerLight = Color(0xFFC4F1FA)
val DeepTealLight = Color(0xFF0F766E)
val DeepTealContainerLight = Color(0xFFCCFBF1)
val DeepAmberLight = Color(0xFFB45309)
val DeepAmberContainerLight = Color(0xFFFEF3C7)
val LightError = Color(0xFFBA1A1A)
val LightErrorContainer = Color(0xFFFFDAD6)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
