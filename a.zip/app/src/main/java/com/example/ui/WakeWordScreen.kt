package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.UserSettings
import com.example.data.WakeWordProfileEntity
import com.example.engine.WakeServiceRuntimeState
import com.example.ui.theme.LocalYankiStatusColors
import kotlin.math.roundToInt

@Composable
fun WakeWordScreen(
    wakeWords: List<WakeWordProfileEntity>,
    settings: UserSettings,
    wakeState: WakeServiceRuntimeState,
    isRecording: Boolean,
    recordingWaveform: List<Float>,
    lastRecordedPreview: List<Float>,
    hasSavedPin: Boolean,
    isDeviceSecure: Boolean,
    revealedPin: String?,
    onRecordWakeWord: (String, String) -> Unit,
    onPlayWakeWord: (WakeWordProfileEntity) -> Unit,
    onActivateWakeWord: (Int, String) -> Unit,
    onDeleteWakeWord: (WakeWordProfileEntity) -> Unit,
    onToggleBackgroundService: (Boolean) -> Unit,
    onSetAutoBoot: (Boolean) -> Unit,
    onSetSensitivity: (Float) -> Unit,
    onSavePinToVault: (String) -> Unit,
    onRevealPinWithDeviceLock: () -> Unit,
    onHideRevealedPin: () -> Unit,
    onClearSavedPin: () -> Unit,
    onPreviewRgbEdge: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColors = LocalYankiStatusColors.current
    var phraseInput by remember { mutableStateOf("Hey Axiom") }
    var selectedLang by remember { mutableStateOf("tr-TR") }
    var pinDraft by remember { mutableStateOf("") }

    val activeBins = if (isRecording) recordingWaveform else wakeState.spectrumBins
    val barColor = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    val secondaryBarColor = MaterialTheme.colorScheme.secondary

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text("Uyandırma Kelimesi & Arka Plan", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Uygulama tamamen kapalıyken bile kaydettiğiniz kelimenin ses imzasını duyunca otomatik dinlemeye başlar.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Always-On Background Foreground Service Control
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (wakeState.isBackgroundServiceRunning) statusColors.activeGlow.copy(alpha = 0.6f)
                            else MaterialTheme.colorScheme.outlineVariant,
                            MaterialTheme.shapes.large
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (wakeState.isBackgroundServiceRunning)
                                                statusColors.activeGlow.copy(alpha = 0.18f)
                                            else MaterialTheme.colorScheme.surface
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Hearing,
                                        contentDescription = null,
                                        tint = if (wakeState.isBackgroundServiceRunning) statusColors.activeGlow
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column {
                                    Text("Uygulama Kapalıyken Dinle", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        wakeState.statusMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = wakeState.isBackgroundServiceRunning,
                                onCheckedChange = onToggleBackgroundService,
                                modifier = Modifier.testTag("background_wake_switch")
                            )
                        }

                        // Real-time Acoustic Spectrum Canvas
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(74.dp)
                                .clip(MaterialTheme.shapes.small)
                                .background(MaterialTheme.colorScheme.background)
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val count = activeBins.size.coerceAtLeast(1)
                                val gap = 6.dp.toPx()
                                val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(4f)
                                activeBins.forEachIndexed { idx, value ->
                                    val barHeight = (size.height * value.coerceIn(0.08f, 1f))
                                    val left = idx * (barWidth + gap)
                                    val top = (size.height - barHeight) / 2f
                                    drawRoundRect(
                                        brush = Brush.verticalGradient(listOf(barColor, secondaryBarColor)),
                                        topLeft = Offset(left, top),
                                        size = Size(barWidth, barHeight),
                                        cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Ses Seviyesi: ${wakeState.currentRmsDb.roundToInt()} dBFS",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "Kelime: %${(wakeState.lastMatchConfidence * 100).roundToInt()} • Ses İzi: %${(wakeState.lastSpeakerSimilarity * 100).roundToInt()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = statusColors.activeGlow
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                        // Sensitivity Slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Akustik Eşleşme Hassasiyeti", style = MaterialTheme.typography.labelLarge)
                                Text(
                                    "%${(settings.wakeSensitivity * 100).roundToInt()}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = settings.wakeSensitivity,
                                onValueChange = onSetSensitivity,
                                valueRange = 0.45f..0.95f
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(18.dp))
                                Text("Telefon açılınca otomatik başlat", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(
                                checked = settings.autoStartOnBoot,
                                onCheckedChange = onSetAutoBoot
                            )
                        }

                        FilledTonalButton(
                            onClick = onPreviewRgbEdge,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("preview_rgb_edge_button")
                        ) {
                            Text("1 mm RGB Kenar Dinleme Şeridini Test Et (Tam Ekran Açılmaz)")
                        }
                    }
                }
            }

            // Record New Wake-Word Audio Sample
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Yeni Uyandırma Kelimesi Kaydet", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Önce tetikleyici kelimeyi yazın, ardından kayıt butonuna basıp 2 saniye boyunca o kelimeyi netçe söyleyin. Sesin 24-bant akustik imzası cihazda saklanır.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = phraseInput,
                            onValueChange = { phraseInput = it },
                            label = { Text("Uyandırma Kelimesi / İfadesi") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("wake_phrase_input")
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("tr-TR" to "Türkçe", "en-US" to "English").forEach { (code, label) ->
                                FilledTonalButton(
                                    onClick = { selectedLang = code },
                                    colors = if (selectedLang == code) {
                                        ButtonDefaults.filledTonalButtonColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer
                                        )
                                    } else ButtonDefaults.filledTonalButtonColors()
                                ) {
                                    Text(label)
                                }
                            }
                        }

                        if (lastRecordedPreview.isNotEmpty()) {
                            val waveformColor = statusColors.offlineShield
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                val step = size.width / lastRecordedPreview.size.coerceAtLeast(1)
                                lastRecordedPreview.forEachIndexed { idx, amp ->
                                    val h = (size.height * amp).coerceAtLeast(4f)
                                    drawRoundRect(
                                        color = waveformColor,
                                        topLeft = Offset(idx * step, (size.height - h) / 2f),
                                        size = Size((step * 0.65f).coerceAtLeast(3f), h),
                                        cornerRadius = CornerRadius(3f, 3f)
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { onRecordWakeWord(phraseInput, selectedLang) },
                            enabled = !isRecording,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("record_wake_word_button")
                        ) {
                            Icon(
                                if (isRecording) Icons.Default.FiberManualRecord else Icons.Default.GraphicEq,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (isRecording) "Kaydediliyor (Şimdi Konuşun)… 2.2 sn"
                                else "Ses Kaydı Al & Akustik İmza Çıkar"
                            )
                        }
                    }
                }
            }

            // Lock Screen Voice Verification & Biometric-Protected PIN Vault
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                            Text("Kilit Ekranı & Biyometrik Şifre Kasası", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Şifreniz Android Keystore AES-256 ile şifrelenir ve yalnızca cihaz kilidiniz (Parmak İzi / Yüz / Cihaz PIN'i) doğrulandığında görüntülenebilir. " +
                                "Kilit ekranında uyandırma kelimesini duyunca ekran uyanır ve konuşmacı ses izi ölçülür (%72+).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Güvenlik Notu: Android 13+ işletim sistemleri, sistem PIN ekranına üçüncü parti otomatik dokunmayı güvenlik nedeniyle kısıtlayabilir; bu durumda sistem kilit ekranı öne getirilir.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.tertiary
                        )

                        if (revealedPin != null) {
                            Surface(
                                color = statusColors.offlineShield.copy(alpha = 0.16f),
                                shape = MaterialTheme.shapes.small,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "Kayıtlı Şifre: $revealedPin",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = statusColors.offlineShield
                                    )
                                    IconButton(onClick = onHideRevealedPin) {
                                        Icon(Icons.Default.VisibilityOff, contentDescription = "Şifreyi Gizle")
                                    }
                                }
                            }
                        } else if (hasSavedPin) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilledTonalButton(
                                    onClick = onRevealPinWithDeviceLock,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("reveal_pin_biometric_button")
                                ) {
                                    Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isDeviceSecure) "Cihaz Kilidiyle Görüntüle" else "Şifreyi Göster")
                                }
                                OutlinedButton(onClick = onClearSavedPin) {
                                    Text("Sil")
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = pinDraft,
                                onValueChange = { pinDraft = it },
                                label = { Text("Yeni Kilit Şifresi / PIN") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("vault_pin_input")
                            )
                            Button(
                                onClick = {
                                    if (pinDraft.isNotBlank()) {
                                        onSavePinToVault(pinDraft)
                                        pinDraft = ""
                                    }
                                },
                                enabled = pinDraft.isNotBlank(),
                                modifier = Modifier.testTag("save_vault_pin_button")
                            ) {
                                Text("Kaydet")
                            }
                        }
                    }
                }
            }

            // Saved Wake-Word Recordings List
            item {
                Text(
                    "Kayıtlı Uyandırma Sesleri (${wakeWords.size})",
                    style = MaterialTheme.typography.titleSmall
                )
            }

            if (wakeWords.isEmpty()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "Henüz kaydedilmiş bir uyandırma sesi yok. Yukarıdan bir kelime söyleyip kaydedin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }

            items(wakeWords, key = { it.id }) { profile ->
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(
                        containerColor = if (profile.isActive) MaterialTheme.colorScheme.surfaceContainerHigh
                        else MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (profile.isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            MaterialTheme.shapes.medium
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("\"${profile.phrase}\"", style = MaterialTheme.typography.titleMedium)
                                if (profile.isActive) {
                                    Surface(
                                        color = statusColors.offlineShield.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(50.dp)
                                    ) {
                                        Text(
                                            "AKTİF",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = statusColors.offlineShield,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                "${profile.languageCode} • ${profile.durationMs} ms • Tepe RMS ${(profile.peakRms * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { onPlayWakeWord(profile) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Kaydı Dinle")
                            }
                            if (!profile.isActive) {
                                IconButton(onClick = { onActivateWakeWord(profile.id, profile.phrase) }) {
                                    Icon(Icons.Default.RadioButtonChecked, contentDescription = "Aktif Seç")
                                }
                            } else {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = "Aktif",
                                    tint = statusColors.offlineShield,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                            }
                            IconButton(onClick = { onDeleteWakeWord(profile) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Kaydı Sil")
                            }
                        }
                    }
                }
            }
        }
    }
}
