package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Hearing
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.ModelStatus
import com.example.ui.theme.YankiTheme

private enum class YankiTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    ASSISTANT("assistant", "Asistan", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
    WAKE_WORD("wake_word", "Uyandırma", Icons.Filled.Hearing, Icons.Outlined.Hearing),
    MODELS("models", "Modeller", Icons.Filled.Memory, Icons.Outlined.Memory),
    LAB("lab", "Otomasyon", Icons.Filled.Build, Icons.Outlined.Build)
}

@Composable
fun YankiApp(
    viewModel: MainViewModel,
    activity: FragmentActivity,
    initialWakeTriggered: Boolean = false,
    isLockScreenMiniMode: Boolean = false
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val models by viewModel.languageModels.collectAsStateWithLifecycle()
    val wakeWords by viewModel.wakeWords.collectAsStateWithLifecycle()
    val macros by viewModel.macros.collectAsStateWithLifecycle()
    val cachedSites by viewModel.cachedSites.collectAsStateWithLifecycle()
    val wakeState by viewModel.wakeServiceState.collectAsStateWithLifecycle()
    val accessibilityConnected by viewModel.accessibilityConnected.collectAsStateWithLifecycle()
    val conversation by viewModel.conversation.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val diagnostics by viewModel.diagnostics.collectAsStateWithLifecycle()
    val isListeningMic by viewModel.isListeningMic.collectAsStateWithLifecycle()
    val isRecordingWakeWord by viewModel.isRecordingWakeWord.collectAsStateWithLifecycle()
    val recordingWaveform by viewModel.recordingWaveform.collectAsStateWithLifecycle()
    val lastRecordedPreview by viewModel.lastRecordedPreview.collectAsStateWithLifecycle()
    val automationLogs by viewModel.automationLogs.collectAsStateWithLifecycle()
    val researchResult by viewModel.researchResult.collectAsStateWithLifecycle()
    val comparisonResult by viewModel.comparisonResult.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val showAccessibilityDisclosure by viewModel.showAccessibilityDisclosure.collectAsStateWithLifecycle()
    val hasSavedPin by viewModel.hasSavedPin.collectAsStateWithLifecycle()
    val isDeviceSecure by viewModel.isDeviceSecure.collectAsStateWithLifecycle()
    val revealedPin by viewModel.revealedPin.collectAsStateWithLifecycle()
    val workspaceItems by viewModel.workspaceItems.collectAsStateWithLifecycle()
    val lastZipReport by viewModel.lastZipReport.collectAsStateWithLifecycle()
    val selectedZipName by viewModel.selectedZipName.collectAsStateWithLifecycle()
    val selectedTargetTreeName by viewModel.selectedTargetTreeName.collectAsStateWithLifecycle()
    val hardwareReport by viewModel.hardwareReport.collectAsStateWithLifecycle()
    val ttsStatus by viewModel.ttsStatus.collectAsStateWithLifecycle()
    val llmDownloadProgress by viewModel.llmDownloadProgress.collectAsStateWithLifecycle()
    val previewRgbEdge by viewModel.previewRgbEdge.collectAsStateWithLifecycle()

    var permissionsRequested by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toastMessage) {
        val msg = toastMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearToast()
    }

    val hasAnyInstalledModel = remember(models) {
        models.any { it.status == ModelStatus.ACTIVE.name || it.status == ModelStatus.INSTALLED.name }
    }

    YankiTheme(darkTheme = settings.darkTheme) {
        Box(modifier = Modifier.fillMaxSize()) {
            val showModelOnboarding = models.isNotEmpty() && !hasAnyInstalledModel && !settings.modelOnboardingDismissed

            if (isLockScreenMiniMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 48.dp)
                        .testTag("lock_screen_mini_overlay"),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                        tonalElevation = 6.dp,
                        shadowElevation = 8.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Hearing,
                                contentDescription = "Axiom dinliyor",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = wakeState.statusMessage.ifBlank { "Axiom Kilit Ekranında Dinliyor..." },
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            } else if (showModelOnboarding) {
                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing,
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    ModelSetupOnboardingScreen(
                        models = models,
                        isBusy = isBusy,
                        onInstallAllAndStart = { viewModel.installAllCoreModelsAndEnter() },
                        onInstallSingle = { viewModel.installSingleModel(it) },
                        onSkip = { viewModel.dismissOnboardingOnly() },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            } else {
            val navController = rememberNavController()
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route ?: YankiTab.ASSISTANT.route

            // Ensure hardware back from secondary tabs returns to Assistant tab cleanly
            BackHandler(enabled = currentRoute != YankiTab.ASSISTANT.route) {
                navController.navigate(YankiTab.ASSISTANT.route) {
                    popUpTo(YankiTab.ASSISTANT.route) { inclusive = false }
                    launchSingleTop = true
                }
            }

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val useNavRail = maxWidth >= 600.dp

                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        if (!useNavRail) {
                            NavigationBar {
                                YankiTab.entries.forEach { tab ->
                                    val selected = currentRoute == tab.route
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = {
                                            navController.navigate(tab.route) {
                                                popUpTo(YankiTab.ASSISTANT.route) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        icon = {
                                            Icon(
                                                if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label
                                            )
                                        },
                                        label = { Text(tab.label, maxLines = 1) },
                                        modifier = Modifier.testTag("nav_${tab.route}")
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (useNavRail) {
                            NavigationRail(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(84.dp)
                            ) {
                                YankiTab.entries.forEach { tab ->
                                    val selected = currentRoute == tab.route
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = {
                                            navController.navigate(tab.route) {
                                                popUpTo(YankiTab.ASSISTANT.route) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        icon = {
                                            Icon(
                                                if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label
                                            )
                                        },
                                        label = { Text(tab.label) },
                                        modifier = Modifier.testTag("rail_${tab.route}")
                                    )
                                }
                            }
                        }

                        Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                            NavHost(
                                navController = navController,
                                startDestination = YankiTab.ASSISTANT.route
                            ) {
                                composable(YankiTab.ASSISTANT.route) {
                                    AssistantScreen(
                                        models = models,
                                        settings = settings,
                                        wakeState = wakeState,
                                        accessibilityConnected = accessibilityConnected,
                                        isListeningMic = isListeningMic,
                                        conversation = conversation,
                                        onSubmitCommand = { viewModel.submitCommand(it) },
                                        onToggleVoiceInput = {
                                            if (isListeningMic) viewModel.stopOfflineVoiceInput()
                                            else viewModel.startOfflineVoiceInput()
                                        },
                                        onSpeakText = { viewModel.speakOut(it) },
                                        onOpenAccessibilityGuide = { viewModel.requestAccessibilityDisclosure(true) },
                                        onNavigateToModels = {
                                            navController.navigate(YankiTab.MODELS.route) {
                                                launchSingleTop = true
                                            }
                                        }
                                    )
                                }

                                composable(YankiTab.WAKE_WORD.route) {
                                    WakeWordScreen(
                                        wakeWords = wakeWords,
                                        settings = settings,
                                        wakeState = wakeState,
                                        isRecording = isRecordingWakeWord,
                                        recordingWaveform = recordingWaveform,
                                        lastRecordedPreview = lastRecordedPreview,
                                        hasSavedPin = hasSavedPin,
                                        isDeviceSecure = isDeviceSecure,
                                        revealedPin = revealedPin,
                                        onRecordWakeWord = { phrase, lang -> viewModel.recordWakeWord(phrase, lang) },
                                        onPlayWakeWord = { viewModel.playWakeWord(it) },
                                        onActivateWakeWord = { id, phrase -> viewModel.activateWakeWord(id, phrase) },
                                        onDeleteWakeWord = { viewModel.deleteWakeWord(it) },
                                        onToggleBackgroundService = { viewModel.toggleBackgroundWakeService(it) },
                                        onSetAutoBoot = { viewModel.setAutoStartOnBoot(it) },
                                        onSetSensitivity = { viewModel.setWakeSensitivity(it) },
                                        onSetIgnoreDuringMedia = { viewModel.setIgnoreWakeDuringMedia(it) },
                                        onSetStrictSpeaker = { viewModel.setStrictSpeakerVerification(it) },
                                        onSetSpeakerThreshold = { viewModel.setSpeakerThreshold(it) },
                                        onSavePinToVault = { viewModel.savePinToVault(it) },
                                        onRevealPinWithDeviceLock = { viewModel.revealPinWithDeviceLock(activity) },
                                        onHideRevealedPin = { viewModel.hideRevealedPin() },
                                        onClearSavedPin = { viewModel.clearSavedPin() },
                                        onPreviewRgbEdge = { viewModel.triggerRgbEdgePreview() }
                                    )
                                }

                                composable(YankiTab.MODELS.route) {
                                    ModelsHubScreen(
                                        models = models,
                                        diagnostics = diagnostics,
                                        settings = settings,
                                        hardwareReport = hardwareReport,
                                        powerfulCatalog = viewModel.powerfulLlmCatalog,
                                        llmDownloadProgress = llmDownloadProgress,
                                        ttsStatus = ttsStatus,
                                        onInstallModel = { viewModel.installSingleModel(it) },
                                        onToggleActive = { viewModel.toggleModelActive(it) },
                                        onUninstallModel = { viewModel.uninstallModel(it) },
                                        onImportExternalModel = { uri, lang -> viewModel.importExternalModel(uri, lang) },
                                        onSelectSpeechLocale = { viewModel.setSpeechLocale(it) },
                                        onOpenOfflineVoiceSettings = { viewModel.openSystemOfflineVoiceSettings() },
                                        onToggleDarkTheme = { viewModel.setDarkTheme(it) },
                                        onDownloadPowerfulLlm = { viewModel.downloadPowerfulLlm(it) },
                                        onSelectPowerfulLlm = { viewModel.selectPowerfulLlm(it) },
                                        onToggleTtsAutoSpeak = { viewModel.setTtsAutoSpeak(it) },
                                        onTestMaleVoice = { viewModel.testMaleVoiceReadout() },
                                        onToggleOfflineShield = { viewModel.setOfflineShield(it) }
                                    )
                                }

                                composable(YankiTab.LAB.route) {
                                    AutomationResearchScreen(
                                        installedApps = installedApps,
                                        macros = macros,
                                        cachedSites = cachedSites,
                                        settings = settings,
                                        accessibilityConnected = accessibilityConnected,
                                        automationLogs = automationLogs,
                                        researchResult = researchResult,
                                        comparisonResult = comparisonResult,
                                        isBusy = isBusy,
                                        workspaceItems = workspaceItems,
                                        lastZipReport = lastZipReport,
                                        selectedZipName = selectedZipName,
                                        selectedTargetTreeName = selectedTargetTreeName,
                                        onRunCommand = { viewModel.submitCommand(it) },
                                        onOpenAccessibilityGuide = { viewModel.requestAccessibilityDisclosure(true) },
                                        onSaveAndRunMacro = { title, trig, app, steps, runNow ->
                                            viewModel.saveAndOptionallyRunMacro(title, trig, app, steps, runNow)
                                        },
                                        onRunMacro = { viewModel.runMacro(it) },
                                        onDeleteMacro = { viewModel.deleteMacro(it) },
                                        onSummarizeSite = { viewModel.summarizeOfflineSite(it) },
                                        onCompareSites = { a, b -> viewModel.compareOfflineSites(a, b) },
                                        onSavePastedSite = { t, u, c -> viewModel.savePastedSite(t, u, c) },
                                        onImportLocalDocument = { viewModel.importLocalDocumentSite(it) },
                                        onFetchLiveSite = { viewModel.fetchAndCacheLiveSite(it) },
                                        onDeleteSite = { viewModel.deleteCachedSite(it) },
                                        onToggleOfflineShield = { viewModel.setOfflineShield(it) },
                                        onPickZipFile = { viewModel.selectZipUri(it) },
                                        onPickTargetFolder = { viewModel.selectTargetFolderUri(it) },
                                        onExtractZip = { sub, toRoot -> viewModel.extractSelectedZip(sub, toRoot) },
                                        onCreateWorkspaceFolder = { viewModel.createWorkspaceFolder(it) },
                                        onCompressFolder = { viewModel.compressWorkspaceFolder(it) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAccessibilityDisclosure) {
            AlertDialog(
                onDismissRequest = { viewModel.requestAccessibilityDisclosure(false) },
                icon = { Icon(Icons.Default.AccessibilityNew, contentDescription = null) },
                title = { Text("Erişilebilirlik Otomasyon İzni") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "Axiom, şu komutları cihazınızda otomatik gerçekleştirmek için Android Erişilebilirlik Servisini kullanır:",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            "• \"Telefonu kapat\" (Sistem güç menüsünü açar)\n" +
                                "• \"Wi-Fi aç / Bluetooth aç\" (Ayarlar anahtarına tıklar)\n" +
                                "• \"Şu uygulamaya girip bunları yap\" (Çok adımlı uygulama içi tıklama ve yazma)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Hiçbir ekran verisi cihaz dışına gönderilmez veya kaydedilmez.",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = { viewModel.openAccessibilitySettings() }) {
                        Text("Ayarlara Git")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.requestAccessibilityDisclosure(false) }) {
                        Text("İptal")
                    }
                }
            )
        }

            // Razor-thin (~1mm) non-blocking animated RGB outer frame strip during voice listening
            RgbEdgeListeningBorder(
                visible = isListeningMic || wakeState.isListeningForCommand || previewRgbEdge || isLockScreenMiniMode,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
