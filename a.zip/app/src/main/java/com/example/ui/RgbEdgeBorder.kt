package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

/**
 * Razor-thin (~1mm / 3.5dp) non-blocking animated RGB outer frame strip.
 * Replaces intrusive full-screen assistant popups when voice listening is active.
 */
@Composable
fun RgbEdgeListeningBorder(
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "rgb_border")
        val angle by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 2200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "rgb_angle"
        )
        val glowAlpha by infiniteTransition.animateFloat(
            initialValue = 0.65f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 700),
                repeatMode = RepeatMode.Reverse
            ),
            label = "rgb_pulse"
        )

        val rgbSpectrum = listOf(
            Color(0xFF00E5FF),
            Color(0xFF3B82F6),
            Color(0xFF9333EA),
            Color(0xFFEC4899),
            Color(0xFFF59E0B),
            Color(0xFF10B981),
            Color(0xFF00E5FF)
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx = 3.6.dp.toPx() // ~1 mm physical edge strip
            val halfStroke = strokePx / 2f
            val cornerPx = 22.dp.toPx()

            rotate(degrees = angle, pivot = Offset(size.width / 2f, size.height / 2f)) {
                val sweep = Brush.sweepGradient(
                    colors = rgbSpectrum.map { it.copy(alpha = glowAlpha) },
                    center = Offset(size.width / 2f, size.height / 2f)
                )
                // Soft outer ambient halo
                drawRoundRect(
                    brush = sweep,
                    topLeft = Offset(halfStroke, halfStroke),
                    size = Size(size.width - strokePx, size.height - strokePx),
                    cornerRadius = CornerRadius(cornerPx, cornerPx),
                    style = Stroke(width = strokePx * 2.2f),
                    alpha = 0.32f
                )
                // Crisp 1mm RGB edge strip
                drawRoundRect(
                    brush = sweep,
                    topLeft = Offset(halfStroke, halfStroke),
                    size = Size(size.width - strokePx, size.height - strokePx),
                    cornerRadius = CornerRadius(cornerPx, cornerPx),
                    style = Stroke(width = strokePx)
                )
            }
        }
    }
}
