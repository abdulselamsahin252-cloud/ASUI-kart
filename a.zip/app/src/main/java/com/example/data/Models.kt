package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ModelLanguage(val code: String, val displayNameTr: String, val displayNameEn: String) {
    TURKISH("tr-TR", "Türkçe", "Turkish"),
    ENGLISH("en-US", "İngilizce", "English"),
    BILINGUAL("tr-en", "Çift Dilli (TR+EN)", "Bilingual (TR+EN)")
}

enum class ModelStatus {
    NOT_INSTALLED,
    INSTALLING,
    INSTALLED,
    ACTIVE
}

@Entity(tableName = "language_models")
data class LanguageModelEntity(
    @PrimaryKey val id: String,
    val name: String,
    val languageCode: String,
    val description: String,
    val version: String,
    val sizeMb: Int,
    val status: String, // ModelStatus name
    val progressPercent: Int = 0,
    val sha256: String,
    val localFilePath: String = "",
    val isExternalImport: Boolean = false,
    val latencyMs: Int = 0,
    val installedAt: Long = 0L
)

@Entity(tableName = "wake_word_profiles")
data class WakeWordProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val phrase: String,
    val languageCode: String,
    val audioFilePath: String,
    val durationMs: Long,
    val signatureCsv: String, // 24-bin normalized energy + spectral + ZCR acoustic vector
    val peakRms: Float,
    val isActive: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

enum class AutomationActionType(val labelTr: String) {
    OPEN_APP("Uygulamayı Aç"),
    WAIT("Bekle"),
    CLICK_TEXT("Metne Tıkla"),
    INPUT_TEXT("Metin Yaz"),
    SCROLL_DOWN("Aşağı Kaydır"),
    SCROLL_UP("Yukarı Kaydır"),
    PRESS_BACK("Geri Git"),
    PRESS_HOME("Ana Ekrana Dön")
}

data class AutomationStep(
    val type: AutomationActionType,
    val target: String = "",
    val value: String = "",
    val delayMs: Long = 900L
)

@Entity(tableName = "automation_macros")
data class AutomationMacroEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val triggerPhrase: String,
    val targetPackageName: String,
    val targetAppLabel: String,
    val stepsSerialized: String, // Pipe-delimited safe serialization
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_sites")
data class CachedSiteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val url: String,
    val title: String,
    val domain: String,
    val language: String,
    val rawContent: String,
    val category: String,
    val isPreseeded: Boolean = false,
    val cachedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "command_logs")
data class CommandLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userQuery: String,
    val intentTag: String,
    val responseSummary: String,
    val stepsJson: String,
    val executionSuccess: Boolean,
    val triggeredByWakeWord: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class ResearchSummaryResult(
    val siteTitle: String,
    val siteUrl: String,
    val language: String,
    val wordCount: Int,
    val readingMinutes: Int,
    val keySentences: List<String>,
    val keywords: List<String>,
    val bulletPoints: List<String>,
    val verdict: String
)

data class SiteComparisonResult(
    val siteATitle: String,
    val siteAUrl: String,
    val siteBTitle: String,
    val siteBUrl: String,
    val similarityPercent: Int,
    val sharedTopics: List<String>,
    val uniqueToA: List<String>,
    val uniqueToB: List<String>,
    val wordCountA: Int,
    val wordCountB: Int,
    val keyHighlightsA: List<String>,
    val keyHighlightsB: List<String>,
    val executiveSummary: String
)

data class InstalledAppInfo(
    val packageName: String,
    val label: String
)

object StepSerializer {
    fun encode(steps: List<AutomationStep>): String {
        return steps.joinToString(separator = "\n") { step ->
            val safeTarget = step.target.replace("|", " ").replace("\n", " ")
            val safeValue = step.value.replace("|", " ").replace("\n", " ")
            "${step.type.name}|$safeTarget|$safeValue|${step.delayMs}"
        }
    }

    fun decode(raw: String): List<AutomationStep> {
        if (raw.isBlank()) return emptyList()
        return raw.lines().mapNotNull { line ->
            val parts = line.split("|")
            if (parts.isEmpty()) return@mapNotNull null
            val type = runCatching { AutomationActionType.valueOf(parts[0]) }.getOrNull()
                ?: return@mapNotNull null
            AutomationStep(
                type = type,
                target = parts.getOrElse(1) { "" },
                value = parts.getOrElse(2) { "" },
                delayMs = parts.getOrElse(3) { "900" }.toLongOrNull() ?: 900L
            )
        }
    }
}
