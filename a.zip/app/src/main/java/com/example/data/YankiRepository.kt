package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

class YankiRepository(
    private val context: Context,
    private val dao: YankiDao,
    val preferences: AppPreferences
) {
    val languageModels: Flow<List<LanguageModelEntity>> = dao.observeLanguageModels()
    val wakeWords: Flow<List<WakeWordProfileEntity>> = dao.observeWakeWords()
    val macros: Flow<List<AutomationMacroEntity>> = dao.observeMacros()
    val cachedSites: Flow<List<CachedSiteEntity>> = dao.observeCachedSites()
    val commandLogs: Flow<List<CommandLogEntity>> = dao.observeCommandLogs()

    suspend fun ensureSeeded(): Int = withContext(Dispatchers.IO) {
        if (dao.getAllModelsOnce().isEmpty()) {
            dao.upsertModels(defaultModels())
        }
        if (dao.getAllMacrosOnce().isEmpty()) {
            dao.upsertMacros(defaultMacros())
        }
        if (dao.getAllCachedSitesOnce().isEmpty()) {
            dao.upsertSites(defaultOfflineSites())
        }
        val restored = discoverAndRestorePersistentModels()
        syncActiveLexiconsIntoNlu()
        restored
    }

    suspend fun syncActiveLexiconsIntoNlu() = withContext(Dispatchers.IO) {
        val all = dao.getAllModelsOnce()
        for (m in all) {
            if (m.status == ModelStatus.ACTIVE.name && m.localFilePath.isNotBlank()) {
                val f = File(m.localFilePath)
                if (f.exists()) {
                    com.example.engine.OfflineNluEngine.loadModelLexiconFromFile(m.id, f)
                }
            } else {
                com.example.engine.OfflineNluEngine.unloadModelLexicon(m.id)
            }
        }
    }

    suspend fun linkAndRestoreFromTreeUri(treeUri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            preferences.setLinkedModelTreeUri(treeUri.toString())
            val count = discoverAndRestorePersistentModels()
            syncActiveLexiconsIntoNlu()
            count
        }
    }

    /**
     * Discovers previously downloaded/installed models from shared Download/Axiom/Models storage
     * (surviving app updates and reinstalls) and restores them into Room as ACTIVE automatically.
     */
    suspend fun discoverAndRestorePersistentModels(): Int = withContext(Dispatchers.IO) {
        val settings = runCatching { preferences.settingsFlow.first() }.getOrNull()
        val treeUri = settings?.linkedModelTreeUri.orEmpty()
        val discovered = PersistentModelStorage.scanPersistentDeviceModels(context, treeUri)
        if (discovered.isEmpty()) return@withContext 0

        var restoredCount = 0
        val existing = dao.getAllModelsOnce().associateBy { it.id }

        for (item in discovered) {
            val baseId = item.fileName.substringBeforeLast('.')
            val builtinMatch = existing[baseId]
            val catalogProfile = com.example.engine.LocalLlmEngine.powerfulCatalog.find { it.id == baseId }

            if (builtinMatch != null && builtinMatch.status == ModelStatus.ACTIVE.name && File(builtinMatch.localFilePath).exists()) {
                continue
            }

            val destDir = File(context.filesDir, "models/$baseId").apply { mkdirs() }
            val destFile = File(destDir, item.fileName)
            if (!destFile.exists() || destFile.length() != item.localCacheFile.length()) {
                item.localCacheFile.copyTo(destFile, overwrite = true)
            }

            if (builtinMatch != null) {
                val digest = sha256File(destFile)
                dao.upsertModel(
                    builtinMatch.copy(
                        status = ModelStatus.ACTIVE.name,
                        progressPercent = 100,
                        sha256 = digest.take(16) + " (Cihaz Deposundan)",
                        localFilePath = destFile.absolutePath,
                        latencyMs = 10,
                        installedAt = System.currentTimeMillis()
                    )
                )
                restoredCount++
            } else if (catalogProfile != null) {
                val gguf = com.example.engine.LocalLlmEngine.inspectGgufHeader(destFile)
                val hash = sha256File(destFile)
                val actualMb = (destFile.length() / (1024L * 1024L)).toInt().coerceAtLeast(1)
                dao.upsertModel(
                    LanguageModelEntity(
                        id = catalogProfile.id,
                        name = catalogProfile.name,
                        languageCode = "tr-en",
                        description = if (gguf.isValidGguf) {
                            "${catalogProfile.strengthSummary} • GGUF v${gguf.formatVersion} (${gguf.tensorCount} tensör)"
                        } else catalogProfile.strengthSummary,
                        version = "${catalogProfile.paramsLabel} ${catalogProfile.quantLabel}",
                        sizeMb = actualMb,
                        status = ModelStatus.ACTIVE.name,
                        progressPercent = 100,
                        sha256 = hash.take(16),
                        localFilePath = destFile.absolutePath,
                        isExternalImport = true,
                        latencyMs = 24,
                        installedAt = System.currentTimeMillis()
                    )
                )
                preferences.setActivePowerfulLlmId(catalogProfile.id)
                restoredCount++
            } else {
                val gguf = com.example.engine.LocalLlmEngine.inspectGgufHeader(destFile)
                val hash = sha256File(destFile)
                val extId = "ext_${baseId.lowercase().replace(Regex("[^a-z0-9_]"), "_")}"
                if (existing[extId]?.status == ModelStatus.ACTIVE.name && File(existing[extId]?.localFilePath.orEmpty()).exists()) {
                    continue
                }
                val actualMb = (destFile.length() / (1024L * 1024L)).toInt().coerceAtLeast(1)
                dao.upsertModel(
                    LanguageModelEntity(
                        id = extId,
                        name = baseId,
                        languageCode = "tr-en",
                        description = if (gguf.isValidGguf) {
                            "Cihaz deposundan otomatik geri yüklendi • GGUF v${gguf.formatVersion} (${gguf.tensorCount} tensör)"
                        } else {
                            "Cihaz deposundan otomatik geri yüklendi (${item.fileName})"
                        },
                        version = if (gguf.isValidGguf) "GGUF v${gguf.formatVersion}" else "Yerel Dosya",
                        sizeMb = actualMb,
                        status = ModelStatus.ACTIVE.name,
                        progressPercent = 100,
                        sha256 = hash.take(16),
                        localFilePath = destFile.absolutePath,
                        isExternalImport = true,
                        latencyMs = 14,
                        installedAt = System.currentTimeMillis()
                    )
                )
                restoredCount++
            }
        }

        if (restoredCount > 0) {
            preferences.setModelOnboardingDismissed(true)
        }
        restoredCount
    }

    suspend fun installBuiltinModel(modelId: String) = withContext(Dispatchers.IO) {
        val current = dao.getModelById(modelId) ?: return@withContext
        val modelDir = File(context.filesDir, "models/$modelId").apply { mkdirs() }

        dao.upsertModel(current.copy(status = ModelStatus.INSTALLING.name, progressPercent = 10))
        delay(220)

        val lexiconPayload = buildLocalModelPayload(modelId)
        val fileName = "$modelId.yanki_model"
        val modelFile = File(modelDir, fileName)
        modelFile.writeText(lexiconPayload)

        dao.upsertModel(current.copy(status = ModelStatus.INSTALLING.name, progressPercent = 55))
        delay(240)

        PersistentModelStorage.mirrorModelToSharedStorage(context, modelFile, fileName)
        com.example.engine.OfflineNluEngine.loadModelLexiconFromFile(modelId, modelFile)

        val digest = sha256Hex(modelFile.readBytes())
        val benchmarkStart = System.nanoTime()
        val tokenCount = lexiconPayload.split(",", "=").size
        val elapsedMs = ((System.nanoTime() - benchmarkStart) / 1_000_000L).toInt().coerceAtLeast(8)

        dao.upsertModel(current.copy(status = ModelStatus.INSTALLING.name, progressPercent = 90))
        delay(180)

        dao.upsertModel(
            current.copy(
                status = ModelStatus.ACTIVE.name,
                progressPercent = 100,
                sha256 = digest.take(14) + "…($tokenCount kavram)",
                localFilePath = modelFile.absolutePath,
                latencyMs = elapsedMs,
                installedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun toggleModelActive(modelId: String) = withContext(Dispatchers.IO) {
        val current = dao.getModelById(modelId) ?: return@withContext
        val nextStatus = when (current.status) {
            ModelStatus.ACTIVE.name -> ModelStatus.INSTALLED.name
            ModelStatus.INSTALLED.name -> ModelStatus.ACTIVE.name
            else -> return@withContext
        }
        dao.upsertModel(current.copy(status = nextStatus))
        if (nextStatus == ModelStatus.ACTIVE.name && current.localFilePath.isNotBlank()) {
            com.example.engine.OfflineNluEngine.loadModelLexiconFromFile(modelId, File(current.localFilePath))
        } else {
            com.example.engine.OfflineNluEngine.unloadModelLexicon(modelId)
        }
    }

    suspend fun uninstallModel(modelId: String) = withContext(Dispatchers.IO) {
        val current = dao.getModelById(modelId) ?: return@withContext
        com.example.engine.OfflineNluEngine.unloadModelLexicon(modelId)
        if (current.localFilePath.isNotBlank()) {
            val f = File(current.localFilePath)
            PersistentModelStorage.removeFromSharedStorage(context, f.name)
            runCatching { f.delete() }
            runCatching { File(context.filesDir, "models/$modelId").deleteRecursively() }
        }
        if (current.isExternalImport) {
            dao.deleteModelById(modelId)
        } else {
            dao.upsertModel(
                current.copy(
                    status = ModelStatus.NOT_INSTALLED.name,
                    progressPercent = 0,
                    localFilePath = "",
                    latencyMs = 0,
                    installedAt = 0L
                )
            )
        }
    }

    suspend fun importExternalModelUri(uri: Uri, languageCode: String): Result<LanguageModelEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val fileName = queryDisplayName(uri) ?: "external_model_${System.currentTimeMillis()}.bin"
                val id = "ext_${System.currentTimeMillis()}"
                val dir = File(context.filesDir, "models/$id").apply { mkdirs() }
                val destFile = File(dir, fileName)

                context.contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                } ?: error("Dosya okunamadı")

                val bytes = destFile.length()
                val sizeMb = (bytes / (1024L * 1024L)).toInt().coerceAtLeast(1)
                val hash = sha256File(destFile)
                PersistentModelStorage.mirrorModelToSharedStorage(context, destFile, fileName)
                val gguf = com.example.engine.LocalLlmEngine.inspectGgufHeader(destFile)
                val desc = if (gguf.isValidGguf) {
                    "Doğrulanmış GGUF v${gguf.formatVersion} • ${gguf.tensorCount} tensör • ${gguf.kvCount} metadata ($fileName)"
                } else {
                    "Cihaz depolamasından içe aktarılan yerel model ($fileName)"
                }
                val entity = LanguageModelEntity(
                    id = id,
                    name = fileName.substringBeforeLast('.'),
                    languageCode = languageCode,
                    description = desc,
                    version = if (gguf.isValidGguf) "GGUF v${gguf.formatVersion}" else "Yerel Dosya",
                    sizeMb = sizeMb,
                    status = ModelStatus.ACTIVE.name,
                    progressPercent = 100,
                    sha256 = hash.take(16),
                    localFilePath = destFile.absolutePath,
                    isExternalImport = true,
                    latencyMs = 14,
                    installedAt = System.currentTimeMillis()
                )
                dao.upsertModel(entity)
                entity
            }
        }

    suspend fun downloadPublicGgufModel(
        profile: com.example.engine.PowerfulLlmProfile,
        onProgress: (Int) -> Unit
    ): Result<LanguageModelEntity> = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "models/${profile.id}").apply { mkdirs() }
            val destFile = File(dir, "${profile.id}.gguf")
            val tempFile = File(dir, "${profile.id}.gguf.part")

            val client = okhttp3.OkHttpClient.Builder()
                .followRedirects(true)
                .connectTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            val request = okhttp3.Request.Builder()
                .url(profile.publicDownloadUrl)
                .header("User-Agent", "YankiAI-Android/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    error("İndirme başarısız (HTTP ${response.code})")
                }
                val body = response.body ?: error("Boş yanıt")
                val total = body.contentLength().coerceAtLeast(profile.sizeMb * 1024L * 1024L)
                var downloaded = 0L
                var lastPct = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buf = ByteArray(32 * 1024)
                        var read = input.read(buf)
                        while (read >= 0) {
                            if (read > 0) {
                                output.write(buf, 0, read)
                                downloaded += read
                                val pct = ((downloaded * 100L) / total).toInt().coerceIn(1, 99)
                                if (pct != lastPct) {
                                    lastPct = pct
                                    onProgress(pct)
                                }
                            }
                            read = input.read(buf)
                        }
                    }
                }
            }

            if (destFile.exists()) destFile.delete()
            if (!tempFile.renameTo(destFile)) {
                tempFile.copyTo(destFile, overwrite = true)
                tempFile.delete()
            }

            PersistentModelStorage.mirrorModelToSharedStorage(context, destFile, "${profile.id}.gguf")
            val gguf = com.example.engine.LocalLlmEngine.inspectGgufHeader(destFile)
            val hash = sha256File(destFile)
            val actualMb = (destFile.length() / (1024L * 1024L)).toInt().coerceAtLeast(1)
            val desc = if (gguf.isValidGguf) {
                "${profile.strengthSummary} • GGUF v${gguf.formatVersion} (${gguf.tensorCount} tensör) • Cihazda Kalıcı"
            } else {
                profile.strengthSummary
            }

            val entity = LanguageModelEntity(
                id = profile.id,
                name = profile.name,
                languageCode = "tr-en",
                description = desc,
                version = "${profile.paramsLabel} ${profile.quantLabel}",
                sizeMb = actualMb,
                status = ModelStatus.ACTIVE.name,
                progressPercent = 100,
                sha256 = hash.take(16),
                localFilePath = destFile.absolutePath,
                isExternalImport = true,
                latencyMs = 28,
                installedAt = System.currentTimeMillis()
            )
            dao.upsertModel(entity)
            onProgress(100)
            entity
        }
    }

    suspend fun saveWakeWordProfile(profile: WakeWordProfileEntity): Int = withContext(Dispatchers.IO) {
        dao.deactivateAllWakeWords()
        val id = dao.insertWakeWord(profile.copy(isActive = true)).toInt()
        id
    }

    suspend fun activateWakeWord(id: Int) = withContext(Dispatchers.IO) {
        dao.deactivateAllWakeWords()
        dao.activateWakeWordById(id)
    }

    suspend fun deleteWakeWord(profile: WakeWordProfileEntity) = withContext(Dispatchers.IO) {
        runCatching { File(profile.audioFilePath).delete() }
        dao.deleteWakeWordById(profile.id)
    }

    suspend fun getActiveWakeWord(): WakeWordProfileEntity? = withContext(Dispatchers.IO) {
        dao.getActiveWakeWordOnce()
    }

    suspend fun saveMacro(macro: AutomationMacroEntity) = withContext(Dispatchers.IO) {
        dao.upsertMacro(macro)
    }

    suspend fun deleteMacro(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteMacroById(id)
    }

    suspend fun getAllMacros(): List<AutomationMacroEntity> = withContext(Dispatchers.IO) {
        dao.getAllMacrosOnce()
    }

    suspend fun saveCachedSite(site: CachedSiteEntity): Long = withContext(Dispatchers.IO) {
        dao.upsertSite(site)
    }

    suspend fun deleteCachedSite(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteSiteById(id)
    }

    suspend fun getAllCachedSites(): List<CachedSiteEntity> = withContext(Dispatchers.IO) {
        dao.getAllCachedSitesOnce()
    }

    suspend fun logCommand(log: CommandLogEntity) = withContext(Dispatchers.IO) {
        dao.insertCommandLog(log)
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        dao.clearCommandLogs()
    }

    private fun queryDisplayName(uri: Uri): String? {
        return context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        }
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(bytes).joinToString("") { "%02x".format(it) }
    }

    private fun sha256File(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(8192)
            var read = input.read(buf)
            while (read > 0) {
                md.update(buf, 0, read)
                read = input.read(buf)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun buildLocalModelPayload(modelId: String): String {
        return when (modelId) {
            "yanki_tr_core" -> """
                MODEL=axiom-tr-core-v3.0;LANG=tr-TR;OFFLINE=true;
                CONCEPT:WAKE=uyandir,uyan,kalk,canlandir,ekrana gel,ekrani yak,isiklandir
                CONCEPT:LOCK=kilitle,kitle,uyut,dondur,uyku,karart
                CONCEPT:WIFI=wifi,wi-fi,kablosuz,wlan,kablosuz ag,kablosuz internet
                CONCEPT:BLUETOOTH=bluetooth,blutut,mavi dis,kulaklik baglanti
                CONCEPT:FLASHLIGHT=fener,el feneri,flas,isik,aydinlat,arka isik
                CONCEPT:VOLUME=ses,muzik,medya,sessiz,sustur,fulle,sonla,kokle,kis,azalt
                CONCEPT:TIMER=zamanlayici,sayac,kronometre,dakika sonra,dk sonra
                CONCEPT:ALARM=alarm,uyandir beni,sabah kur,saat kur
                CONCEPT:RESEARCH=arastir,ozetle,ozet,incele,analiz et,acikla
                CONCEPT:COMPARE=karsilastir,farklari,farki ne,kiyasla,hangisi iyi
            """.trimIndent()
            "yanki_en_core" -> """
                MODEL=axiom-en-core-v3.0;LANG=en-US;OFFLINE=true;
                CONCEPT:WAKE=wake up,wake screen,turn on display,light up screen,awaken
                CONCEPT:LOCK=lock screen,sleep screen,lock phone,turn off screen
                CONCEPT:WIFI=wifi,wi-fi,wireless,wlan,wireless internet
                CONCEPT:BLUETOOTH=bluetooth,bt,pair audio
                CONCEPT:FLASHLIGHT=flashlight,torch,flash,lamp
                CONCEPT:VOLUME=volume,sound,audio,mute,silent,louder,quieter
                CONCEPT:TIMER=timer,countdown,minutes from now,remind in
                CONCEPT:ALARM=alarm,wake me at,set alarm
                CONCEPT:RESEARCH=summarize,research,analyze,overview,digest
                CONCEPT:COMPARE=compare,versus,differences,contrast
            """.trimIndent()
            else -> """
                MODEL=axiom-bi-research-v2.0;LANG=tr-en;OFFLINE=true;
                CONCEPT:RESEARCH=arastir,ozetle,ozet,summarize,research,extract,tfidf
                CONCEPT:COMPARE=karsilastir,kiyasla,compare,versus,diff
                WEIGHTS=tfidf,textrank,jaccard,cosine,entity_extract,sentiment_lexicon;
                STOPWORDS=ve,ile,bir,bu,su,the,and,is,for,with,that,from
            """.trimIndent()
        }
    }

    private fun defaultModels(): List<LanguageModelEntity> = listOf(
        LanguageModelEntity(
            id = "yanki_tr_core",
            name = "Axiom Türkçe Çekirdek (TR)",
            languageCode = ModelLanguage.TURKISH.code,
            description = "Türkçe ek-kök çözümleme, akustik uyandırma eşleştirme ve cihaz otomasyon niyet motoru.",
            version = "v2.4-int4",
            sizeMb = 48,
            status = ModelStatus.NOT_INSTALLED.name,
            sha256 = "tr24-beklemede",
            latencyMs = 0
        ),
        LanguageModelEntity(
            id = "yanki_en_core",
            name = "Axiom English Core (EN)",
            languageCode = ModelLanguage.ENGLISH.code,
            description = "Offline English NLU parser, acoustic wake-word matcher, and multi-step app macro planner.",
            version = "v2.4-int4",
            sizeMb = 42,
            status = ModelStatus.NOT_INSTALLED.name,
            sha256 = "en24-beklemede",
            latencyMs = 0
        ),
        LanguageModelEntity(
            id = "yanki_bi_research",
            name = "Çift Dilli Araştırma & Özet Motoru",
            languageCode = ModelLanguage.BILINGUAL.code,
            description = "İnternetsiz TF-IDF ekstraktif özetleme, HTML temizleme ve iki siteyi yan yana karşılaştırma çekirdeği.",
            version = "v1.8-tfidf",
            sizeMb = 18,
            status = ModelStatus.NOT_INSTALLED.name,
            sha256 = "bi18-beklemede",
            latencyMs = 0
        )
    )

    private fun defaultMacros(): List<AutomationMacroEntity> = listOf(
        AutomationMacroEntity(
            title = "Ayarlardan Bluetooth Aç",
            triggerPhrase = "ayarlara girip bluetooth aç",
            targetPackageName = "com.android.settings",
            targetAppLabel = "Ayarlar",
            stepsSerialized = StepSerializer.encode(
                listOf(
                    AutomationStep(AutomationActionType.OPEN_APP, target = "Ayarlar"),
                    AutomationStep(AutomationActionType.WAIT, delayMs = 1100L),
                    AutomationStep(AutomationActionType.CLICK_TEXT, target = "Bağlı cihazlar"),
                    AutomationStep(AutomationActionType.WAIT, delayMs = 700L),
                    AutomationStep(AutomationActionType.CLICK_TEXT, target = "Bluetooth")
                )
            )
        ),
        AutomationMacroEntity(
            title = "Hızlı Wi-Fi Paneli",
            triggerPhrase = "ayarlara girip ağ ayarlarını aç",
            targetPackageName = "com.android.settings",
            targetAppLabel = "Ayarlar",
            stepsSerialized = StepSerializer.encode(
                listOf(
                    AutomationStep(AutomationActionType.OPEN_APP, target = "Ayarlar"),
                    AutomationStep(AutomationActionType.WAIT, delayMs = 1000L),
                    AutomationStep(AutomationActionType.CLICK_TEXT, target = "Ağ ve internet")
                )
            )
        )
    )

    private fun defaultOfflineSites(): List<CachedSiteEntity> = listOf(
        CachedSiteEntity(
            url = "https://kotlinlang.org",
            title = "Kotlin Programlama Dili Resmi Sitesi",
            domain = "kotlinlang.org",
            language = "tr",
            category = "Yazılım & Mobil",
            isPreseeded = true,
            rawContent = """
                Kotlin, JetBrains tarafından geliştirilen modern, statik tipli ve çoklu platform destekli bir programlama dilidir.
                Android uygulama geliştirme için Google tarafından resmi öncelikli dil olarak önerilir.
                Null güvenliği (null safety) sayesinde çalışma zamanında oluşan NullPointerException hatalarını derleme aşamasında önler.
                Coroutines ve Flow yapıları ile asenkron ve paralel programlamayı sadeleştirir ve yüksek performans sunar.
                Kotlin Multiplatform sayesinde Android, iOS, masaüstü ve sunucu tarafında ortak iş mantığı paylaşılabilir.
                Jetpack Compose ile tamamen deklaratif ve hızlı kullanıcı arayüzleri oluşturmak mümkündür.
                Java ile yüzde yüz uyumludur ve mevcut Java kütüphaneleri doğrudan Kotlin projelerinde kullanılabilir.
            """.trimIndent()
        ),
        CachedSiteEntity(
            url = "https://python.org",
            title = "Python Resmi Dokümantasyon ve Topluluk",
            domain = "python.org",
            language = "tr",
            category = "Yazılım & Yapay Zeka",
            isPreseeded = true,
            rawContent = """
                Python, okunabilir sözdizimine odaklanan yüksek seviyeli ve yorumlanan bir programlama dilidir.
                Yapay zeka, makine öğrenmesi, veri bilimi ve otomasyon betiklerinde dünya genelinde en yaygın kullanılan dildir.
                PyTorch, TensorFlow, NumPy ve Pandas gibi devasa bilimsel kütüphane ekosistemine sahiptir.
                Dinamik tipli yapısı hızlı prototipleme sağlar ancak büyük ölçekli sistemlerde tip ipuçları (type hints) önerilir.
                Mobil cihazlarda doğrudan yerel arayüz geliştirme için genellikle tercih edilmez, daha çok sunucu ve veri işleme alanında öne çıkar.
                Açık kaynaklı topluluğu sayesinde binlerce ücretsiz paket PyPI üzerinden kurulabilir.
            """.trimIndent()
        ),
        CachedSiteEntity(
            url = "https://developer.android.com",
            title = "Android Developers — Jetpack & Performans",
            domain = "developer.android.com",
            language = "tr",
            category = "Mobil Sistemler",
            isPreseeded = true,
            rawContent = """
                Android Developers portalı modern mobil uygulamalar için resmi mimari rehberleri ve API dokümanlarını sunar.
                Jetpack Compose, Room veritabanı, WorkManager ve AccessibilityService gibi bileşenlerle güçlü yerel deneyimler geliştirilir.
                Gizlilik ve pil optimizasyonu için Foreground Service tiplerinin açıkça tanımlanması zorunludur.
                Cihaz içi yapay zeka ve çevrimdışı ses işleme, verilerin sunucuya gönderilmeden cihazda kalmasını sağlar.
                Material Design 3 ile uyarlanabilir telefon, tablet ve katlanabilir ekran arayüzleri tasarlanır.
            """.trimIndent()
        ),
        CachedSiteEntity(
            url = "https://rust-lang.org",
            title = "Rust Systems Programming Language",
            domain = "rust-lang.org",
            language = "en",
            category = "Systems Engineering",
            isPreseeded = true,
            rawContent = """
                Rust is a systems programming language focused on memory safety, concurrency, and blazing speed without a garbage collector.
                The ownership and borrow checker model guarantees thread safety and prevents data races at compile time.
                Rust compiles to native machine code via LLVM and is widely used in operating systems, embedded AI runtimes, and WebAssembly.
                Its steep learning curve requires understanding lifetimes and borrowing rules, yet yields highly reliable production binaries.
                Cargo serves as the integrated build tool, test runner, and dependency manager across crates.io.
            """.trimIndent()
        ),
        CachedSiteEntity(
            url = "https://tr.wikipedia.org/wiki/Yapay_zeka",
            title = "Yapay Zeka — Çevrimdışı Ansiklopedi Özeti",
            domain = "tr.wikipedia.org",
            language = "tr",
            category = "Bilim & Teknoloji",
            isPreseeded = true,
            rawContent = """
                Yapay zeka, insan zekasına özgü algılama, öğrenme, akıl yürütme ve karar verme süreçlerini bilgisayar sistemlerine kazandıran bilim dalıdır.
                Doğal dil işleme, ses tanıma, bilgisayarla görü ve otonom görev planlama temel alt alanları oluşturur.
                Uç bilişim (Edge AI) yaklaşımı sayesinde dil ve ses modelleri bulut sunucuya bağlanmadan doğrudan akıllı telefonlarda çalışabilir.
                Çevrimdışı çalışan yapay zeka sistemleri kullanıcı gizliliğini maksimum düzeyde korur ve internet kesintilerinden etkilenmez.
                Kuantizasyon teknikleri büyük modellerin bellek tüketimini azaltarak mobil işlemcilerde düşük gecikme sağlar.
            """.trimIndent()
        ),
        CachedSiteEntity(
            url = "https://sqlite.org",
            title = "SQLite — Gömülü Çevrimdışı Veritabanı",
            domain = "sqlite.org",
            language = "tr",
            category = "Veri & Depolama",
            isPreseeded = true,
            rawContent = """
                SQLite, sunucu kurulumu gerektirmeyen, tamamen dosya tabanlı ve sıfır yapılandırmalı bir ilişkisel veritabanı motorudur.
                Dünyada en yaygın dağıtılan veritabanıdır ve tüm Android cihazların yerel depolama altyapısında yerleşik olarak bulunur.
                ACID uyumlu işlemler sunarak uygulama kapansa bile verilerin bozulmasını önler.
                İnternet bağlantısı olmadan çalışan uygulamalarda metin, model metadata ve kullanıcı kayıtlarını güvenle saklar.
            """.trimIndent()
        )
    )
}
