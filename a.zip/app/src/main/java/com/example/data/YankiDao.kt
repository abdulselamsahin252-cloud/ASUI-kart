package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface YankiDao {

    // Language Models
    @Query("SELECT * FROM language_models ORDER BY isExternalImport ASC, id ASC")
    fun observeLanguageModels(): Flow<List<LanguageModelEntity>>

    @Query("SELECT * FROM language_models")
    suspend fun getAllModelsOnce(): List<LanguageModelEntity>

    @Query("SELECT * FROM language_models WHERE id = :id LIMIT 1")
    suspend fun getModelById(id: String): LanguageModelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertModels(models: List<LanguageModelEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertModel(model: LanguageModelEntity)

    @Query("DELETE FROM language_models WHERE id = :id")
    suspend fun deleteModelById(id: String)

    // Wake Word Profiles
    @Query("SELECT * FROM wake_word_profiles ORDER BY isActive DESC, createdAt DESC")
    fun observeWakeWords(): Flow<List<WakeWordProfileEntity>>

    @Query("SELECT * FROM wake_word_profiles WHERE isActive = 1 LIMIT 1")
    suspend fun getActiveWakeWordOnce(): WakeWordProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWakeWord(profile: WakeWordProfileEntity): Long

    @Query("UPDATE wake_word_profiles SET isActive = 0")
    suspend fun deactivateAllWakeWords()

    @Query("UPDATE wake_word_profiles SET isActive = 1 WHERE id = :id")
    suspend fun activateWakeWordById(id: Int)

    @Query("DELETE FROM wake_word_profiles WHERE id = :id")
    suspend fun deleteWakeWordById(id: Int)

    // Automation Macros
    @Query("SELECT * FROM automation_macros ORDER BY createdAt DESC")
    fun observeMacros(): Flow<List<AutomationMacroEntity>>

    @Query("SELECT * FROM automation_macros")
    suspend fun getAllMacrosOnce(): List<AutomationMacroEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMacro(macro: AutomationMacroEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMacros(macros: List<AutomationMacroEntity>)

    @Query("DELETE FROM automation_macros WHERE id = :id")
    suspend fun deleteMacroById(id: Int)

    // Cached Offline Sites
    @Query("SELECT * FROM cached_sites ORDER BY isPreseeded ASC, cachedAt DESC")
    fun observeCachedSites(): Flow<List<CachedSiteEntity>>

    @Query("SELECT * FROM cached_sites")
    suspend fun getAllCachedSitesOnce(): List<CachedSiteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSite(site: CachedSiteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSites(sites: List<CachedSiteEntity>)

    @Query("DELETE FROM cached_sites WHERE id = :id")
    suspend fun deleteSiteById(id: Int)

    // Command Logs
    @Query("SELECT * FROM command_logs ORDER BY timestamp DESC LIMIT 100")
    fun observeCommandLogs(): Flow<List<CommandLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommandLog(log: CommandLogEntity)

    @Query("DELETE FROM command_logs")
    suspend fun clearCommandLogs()
}
