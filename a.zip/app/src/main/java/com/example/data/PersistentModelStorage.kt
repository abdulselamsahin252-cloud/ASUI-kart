package com.example.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class DiscoveredDeviceModel(
    val fileName: String,
    val localCacheFile: File,
    val sizeBytes: Long,
    val sourceLabel: String
)

/**
 * Play-Policy-Compliant Persistent Device Model Storage.
 *
 * Mirrors installed TR/EN semantic packs and downloaded/imported .gguf models to
 * shared device storage (Download/Axiom/Models) so models survive app uninstalls
 * and can be auto-discovered on app updates or 1-tap re-linked after fresh installs
 * via Storage Access Framework (no broad storage permissions required).
 */
object PersistentModelStorage {

    const val RELATIVE_DIR = "Axiom/Models"

    fun sharedDownloadsDir(): File {
        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return File(downloads, RELATIVE_DIR)
    }

    /**
     * Mirrors a local model file (text lexicon or binary GGUF) into shared Download/Axiom/Models
     * using zero-permission MediaStore.Downloads on Android 10+ or direct file on Android 9-.
     */
    suspend fun mirrorModelToSharedStorage(
        context: Context,
        sourceFile: File,
        targetFileName: String
    ): String? = withContext(Dispatchers.IO) {
        if (!sourceFile.exists() || sourceFile.length() == 0L) return@withContext null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching {
                val resolver = context.contentResolver
                val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/$RELATIVE_DIR"

                // Remove older entry with the same display name in our folder to keep 1 clean copy
                val selection = "${MediaStore.Downloads.DISPLAY_NAME} = ? AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?"
                resolver.delete(collection, selection, arrayOf(targetFileName, "%$RELATIVE_DIR%"))

                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, targetFileName)
                    put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val itemUri = resolver.insert(collection, values) ?: return@runCatching null
                resolver.openOutputStream(itemUri)?.use { out ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(out, bufferSize = 64 * 1024)
                    }
                }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                "İndirilenler/$RELATIVE_DIR/$targetFileName"
            }.getOrNull()
        } else {
            runCatching {
                val dir = sharedDownloadsDir().apply { mkdirs() }
                val dest = File(dir, targetFileName)
                sourceFile.copyTo(dest, overwrite = true)
                dest.absolutePath
            }.getOrNull()
        }
    }

    /**
     * Removes a mirrored file from shared Download/Axiom/Models when user explicitly uninstalls a model.
     */
    suspend fun removeFromSharedStorage(context: Context, targetFileName: String) = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching {
                val resolver = context.contentResolver
                val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val selection = "${MediaStore.Downloads.DISPLAY_NAME} = ? AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?"
                resolver.delete(collection, selection, arrayOf(targetFileName, "%$RELATIVE_DIR%"))
            }
        } else {
            runCatching {
                File(sharedDownloadsDir(), targetFileName).delete()
            }
        }
    }

    /**
     * Automatically scans shared Downloads (MediaStore + direct folder) and any persisted SAF tree URI
     * to restore models that exist on device (e.g., after an update or reinstall).
     */
    suspend fun scanPersistentDeviceModels(
        context: Context,
        persistedTreeUriString: String
    ): List<DiscoveredDeviceModel> = withContext(Dispatchers.IO) {
        val found = linkedMapOf<String, DiscoveredDeviceModel>()
        val cacheRoot = File(context.filesDir, "models_restored").apply { mkdirs() }

        // 1. Scan persisted SAF tree URI (survives across clean reinstall once linked)
        if (persistedTreeUriString.isNotBlank()) {
            runCatching {
                val treeUri = Uri.parse(persistedTreeUriString)
                scanDocumentTreeRecursive(context, DocumentFile.fromTreeUri(context, treeUri), cacheRoot, found)
            }
        }

        // 2. Query MediaStore.Downloads for Axiom/Models entries (same-UID updates / auto-restored entries)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching {
                val resolver = context.contentResolver
                val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val projection = arrayOf(
                    MediaStore.Downloads._ID,
                    MediaStore.Downloads.DISPLAY_NAME,
                    MediaStore.Downloads.SIZE,
                    MediaStore.Downloads.RELATIVE_PATH
                )
                val selection = "${MediaStore.Downloads.RELATIVE_PATH} LIKE ?"
                resolver.query(collection, projection, selection, arrayOf("%$RELATIVE_DIR%"), null)?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(nameCol) ?: continue
                        if (!isSupportedModelFile(name) || found.containsKey(name)) continue
                        val uri = Uri.withAppendedPath(collection, cursor.getLong(idCol).toString())
                        val size = cursor.getLong(sizeCol)
                        val dest = File(cacheRoot, name)
                        if (!dest.exists() || dest.length() != size) {
                            resolver.openInputStream(uri)?.use { input ->
                                dest.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                            }
                        }
                        if (dest.exists() && dest.length() > 0L) {
                            found[name] = DiscoveredDeviceModel(
                                fileName = name,
                                localCacheFile = dest,
                                sizeBytes = dest.length(),
                                sourceLabel = "MediaStore İndirilenler/$RELATIVE_DIR"
                            )
                        }
                    }
                }
            }
        }

        // 3. Direct File scan on Download/Axiom/Models (works on Android 9- or permissive ROMs)
        runCatching {
            val dir = sharedDownloadsDir()
            if (dir.exists() && dir.isDirectory && dir.canRead()) {
                dir.listFiles()?.forEach { file ->
                    if (file.isFile && isSupportedModelFile(file.name) && !found.containsKey(file.name)) {
                        val dest = File(cacheRoot, file.name)
                        if (!dest.exists() || dest.length() != file.length()) {
                            file.copyTo(dest, overwrite = true)
                        }
                        found[file.name] = DiscoveredDeviceModel(
                            fileName = file.name,
                            localCacheFile = dest,
                            sizeBytes = dest.length(),
                            sourceLabel = dir.absolutePath
                        )
                    }
                }
            }
        }

        found.values.toList()
    }

    private fun scanDocumentTreeRecursive(
        context: Context,
        dir: DocumentFile?,
        cacheRoot: File,
        found: MutableMap<String, DiscoveredDeviceModel>
    ) {
        if (dir == null || !dir.isDirectory) return
        dir.listFiles().forEach { child ->
            if (child.isDirectory) {
                scanDocumentTreeRecursive(context, child, cacheRoot, found)
            } else if (child.isFile) {
                val name = child.name ?: return@forEach
                if (!isSupportedModelFile(name) || found.containsKey(name)) return@forEach
                val dest = File(cacheRoot, name)
                val expectedSize = child.length()
                if (!dest.exists() || (expectedSize > 0L && dest.length() != expectedSize)) {
                    runCatching {
                        context.contentResolver.openInputStream(child.uri)?.use { input ->
                            dest.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                        }
                    }
                }
                if (dest.exists() && dest.length() > 0L) {
                    found[name] = DiscoveredDeviceModel(
                        fileName = name,
                        localCacheFile = dest,
                        sizeBytes = dest.length(),
                        sourceLabel = "Cihaz Model Klasörü"
                    )
                }
            }
        }
    }

    private fun isSupportedModelFile(name: String): Boolean {
        val lower = name.lowercase()
        return lower.endsWith(".yanki_model") ||
            lower.endsWith(".yanki_bin") ||
            lower.endsWith(".gguf") ||
            lower.endsWith(".tflite") ||
            lower.endsWith(".bin")
    }
}
