package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "yanki_preferences")

data class UserSettings(
    val offlineShieldEnabled: Boolean = true,
    val wakeWordServiceEnabled: Boolean = false,
    val autoStartOnBoot: Boolean = false,
    val wakeSensitivity: Float = 0.82f,
    val ignoreWakeDuringMedia: Boolean = true,
    val strictSpeakerVerification: Boolean = true,
    val speakerThreshold: Float = 0.82f,
    val activeSpeechLocale: String = "tr-TR",
    val ttsAutoSpeak: Boolean = true,
    val modelOnboardingDismissed: Boolean = false,
    val darkTheme: Boolean = true,
    val activePowerfulLlmId: String = "llm_gemma3_1b_q4"
)

class AppPreferences(private val context: Context) {

    private object Keys {
        val OFFLINE_SHIELD = booleanPreferencesKey("offline_shield_enabled")
        val WAKE_SERVICE = booleanPreferencesKey("wake_word_service_enabled")
        val AUTO_BOOT = booleanPreferencesKey("auto_start_on_boot")
        val WAKE_SENSITIVITY = floatPreferencesKey("wake_sensitivity")
        val IGNORE_DURING_MEDIA = booleanPreferencesKey("ignore_wake_during_media")
        val STRICT_SPEAKER = booleanPreferencesKey("strict_speaker_verification")
        val SPEAKER_THRESHOLD = floatPreferencesKey("speaker_threshold")
        val SPEECH_LOCALE = stringPreferencesKey("active_speech_locale")
        val TTS_AUTO_SPEAK = booleanPreferencesKey("tts_auto_speak")
        val ONBOARDING_DISMISSED = booleanPreferencesKey("model_onboarding_dismissed")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val ACTIVE_POWERFUL_LLM = stringPreferencesKey("active_powerful_llm_id")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            offlineShieldEnabled = prefs[Keys.OFFLINE_SHIELD] ?: true,
            wakeWordServiceEnabled = prefs[Keys.WAKE_SERVICE] ?: false,
            autoStartOnBoot = prefs[Keys.AUTO_BOOT] ?: false,
            wakeSensitivity = (prefs[Keys.WAKE_SENSITIVITY] ?: 0.82f).coerceIn(0.60f, 0.96f),
            ignoreWakeDuringMedia = prefs[Keys.IGNORE_DURING_MEDIA] ?: true,
            strictSpeakerVerification = prefs[Keys.STRICT_SPEAKER] ?: true,
            speakerThreshold = (prefs[Keys.SPEAKER_THRESHOLD] ?: 0.82f).coerceIn(0.72f, 0.94f),
            activeSpeechLocale = prefs[Keys.SPEECH_LOCALE] ?: "tr-TR",
            ttsAutoSpeak = prefs[Keys.TTS_AUTO_SPEAK] ?: true,
            modelOnboardingDismissed = prefs[Keys.ONBOARDING_DISMISSED] ?: false,
            darkTheme = prefs[Keys.DARK_THEME] ?: true,
            activePowerfulLlmId = prefs[Keys.ACTIVE_POWERFUL_LLM] ?: "llm_gemma3_1b_q4"
        )
    }

    suspend fun setOfflineShield(enabled: Boolean) {
        context.dataStore.edit { it[Keys.OFFLINE_SHIELD] = enabled }
    }

    suspend fun setWakeWordServiceEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.WAKE_SERVICE] = enabled }
    }

    suspend fun setAutoStartOnBoot(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_BOOT] = enabled }
    }

    suspend fun setWakeSensitivity(value: Float) {
        context.dataStore.edit { it[Keys.WAKE_SENSITIVITY] = value.coerceIn(0.60f, 0.96f) }
    }

    suspend fun setIgnoreWakeDuringMedia(ignore: Boolean) {
        context.dataStore.edit { it[Keys.IGNORE_DURING_MEDIA] = ignore }
    }

    suspend fun setStrictSpeakerVerification(strict: Boolean) {
        context.dataStore.edit { it[Keys.STRICT_SPEAKER] = strict }
    }

    suspend fun setSpeakerThreshold(value: Float) {
        context.dataStore.edit { it[Keys.SPEAKER_THRESHOLD] = value.coerceIn(0.72f, 0.94f) }
    }

    suspend fun setSpeechLocale(locale: String) {
        context.dataStore.edit { it[Keys.SPEECH_LOCALE] = locale }
    }

    suspend fun setTtsAutoSpeak(enabled: Boolean) {
        context.dataStore.edit { it[Keys.TTS_AUTO_SPEAK] = enabled }
    }

    suspend fun setModelOnboardingDismissed(dismissed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DISMISSED] = dismissed }
    }

    suspend fun setDarkTheme(dark: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = dark }
    }

    suspend fun setActivePowerfulLlmId(id: String) {
        context.dataStore.edit { it[Keys.ACTIVE_POWERFUL_LLM] = id }
    }
}
