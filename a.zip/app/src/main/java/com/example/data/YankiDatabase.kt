package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LanguageModelEntity::class,
        WakeWordProfileEntity::class,
        AutomationMacroEntity::class,
        CachedSiteEntity::class,
        CommandLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class YankiDatabase : RoomDatabase() {
    abstract fun yankiDao(): YankiDao

    companion object {
        @Volatile
        private var INSTANCE: YankiDatabase? = null

        fun getInstance(context: Context): YankiDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    YankiDatabase::class.java,
                    "yanki_offline_ai.db"
                ).fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
