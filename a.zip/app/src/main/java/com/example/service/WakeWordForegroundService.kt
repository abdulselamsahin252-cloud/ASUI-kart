package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppPreferences
import com.example.data.CommandLogEntity
import com.example.data.YankiDatabase
import com.example.data.YankiRepository
import com.example.engine.AcousticWakeWordEngine
import com.example.engine.AssistantRuntimeHub
import com.example.engine.DeviceControlExecutor
import com.example.engine.NaturalVoiceSpeaker
import com.example.engine.OfflineNluEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Always-On Background Foreground Service (foregroundServiceType="microphone").
 * Continues listening for the user's recorded wake-word even when the app Activity is closed.
 * Upon match: triggers 1mm RGB edge strip (no giant Google-Assistant-style screen),
 * runs offline SpeechRecognizer + OfflineNluEngine, and responds via fluid NaturalVoiceSpeaker.
 */
class WakeWordForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var monitorJob: Job? = null

    private lateinit var repository: YankiRepository
    private lateinit var executor: DeviceControlExecutor
    private lateinit var naturalSpeaker: NaturalVoiceSpeaker

    override fun onCreate() {
        super.onCreate()
        val db = YankiDatabase.getInstance(this)
        val prefs = AppPreferences(this)
        repository = YankiRepository(this, db.yankiDao(), prefs)
        executor = DeviceControlExecutor(this)
        naturalSpeaker = NaturalVoiceSpeaker(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        val hasMicPerm = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMicPerm) {
            AssistantRuntimeHub.updateWakeState {
                it.copy(
                    isBackgroundServiceRunning = false,
                    statusMessage = "Mikrofon izni verilmedi"
                )
            }
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification("Uyandırma kelimesi arka planda dinleniyor…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        startWakeWordLoop()
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startWakeWordLoop() {
        if (monitorJob?.isActive == true) return
        AssistantRuntimeHub.updateWakeState {
            it.copy(
                isBackgroundServiceRunning = true,
                statusMessage = "Arka planda aktif dinleme (Uygulama kapansa da çalışır)"
            )
        }

        monitorJob = serviceScope.launch {
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            val cpuWakeLock = pm.newWakeLock(
                android.os.PowerManager.PARTIAL_WAKE_LOCK,
                "Axiom:WakeWordCpuLock"
            ).apply {
                setReferenceCounted(false)
                runCatching { acquire(12 * 60 * 60 * 1000L) }
            }
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

            val sampleRate = AcousticWakeWordEngine.SAMPLE_RATE
            val bufferFrames = (sampleRate * 1.8f).toInt()
            val ringBuffer = ShortArray(bufferFrames)
            var ringPos = 0

            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            val recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 2
            )

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                AssistantRuntimeHub.updateWakeState {
                    it.copy(
                        isBackgroundServiceRunning = false,
                        statusMessage = "Mikrofon donanımı açılamadı"
                    )
                }
                recorder.release()
                runCatching { if (cpuWakeLock.isHeld) cpuWakeLock.release() }
                stopSelf()
                return@launch
            }

            val chunk = ShortArray(1024)
            var lastTriggerTime = 0L
            var voicedFrames = 0
            var consecutiveMatches = 0
            var ambientFloorDb = -52f

            try {
                recorder.startRecording()
                while (isActive) {
                    val read = recorder.read(chunk, 0, chunk.size)
                    if (read <= 0) {
                        delay(40)
                        continue
                    }

                    for (i in 0 until read) {
                        ringBuffer[ringPos] = chunk[i]
                        ringPos = (ringPos + 1) % bufferFrames
                    }

                    val rmsDb = AcousticWakeWordEngine.computeRmsDb(chunk, read)
                    val bins = AcousticWakeWordEngine.computeSpectrumBins(chunk, read, 16)

                    val activeProfile = repository.getActiveWakeWord()
                    val settings = repository.preferences.settingsFlow.first()

                    // If Reels / TikTok / YouTube / Music is actively playing from device speaker,
                    // suppress acoustic wake triggers to prevent false activations.
                    val isMediaPlaying = settings.ignoreWakeDuringMedia && audioManager.isMusicActive
                    if (isMediaPlaying) {
                        voicedFrames = 0
                        consecutiveMatches = 0
                        AssistantRuntimeHub.updateWakeState {
                            it.copy(
                                isBackgroundServiceRunning = true,
                                activeWakePhrase = activeProfile?.phrase ?: "Önce uyandırma kelimesi kaydedin",
                                currentRmsDb = rmsDb,
                                spectrumBins = bins,
                                lastMatchConfidence = 0f,
                                statusMessage = "Medya / Reels sesi aktif — yanlış tetikleme engellendi"
                            )
                        }
                        continue
                    }

                    // Track adaptive room noise floor; require >= +11 dB burst above background
                    if (rmsDb < -30f) {
                        ambientFloorDb = (ambientFloorDb * 0.94f + rmsDb * 0.06f).coerceIn(-58f, -26f)
                    }
                    val speechGateDb = maxOf(-29f, ambientFloorDb + 11f)

                    if (rmsDb > speechGateDb) {
                        voicedFrames++
                    } else {
                        voicedFrames = (voicedFrames - 1).coerceAtLeast(0)
                        if (voicedFrames == 0) consecutiveMatches = 0
                    }

                    var confidence = 0f
                    var speakerSim = 0f
                    if (activeProfile != null && voicedFrames >= 4) {
                        val linearWindow = ShortArray(bufferFrames)
                        val tailLen = bufferFrames - ringPos
                        System.arraycopy(ringBuffer, ringPos, linearWindow, 0, tailLen)
                        System.arraycopy(ringBuffer, 0, linearWindow, tailLen, ringPos)

                        val targetSig = AcousticWakeWordEngine.parseSignature(activeProfile.signatureCsv)
                        confidence = AcousticWakeWordEngine.matchConfidence(
                            windowSamples = linearWindow,
                            targetSignature = targetSig,
                            targetDurationMs = activeProfile.durationMs
                        )
                        val activeSlice = AcousticWakeWordEngine.extractActiveSpeechWindow(
                            linearWindow,
                            activeProfile.durationMs
                        ) ?: linearWindow
                        speakerSim = AcousticWakeWordEngine.verifySpeakerSimilarity(activeSlice, targetSig)

                        val speakerThreshold = settings.speakerThreshold.coerceIn(0.72f, 0.94f)
                        val speakerPass = !settings.strictSpeakerVerification || speakerSim >= speakerThreshold

                        if (confidence >= settings.wakeSensitivity && speakerPass) {
                            consecutiveMatches++
                        } else {
                            consecutiveMatches = 0
                        }
                    }

                    val speakerThreshold = settings.speakerThreshold.coerceIn(0.72f, 0.94f)
                    val speakerVerified = speakerSim >= speakerThreshold
                    val speakerGateOk = !settings.strictSpeakerVerification || speakerVerified
                    val foreignVoiceRejected = activeProfile != null &&
                        settings.strictSpeakerVerification &&
                        confidence >= settings.wakeSensitivity * 0.92f &&
                        !speakerVerified

                    AssistantRuntimeHub.updateWakeState {
                        it.copy(
                            isBackgroundServiceRunning = true,
                            activeWakePhrase = activeProfile?.phrase ?: "Önce uyandırma kelimesi kaydedin",
                            currentRmsDb = rmsDb,
                            spectrumBins = bins,
                            lastMatchConfidence = confidence,
                            lastSpeakerSimilarity = speakerSim,
                            lastSpeakerVerified = speakerVerified,
                            statusMessage = if (foreignVoiceRejected) {
                                "Yabancı ses reddedildi (%${(speakerSim * 100).toInt()} < %${(speakerThreshold * 100).toInt()}) — Sadece kayıtlı sese yanıt verilir"
                            } else {
                                it.statusMessage
                            }
                        )
                    }

                    val now = System.currentTimeMillis()
                    if (activeProfile != null &&
                        voicedFrames >= 5 &&
                        consecutiveMatches >= 2 &&
                        speakerGateOk &&
                        confidence >= settings.wakeSensitivity &&
                        now - lastTriggerTime > 4500L
                    ) {
                        lastTriggerTime = now
                        voicedFrames = 0
                        consecutiveMatches = 0
                        // Pause AudioRecord briefly so SpeechRecognizer can exclusively access the mic
                        runCatching { recorder.stop() }
                        handleWakeTriggered(
                            phrase = activeProfile.phrase,
                            locale = settings.activeSpeechLocale,
                            speakerSimilarity = speakerSim,
                            speakerVerified = speakerVerified
                        )
                        delay(5200L)
                        runCatching { recorder.startRecording() }
                    }
                }
            } finally {
                runCatching { recorder.stop() }
                recorder.release()
                runCatching { if (cpuWakeLock.isHeld) cpuWakeLock.release() }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun handleWakeTriggered(
        phrase: String,
        locale: String,
        speakerSimilarity: Float,
        speakerVerified: Boolean
    ) {
        triggerHapticAndChime()
        val isLocked = com.example.engine.SecurityVaultManager.isDeviceCurrentlyLocked(this)
        if (isLocked) {
            runCatching {
                val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                val wl = pm.newWakeLock(
                    android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK or android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "Axiom:LockScreenWake"
                )
                wl.acquire(15_000L)
            }
            // On locked screens ONLY, Android 11+ requires a visible showWhenLocked Activity to allow
            // SpeechRecognizer mic capture over keyguard. MainActivity renders only a minimal lock-edge pill
            // and auto-dismisses when finished — unlocked screens remain 100% popup-free!
            val lockWakeIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(EXTRA_WAKE_TRIGGERED, true)
                putExtra(EXTRA_LOCK_SCREEN_MINI_MODE, true)
                putExtra(EXTRA_WAKE_PHRASE, phrase)
            }
            runCatching { startActivity(lockWakeIntent) }
        }

        AssistantRuntimeHub.updateWakeState {
            it.copy(
                isListeningForCommand = true,
                lastSpeakerSimilarity = speakerSimilarity,
                lastSpeakerVerified = speakerVerified,
                lastTriggeredOnLockScreen = isLocked,
                lastTriggeredTimestamp = System.currentTimeMillis(),
                statusMessage = "\"$phrase\" algılandı (Ses uyumu %${(speakerSimilarity * 100).toInt()})! 1mm RGB şerit ile dinleniyor…"
            )
        }
        AssistantRuntimeHub.emitWakeTriggered(phrase)
        updateNotification("\"$phrase\" duyuldu — Komut dinleniyor…")

        // Activate 1mm RGB outer border silently instead of popping up a full-screen Assistant screen!
        AssistantAccessibilityService.instance?.showRgbEdgeBorder(true)

        serviceScope.launch(Dispatchers.Main) {
            if (isLocked) {
                delay(420L) // allow showWhenLocked Activity & screen wake to grant mic focus
            }
            startOfflineCommandRecognition(locale, phrase, isLocked = isLocked, attempt = 1)
        }
    }

    private fun startOfflineCommandRecognition(
        locale: String,
        wakePhrase: String,
        isLocked: Boolean,
        attempt: Int
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            AssistantAccessibilityService.instance?.showRgbEdgeBorder(false)
            if (isLocked) AssistantRuntimeHub.emitLockScreenSessionFinished()
            AssistantRuntimeHub.updateWakeState {
                it.copy(isListeningForCommand = false, statusMessage = "Sistem konuşma tanıyıcı bulunamadı")
            }
            return
        }

        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                recognizer.destroy()
                // Retry once on lock screen if mic/recognizer was transitioning from screen-off
                if (isLocked && attempt == 1 && (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_AUDIO)) {
                    serviceScope.launch(Dispatchers.Main) {
                        delay(350L)
                        startOfflineCommandRecognition(locale, wakePhrase, isLocked = true, attempt = 2)
                    }
                    return
                }
                AssistantAccessibilityService.instance?.showRgbEdgeBorder(false)
                if (isLocked) AssistantRuntimeHub.emitLockScreenSessionFinished()
                AssistantRuntimeHub.updateWakeState {
                    it.copy(
                        isListeningForCommand = false,
                        statusMessage = "Arka planda \"$wakePhrase\" bekleniyor"
                    )
                }
                updateNotification("Uyandırma kelimesi dinleniyor: \"$wakePhrase\"")
            }

            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                recognizer.destroy()
                AssistantAccessibilityService.instance?.showRgbEdgeBorder(false)
                if (spoken.isNotBlank()) {
                    executeSpokenCommandInBackground(spoken, wasLocked = isLocked)
                } else if (isLocked) {
                    AssistantRuntimeHub.emitLockScreenSessionFinished()
                }
                AssistantRuntimeHub.updateWakeState {
                    it.copy(
                        isListeningForCommand = false,
                        statusMessage = if (spoken.isNotBlank()) "Yürütüldü: \"$spoken\"" else "Arka planda \"$wakePhrase\" bekleniyor"
                    )
                }
                updateNotification("Uyandırma kelimesi dinleniyor: \"$wakePhrase\"")
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        recognizer.startListening(recIntent)
    }

    private fun executeSpokenCommandInBackground(spokenText: String, wasLocked: Boolean) {
        serviceScope.launch {
            val intent = OfflineNluEngine.parse(spokenText)
            val macros = repository.getAllMacros()
            val sites = repository.getAllCachedSites()
            val models = repository.languageModels.first()
                .filter { it.status == com.example.data.ModelStatus.ACTIVE.name }
                .map { it.name }
            val currentSettings = repository.preferences.settingsFlow.first()

            if (wasLocked && intent is com.example.engine.CommandIntent.UnlockDeviceWithVoice) {
                AssistantRuntimeHub.emitRequestKeyguardDismiss()
                delay(320L)
            } else if (wasLocked) {
                // Dismiss mini lock overlay cleanly after execution (unless opening an app)
                AssistantRuntimeHub.emitLockScreenSessionFinished()
            }

            val outcome = executor.executeIntent(intent, macros, sites, models)
            repository.logCommand(
                CommandLogEntity(
                    userQuery = spokenText,
                    intentTag = outcome.intentTag,
                    responseSummary = outcome.summaryText,
                    stepsJson = outcome.steps.joinToString("\n"),
                    executionSuccess = outcome.success,
                    triggeredByWakeWord = true
                )
            )
            if (currentSettings.ttsAutoSpeak) {
                naturalSpeaker.speakFluidly(outcome.summaryText, currentSettings.activeSpeechLocale)
            }
            AssistantRuntimeHub.emitBackgroundCommandText(spokenText)
        }
    }

    private fun triggerHapticAndChime() {
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(140L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(140L)
            }
        }
        runCatching {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 180)
            serviceScope.launch {
                delay(240L)
                tg.release()
            }
        }
    }

    private fun stopSelfCleanly() {
        monitorJob?.cancel()
        AssistantRuntimeHub.updateWakeState {
            it.copy(
                isBackgroundServiceRunning = false,
                isListeningForCommand = false,
                currentRmsDb = -60f,
                statusMessage = "Arka plan dinleyici durduruldu"
            )
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateNotification(content: String) {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.notify(NOTIFICATION_ID, buildNotification(content))
    }

    private fun buildNotification(content: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, WakeWordForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Axiom — Çevrimdışı Dinleyici")
            .setContentText(content)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "Durdur", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Axiom Uyandırma Dinleyicisi",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Uygulama kapalıyken kayıtlı uyandırma kelimesini çevrimdışı dinler."
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        AssistantAccessibilityService.instance?.showRgbEdgeBorder(false)
        naturalSpeaker.shutdown()
        monitorJob?.cancel()
        serviceScope.cancel()
        AssistantRuntimeHub.updateWakeState {
            it.copy(isBackgroundServiceRunning = false, isListeningForCommand = false)
        }
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "yanki_wake_word_channel"
        const val NOTIFICATION_ID = 4102
        const val ACTION_STOP = "com.example.action.STOP_WAKE_SERVICE"
        const val EXTRA_WAKE_TRIGGERED = "extra_wake_triggered"
        const val EXTRA_LOCK_SCREEN_MINI_MODE = "extra_lock_screen_mini_mode"
        const val EXTRA_WAKE_PHRASE = "extra_wake_phrase"

        fun start(context: Context) {
            val intent = Intent(context, WakeWordForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, WakeWordForegroundService::class.java).apply { action = ACTION_STOP }
            )
        }
    }
}
