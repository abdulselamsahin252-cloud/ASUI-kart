package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.SweepGradient
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.LinearInterpolator
import com.example.data.AutomationActionType
import com.example.data.AutomationStep
import com.example.engine.AssistantRuntimeHub
import com.example.engine.NavAction
import com.example.engine.OfflineNluEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AssistantAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var rgbOverlayView: RgbEdgeOverlayView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AssistantRuntimeHub.setAccessibilityConnected(true)
        AssistantRuntimeHub.emitAutomationLog("Erişilebilirlik otomasyon motoru bağlandı.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event stream keeps rootInActiveWindow fresh for on-demand step execution.
    }

    override fun onInterrupt() {
        AssistantRuntimeHub.emitAutomationLog("Erişilebilirlik servisi kesintiye uğradı.")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideRgbEdgeBorderImmediate()
        instance = null
        AssistantRuntimeHub.setAccessibilityConnected(false)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideRgbEdgeBorderImmediate()
        instance = null
        AssistantRuntimeHub.setAccessibilityConnected(false)
        serviceScope.cancel()
        super.onDestroy()
    }

    /**
     * Shows or hides a non-blocking ~1mm (3.6dp) animated RGB strip around the entire screen
     * using TYPE_ACCESSIBILITY_OVERLAY so voice listening never pops up a giant modal.
     */
    fun showRgbEdgeBorder(visible: Boolean) {
        mainHandler.post {
            if (visible) {
                if (rgbOverlayView != null) return@post
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val view = RgbEdgeOverlayView(this)
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                runCatching {
                    wm.addView(view, lp)
                    rgbOverlayView = view
                }
            } else {
                hideRgbEdgeBorderImmediate()
            }
        }
    }

    private fun hideRgbEdgeBorderImmediate() {
        val view = rgbOverlayView ?: return
        rgbOverlayView = null
        view.stopAnimation()
        runCatching {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeViewImmediate(view)
        }
    }

    fun triggerPowerDialog(): Boolean {
        val ok = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        AssistantRuntimeHub.emitAutomationLog(
            if (ok) "Güç menüsü (Kapat / Yeniden Başlat) açıldı." else "Güç menüsü açılamadı."
        )
        return ok
    }

    fun triggerLockScreen(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val ok = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            AssistantRuntimeHub.emitAutomationLog(if (ok) "Ekran kilitlendi." else "Ekran kilitlenemedi.")
            ok
        } else {
            false
        }
    }

    fun triggerGlobalNav(action: NavAction): Boolean {
        val code = when (action) {
            NavAction.HOME -> GLOBAL_ACTION_HOME
            NavAction.BACK -> GLOBAL_ACTION_BACK
            NavAction.RECENTS -> GLOBAL_ACTION_RECENTS
            NavAction.QUICK_SETTINGS -> GLOBAL_ACTION_QUICK_SETTINGS
            NavAction.SCREENSHOT -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) GLOBAL_ACTION_TAKE_SCREENSHOT else GLOBAL_ACTION_HOME
        }
        return performGlobalAction(code)
    }

    fun executeSteps(steps: List<AutomationStep>, launchPackageFirst: String? = null) {
        serviceScope.launch {
            if (!launchPackageFirst.isNullOrBlank()) {
                val launchIntent = packageManager.getLaunchIntentForPackage(launchPackageFirst)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (launchIntent != null) {
                    startActivity(launchIntent)
                    AssistantRuntimeHub.emitAutomationLog("Uygulama başlatılıyor: $launchPackageFirst")
                    delay(1200L)
                }
            }

            for (step in steps) {
                when (step.type) {
                    AutomationActionType.OPEN_APP -> {
                        AssistantRuntimeHub.emitAutomationLog("Adım: ${step.target} açılıyor")
                    }
                    AutomationActionType.WAIT -> {
                        delay(step.delayMs.coerceIn(200L, 5000L))
                    }
                    AutomationActionType.CLICK_TEXT -> {
                        val clicked = clickNodeMatching(step.target)
                        AssistantRuntimeHub.emitAutomationLog(
                            if (clicked) "Tıklandı: \"${step.target}\"" else "Öğe bulunamadı: \"${step.target}\""
                        )
                        delay(step.delayMs.coerceIn(300L, 3000L))
                    }
                    AutomationActionType.INPUT_TEXT -> {
                        val typed = inputTextIntoNode(step.target, step.value)
                        AssistantRuntimeHub.emitAutomationLog(
                            if (typed) "Yazıldı: \"${step.value}\"" else "Yazı alanı bulunamadı"
                        )
                        delay(step.delayMs.coerceIn(300L, 3000L))
                    }
                    AutomationActionType.SCROLL_DOWN -> {
                        performScroll(forward = true)
                        AssistantRuntimeHub.emitAutomationLog("Aşağı kaydırıldı")
                        delay(600L)
                    }
                    AutomationActionType.SCROLL_UP -> {
                        performScroll(forward = false)
                        AssistantRuntimeHub.emitAutomationLog("Yukarı kaydırıldı")
                        delay(600L)
                    }
                    AutomationActionType.PRESS_BACK -> {
                        performGlobalAction(GLOBAL_ACTION_BACK)
                        AssistantRuntimeHub.emitAutomationLog("Geri tuşuna basıldı")
                        delay(500L)
                    }
                    AutomationActionType.PRESS_HOME -> {
                        performGlobalAction(GLOBAL_ACTION_HOME)
                        AssistantRuntimeHub.emitAutomationLog("Ana ekrana dönüldü")
                        delay(500L)
                    }
                }
            }
        }
    }

    /**
     * Attempts to toggle Wi-Fi or Bluetooth directly inside the active Settings/Panel window.
     */
    fun tryToggleSystemSwitchInPanel(keywords: List<String>, targetEnable: Boolean) {
        serviceScope.launch {
            delay(950L)
            val root = rootInActiveWindow ?: return@launch
            val switchNode = findToggleNode(root, keywords)
            if (switchNode != null) {
                val isChecked = switchNode.isChecked
                if (isChecked != targetEnable) {
                    clickNodeOrParent(switchNode)
                    AssistantRuntimeHub.emitAutomationLog(
                        "${keywords.first()} anahtarı ${if (targetEnable) "AÇILDI" else "KAPATILDI"}."
                    )
                } else {
                    AssistantRuntimeHub.emitAutomationLog(
                        "${keywords.first()} zaten ${if (targetEnable) "açık" else "kapalı"} durumda."
                    )
                }
            } else {
                clickNodeMatching(keywords.first())
            }
        }
    }

    private fun clickNodeMatching(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val targetNode = findNodeByText(root, query) ?: return false
        return clickNodeOrParent(targetNode)
    }

    private fun inputTextIntoNode(targetHint: String, text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val editNode = if (targetHint.isNotBlank()) {
            findNodeByText(root, targetHint) ?: findFirstEditable(root)
        } else {
            findFirstEditable(root)
        } ?: return false

        editNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return editNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun performScroll(forward: Boolean) {
        val root = rootInActiveWindow ?: return
        val scrollable = findFirstScrollable(root)
        if (scrollable != null) {
            scrollable.performAction(
                if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
            return
        }
        val path = Path().apply {
            if (forward) {
                moveTo(500f, 1400f)
                lineTo(500f, 500f)
            } else {
                moveTo(500f, 500f)
                lineTo(500f, 1400f)
            }
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 320L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun findNodeByText(node: AccessibilityNodeInfo, query: String): AccessibilityNodeInfo? {
        val qNorm = OfflineNluEngine.normalizeTrEn(query)
        val textNorm = OfflineNluEngine.normalizeTrEn(node.text?.toString().orEmpty())
        val descNorm = OfflineNluEngine.normalizeTrEn(node.contentDescription?.toString().orEmpty())
        if (qNorm.isNotBlank() && (textNorm.contains(qNorm) || descNorm.contains(qNorm))) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val match = findNodeByText(child, query)
            if (match != null) return match
        }
        return null
    }

    private fun findToggleNode(node: AccessibilityNodeInfo, keywords: List<String>): AccessibilityNodeInfo? {
        val label = findNodeByText(node, keywords.first())
        val parent = label?.parent
        if (parent != null) {
            for (i in 0 until parent.childCount) {
                val sibling = parent.getChild(i) ?: continue
                if (sibling.isCheckable) return sibling
            }
        }
        return findAnyCheckable(node)
    }

    private fun findAnyCheckable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isCheckable) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val hit = findAnyCheckable(c)
            if (hit != null) return hit
        }
        return null
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val hit = findFirstEditable(c)
            if (hit != null) return hit
        }
        return null
    }

    private fun findFirstScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val hit = findFirstScrollable(c)
            if (hit != null) return hit
        }
        return null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        repeat(5) {
            if (cur == null) return false
            if (cur!!.isClickable) {
                return cur!!.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            cur = cur!!.parent
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * Best-effort attempt to tap numeric PIN digits on the lock screen if the device ROM
     * allows AccessibilityServices to inspect Keyguard nodes. Modern Android (13+) often
     * isolates Keyguard PIN views from third-party AccessibilityServices for OS security.
     */
    fun attemptLockScreenPinEntry(pin: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var tappedCount = 0
        for (ch in pin) {
            val digitNode = findNodeByText(root, ch.toString())
            if (digitNode != null && clickNodeOrParent(digitNode)) {
                tappedCount++
            }
        }
        if (tappedCount == pin.length) {
            val okNode = findNodeByText(root, "OK")
                ?: findNodeByText(root, "Enter")
                ?: findNodeByText(root, "Tamam")
                ?: findNodeByText(root, "Onayla")
            okNode?.let { clickNodeOrParent(it) }
            return true
        }
        return false
    }

    private class RgbEdgeOverlayView(context: Context) : View(context) {
        private val density = context.resources.displayMetrics.density
        private val strokePx = 3.6f * density // ~1 mm physical edge strip
        private val cornerPx = 22f * density

        private val spectrum = intArrayOf(
            Color.parseColor("#00E5FF"),
            Color.parseColor("#3B82F6"),
            Color.parseColor("#9333EA"),
            Color.parseColor("#EC4899"),
            Color.parseColor("#F59E0B"),
            Color.parseColor("#10B981"),
            Color.parseColor("#00E5FF")
        )

        private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = strokePx
        }
        private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = strokePx * 2.2f
            alpha = 84
        }
        private val rect = RectF()
        private val matrix = Matrix()
        private var shader: SweepGradient? = null
        private var angleDeg = 0f

        private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2100L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                angleDeg = it.animatedValue as Float
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            animator.start()
        }

        override fun onDetachedFromWindow() {
            animator.cancel()
            super.onDetachedFromWindow()
        }

        fun stopAnimation() {
            animator.cancel()
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            val half = strokePx / 2f
            rect.set(half, half, w - half, h - half)
            shader = SweepGradient(w / 2f, h / 2f, spectrum, null)
            corePaint.shader = shader
            haloPaint.shader = shader
        }

        override fun onDraw(canvas: Canvas) {
            val s = shader ?: return
            matrix.setRotate(angleDeg, width / 2f, height / 2f)
            s.setLocalMatrix(matrix)
            canvas.drawRoundRect(rect, cornerPx, cornerPx, haloPaint)
            canvas.drawRoundRect(rect, cornerPx, cornerPx, corePaint)
        }
    }

    companion object {
        @Volatile
        var instance: AssistantAccessibilityService? = null
            private set
    }
}
