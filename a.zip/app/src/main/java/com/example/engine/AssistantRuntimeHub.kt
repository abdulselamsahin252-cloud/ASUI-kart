package com.example.engine

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

data class WakeServiceRuntimeState(
    val isBackgroundServiceRunning: Boolean = false,
    val isListeningForCommand: Boolean = false,
    val activeWakePhrase: String = "Kayıtlı kelime yok",
    val currentRmsDb: Float = -60f,
    val spectrumBins: List<Float> = List(16) { 0.08f },
    val lastMatchConfidence: Float = 0f,
    val lastSpeakerSimilarity: Float = 0f,
    val lastSpeakerVerified: Boolean = false,
    val lastTriggeredOnLockScreen: Boolean = false,
    val lastTriggeredTimestamp: Long = 0L,
    val statusMessage: String = "Arka plan dinleyici beklemede"
)

object AssistantRuntimeHub {
    private val _wakeState = MutableStateFlow(WakeServiceRuntimeState())
    val wakeState = _wakeState.asStateFlow()

    private val _accessibilityConnected = MutableStateFlow(false)
    val accessibilityConnected = _accessibilityConnected.asStateFlow()

    private val _automationLog = MutableSharedFlow<String>(extraBufferCapacity = 32)
    val automationLog = _automationLog.asSharedFlow()

    private val _wakeTriggerEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val wakeTriggerEvents = _wakeTriggerEvents.asSharedFlow()

    private val _backgroundCommandResult = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val backgroundCommandResult = _backgroundCommandResult.asSharedFlow()

    private val _lockScreenSessionFinished = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val lockScreenSessionFinished = _lockScreenSessionFinished.asSharedFlow()

    private val _requestKeyguardDismiss = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    val requestKeyguardDismiss = _requestKeyguardDismiss.asSharedFlow()

    fun updateWakeState(transform: (WakeServiceRuntimeState) -> WakeServiceRuntimeState) {
        _wakeState.value = transform(_wakeState.value)
    }

    fun setAccessibilityConnected(connected: Boolean) {
        _accessibilityConnected.value = connected
    }

    fun emitAutomationLog(message: String) {
        _automationLog.tryEmit(message)
    }

    fun emitWakeTriggered(phrase: String) {
        _wakeTriggerEvents.tryEmit(phrase)
    }

    fun emitBackgroundCommandText(commandText: String) {
        _backgroundCommandResult.tryEmit(commandText)
    }

    fun emitLockScreenSessionFinished() {
        _lockScreenSessionFinished.tryEmit(Unit)
    }

    fun emitRequestKeyguardDismiss() {
        _requestKeyguardDismiss.tryEmit(Unit)
    }
}
