package com.example.engine

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class HardwareCapabilityReport(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val cpuCores: Int,
    val primaryAbi: String,
    val freeStorageGb: Float,
    val recommendedMaxParams: String,
    val estimated1BSpeed: String,
    val estimated3BSpeed: String,
    val estimated7BSpeed: String
)

data class PowerfulLlmProfile(
    val id: String,
    val name: String,
    val family: String,
    val paramsLabel: String,
    val quantLabel: String,
    val sizeMb: Int,
    val minRamMb: Long,
    val publicDownloadUrl: String,
    val languages: String,
    val strengthSummary: String
)

data class GgufInspectionResult(
    val isValidGguf: Boolean,
    val formatVersion: Int,
    val tensorCount: Long,
    val kvCount: Long,
    val fileSizeMb: Long
)

/**
 * Hardware-aware Powerful Local LLM Catalog, Real GGUF Binary Inspector, and
 * Instant-vs-Deep Hybrid Execution Estimator.
 */
object LocalLlmEngine {

    val powerfulCatalog = listOf(
        PowerfulLlmProfile(
            id = "llm_gemma3_1b_q4",
            name = "Gemma 3 1B Instruct (Hızlı Mobil)",
            family = "Google Open Weights",
            paramsLabel = "1B",
            quantLabel = "Q4_K_M",
            sizeMb = 680,
            minRamMb = 2500L,
            publicDownloadUrl = "https://huggingface.co/bartowski/google_gemma-3-1b-it-GGUF/resolve/main/google_gemma-3-1b-it-Q4_K_M.gguf",
            languages = "TR + EN + Çok Dilli",
            strengthSummary = "Telefonda neredeyse anlık yanıt (1-3 sn). Özetleme, doğal sohbet ve komut planlama için en dengeli mobil model."
        ),
        PowerfulLlmProfile(
            id = "llm_qwen25_3b_q4",
            name = "Qwen 2.5 3B Instruct (Güçlü Türkçe)",
            family = "Alibaba Qwen2.5 Open",
            paramsLabel = "3B",
            quantLabel = "Q4_K_M",
            sizeMb = 1930,
            minRamMb = 4500L,
            publicDownloadUrl = "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
            languages = "Yüksek Türkçe + İngilizce",
            strengthSummary = "Türkçe dil bilgisi, karmaşık karşılaştırma ve mantık yürütmede sınıfının en güçlü mobil açık ağırlıklı modeli."
        ),
        PowerfulLlmProfile(
            id = "llm_llama32_3b_q4",
            name = "Llama 3.2 3B Instruct (Meta Open)",
            family = "Meta Llama 3.2",
            paramsLabel = "3B",
            quantLabel = "Q4_K_M",
            sizeMb = 2020,
            minRamMb = 4800L,
            publicDownloadUrl = "https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf",
            languages = "EN + TR",
            strengthSummary = "Güçlü araç çağırma (tool calling) ve adım adım otomasyon planlama yeteneği."
        ),
        PowerfulLlmProfile(
            id = "llm_phi35_mini_q4",
            name = "Phi-3.5 Mini 3.8B (Derin Analiz)",
            family = "Microsoft Phi Open",
            paramsLabel = "3.8B",
            quantLabel = "Q4_K_M",
            sizeMb = 2390,
            minRamMb = 5500L,
            publicDownloadUrl = "https://huggingface.co/bartowski/Phi-3.5-mini-instruct-GGUF/resolve/main/Phi-3.5-mini-instruct-Q4_K_M.gguf",
            languages = "EN + Teknik Muhakeme",
            strengthSummary = "Uzun belge analizi, kod/veri karşılaştırma ve teknik problem çözme için yüksek kapasiteli yerel model."
        )
    )

    fun profileHardware(context: Context): HardwareCapabilityReport {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val totalRamMb = mem.totalMem / (1024L * 1024L)
        val availRamMb = mem.availMem / (1024L * 1024L)

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeGb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024f * 1024f * 1024f)
        val cores = Runtime.getRuntime().availableProcessors()
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"

        val maxParams = when {
            totalRamMb >= 7500 -> "3B – 4B Q4 (Yüksek Hız)"
            totalRamMb >= 5000 -> "1B – 3B Q4 (Önerilen)"
            else -> "0.5B – 1.5B Q4 (Hafif)"
        }

        val speed1B = if (totalRamMb >= 4000) "~18-26 token/sn (1-3 sn)" else "~8-12 token/sn (3-6 sn)"
        val speed3B = if (totalRamMb >= 6000) "~10-16 token/sn (3-7 sn)" else "RAM düşük (12-25 sn)"
        val speed7B = if (totalRamMb >= 10000) "~4-7 token/sn (15-35 sn)" else "Telefonda 30-90+ sn / RAM sınırı"

        return HardwareCapabilityReport(
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            cpuCores = cores,
            primaryAbi = abi,
            freeStorageGb = freeGb,
            recommendedMaxParams = maxParams,
            estimated1BSpeed = speed1B,
            estimated3BSpeed = speed3B,
            estimated7BSpeed = speed7B
        )
    }

    /**
     * Reads real binary GGUF header (magic "GGUF", version, tensor count, metadata KV count)
     * from any locally imported .gguf model file.
     */
    fun inspectGgufHeader(file: File): GgufInspectionResult {
        val sizeMb = (file.length() / (1024L * 1024L)).coerceAtLeast(1L)
        if (!file.exists() || file.length() < 24L) {
            return GgufInspectionResult(false, 0, 0, 0, sizeMb)
        }
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                val header = ByteArray(24)
                raf.readFully(header)
                val magic = String(header, 0, 4, Charsets.US_ASCII)
                if (magic != "GGUF") {
                    return GgufInspectionResult(false, 0, 0, 0, sizeMb)
                }
                val bb = ByteBuffer.wrap(header, 4, 20).order(ByteOrder.LITTLE_ENDIAN)
                val version = bb.int
                val tensorCount = bb.long
                val kvCount = bb.long
                GgufInspectionResult(
                    isValidGguf = true,
                    formatVersion = version,
                    tensorCount = tensorCount,
                    kvCount = kvCount,
                    fileSizeMb = sizeMb
                )
            }
        }.getOrElse {
            GgufInspectionResult(false, 0, 0, 0, sizeMb)
        }
    }
}
