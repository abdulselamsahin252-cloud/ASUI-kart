package com.example.engine

import com.example.data.AutomationActionType
import com.example.data.AutomationStep
import java.util.Locale

sealed class CommandIntent {
    data object PowerDialog : CommandIntent()
    data object LockScreen : CommandIntent()
    data object UnlockDeviceWithVoice : CommandIntent()
    data class WifiControl(val enable: Boolean) : CommandIntent()
    data class BluetoothControl(val enable: Boolean) : CommandIntent()
    data class FlashlightControl(val enable: Boolean) : CommandIntent()
    data class VolumeControl(val mode: VolumeMode) : CommandIntent()
    data class SetTimer(val minutes: Int) : CommandIntent()
    data class SetAlarm(val hour: Int, val minute: Int) : CommandIntent()
    data class GlobalNav(val action: NavAction) : CommandIntent()
    data class AppAutomation(
        val appNameQuery: String,
        val steps: List<AutomationStep>
    ) : CommandIntent()
    data class ZipArchiveOp(
        val action: ZipAction,
        val archiveName: String? = null,
        val subFolder: String? = null,
        val extractToRoot: Boolean = true
    ) : CommandIntent()
    data class FileWorkspaceOp(
        val action: FileOpAction,
        val targetName: String
    ) : CommandIntent()
    data class QuickCalculate(val expression: String) : CommandIntent()
    data class ResearchSite(val siteQuery: String) : CommandIntent()
    data class CompareSites(val siteAQuery: String, val siteBQuery: String) : CommandIntent()
    data class OfflineChatHelp(val topic: String) : CommandIntent()
}

enum class VolumeMode { UP, DOWN, MUTE }
enum class NavAction { HOME, BACK, RECENTS, QUICK_SETTINGS, SCREENSHOT }
enum class ZipAction { EXTRACT, LIST, CREATE }
enum class FileOpAction { LIST_FILES, CREATE_FOLDER }

/**
 * Generalized Offline Bilingual (TR + EN) Semantic Action-Target-Destination NLU Router.
 * Parses natural clauses into structured tool calls without requiring rigid verbatim templates.
 */
object OfflineNluEngine {

    fun parse(rawInput: String): CommandIntent {
        val clean = rawInput.trim()
        val norm = normalizeTrEn(clean)

        // 1. Two-site comparison
        if (norm.contains("karsilastir") || norm.contains("compare") || norm.contains("farklari") || norm.contains("versus") || norm.contains(" vs ")) {
            val (siteA, siteB) = extractTwoSites(clean, norm)
            return CommandIntent.CompareSites(siteA, siteB)
        }

        // 2. Single-site research & summarization
        if (norm.contains("arastir") || norm.contains("ozetle") || norm.contains("ozetini") ||
            norm.contains("summarize") || norm.contains("research") ||
            (norm.contains("site") && !norm.contains("karsilastir"))
        ) {
            val siteQuery = extractSingleSite(clean, norm)
            return CommandIntent.ResearchSite(siteQuery)
        }

        // 3. Semantic ZIP & Archive Tool Routing (handles arbitrary phrasing like "bu dosya zip bunu aç şu klasörü ana dizine çıkar")
        if (isZipArchiveCommand(norm)) {
            return parseZipArchiveOp(clean, norm)
        }

        // 4. Semantic File & Folder Tool Routing
        if (isFileWorkspaceCommand(norm)) {
            return parseFileWorkspaceOp(clean, norm)
        }

        // 5. Voice Unlock / Screen Unlock Vault Command
        if (norm.contains("sifreyi ac") || norm.contains("kilidi ac") || norm.contains("kilit ac") ||
            norm.contains("ekrani ac") || norm.contains("ekran kilidini ac") || norm.contains("unlock") ||
            (norm.contains("telefon") && norm.contains("ac") && !norm.contains("kapat"))
        ) {
            return CommandIntent.UnlockDeviceWithVoice
        }

        // 6. Multi-Step App Automation ("şu uygulamaya girip bunları bunları yap")
        if (isAppAutomationCommand(norm)) {
            return parseAppAutomation(clean, norm)
        }

        // 7. Phone Power Off / Lock Screen
        if ((norm.contains("telefon") || norm.contains("cihaz") || norm.contains("phone") || norm.contains("device")) &&
            (norm.contains("kapat") || norm.contains("power off") || norm.contains("shut down") || norm.contains("shutdown"))
        ) {
            return CommandIntent.PowerDialog
        }
        if (norm == "kapat" || norm.contains("guc menusu") || norm.contains("yeniden baslat") || norm.contains("restart")) {
            return CommandIntent.PowerDialog
        }
        if (norm.contains("ekrani kilitle") || norm.contains("ekran kilitle") || norm.contains("lock screen")) {
            return CommandIntent.LockScreen
        }

        // 8. Wi-Fi Control
        if (norm.contains("wifi") || norm.contains("wi-fi") || norm.contains("kablosuz")) {
            val enable = inferEnableState(norm, defaultEnable = true)
            return CommandIntent.WifiControl(enable)
        }

        // 9. Bluetooth Control
        if (norm.contains("bluetooth") || norm.contains("blutut") || norm.contains("mavi dis")) {
            val enable = inferEnableState(norm, defaultEnable = true)
            return CommandIntent.BluetoothControl(enable)
        }

        // 10. Flashlight Control
        if (norm.contains("fener") || norm.contains("flas") || norm.contains("isik") || norm.contains("flashlight") || norm.contains("torch")) {
            val enable = inferEnableState(norm, defaultEnable = true)
            return CommandIntent.FlashlightControl(enable)
        }

        // 11. Volume Control
        if (norm.contains("sesi ac") || norm.contains("sesi yukselt") || norm.contains("volume up")) {
            return CommandIntent.VolumeControl(VolumeMode.UP)
        }
        if (norm.contains("sesi kis") || norm.contains("sesi azalt") || norm.contains("volume down")) {
            return CommandIntent.VolumeControl(VolumeMode.DOWN)
        }
        if (norm.contains("sessiz") || norm.contains("sesi kapat") || norm.contains("mute")) {
            return CommandIntent.VolumeControl(VolumeMode.MUTE)
        }

        // 12. Timer & Alarm
        if (norm.contains("zamanlayici") || norm.contains("sayac") || norm.contains("timer")) {
            val mins = Regex("""(\d+)""").find(norm)?.groupValues?.get(1)?.toIntOrNull() ?: 5
            return CommandIntent.SetTimer(mins.coerceIn(1, 720))
        }
        if (norm.contains("alarm")) {
            val timeMatch = Regex("""(\d{1,2})[:.](\d{2})""").find(norm)
            val hour = timeMatch?.groupValues?.get(1)?.toIntOrNull()
                ?: Regex("""(\d{1,2})""").find(norm)?.groupValues?.get(1)?.toIntOrNull()
                ?: 8
            val minute = timeMatch?.groupValues?.get(2)?.toIntOrNull() ?: 0
            return CommandIntent.SetAlarm(hour.coerceIn(0, 23), minute.coerceIn(0, 59))
        }

        // 13. Global Navigation
        if (norm.contains("ana ekran") || norm.contains("go home")) return CommandIntent.GlobalNav(NavAction.HOME)
        if (norm.contains("geri git") || norm.contains("geri don") || norm == "back") return CommandIntent.GlobalNav(NavAction.BACK)
        if (norm.contains("son uygulama") || norm.contains("recents")) return CommandIntent.GlobalNav(NavAction.RECENTS)
        if (norm.contains("hizli ayar") || norm.contains("quick settings")) return CommandIntent.GlobalNav(NavAction.QUICK_SETTINGS)
        if (norm.contains("ekran goruntusu") || norm.contains("screenshot")) return CommandIntent.GlobalNav(NavAction.SCREENSHOT)

        // 14. Quick Offline Math / Expression
        if (norm.contains("hesapla") || norm.contains("kac eder") ||
            Regex("""^\s*\d+(?:\.\d+)?\s*[+\-*/x]\s*\d+(?:\.\d+)?\s*$""").matches(norm)
        ) {
            return CommandIntent.QuickCalculate(clean)
        }

        // 15. Fallback generalized offline assistant response
        return CommandIntent.OfflineChatHelp(clean)
    }

    private fun isZipArchiveCommand(norm: String): Boolean {
        val archiveNouns = listOf(".zip", " zip", "zip ", "arsiv", "paket")
        val archiveVerbs = listOf("ac", "cikar", "cikart", "ayikla", "extract", "unzip", "listele", "goster", "sikistir", "zip yap", "compress", "ana dizin")
        return archiveNouns.any { norm.contains(it) } && archiveVerbs.any { norm.contains(it) }
    }

    private fun parseZipArchiveOp(raw: String, norm: String): CommandIntent.ZipArchiveOp {
        val zipFileMatch = Regex("""([a-zA-Z0-9çğıöşüÇĞİÖŞÜ._-]+\.zip)\b""", RegexOption.IGNORE_CASE).find(raw)
        val archiveName = zipFileMatch?.groupValues?.get(1)

        val action = when {
            norm.contains("sikistir") || norm.contains("zip yap") || norm.contains("compress") || norm.contains("arsivle") -> ZipAction.CREATE
            (norm.contains("listele") || norm.contains("icerik") || norm.contains("icinde ne")) && !norm.contains("cikar") -> ZipAction.LIST
            else -> ZipAction.EXTRACT
        }

        // Extract folder filter e.g. "belgeler klasörünü ana dizine çıkar" or "ayarlar klasörünü çıkar"
        val folderMatch = Regex(
            """([a-zA-Z0-9çğıöşüÇĞİÖŞÜ._-]+)\s+klas[oö]r[üu]?n?[üui]?\b""",
            RegexOption.IGNORE_CASE
        ).find(raw)
        val folderCandidate = folderMatch?.groupValues?.get(1)?.trim()
        val subFolder = if (folderCandidate != null &&
            normalizeTrEn(folderCandidate) !in setOf("su", "bu", "o", "bir", "yeni", "tum", "hangi")
        ) {
            folderCandidate
        } else null

        val extractToRoot = norm.contains("ana dizin") || norm.contains("root") || norm.contains("disari") || subFolder != null

        return CommandIntent.ZipArchiveOp(
            action = action,
            archiveName = archiveName,
            subFolder = subFolder,
            extractToRoot = extractToRoot
        )
    }

    private fun isFileWorkspaceCommand(norm: String): Boolean {
        val fileNouns = listOf("dosya", "klasor", "dizin", "calisma alani", "folder", "files")
        val fileVerbs = listOf("listele", "goster", "olustur", "yeni", "ac", "bak", "list", "create")
        return fileNouns.any { norm.contains(it) } && fileVerbs.any { norm.contains(it) }
    }

    private fun parseFileWorkspaceOp(raw: String, norm: String): CommandIntent.FileWorkspaceOp {
        return if (norm.contains("olustur") || norm.contains("yeni") || norm.contains("create")) {
            val cleaned = raw.replace(
                Regex("""\b(yeni|klas[oö]r|klas[oö]r[üu]|olu[sş]tur|create|folder|new|bir|ad[ıi]nda)\b""", RegexOption.IGNORE_CASE),
                " "
            ).trim().replace(Regex("""\s+"""), "_")
            CommandIntent.FileWorkspaceOp(FileOpAction.CREATE_FOLDER, cleaned.ifBlank { "yeni_klasor" })
        } else {
            CommandIntent.FileWorkspaceOp(FileOpAction.LIST_FILES, "")
        }
    }

    private fun isAppAutomationCommand(norm: String): Boolean {
        val triggers = listOf(
            "uygulamasina gir", "uygulamasini ac", "uygulamaya gir", "girip",
            "uygulamayi ac", "ac ve", "open ", "launch ", "gir ve", "'a gir", "'e gir", "a girip", "e girip"
        )
        if (triggers.any { norm.contains(it) }) return true

        val singleOpenMatch = Regex("""^([a-z0-9çğıöşü]+)\s+(ac|gir|baslat)$""").find(norm)
        if (singleOpenMatch != null) {
            val noun = singleOpenMatch.groupValues[1]
            val hardwareNouns = setOf(
                "wifi", "bluetooth", "blutut", "fener", "feneri", "flas", "flasi",
                "isik", "isigi", "ses", "sesi", "kablosuz", "flashlight", "torch",
                "sifre", "sifreyi", "kilit", "kilidi", "zip", "dosya"
            )
            return noun !in hardwareNouns
        }
        return false
    }

    private fun parseAppAutomation(raw: String, norm: String): CommandIntent.AppAutomation {
        val appRegex = Regex(
            """(?:^|.*?\s)([a-zA-Z0-9çğıöşüÇĞİÖŞÜ._-]+)\s*(?:'?[aeuı]?'?n?[ıiuü]?n?\s+)?(?:uygulamas[ıi]n[ıia]\s*)?(?:girip|gir|acip|ac|baslat|open|launch)\b""",
            RegexOption.IGNORE_CASE
        )
        val rawBeforeAction = raw.split(
            Regex("""\b(?:girip|uygulamas[ıi]na|uygulamaya|uygulamas[ıi]n[ıi]|acip|açıp|ve|sonra|and then|then)\b""", RegexOption.IGNORE_CASE)
        ).firstOrNull()?.trim().orEmpty()

        val appName = appRegex.find(raw)?.groupValues?.getOrNull(1)
            ?.replace(Regex("""['’].*$"""), "")
            ?.takeIf { it.length >= 2 }
            ?: rawBeforeAction
                .replace(Regex("""^(su|bu|lütfen|please|open|launch)\s+""", RegexOption.IGNORE_CASE), "")
                .replace(Regex("""['’].*$"""), "")
                .trim()
                .ifBlank { "Ayarlar" }

        val steps = mutableListOf<AutomationStep>()
        steps += AutomationStep(AutomationActionType.OPEN_APP, target = appName)
        steps += AutomationStep(AutomationActionType.WAIT, delayMs = 1100L)

        val tailPart = raw.substringAfter("girip", missingDelimiterValue = "")
            .ifBlank { raw.substringAfter("gir ve", missingDelimiterValue = "") }
            .ifBlank { raw.substringAfter("açıp", missingDelimiterValue = "") }
            .ifBlank { raw.substringAfter("acip", missingDelimiterValue = "") }
            .ifBlank { raw.substringAfter("and ", missingDelimiterValue = "") }
            .trim()

        if (tailPart.isNotBlank()) {
            val subClauses = tailPart.split(Regex("""\b(?:ve|sonra|ardından|ardindan|then|and|,)\b""", RegexOption.IGNORE_CASE))
            for (clause in subClauses) {
                val c = clause.trim()
                val cNorm = normalizeTrEn(c)
                if (c.isBlank()) continue
                when {
                    cNorm.contains("yaz") || cNorm.contains("type") || cNorm.contains("gir") -> {
                        val quoted = Regex("""["“”']([^"“”']+)["“”']""").find(c)?.groupValues?.get(1)
                        val textToType = quoted ?: c.replace(
                            Regex("""\b(yaz|yazdir|yazdır|gir|type|input|diye|olarak|metnini)\b""", RegexOption.IGNORE_CASE),
                            ""
                        ).trim()
                        if (textToType.isNotBlank() && !cNorm.contains("bunlari bunlari")) {
                            steps += AutomationStep(
                                type = AutomationActionType.INPUT_TEXT,
                                target = "",
                                value = textToType
                            )
                            steps += AutomationStep(AutomationActionType.WAIT, delayMs = 650L)
                        }
                    }
                    cNorm.contains("tikla") || cNorm.contains("bas") || cNorm.contains("sec") ||
                        cNorm.contains("click") || cNorm.contains("tap") || cNorm.contains("ac") -> {
                        val quoted = Regex("""["“”']([^"“”']+)["“”']""").find(c)?.groupValues?.get(1)
                        val targetLabel = quoted ?: c.replace(
                            Regex("""\b(tikla|tıkla|bas|sec|seç|ac|aç|click|tap|on|ogesine|öğesine|butonuna|sekmesine)\b""", RegexOption.IGNORE_CASE),
                            ""
                        ).replace(Regex("""['’][a-zçğıöşü]+$""", RegexOption.IGNORE_CASE), "").trim()
                        if (targetLabel.isNotBlank() && !cNorm.contains("bunlari")) {
                            steps += AutomationStep(
                                type = AutomationActionType.CLICK_TEXT,
                                target = targetLabel
                            )
                            steps += AutomationStep(AutomationActionType.WAIT, delayMs = 750L)
                        }
                    }
                    cNorm.contains("asagi kaydir") || cNorm.contains("scroll down") -> {
                        steps += AutomationStep(AutomationActionType.SCROLL_DOWN)
                    }
                    cNorm.contains("yukari kaydir") || cNorm.contains("scroll up") -> {
                        steps += AutomationStep(AutomationActionType.SCROLL_UP)
                    }
                    cNorm.contains("geri") || cNorm.contains("back") -> {
                        steps += AutomationStep(AutomationActionType.PRESS_BACK)
                    }
                }
            }
        }

        return CommandIntent.AppAutomation(appNameQuery = appName, steps = steps)
    }

    private fun extractSingleSite(raw: String, norm: String): String {
        val domainMatch = Regex("""([a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?)""").find(raw)
        if (domainMatch != null) return domainMatch.groupValues[1]

        return norm
            .replace(Regex("""\b(bu|su|siteyi|sitesini|sayfayi|sayfasini|arastir|ozetle|ozetini|cikar|ve|summarize|research|site|page)\b"""), " ")
            .trim()
            .replace(Regex("""\s+"""), " ")
    }

    private fun extractTwoSites(raw: String, norm: String): Pair<String, String> {
        val domains = Regex("""([a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?)""").findAll(raw).map { it.groupValues[1] }.toList()
        if (domains.size >= 2) return domains[0] to domains[1]

        val parts = norm
            .replace(Regex("""\b(bu|iki|siteyi|sitelerini|sitesini|karsilastir|farklari|compare|between|sites)\b"""), " ")
            .split(Regex("""\b(ile|ve|and|vs|versus)\b"""))
            .map { it.trim() }
            .filter { it.length >= 2 }

        return if (parts.size >= 2) {
            parts[0] to parts[1]
        } else {
            "kotlinlang.org" to "python.org"
        }
    }

    private fun inferEnableState(norm: String, defaultEnable: Boolean): Boolean {
        val offKeywords = listOf("kapat", "kapa", "durdur", "kes", "pasif", "devre disi", "turn off", "disable", "off", "stop")
        val onKeywords = listOf("ac", "aktif", "baslat", "etkinlestir", "turn on", "enable", "on", "start")
        if (offKeywords.any { norm.contains(it) }) return false
        if (onKeywords.any { norm.contains(it) }) return true
        return defaultEnable
    }

    fun normalizeTrEn(input: String): String {
        return input.lowercase(Locale("tr", "TR"))
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('İ', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')
            .replace(Regex("""\s+"""), " ")
            .trim()
    }
}
