package com.example.engine

import com.example.data.AutomationActionType
import com.example.data.AutomationStep
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

sealed class CommandIntent {
    data object PowerDialog : CommandIntent()
    data object WakeScreen : CommandIntent()
    data object LockScreen : CommandIntent()
    data object UnlockDeviceWithVoice : CommandIntent()
    data class WifiControl(val enable: Boolean) : CommandIntent()
    data class BluetoothControl(val enable: Boolean) : CommandIntent()
    data class FlashlightControl(val enable: Boolean) : CommandIntent()
    data class VolumeControl(val mode: VolumeMode) : CommandIntent()
    data class SetTimer(val minutes: Int) : CommandIntent()
    data class SetAlarm(val hour: Int, val minute: Int) : CommandIntent()
    data class GlobalNav(val action: NavAction) : CommandIntent()
    data class AppAutomation(
        val appNameQuery: String,
        val steps: List<AutomationStep>
    ) : CommandIntent()
    data class ZipArchiveOp(
        val action: ZipAction,
        val archiveName: String? = null,
        val subFolder: String? = null,
        val extractToRoot: Boolean = true
    ) : CommandIntent()
    data class FileWorkspaceOp(
        val action: FileOpAction,
        val targetName: String
    ) : CommandIntent()
    data class QuickCalculate(val expression: String) : CommandIntent()
    data class ResearchSite(val siteQuery: String) : CommandIntent()
    data class CompareSites(val siteAQuery: String, val siteBQuery: String) : CommandIntent()
    data class ModelRequiredNotice(val missingModelHint: String, val originalQuery: String) : CommandIntent()
    data class OfflineChatHelp(val topic: String) : CommandIntent()
}

enum class VolumeMode { UP, DOWN, MUTE }
enum class NavAction { HOME, BACK, RECENTS, QUICK_SETTINGS, SCREENSHOT }
enum class ZipAction { EXTRACT, LIST, CREATE }
enum class FileOpAction { LIST_FILES, CREATE_FOLDER }

/**
 * Generalized Offline Bilingual (TR + EN) Semantic Purpose & Stemming NLU Engine.
 *
 * Understands user intent regardless of phrasing style, word order, or Turkish suffixes
 * by combining:
 * 1) Turkish/English morphological root stemming (e.g. "uyandırsana" -> "uyandir", "kablosuzu" -> "kablosuz")
 * 2) Semantic polarity inference (ON/WAKE/UP vs OFF/SLEEP/DOWN)
 * 3) Runtime-loaded TR/EN language model lexicon weights from disk (.yanki_model)
 */
object OfflineNluEngine {

    private val loadedModelConcepts = ConcurrentHashMap<String, Map<String, Set<String>>>()

    fun loadModelLexiconFromFile(modelId: String, file: File) {
        if (!file.exists()) return
        runCatching {
            val map = mutableMapOf<String, MutableSet<String>>()
            file.readLines().forEach { line ->
                val trimmed = line.trim()
                if (trimmed.startsWith("CONCEPT:")) {
                    val body = trimmed.removePrefix("CONCEPT:")
                    val parts = body.split("=", limit = 2)
                    if (parts.size == 2) {
                        val concept = parts[0].trim().uppercase(Locale.US)
                        val roots = parts[1].split(",").map { normalizeTrEn(it) }.filter { it.isNotBlank() }
                        map.getOrPut(concept) { mutableSetOf() }.addAll(roots)
                    }
                }
            }
            if (map.isNotEmpty()) {
                loadedModelConcepts[modelId] = map
            }
        }
    }

    fun unloadModelLexicon(modelId: String) {
        loadedModelConcepts.remove(modelId)
    }

    fun hasAnyLoadedLanguagePack(): Boolean = loadedModelConcepts.isNotEmpty()

    /**
     * Runtime entry point aware of installed & active language models.
     * Requires at least one active TR/EN/Research/External language model for semantic flexible intent
     * inference, research summarization/comparison, and AI responses.
     */
    fun parseWithModels(rawInput: String, activeModelIds: Set<String>): CommandIntent {
        val hasTrOrEn = activeModelIds.any {
            it == "yanki_tr_core" || it == "yanki_en_core" || it.startsWith("ext_") || it.startsWith("llm_")
        }
        val hasResearch = activeModelIds.contains("yanki_bi_research") || hasTrOrEn

        val intent = parse(rawInput)
        if (!hasTrOrEn && intent !is CommandIntent.QuickCalculate) {
            return CommandIntent.ModelRequiredNotice(
                missingModelHint = "Türkçe veya İngilizce Dil Modeli henüz kurulu/aktif değil. Serbest üslup anlama (\"uyandır\", \"kablosuzu kes\" vb.), otomasyon planlama ve çevrimdışı yapay zeka için Modeller sekmesinden dil modellerini yükleyin.",
                originalQuery = rawInput.trim()
            )
        }
        if (!hasResearch && (intent is CommandIntent.ResearchSite || intent is CommandIntent.CompareSites)) {
            return CommandIntent.ModelRequiredNotice(
                missingModelHint = "Çift Dilli Araştırma & Özet Motoru modeli aktif değil. Modeller sekmesinden kurup aktif edebilirsiniz.",
                originalQuery = rawInput.trim()
            )
        }
        return intent
    }

    fun parse(rawInput: String): CommandIntent {
        val clean = rawInput.trim()
        val norm = normalizeTrEn(clean)
        val stems = tokenizeAndStem(norm)

        // 1. Two-site comparison
        if (hasAnyConcept(norm, stems, "COMPARE", listOf("karsilastir", "compare", "farklari", "farki ne", "kiyasla", "versus", "hangisi iyi")) ||
            norm.contains(" vs ")
        ) {
            val (siteA, siteB) = extractTwoSites(clean, norm)
            return CommandIntent.CompareSites(siteA, siteB)
        }

        // 2. Single-site research & summarization
        if (hasAnyConcept(norm, stems, "RESEARCH", listOf("arastir", "ozetle", "ozet", "summarize", "research", "incele", "analiz et")) ||
            (norm.contains("site") && !norm.contains("karsilastir"))
        ) {
            val siteQuery = extractSingleSite(clean, norm)
            return CommandIntent.ResearchSite(siteQuery)
        }

        // 3. Semantic ZIP & Archive Tool Routing
        if (isZipArchiveCommand(norm, stems)) {
            return parseZipArchiveOp(clean, norm)
        }

        // 4. Semantic File & Folder Tool Routing
        if (isFileWorkspaceCommand(norm, stems)) {
            return parseFileWorkspaceOp(clean, norm)
        }

        // 5. Screen Wake vs Voice Unlock ("uyandır" vs "ekranı aç / kilidi aç / şifreyi aç")
        val hasUnlockNoun = hasAnyStemOrSub(norm, stems, listOf("sifre", "kilit", "parola", "pin", "unlock"))
        val hasWakeWord = hasAnyConcept(
            norm, stems, "WAKE",
            listOf("uyandir", "uyan", "kalk", "canlandir", "wake", "ekrana gel", "ekrani yak")
        )
        val hasDirectOpenScreen = norm.contains("ekrani ac") || norm.contains("ekran ac") ||
            norm.contains("telefonu ac") || norm.contains("telefon ac") || norm.contains("cihazi ac")

        if (hasUnlockNoun && hasActionVerb(norm, stems, POSITIVE_VERBS + listOf("coz", "kaldir", "gir"))) {
            return CommandIntent.UnlockDeviceWithVoice
        }
        if (hasDirectOpenScreen) {
            return CommandIntent.UnlockDeviceWithVoice
        }
        if (hasWakeWord && !norm.contains("kapat") && !norm.contains("alarm")) {
            return CommandIntent.WakeScreen
        }

        // 6. Lock Screen / Sleep Display ("ekranı uyut", "ekranı kilitle", "ekranı dondur", "uyut")
        if (hasAnyConcept(norm, stems, "LOCK", listOf("kilitle", "kitle", "uyut", "dondur", "lock screen", "sleep screen")) ||
            ((norm.contains("ekran") || norm.contains("telefon")) && (stems.contains("uyut") || stems.contains("kilitle")))
        ) {
            return CommandIntent.LockScreen
        }

        // 7. Multi-Step App Automation ("şu uygulamaya girip bunları bunları yap")
        if (isAppAutomationCommand(norm, stems)) {
            return parseAppAutomation(clean, norm)
        }

        // 8. Phone Power Off / Shutdown / Restart
        if ((hasAnyStemOrSub(norm, stems, listOf("telefon", "cihaz", "sistem", "phone", "device")) &&
                hasActionVerb(norm, stems, NEGATIVE_VERBS + listOf("yeniden baslat", "reboot", "restart", "power off", "shutdown", "shut down"))) ||
            norm in setOf("kapat", "kapa", "kapatsana", "gucu kes") ||
            norm.contains("guc menusu") || norm.contains("yeniden baslat") || norm.contains("restart")
        ) {
            return CommandIntent.PowerDialog
        }

        // 9. Wi-Fi Control
        if (hasAnyConcept(norm, stems, "WIFI", listOf("wifi", "wi-fi", "kablosuz", "wlan", "internet"))) {
            // Only treat generic "internet" as Wi-Fi if paired with toggle verb
            if (!norm.contains("internet") || hasAnyActionVerb(norm, stems)) {
                val enable = inferEnableState(norm, stems, defaultEnable = true)
                return CommandIntent.WifiControl(enable)
            }
        }

        // 10. Bluetooth Control
        if (hasAnyConcept(norm, stems, "BLUETOOTH", listOf("bluetooth", "blutut", "mavi dis", "kulaklik baglanti"))) {
            val enable = inferEnableState(norm, stems, defaultEnable = true)
            return CommandIntent.BluetoothControl(enable)
        }

        // 11. Flashlight Control
        if (hasAnyConcept(norm, stems, "FLASHLIGHT", listOf("fener", "flas", "isik", "aydinlat", "flashlight", "torch"))) {
            val enable = inferEnableState(norm, stems, defaultEnable = true)
            return CommandIntent.FlashlightControl(enable)
        }

        // 12. Volume Control (handles slang like "fulle", "kökle", "kıs", "sus", "sessize al")
        if (hasAnyConcept(norm, stems, "VOLUME", listOf("ses", "muzik", "medya", "volume", "sessiz", "sustur", "mute"))) {
            return when {
                hasAnyStemOrSub(norm, stems, listOf("sessiz", "sustur", "mute", "sesini kes", "sesi kes")) ||
                    (stems.contains("ses") && hasActionVerb(norm, stems, NEGATIVE_VERBS)) -> CommandIntent.VolumeControl(VolumeMode.MUTE)
                hasAnyStemOrSub(norm, stems, listOf("kis", "azalt", "dusur", "indir", "alcalt", "down", "lower", "quieter")) ->
                    CommandIntent.VolumeControl(VolumeMode.DOWN)
                else -> CommandIntent.VolumeControl(VolumeMode.UP)
            }
        }
        if (hasAnyStemOrSub(norm, stems, listOf("fulle", "sonla", "kokle"))) {
            return CommandIntent.VolumeControl(VolumeMode.UP)
        }

        // 13. Timer ("5 dk sayaç", "3 dakika sonra uyar/hatırlat")
        if (hasAnyConcept(norm, stems, "TIMER", listOf("zamanlayici", "sayac", "timer", "dakika sonra", "dk sonra", "kronometre"))) {
            val mins = Regex("""(\d+)""").find(norm)?.groupValues?.get(1)?.toIntOrNull() ?: 5
            return CommandIntent.SetTimer(mins.coerceIn(1, 720))
        }

        // 14. Alarm ("saat 7 buçuğa alarm", "sabah 8 kur")
        if (hasAnyConcept(norm, stems, "ALARM", listOf("alarm", "uyandir beni", "sabah kur"))) {
            val timeMatch = Regex("""(\d{1,2})[:.](\d{2})""").find(norm)
            val hour = timeMatch?.groupValues?.get(1)?.toIntOrNull()
                ?: Regex("""(\d{1,2})""").find(norm)?.groupValues?.get(1)?.toIntOrNull()
                ?: 8
            val minute = timeMatch?.groupValues?.get(2)?.toIntOrNull()
                ?: if (norm.contains("bucuk") || norm.contains("yarim")) 30 else 0
            return CommandIntent.SetAlarm(hour.coerceIn(0, 23), minute.coerceIn(0, 59))
        }

        // 15. Global Navigation (natural variants)
        if (hasAnyStemOrSub(norm, stems, listOf("ana ekran", "ana menu", "masaustu", "cik buradan", "go home"))) {
            return CommandIntent.GlobalNav(NavAction.HOME)
        }
        if (hasAnyStemOrSub(norm, stems, listOf("geri git", "geri don", "bir onceki", "geri gel")) || norm == "geri" || norm == "back") {
            return CommandIntent.GlobalNav(NavAction.BACK)
        }
        if (hasAnyStemOrSub(norm, stems, listOf("son uygulama", "acik uygulama", "recents"))) {
            return CommandIntent.GlobalNav(NavAction.RECENTS)
        }
        if (hasAnyStemOrSub(norm, stems, listOf("hizli ayar", "bildirim panel", "kontrol merkez", "yukaridan cek", "quick settings"))) {
            return CommandIntent.GlobalNav(NavAction.QUICK_SETTINGS)
        }
        if (hasAnyStemOrSub(norm, stems, listOf("ekran goruntusu", "ekran foto", "ss al", "ekrani cek", "screenshot"))) {
            return CommandIntent.GlobalNav(NavAction.SCREENSHOT)
        }

        // 16. Quick Offline Math / Expression
        if (norm.contains("hesapla") || norm.contains("kac eder") || norm.contains("sonucu ne") ||
            Regex("""^\s*\d+(?:\.\d+)?\s*[+\-*/x]\s*\d+(?:\.\d+)?\s*$""").matches(norm)
        ) {
            return CommandIntent.QuickCalculate(clean)
        }

        // 17. Fallback generalized offline assistant response
        return CommandIntent.OfflineChatHelp(clean)
    }

    private val POSITIVE_VERBS = listOf("ac", "yak", "baslat", "calistir", "etkinlestir", "aktif", "ver", "baglan", "bagla", "on", "enable", "start", "open")
    private val NEGATIVE_VERBS = listOf("kapat", "kapa", "sondur", "kes", "durdur", "bitir", "pasif", "devre disi", "off", "disable", "stop", "shut")

    private fun hasAnyConcept(
        norm: String,
        stems: Set<String>,
        conceptKey: String,
        builtInCandidates: List<String>
    ): Boolean {
        if (hasAnyStemOrSub(norm, stems, builtInCandidates)) return true
        // Check dynamically loaded lexicon packs from downloaded/installed TR/EN models
        for ((_, conceptMap) in loadedModelConcepts) {
            val packRoots = conceptMap[conceptKey] ?: continue
            if (packRoots.any { root -> norm.contains(root) || stems.contains(root) }) return true
        }
        return false
    }

    private fun hasAnyStemOrSub(norm: String, stems: Set<String>, candidates: List<String>): Boolean {
        return candidates.any { c ->
            norm.contains(c) || stems.contains(c)
        }
    }

    private fun hasActionVerb(norm: String, stems: Set<String>, verbs: List<String>): Boolean {
        return hasAnyStemOrSub(norm, stems, verbs)
    }

    private fun hasAnyActionVerb(norm: String, stems: Set<String>): Boolean {
        return hasActionVerb(norm, stems, POSITIVE_VERBS + NEGATIVE_VERBS)
    }

    private fun isZipArchiveCommand(norm: String, stems: Set<String>): Boolean {
        val archiveNouns = listOf(".zip", " zip", "zip ", "arsiv", "paket")
        val archiveVerbs = listOf("ac", "cikar", "cikart", "ayikla", "coz", "extract", "unzip", "listele", "goster", "sikistir", "zip yap", "compress", "ana dizin")
        return (archiveNouns.any { norm.contains(it) } || stems.contains("zip")) &&
            (archiveVerbs.any { norm.contains(it) } || stems.any { it in archiveVerbs })
    }

    private fun parseZipArchiveOp(raw: String, norm: String): CommandIntent.ZipArchiveOp {
        val zipFileMatch = Regex("""([a-zA-Z0-9çğıöşüÇĞİÖŞÜ._-]+\.zip)\b""", RegexOption.IGNORE_CASE).find(raw)
        val archiveName = zipFileMatch?.groupValues?.get(1)

        val action = when {
            norm.contains("sikistir") || norm.contains("zip yap") || norm.contains("compress") || norm.contains("arsivle") -> ZipAction.CREATE
            (norm.contains("listele") || norm.contains("icerik") || norm.contains("icinde ne")) && !norm.contains("cikar") -> ZipAction.LIST
            else -> ZipAction.EXTRACT
        }

        val folderMatch = Regex(
            """([a-zA-Z0-9çğıöşüÇĞİÖŞÜ._-]+)\s+klas[oö]r[üu]?n?[üui]?\b""",
            RegexOption.IGNORE_CASE
        ).find(raw)
        val folderCandidate = folderMatch?.groupValues?.get(1)?.trim()
        val subFolder = if (folderCandidate != null &&
            normalizeTrEn(folderCandidate) !in setOf("su", "bu", "o", "bir", "yeni", "tum", "hangi")
        ) {
            folderCandidate
        } else null

        val extractToRoot = norm.contains("ana dizin") || norm.contains("root") || norm.contains("disari") || subFolder != null

        return CommandIntent.ZipArchiveOp(
            action = action,
            archiveName = archiveName,
            subFolder = subFolder,
            extractToRoot = extractToRoot
        )
    }

    private fun isFileWorkspaceCommand(norm: String, stems: Set<String>): Boolean {
        val fileNouns = listOf("dosya", "klasor", "dizin", "calisma alani", "folder", "files")
        val fileVerbs = listOf("listele", "goster", "olustur", "yeni", "ac", "bak", "neler var", "list", "create")
        return fileNouns.any { norm.contains(it) || stems.contains(it) } &&
            fileVerbs.any { norm.contains(it) || stems.contains(it) }
    }

    private fun parseFileWorkspaceOp(raw: String, norm: String): CommandIntent.FileWorkspaceOp {
        return if (norm.contains("olustur") || norm.contains("yeni") || norm.contains("create")) {
            val cleaned = raw.replace(
                Regex("""\b(yeni|klas[oö]r|klas[oö]r[üu]|olu[sş]tur|create|folder|new|bir|ad[ıi]nda)\b""", RegexOption.IGNORE_CASE),
                " "
            ).trim().replace(Regex("""\s+"""), "_")
            CommandIntent.FileWorkspaceOp(FileOpAction.CREATE_FOLDER, cleaned.ifBlank { "yeni_klasor" })
        } else {
            CommandIntent.FileWorkspaceOp(FileOpAction.LIST_FILES, "")
        }
    }

    private fun isAppAutomationCommand(norm: String, stems: Set<String>): Boolean {
        val triggers = listOf(
            "uygulamasina gir", "uygulamasini ac", "uygulamaya gir", "girip",
            "uygulamayi ac", "ac ve", "open ", "launch ", "gir ve", "'a gir", "'e gir", "a girip", "e girip"
        )
        if (triggers.any { norm.contains(it) }) return true

        val singleOpenMatch = Regex("""^([a-z0-9çğıöşü]+)(?:'?[aeuı]?'?n?[ıiuü]?)?\s+(ac|acsana|gir|baslat|calistir)$""").find(norm)
        if (singleOpenMatch != null) {
            val noun = stemTrToken(singleOpenMatch.groupValues[1])
            val hardwareNouns = setOf(
                "wifi", "bluetooth", "blutut", "fener", "flas",
                "isik", "ses", "kablosuz", "flashlight", "torch",
                "sifre", "kilit", "zip", "dosya", "ekran", "telefon", "cihaz"
            )
            return noun !in hardwareNouns && !stems.contains("ekran") && !stems.contains("telefon")
        }
        return false
    }

    private fun parseAppAutomation(raw: String, norm: String): CommandIntent.AppAutomation {
        val appRegex = Regex(
            """(?:^|.*?\s)([a-zA-Z0-9çğıöşüÇĞİÖŞÜ._-]+)\s*(?:'?[aeuı]?'?n?[ıiuü]?n?\s+)?(?:uygulamas[ıi]n[ıia]\s*)?(?:girip|gir|acip|ac|acsana|baslat|calistir|open|launch)\b""",
            RegexOption.IGNORE_CASE
        )
        val rawBeforeAction = raw.split(
            Regex("""\b(?:girip|uygulamas[ıi]na|uygulamaya|uygulamas[ıi]n[ıi]|acip|açıp|ve|sonra|and then|then)\b""", RegexOption.IGNORE_CASE)
        ).firstOrNull()?.trim().orEmpty()

        val appName = appRegex.find(raw)?.groupValues?.getOrNull(1)
            ?.replace(Regex("""['’].*$"""), "")
            ?.takeIf { it.length >= 2 }
            ?: rawBeforeAction
                .replace(Regex("""^(su|bu|lütfen|please|open|launch)\s+""", RegexOption.IGNORE_CASE), "")
                .replace(Regex("""['’].*$"""), "")
                .trim()
                .ifBlank { "Ayarlar" }

        val steps = mutableListOf<AutomationStep>()
        steps += AutomationStep(AutomationActionType.OPEN_APP, target = appName)
        steps += AutomationStep(AutomationActionType.WAIT, delayMs = 1100L)

        val tailPart = raw.substringAfter("girip", missingDelimiterValue = "")
            .ifBlank { raw.substringAfter("gir ve", missingDelimiterValue = "") }
            .ifBlank { raw.substringAfter("açıp", missingDelimiterValue = "") }
            .ifBlank { raw.substringAfter("acip", missingDelimiterValue = "") }
            .ifBlank { raw.substringAfter("and ", missingDelimiterValue = "") }
            .trim()

        if (tailPart.isNotBlank()) {
            val subClauses = tailPart.split(Regex("""\b(?:ve|sonra|ardından|ardindan|then|and|,)\b""", RegexOption.IGNORE_CASE))
            for (clause in subClauses) {
                val c = clause.trim()
                val cNorm = normalizeTrEn(c)
                if (c.isBlank()) continue
                when {
                    cNorm.contains("yaz") || cNorm.contains("type") || cNorm.contains("gir") -> {
                        val quoted = Regex("""["“”']([^"“”']+)["“”']""").find(c)?.groupValues?.get(1)
                        val textToType = quoted ?: c.replace(
                            Regex("""\b(yaz|yazdir|yazdır|gir|type|input|diye|olarak|metnini)\b""", RegexOption.IGNORE_CASE),
                            ""
                        ).trim()
                        if (textToType.isNotBlank() && !cNorm.contains("bunlari bunlari")) {
                            steps += AutomationStep(
                                type = AutomationActionType.INPUT_TEXT,
                                target = "",
                                value = textToType
                            )
                            steps += AutomationStep(AutomationActionType.WAIT, delayMs = 650L)
                        }
                    }
                    cNorm.contains("tikla") || cNorm.contains("bas") || cNorm.contains("sec") ||
                        cNorm.contains("click") || cNorm.contains("tap") || cNorm.contains("ac") -> {
                        val quoted = Regex("""["“”']([^"“”']+)["“”']""").find(c)?.groupValues?.get(1)
                        val targetLabel = quoted ?: c.replace(
                            Regex("""\b(tikla|tıkla|bas|sec|seç|ac|aç|click|tap|on|ogesine|öğesine|butonuna|sekmesine)\b""", RegexOption.IGNORE_CASE),
                            ""
                        ).replace(Regex("""['’][a-zçğıöşü]+$""", RegexOption.IGNORE_CASE), "").trim()
                        if (targetLabel.isNotBlank() && !cNorm.contains("bunlari")) {
                            steps += AutomationStep(
                                type = AutomationActionType.CLICK_TEXT,
                                target = targetLabel
                            )
                            steps += AutomationStep(AutomationActionType.WAIT, delayMs = 750L)
                        }
                    }
                    cNorm.contains("asagi kaydir") || cNorm.contains("scroll down") -> {
                        steps += AutomationStep(AutomationActionType.SCROLL_DOWN)
                    }
                    cNorm.contains("yukari kaydir") || cNorm.contains("scroll up") -> {
                        steps += AutomationStep(AutomationActionType.SCROLL_UP)
                    }
                    cNorm.contains("geri") || cNorm.contains("back") -> {
                        steps += AutomationStep(AutomationActionType.PRESS_BACK)
                    }
                }
            }
        }

        return CommandIntent.AppAutomation(appNameQuery = appName, steps = steps)
    }

    private fun extractSingleSite(raw: String, norm: String): String {
        val domainMatch = Regex("""([a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?)""").find(raw)
        if (domainMatch != null) return domainMatch.groupValues[1]

        return norm
            .replace(Regex("""\b(bu|su|siteyi|sitesini|sayfayi|sayfasini|arastir|ozetle|ozetini|cikar|ve|summarize|research|site|page)\b"""), " ")
            .trim()
            .replace(Regex("""\s+"""), " ")
    }

    private fun extractTwoSites(raw: String, norm: String): Pair<String, String> {
        val domains = Regex("""([a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?)""").findAll(raw).map { it.groupValues[1] }.toList()
        if (domains.size >= 2) return domains[0] to domains[1]

        val parts = norm
            .replace(Regex("""\b(bu|iki|siteyi|sitelerini|sitesini|karsilastir|farklari|compare|between|sites)\b"""), " ")
            .split(Regex("""\b(ile|ve|and|vs|versus)\b"""))
            .map { it.trim() }
            .filter { it.length >= 2 }

        return if (parts.size >= 2) {
            parts[0] to parts[1]
        } else {
            "kotlinlang.org" to "python.org"
        }
    }

    private fun inferEnableState(norm: String, stems: Set<String>, defaultEnable: Boolean): Boolean {
        val offKeywords = NEGATIVE_VERBS + listOf("turn off", "shut down", "kes", "son")
        val onKeywords = POSITIVE_VERBS + listOf("turn on", "fulle")
        if (hasActionVerb(norm, stems, offKeywords)) return false
        if (hasActionVerb(norm, stems, onKeywords)) return true
        return defaultEnable
    }

    fun tokenizeAndStem(norm: String): Set<String> {
        val out = mutableSetOf<String>()
        val tokens = norm.split(Regex("""[^a-z0-9.]+""")).filter { it.isNotBlank() }
        for (tok in tokens) {
            out += tok
            out += stemTrToken(tok)
        }
        return out
    }

    private fun stemTrToken(tok: String): String {
        var cur = tok
        val suffixes = listOf(
            "sana", "sene", "misin", "musun", "verir", "lutfen",
            "unu", "ini", "ina", "ine", "sin", "sun",
            "lar", "ler", "dan", "den", "tan", "ten",
            "yi", "yu", "ya", "ye", "ni", "nu", "na", "ne",
            "um", "im", "un", "in", "da", "de", "ta", "te",
            "ip", "up", "a", "e", "i", "u"
        )
        repeat(2) {
            for (sfx in suffixes) {
                if (cur.length > sfx.length + 3 && cur.endsWith(sfx)) {
                    cur = cur.dropLast(sfx.length)
                    break
                }
            }
        }
        return cur
    }

    fun normalizeTrEn(input: String): String {
        return input.lowercase(Locale("tr", "TR"))
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('İ', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')
            .replace(Regex("""\s+"""), " ")
            .trim()
    }
}
