package com.example.engine

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.AutomationActionType
import com.example.data.AutomationMacroEntity
import com.example.data.AutomationStep
import com.example.data.CachedSiteEntity
import com.example.data.InstalledAppInfo
import com.example.data.ResearchSummaryResult
import com.example.data.SiteComparisonResult
import com.example.data.StepSerializer
import com.example.service.AssistantAccessibilityService
import java.util.Locale

data class ExecutionOutcome(
    val intentTag: String,
    val summaryText: String,
    val steps: List<String>,
    val success: Boolean,
    val requiresAccessibilityGuide: Boolean = false,
    val researchSummary: ResearchSummaryResult? = null,
    val siteComparison: SiteComparisonResult? = null
)

class DeviceControlExecutor(private val context: Context) {

    private var torchEnabled = false

    fun listLaunchableApps(): List<InstalledAppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return resolved
            .mapNotNull { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) return@mapNotNull null
                val label = ri.loadLabel(pm)?.toString()?.trim().orEmpty()
                if (label.isBlank()) return@mapNotNull null
                InstalledAppInfo(packageName = pkg, label = label)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale("tr", "TR")) }
    }

    fun executeIntent(
        intent: CommandIntent,
        macros: List<AutomationMacroEntity>,
        sites: List<CachedSiteEntity>,
        activeModelNames: List<String>
    ): ExecutionOutcome {
        val a11y = AssistantAccessibilityService.instance

        return when (intent) {
            is CommandIntent.PowerDialog -> {
                if (a11y != null) {
                    val ok = a11y.triggerPowerDialog()
                    ExecutionOutcome(
                        intentTag = "SYSTEM_POWER",
                        summaryText = if (ok) "Sistem güç menüsü açıldı. 'Kapat' veya 'Yeniden Başlat' seçeneğine dokunabilirsiniz."
                        else "Güç menüsü açılamadı.",
                        steps = listOf(
                            "✓ Niyet algılandı: Telefonu Kapat / Güç Menüsü",
                            if (ok) "✓ GLOBAL_ACTION_POWER_DIALOG tetiklendi" else "✗ Güç menüsü başarısız"
                        ),
                        success = ok
                    )
                } else {
                    ExecutionOutcome(
                        intentTag = "SYSTEM_POWER",
                        summaryText = "Telefon kapatma / güç menüsünü otomatik açmak için Axiom Erişilebilirlik Servisini etkinleştirmeniz gerekir.",
                        steps = listOf(
                            "✓ Komut çözümlendi: Telefonu Kapat",
                            "! Erişilebilirlik Servisi henüz aktif değil"
                        ),
                        success = false,
                        requiresAccessibilityGuide = true
                    )
                }
            }

            is CommandIntent.LockScreen -> {
                if (a11y != null) {
                    val ok = a11y.triggerLockScreen()
                    ExecutionOutcome(
                        intentTag = "LOCK_SCREEN",
                        summaryText = if (ok) "Ekran kilitlendi." else "Ekran kilitleme Android 9+ gerektirir.",
                        steps = listOf("✓ GLOBAL_ACTION_LOCK_SCREEN yürütüldü"),
                        success = ok
                    )
                } else {
                    ExecutionOutcome(
                        intentTag = "LOCK_SCREEN",
                        summaryText = "Ekranı kilitlemek için Erişilebilirlik Servisini etkinleştirin.",
                        steps = listOf("! Erişilebilirlik Servisi gerekli"),
                        success = false,
                        requiresAccessibilityGuide = true
                    )
                }
            }

            is CommandIntent.WifiControl -> handleWifi(intent.enable, a11y)
            is CommandIntent.BluetoothControl -> handleBluetooth(intent.enable, a11y)
            is CommandIntent.FlashlightControl -> handleFlashlight(intent.enable)
            is CommandIntent.VolumeControl -> handleVolume(intent.mode)
            is CommandIntent.SetTimer -> handleTimer(intent.minutes)
            is CommandIntent.SetAlarm -> handleAlarm(intent.hour, intent.minute)
            is CommandIntent.GlobalNav -> handleGlobalNav(intent.action, a11y)

            is CommandIntent.AppAutomation -> handleAppAutomation(intent, macros, a11y)

            is CommandIntent.ResearchSite -> {
                val site = OfflineResearchEngine.findBestSiteMatch(intent.siteQuery, sites)
                if (site == null) {
                    ExecutionOutcome(
                        intentTag = "RESEARCH_SUMMARY",
                        summaryText = "Çevrimdışı arşivde henüz site kaydı yok. Araştırma sekmesinden sayfa ekleyebilirsiniz.",
                        steps = listOf("! Çevrimdışı site arşivi boş"),
                        success = false
                    )
                } else {
                    val summary = OfflineResearchEngine.summarizeSite(site)
                    ExecutionOutcome(
                        intentTag = "RESEARCH_SUMMARY",
                        summaryText = summary.verdict,
                        steps = listOf(
                            "✓ Çevrimdışı arşivden eşleşti: ${site.domain}",
                            "✓ TF-IDF ekstraktif özetleyici çalıştırıldı (${summary.wordCount} kelime)"
                        ),
                        success = true,
                        researchSummary = summary
                    )
                }
            }

            is CommandIntent.CompareSites -> {
                if (sites.size < 2) {
                    ExecutionOutcome(
                        intentTag = "SITE_COMPARE",
                        summaryText = "Karşılaştırma için çevrimdışı arşivde en az 2 site bulunmalıdır.",
                        steps = listOf("! Yetersiz çevrimdışı site"),
                        success = false
                    )
                } else {
                    val siteA = OfflineResearchEngine.findBestSiteMatch(intent.siteAQuery, sites) ?: sites[0]
                    val remaining = sites.filter { it.id != siteA.id }
                    val siteB = OfflineResearchEngine.findBestSiteMatch(intent.siteBQuery, remaining) ?: remaining.first()
                    val cmp = OfflineResearchEngine.compareSites(siteA, siteB)
                    ExecutionOutcome(
                        intentTag = "SITE_COMPARE",
                        summaryText = cmp.executiveSummary,
                        steps = listOf(
                            "✓ Kaynak A: ${siteA.domain}",
                            "✓ Kaynak B: ${siteB.domain}",
                            "✓ Anlamsal benzerlik (%${cmp.similarityPercent}) ve fark analizi tamamlandı"
                        ),
                        success = true,
                        siteComparison = cmp
                    )
                }
            }

            is CommandIntent.UnlockDeviceWithVoice -> handleVoiceUnlock(a11y)

            is CommandIntent.ZipArchiveOp -> handleZipArchiveOp(intent)

            is CommandIntent.FileWorkspaceOp -> handleFileWorkspaceOp(intent)

            is CommandIntent.QuickCalculate -> handleQuickCalculate(intent.expression)

            is CommandIntent.OfflineChatHelp -> {
                val modelsInfo = if (activeModelNames.isEmpty()) {
                    "Henüz aktif dil modeli yok (Modeller sekmesinden TR/EN modeli kurabilirsiniz)."
                } else {
                    "Aktif yerel modeller: ${activeModelNames.joinToString(", ")}."
                }
                ExecutionOutcome(
                    intentTag = "OFFLINE_AI_CORE",
                    summaryText = "Tamamen internetsiz genel NLU çekirdeği yanıtı: $modelsInfo\n\n" +
                        "Eylem-Nesne-Hedef çözümleyicisi ile kalıba bağlı kalmadan şu tür komutları verebilirsiniz:\n" +
                        "• Donanım/Kilit: \"Wi-Fi aç\", \"Bluetooth aç\", \"Telefonu kapat\", \"Şifreyi aç\"\n" +
                        "• ZIP/Dosya: \"proje_yedek.zip içindeki belgeler klasörünü ana dizine çıkar\", \"Dosyaları listele\"\n" +
                        "• Uygulama: \"Ayarlar'a girip Bluetooth'a tıkla\"\n" +
                        "• Araştırma: \"kotlinlang.org sitesini özetle\" veya \"iki siteyi karşılaştır\"\n" +
                        "• Hesaplama: \"hesapla 1250 * 4\"",
                    steps = listOf(
                        "✓ Yerel Semantik NLU çekirdeği çalıştı (0 ms ağ gecikmesi)",
                        "✓ Girdi: \"${intent.topic}\""
                    ),
                    success = true
                )
            }
        }
    }

    private fun handleVoiceUnlock(a11y: AssistantAccessibilityService?): ExecutionOutcome {
        val wakeState = AssistantRuntimeHub.wakeState.value
        val hasPin = SecurityVaultManager.hasSavedPin(context)
        val simPercent = (wakeState.lastSpeakerSimilarity * 100).toInt()
        val steps = mutableListOf<String>()

        steps += if (wakeState.lastSpeakerVerified) {
            "✓ Konuşmacı ses izi doğrulandı (%$simPercent benzerlik)"
        } else {
            "• Ses izi skoru: %$simPercent (Uyandırma kaydıyla sesli tetiklendiğinde otomatik ölçülür)"
        }

        if (!hasPin) {
            return ExecutionOutcome(
                intentTag = "VOICE_UNLOCK",
                summaryText = "Kilit kasasında kayıtlı bir PIN bulunamadı. Uyandırma sekmesindeki 'Cihaz Kilidi Şifre Kasası'na cihaz kilidinizle PIN kaydedebilirsiniz.",
                steps = steps + "! Kayıtlı kilit şifresi yok",
                success = false
            )
        }

        val pinResult = SecurityVaultManager.readDecryptedPin(context)
        val pin = pinResult.getOrNull()
        if (pin.isNullOrBlank()) {
            return ExecutionOutcome(
                intentTag = "VOICE_UNLOCK",
                summaryText = "Android Keystore şifreli PIN okunamadı.",
                steps = steps + "! Keystore çözümleme hatası",
                success = false
            )
        }

        val attemptedTap = a11y?.attemptLockScreenPinEntry(pin) == true
        if (attemptedTap) {
            steps += "✓ Kilit ekranı tuş takımına şifre gönderildi"
        } else {
            steps += "! Android güvenlik kısıtı: İşletim sistemi, kilit ekranı PIN tuşlamasını üçüncü parti servislere kapatabilir (Android 13+)"
        }

        return ExecutionOutcome(
            intentTag = "VOICE_UNLOCK",
            summaryText = if (attemptedTap) {
                "Ses doğrulama geçti (%$simPercent) ve kilit şifresi denendi."
            } else {
                "Ses izi kontrol edildi (%$simPercent) ve Keystore kasasındaki şifre hazırlandı. Ancak Android sistem güvenliği üçüncü parti uygulamaların sistem PIN ekranını otomatik geçmesini engeller; cihaz kilidi ekranı gösteriliyor."
            },
            steps = steps,
            success = true,
            requiresAccessibilityGuide = (a11y == null)
        )
    }

    private fun handleZipArchiveOp(intent: CommandIntent.ZipArchiveOp): ExecutionOutcome {
        return when (intent.action) {
            ZipAction.LIST -> {
                val res = OfflineFileArchiveEngine.listZipEntries(context, workspaceZipName = intent.archiveName)
                res.fold(
                    onSuccess = { entries ->
                        ExecutionOutcome(
                            intentTag = "ZIP_ARCHIVE_LIST",
                            summaryText = "ZIP içeriği (${entries.size} öğe):\n" + entries.take(12).joinToString("\n") { "• $it" },
                            steps = listOf("✓ ZIP arşivi açıldı ve taranıldı (${entries.size} giriş)"),
                            success = true
                        )
                    },
                    onFailure = { err ->
                        ExecutionOutcome(
                            intentTag = "ZIP_ARCHIVE_LIST",
                            summaryText = "ZIP okunamadı: ${err.localizedMessage}",
                            steps = listOf("! ${err.localizedMessage}"),
                            success = false
                        )
                    }
                )
            }
            ZipAction.CREATE -> {
                val folder = intent.subFolder ?: "belgeler"
                val outName = intent.archiveName ?: "${folder}_arsiv.zip"
                val res = OfflineFileArchiveEngine.compressWorkspaceFolderToZip(context, folder, outName)
                res.fold(
                    onSuccess = { file ->
                        ExecutionOutcome(
                            intentTag = "ZIP_ARCHIVE_CREATE",
                            summaryText = "'$folder' klasörü '${file.name}' olarak sıkıştırıldı (${file.length()} bayt).",
                            steps = listOf("✓ ZIP oluşturuldu: ${file.name}"),
                            success = true
                        )
                    },
                    onFailure = { err ->
                        ExecutionOutcome(
                            intentTag = "ZIP_ARCHIVE_CREATE",
                            summaryText = "ZIP oluşturulamadı: ${err.localizedMessage}",
                            steps = listOf("! ${err.localizedMessage}"),
                            success = false
                        )
                    }
                )
            }
            ZipAction.EXTRACT -> {
                val res = OfflineFileArchiveEngine.extractZip(
                    context = context,
                    workspaceZipName = intent.archiveName,
                    subFolderFilter = intent.subFolder,
                    extractToRoot = intent.extractToRoot
                )
                res.fold(
                    onSuccess = { report ->
                        val filterNote = report.folderFilter?.let { " ('$it' klasörü)" } ?: ""
                        ExecutionOutcome(
                            intentTag = "ZIP_ARCHIVE_EXTRACT",
                            summaryText = "${report.archiveName}$filterNote arşivi açıldı; ${report.extractedCount} dosya '${report.destinationLabel}' konumuna çıkarıldı.",
                            steps = listOf(
                                "✓ Arşiv açıldı: ${report.archiveName}",
                                "✓ Hedef: ${report.destinationLabel}"
                            ) + report.extractedPaths.take(6).map { "  → $it" },
                            success = report.extractedCount > 0
                        )
                    },
                    onFailure = { err ->
                        ExecutionOutcome(
                            intentTag = "ZIP_ARCHIVE_EXTRACT",
                            summaryText = "ZIP çıkarılamadı: ${err.localizedMessage}",
                            steps = listOf("! ${err.localizedMessage}"),
                            success = false
                        )
                    }
                )
            }
        }
    }

    private fun handleFileWorkspaceOp(intent: CommandIntent.FileWorkspaceOp): ExecutionOutcome {
        return when (intent.action) {
            FileOpAction.CREATE_FOLDER -> {
                val res = OfflineFileArchiveEngine.createFolderInWorkspace(context, intent.targetName)
                res.fold(
                    onSuccess = { dir ->
                        ExecutionOutcome(
                            intentTag = "FILE_CREATE_FOLDER",
                            summaryText = "'${dir.name}' klasörü yerel çalışma alanında oluşturuldu.",
                            steps = listOf("✓ Klasör oluşturuldu: YankiWorkspace/${dir.name}"),
                            success = true
                        )
                    },
                    onFailure = { err ->
                        ExecutionOutcome(
                            intentTag = "FILE_CREATE_FOLDER",
                            summaryText = "Klasör oluşturulamadı: ${err.localizedMessage}",
                            steps = listOf("! ${err.localizedMessage}"),
                            success = false
                        )
                    }
                )
            }
            FileOpAction.LIST_FILES -> {
                val items = OfflineFileArchiveEngine.listWorkspaceItems(context)
                ExecutionOutcome(
                    intentTag = "FILE_LIST",
                    summaryText = "Yerel Çalışma Alanı (${items.size} öğe):\n" +
                        items.take(14).joinToString("\n") {
                            if (it.isDirectory) "📁 ${it.relativePath}/" else "📄 ${it.relativePath} (${it.sizeBytes} B)"
                        },
                    steps = listOf("✓ Yerel dosya ve klasör dizini listelendi"),
                    success = true
                )
            }
        }
    }

    private fun handleQuickCalculate(raw: String): ExecutionOutcome {
        val m = Regex("""(-?\d+(?:\.\d+)?)\s*([+\-*/xX])\s*(-?\d+(?:\.\d+)?)""").find(raw)
        if (m == null) {
            return ExecutionOutcome(
                intentTag = "OFFLINE_CALC",
                summaryText = "İki sayı ve işlem (+, -, *, /) içeren bir ifade yazın (ör. 'hesapla 1250 * 4').",
                steps = listOf("! Matematiksel ifade ayrıştırılamadı"),
                success = false
            )
        }
        val a = m.groupValues[1].toDoubleOrNull() ?: 0.0
        val op = m.groupValues[2]
        val b = m.groupValues[3].toDoubleOrNull() ?: 0.0
        val result = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*", "x", "X" -> a * b
            "/" -> if (b != 0.0) a / b else Double.NaN
            else -> Double.NaN
        }
        val formatted = if (result.isNaN()) "Tanımsız (0'a bölme)"
        else if (result % 1.0 == 0.0) result.toLong().toString()
        else String.format(Locale.US, "%.4f", result)

        return ExecutionOutcome(
            intentTag = "OFFLINE_CALC",
            summaryText = "$a $op $b = $formatted",
            steps = listOf("✓ Çevrimdışı aritmetik işlem tamamlandı"),
            success = !result.isNaN()
        )
    }

    @Suppress("DEPRECATION")
    private fun handleWifi(enable: Boolean, a11y: AssistantAccessibilityService?): ExecutionOutcome {
        val steps = mutableListOf<String>()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ok = wifiManager?.setWifiEnabled(enable) == true
            steps += if (ok) "✓ WifiManager doğrudan ${if (enable) "açıldı" else "kapatıldı"}" else "! WifiManager değiştirilemedi"
            return ExecutionOutcome(
                intentTag = "WIFI_CONTROL",
                summaryText = "Wi-Fi ${if (enable) "açıldı" else "kapatıldı"}.",
                steps = steps,
                success = ok
            )
        } else {
            val panelIntent = Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { context.startActivity(panelIntent) }.onFailure {
                context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            steps += "✓ Android Wi-Fi hızlı kontrol paneli açıldı"
            if (a11y != null) {
                a11y.tryToggleSystemSwitchInPanel(listOf("Wi-Fi", "İnternet", "Kablosuz"), enable)
                steps += "✓ Erişilebilirlik otomasyonu Wi-Fi anahtarını ${if (enable) "AÇIK" else "KAPALI"} konuma getiriyor"
            } else {
                steps += "• Tek dokunuşsuz otomatik geçiş için Erişilebilirlik Servisini açabilirsiniz"
            }
            return ExecutionOutcome(
                intentTag = "WIFI_CONTROL",
                summaryText = if (a11y != null) {
                    "Wi-Fi paneli açıldı ve ${if (enable) "açma" else "kapatma"} adımı otomasyonla tetiklendi."
                } else {
                    "Wi-Fi kontrol paneli açıldı. Otomatik dokunma için Erişilebilirlik Servisini etkinleştirin."
                },
                steps = steps,
                success = true
            )
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun handleBluetooth(enable: Boolean, a11y: AssistantAccessibilityService?): ExecutionOutcome {
        val steps = mutableListOf<String>()
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = btManager?.adapter

        val hasConnectPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else true

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU && hasConnectPerm && adapter != null) {
            val ok = if (enable) adapter.enable() else adapter.disable()
            if (ok) {
                steps += "✓ BluetoothAdapter doğrudan ${if (enable) "etkinleştirildi" else "kapatıldı"}"
                return ExecutionOutcome(
                    intentTag = "BLUETOOTH_CONTROL",
                    summaryText = "Bluetooth ${if (enable) "açıldı" else "kapatıldı"}.",
                    steps = steps,
                    success = true
                )
            }
        }

        val btIntent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(btIntent)
        steps += "✓ Bluetooth ayarları açıldı"
        if (a11y != null) {
            a11y.tryToggleSystemSwitchInPanel(listOf("Bluetooth", "Cihaz bağlantısı"), enable)
            steps += "✓ Erişilebilirlik otomasyonu Bluetooth anahtarını ${if (enable) "AÇIK" else "KAPALI"} konuma getiriyor"
        } else {
            steps += "• Otomatik anahtarlama için Erişilebilirlik Servisini etkinleştirebilirsiniz"
        }

        return ExecutionOutcome(
            intentTag = "BLUETOOTH_CONTROL",
            summaryText = if (a11y != null) {
                "Bluetooth ayarları açıldı ve ${if (enable) "açma" else "kapatma"} otomasyonu başlatıldı."
            } else {
                "Bluetooth ayarları açıldı."
            },
            steps = steps,
            success = true
        )
    }

    private fun handleFlashlight(enable: Boolean): ExecutionOutcome {
        return runCatching {
            val camMgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = camMgr.cameraIdList.firstOrNull { id ->
                camMgr.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: error("Flaş donanımı bulunamadı")
            camMgr.setTorchMode(cameraId, enable)
            torchEnabled = enable
            ExecutionOutcome(
                intentTag = "FLASHLIGHT",
                summaryText = "El feneri ${if (enable) "açıldı" else "kapatıldı"}.",
                steps = listOf("✓ CameraManager.setTorchMode($enable) uygulandı"),
                success = true
            )
        }.getOrElse { err ->
            ExecutionOutcome(
                intentTag = "FLASHLIGHT",
                summaryText = "Fener kontrol edilemedi: ${err.localizedMessage}",
                steps = listOf("! Donanım flaşı erişilemedi"),
                success = false
            )
        }
    }

    private fun handleVolume(mode: VolumeMode): ExecutionOutcome {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (mode) {
            VolumeMode.UP -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            VolumeMode.DOWN -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            VolumeMode.MUTE -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        }
        val msg = when (mode) {
            VolumeMode.UP -> "Medya sesi artırıldı."
            VolumeMode.DOWN -> "Medya sesi azaltıldı."
            VolumeMode.MUTE -> "Ses kapatıldı (Sessiz)."
        }
        return ExecutionOutcome(
            intentTag = "AUDIO_CONTROL",
            summaryText = msg,
            steps = listOf("✓ AudioManager ses seviyesi güncellendi"),
            success = true
        )
    }

    private fun handleTimer(minutes: Int): ExecutionOutcome {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Axiom Zamanlayıcı")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            context.startActivity(intent)
            ExecutionOutcome(
                intentTag = "TIMER",
                summaryText = "$minutes dakikalık zamanlayıcı başlatıldı.",
                steps = listOf("✓ AlarmClock.ACTION_SET_TIMER ($minutes dk) tetiklendi"),
                success = true
            )
        }.getOrElse {
            ExecutionOutcome(
                intentTag = "TIMER",
                summaryText = "Saat uygulaması zamanlayıcıyı başlatamadı.",
                steps = listOf("! Saat uygulaması bulunamadı"),
                success = false
            )
        }
    }

    private fun handleAlarm(hour: Int, minute: Int): ExecutionOutcome {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Axiom Alarmı")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            context.startActivity(intent)
            ExecutionOutcome(
                intentTag = "ALARM",
                summaryText = "%02d:%02d için alarm kurulumu açıldı.".format(hour, minute),
                steps = listOf("✓ AlarmClock.ACTION_SET_ALARM (%02d:%02d) tetiklendi".format(hour, minute)),
                success = true
            )
        }.getOrElse {
            ExecutionOutcome(
                intentTag = "ALARM",
                summaryText = "Alarm uygulaması açılamadı.",
                steps = listOf("! Alarm uygulaması bulunamadı"),
                success = false
            )
        }
    }

    private fun handleGlobalNav(action: NavAction, a11y: AssistantAccessibilityService?): ExecutionOutcome {
        if (a11y == null) {
            return ExecutionOutcome(
                intentTag = "NAV_ACTION",
                summaryText = "Sistem navigasyon aksiyonları için Erişilebilirlik Servisini etkinleştirin.",
                steps = listOf("! Erişilebilirlik Servisi gerekli"),
                success = false,
                requiresAccessibilityGuide = true
            )
        }
        val ok = a11y.triggerGlobalNav(action)
        return ExecutionOutcome(
            intentTag = "NAV_ACTION",
            summaryText = if (ok) "Sistem komutu uygulandı (${action.name})." else "Sistem komutu başarısız.",
            steps = listOf("✓ Global Action: ${action.name}"),
            success = ok
        )
    }

    private fun handleAppAutomation(
        intent: CommandIntent.AppAutomation,
        macros: List<AutomationMacroEntity>,
        a11y: AssistantAccessibilityService?
    ): ExecutionOutcome {
        val qNorm = OfflineNluEngine.normalizeTrEn(intent.appNameQuery)

        // Check saved custom macros first
        val matchingMacro = macros.firstOrNull { m ->
            val tNorm = OfflineNluEngine.normalizeTrEn("${m.title} ${m.triggerPhrase} ${m.targetAppLabel}")
            tNorm.contains(qNorm) && intent.steps.size <= 2
        }

        val apps = listLaunchableApps()
        val matchedApp = findBestAppMatch(qNorm, apps)
            ?: matchingMacro?.let { InstalledAppInfo(it.targetPackageName, it.targetAppLabel) }

        if (matchedApp == null) {
            return ExecutionOutcome(
                intentTag = "APP_AUTOMATION",
                summaryText = "\"${intent.appNameQuery}\" adlı yüklü bir uygulama cihazda bulunamadı. Otomasyon sekmesinden yüklü uygulamaları seçebilirsiniz.",
                steps = listOf("! Uygulama bulunamadı: ${intent.appNameQuery}"),
                success = false
            )
        }

        val stepsToRun = if (matchingMacro != null && intent.steps.size <= 2) {
            StepSerializer.decode(matchingMacro.stepsSerialized)
        } else {
            intent.steps
        }

        val stepSummary = stepsToRun.map { step ->
            when (step.type) {
                AutomationActionType.OPEN_APP -> "→ Aç: ${matchedApp.label} (${matchedApp.packageName})"
                AutomationActionType.WAIT -> "→ Bekle: ${step.delayMs} ms"
                AutomationActionType.CLICK_TEXT -> "→ Tıkla: \"${step.target}\""
                AutomationActionType.INPUT_TEXT -> "→ Yaz: \"${step.value}\""
                AutomationActionType.SCROLL_DOWN -> "→ Aşağı kaydır"
                AutomationActionType.SCROLL_UP -> "→ Yukarı kaydır"
                AutomationActionType.PRESS_BACK -> "→ Geri git"
                AutomationActionType.PRESS_HOME -> "→ Ana ekran"
            }
        }

        val hasUiSubSteps = stepsToRun.any {
            it.type != AutomationActionType.OPEN_APP && it.type != AutomationActionType.WAIT
        }

        if (a11y != null) {
            a11y.executeSteps(stepsToRun, launchPackageFirst = matchedApp.packageName)
            return ExecutionOutcome(
                intentTag = "APP_AUTOMATION",
                summaryText = "${matchedApp.label} başlatılıyor ve ${stepsToRun.size} adımlı otomasyon yürütülüyor.",
                steps = stepSummary,
                success = true
            )
        } else {
            // Even without AccessibilityService, we can still launch the target app!
            val launch = context.packageManager.getLaunchIntentForPackage(matchedApp.packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (launch != null) {
                context.startActivity(launch)
            }
            return ExecutionOutcome(
                intentTag = "APP_AUTOMATION",
                summaryText = if (hasUiSubSteps) {
                    "${matchedApp.label} açıldı. Uygulama içi otomatik tıklama ve yazı yazma adımlarını yürütmek için Erişilebilirlik Servisini açın."
                } else {
                    "${matchedApp.label} açıldı."
                },
                steps = stepSummary,
                success = true,
                requiresAccessibilityGuide = hasUiSubSteps
            )
        }
    }

    private fun findBestAppMatch(queryNorm: String, apps: List<InstalledAppInfo>): InstalledAppInfo? {
        val aliasMap = mapOf(
            "ayarlar" to listOf("settings", "ayarlar"),
            "kamera" to listOf("camera", "kamera"),
            "mesajlar" to listOf("messages", "mesaj", "sms"),
            "galeri" to listOf("gallery", "photos", "fotoğraflar", "galeri"),
            "hesap makinesi" to listOf("calculator", "hesap"),
            "saat" to listOf("clock", "saat"),
            "takvim" to listOf("calendar", "takvim"),
            "notlar" to listOf("notes", "keep", "not"),
            "tarayici" to listOf("chrome", "browser", "firefox", "tarayıcı"),
            "rehber" to listOf("contacts", "kişiler", "rehber"),
            "telefon" to listOf("phone", "dialer", "telefon")
        )
        val candidates = aliasMap[queryNorm] ?: listOf(queryNorm)
        return apps.firstOrNull { app ->
            val lNorm = OfflineNluEngine.normalizeTrEn(app.label)
            val pNorm = OfflineNluEngine.normalizeTrEn(app.packageName)
            candidates.any { c -> lNorm.contains(c) || pNorm.contains(c) }
        }
    }
}
