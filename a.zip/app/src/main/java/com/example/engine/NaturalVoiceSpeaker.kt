package com.example.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class TtsVoiceProfileStatus(
    val isReady: Boolean = false,
    val selectedVoiceName: String = "Varsayılan Sistem Sesi",
    val isOfflineVoice: Boolean = true,
    val isMaleMatched: Boolean = false,
    val availableTurkishVoices: Int = 0,
    val availableEnglishVoices: Int = 0
)

/**
 * Fluid, low-latency, uninterrupted male-tuned offline Text-to-Speech engine.
 * Normalizes punctuation/symbols into smooth prose and pre-queues clauses so speech
 * flows naturally without robotic word-by-word pauses.
 */
class NaturalVoiceSpeaker(context: Context) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = TextToSpeech(appContext, this)
    private var initialized = false

    private val _status = MutableStateFlow(TtsVoiceProfileStatus())
    val status = _status.asStateFlow()

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            initialized = true
            configureMaleVoice(Locale("tr", "TR"))
        } else {
            _status.value = _status.value.copy(isReady = false)
        }
    }

    fun configureMaleVoice(targetLocale: Locale) {
        if (!initialized) return
        val engine = tts ?: return

        val allVoices = runCatching { engine.voices?.toList().orEmpty() }.getOrDefault(emptyList())
        val trCount = allVoices.count { it.locale.language.equals("tr", ignoreCase = true) }
        val enCount = allVoices.count { it.locale.language.equals("en", ignoreCase = true) }

        val langVoices = allVoices.filter {
            it.locale.language.equals(targetLocale.language, ignoreCase = true)
        }

        val maleHints = listOf(
            "male", "erkek", "mfm", "ama", "tpd", "iom", "iol", "sfg",
            "kemal", "mehmet", "emre", "ali", "adam", "daniel", "guy", "ryan", "davis"
        )
        val femaleHints = listOf("female", "kadin", "tpf", "sfb", "iob", "iof", "yeliz", "ayse", "samantha")

        val chosenVoice: Voice? = langVoices
            .sortedWith(
                compareByDescending<Voice> { v ->
                    val name = v.name.lowercase(Locale.US)
                    val feats = v.features?.joinToString(" ")?.lowercase(Locale.US).orEmpty()
                    var score = 0
                    if (!v.isNetworkConnectionRequired) score += 40
                    if (v.quality >= Voice.QUALITY_HIGH) score += 25
                    if (maleHints.any { name.contains(it) || feats.contains(it) }) score += 50
                    if (femaleHints.any { name.contains(it) }) score -= 35
                    if (v.locale.country.equals(targetLocale.country, ignoreCase = true)) score += 10
                    score
                }
            )
            .firstOrNull()

        if (chosenVoice != null) {
            engine.voice = chosenVoice
        } else {
            engine.language = targetLocale
        }

        // Warm natural baritone male pitch & fluid conversational rate without gaps
        val isExplicitMale = chosenVoice?.name?.lowercase(Locale.US)?.let { n ->
            maleHints.any { n.contains(it) }
        } == true
        engine.setPitch(if (isExplicitMale) 0.94f else 0.85f)
        engine.setSpeechRate(1.06f)

        _status.value = TtsVoiceProfileStatus(
            isReady = true,
            selectedVoiceName = chosenVoice?.name ?: "Sistem (${targetLocale.displayLanguage})",
            isOfflineVoice = chosenVoice?.isNetworkConnectionRequired == false,
            isMaleMatched = isExplicitMale,
            availableTurkishVoices = trCount,
            availableEnglishVoices = enCount
        )
    }

    fun speakFluidly(rawText: String, localeCode: String = "tr-TR") {
        if (!initialized) return
        val engine = tts ?: return
        val locale = if (localeCode.startsWith("en")) Locale.US else Locale("tr", "TR")
        if (engine.voice?.locale?.language != locale.language) {
            configureMaleVoice(locale)
        }

        val prose = normalizeToFluidProse(rawText)
        if (prose.isBlank()) return

        // Split only at natural sentence boundaries and pre-queue seamlessly so synthesis pipelines ahead
        val sentences = prose.split(Regex("""(?<=[.!?])\s+"""))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        if (sentences.isEmpty()) {
            engine.speak(prose, TextToSpeech.QUEUE_FLUSH, null, "yanki_0")
            return
        }

        sentences.forEachIndexed { idx, sentence ->
            val mode = if (idx == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            engine.speak(sentence, mode, null, "yanki_${System.currentTimeMillis()}_$idx")
        }
    }

    fun stop() {
        runCatching { tts?.stop() }
    }

    fun shutdown() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
        initialized = false
    }

    private fun normalizeToFluidProse(raw: String): String {
        return raw
            .replace(Regex("""\[[A-Z0-9_]+\]"""), "")
            .replace("https://", "")
            .replace("http://", "")
            .replace("✓", "")
            .replace("•", ", ")
            .replace("→", ", ")
            .replace("—", ", ")
            .replace("*", "")
            .replace("#", "")
            .replace(Regex("""%(\d+)"""), "yüzde $1")
            .replace("MB", " megabayt")
            .replace("GB", " gigabayt")
            .replace(Regex("""\n+"""), ". ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }
}
