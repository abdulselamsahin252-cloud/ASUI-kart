package com.example.engine

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class WorkspaceItem(
    val name: String,
    val relativePath: String,
    val isDirectory: Boolean,
    val sizeBytes: Long
)

data class ZipExtractionReport(
    val archiveName: String,
    val destinationLabel: String,
    val extractedCount: Int,
    val extractedPaths: List<String>,
    val folderFilter: String?
)

/**
 * Real offline ZIP archive & folder manager supporting both the local YankiWorkspace
 * and user-selected Storage Access Framework (SAF) .zip files and destination folders.
 */
object OfflineFileArchiveEngine {

    private const val WORKSPACE_DIR = "YankiWorkspace"

    fun getWorkspaceRoot(context: Context): File {
        val root = File(context.filesDir, WORKSPACE_DIR).apply { mkdirs() }
        ensureSampleArchive(root)
        return root
    }

    private fun ensureSampleArchive(root: File) {
        val sampleZip = File(root, "proje_yedek.zip")
        if (!sampleZip.exists()) {
            ZipOutputStream(sampleZip.outputStream()).use { zos ->
                writeZipEntry(zos, "belgeler/", byteArrayOf())
                writeZipEntry(
                    zos,
                    "belgeler/notlar.txt",
                    "Axiom çevrimdışı çalışma notları.\nTüm ZIP ve klasör işlemleri internetsiz yapılır.".toByteArray()
                )
                writeZipEntry(
                    zos,
                    "belgeler/rapor.md",
                    "# Yerel Rapor\n- Türkçe NLU aktif\n- Arka plan uyandırma hazır".toByteArray()
                )
                writeZipEntry(zos, "ayarlar/", byteArrayOf())
                writeZipEntry(zos, "ayarlar/config.json", """{"offline":true,"lang":"tr-TR"}""".toByteArray())
            }
        }
    }

    private fun writeZipEntry(zos: ZipOutputStream, name: String, data: ByteArray) {
        zos.putNextEntry(ZipEntry(name))
        if (data.isNotEmpty()) zos.write(data)
        zos.closeEntry()
    }

    fun listWorkspaceItems(context: Context): List<WorkspaceItem> {
        val root = getWorkspaceRoot(context)
        val result = mutableListOf<WorkspaceItem>()
        root.walkTopDown()
            .filter { it != root }
            .sortedWith(compareBy<File> { !it.isDirectory }.thenBy { it.relativeTo(root).path })
            .take(80)
            .forEach { file ->
                val rel = file.relativeTo(root).path
                result += WorkspaceItem(
                    name = file.name,
                    relativePath = rel,
                    isDirectory = file.isDirectory,
                    sizeBytes = if (file.isDirectory) 0L else file.length()
                )
            }
        return result
    }

    fun createFolderInWorkspace(context: Context, folderName: String): Result<File> = runCatching {
        val clean = sanitizeName(folderName).ifBlank { "yeni_klasor" }
        val dir = File(getWorkspaceRoot(context), clean)
        if (!dir.exists() && !dir.mkdirs()) error("Klasör oluşturulamadı")
        dir
    }

    fun listZipEntries(context: Context, zipUri: Uri? = null, workspaceZipName: String? = null): Result<List<String>> =
        runCatching {
            val entries = mutableListOf<String>()
            openZipStream(context, zipUri, workspaceZipName).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    entries += entry.name
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            entries
        }

    fun extractZip(
        context: Context,
        zipUri: Uri? = null,
        workspaceZipName: String? = null,
        subFolderFilter: String? = null,
        extractToRoot: Boolean = true,
        targetTreeUri: Uri? = null
    ): Result<ZipExtractionReport> = runCatching {
        val root = getWorkspaceRoot(context)
        val archiveLabel = when {
            zipUri != null -> queryDisplayName(context, zipUri) ?: "secilen_arsiv.zip"
            !workspaceZipName.isNullOrBlank() -> findBestZipInWorkspace(root, workspaceZipName)?.name ?: workspaceZipName
            else -> findBestZipInWorkspace(root, "")?.name ?: error("Çalışma alanında .zip dosyası bulunamadı")
        }

        val normalizedFilter = subFolderFilter?.trim()?.trim('/')?.let { OfflineNluEngine.normalizeTrEn(it) }
            ?.takeIf { it.isNotBlank() && it != "su" && it != "bu" && it != "tum" }

        val extracted = mutableListOf<String>()
        val targetTree = targetTreeUri?.let { DocumentFile.fromTreeUri(context, it) }

        openZipStream(context, zipUri, workspaceZipName).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val rawName = entry.name.replace("\\", "/").trimStart('/')
                // Zip Slip protection
                if (rawName.contains("..")) {
                    zis.closeEntry()
                    entry = zis.nextEntry
                    continue
                }

                val matchesFilter = if (normalizedFilter == null) {
                    true
                } else {
                    val normEntry = OfflineNluEngine.normalizeTrEn(rawName)
                    normEntry.startsWith("$normalizedFilter/") || normEntry == normalizedFilter
                }

                if (matchesFilter && rawName.isNotBlank()) {
                    val outputRelPath = if (extractToRoot && normalizedFilter != null) {
                        val stripped = rawName.substringAfter("/", missingDelimiterValue = rawName)
                        stripped.trimStart('/')
                    } else if (extractToRoot) {
                        rawName.substringAfterLast('/', missingDelimiterValue = rawName)
                    } else {
                        rawName
                    }

                    if (outputRelPath.isNotBlank() && !entry.isDirectory) {
                        val bytes = zis.readBytes()
                        if (targetTree != null && targetTree.canWrite()) {
                            writeToDocumentTree(context, targetTree, outputRelPath, bytes)
                        } else {
                            val outFile = File(root, outputRelPath)
                            val canonicalRoot = root.canonicalPath
                            val canonicalOut = outFile.canonicalPath
                            if (canonicalOut.startsWith(canonicalRoot)) {
                                outFile.parentFile?.mkdirs()
                                outFile.writeBytes(bytes)
                            }
                        }
                        extracted += outputRelPath
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val destLabel = targetTree?.name ?: "Ana Dizin ($WORKSPACE_DIR)"
        ZipExtractionReport(
            archiveName = archiveLabel,
            destinationLabel = destLabel,
            extractedCount = extracted.size,
            extractedPaths = extracted,
            folderFilter = subFolderFilter
        )
    }

    fun compressWorkspaceFolderToZip(context: Context, folderName: String, zipName: String): Result<File> =
        runCatching {
            val root = getWorkspaceRoot(context)
            val sourceDir = if (folderName.isBlank()) root else File(root, folderName)
            if (!sourceDir.exists()) error("Klasör bulunamadı: $folderName")
            val cleanZipName = if (zipName.endsWith(".zip", ignoreCase = true)) zipName else "$zipName.zip"
            val outZip = File(root, sanitizeName(cleanZipName))

            ZipOutputStream(outZip.outputStream()).use { zos ->
                sourceDir.walkTopDown()
                    .filter { it.isFile && it != outZip }
                    .forEach { file ->
                        val rel = file.relativeTo(sourceDir).path.replace("\\", "/")
                        writeZipEntry(zos, rel, file.readBytes())
                    }
            }
            outZip
        }

    private fun openZipStream(context: Context, zipUri: Uri?, workspaceZipName: String?): ZipInputStream {
        val stream: InputStream = if (zipUri != null) {
            context.contentResolver.openInputStream(zipUri) ?: error("Seçilen ZIP dosyası okunamadı")
        } else {
            val root = getWorkspaceRoot(context)
            val file = findBestZipInWorkspace(root, workspaceZipName.orEmpty())
                ?: error("ZIP dosyası bulunamadı. 'Dosya & ZIP' sekmesinden bir .zip seçebilirsiniz.")
            file.inputStream()
        }
        return ZipInputStream(stream)
    }

    private fun findBestZipInWorkspace(root: File, query: String): File? {
        val zips = root.walkTopDown().filter { it.isFile && it.extension.equals("zip", ignoreCase = true) }.toList()
        if (zips.isEmpty()) return null
        if (query.isBlank()) return zips.first()
        val qNorm = OfflineNluEngine.normalizeTrEn(query)
        return zips.firstOrNull { OfflineNluEngine.normalizeTrEn(it.name).contains(qNorm) } ?: zips.first()
    }

    private fun writeToDocumentTree(context: Context, rootTree: DocumentFile, relPath: String, bytes: ByteArray) {
        val parts = relPath.split("/").filter { it.isNotBlank() }
        if (parts.isEmpty()) return
        var currentDir = rootTree
        for (i in 0 until parts.lastIndex) {
            val dirName = parts[i]
            val existing = currentDir.findFile(dirName)
            currentDir = if (existing != null && existing.isDirectory) {
                existing
            } else {
                currentDir.createDirectory(dirName) ?: currentDir
            }
        }
        val fileName = parts.last()
        currentDir.findFile(fileName)?.delete()
        val doc = currentDir.createFile("application/octet-stream", fileName) ?: return
        context.contentResolver.openOutputStream(doc.uri)?.use { it.write(bytes) }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        return context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }
    }

    private fun sanitizeName(raw: String): String =
        raw.trim().replace(Regex("""[^a-zA-Z0-9çğıöşüÇĞİÖŞÜ._-]"""), "_")
}
