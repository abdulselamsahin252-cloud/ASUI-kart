package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Pure on-device 16kHz PCM Audio Recorder, Playback & Acoustic Signature Matcher.
 * Extracts normalized 24-bin acoustic energy envelope + ZCR + spectral band signature
 * from the user's recorded wake word and performs real-time sliding window matching.
 */
object AcousticWakeWordEngine {
    const val SAMPLE_RATE = 16_000
    const val SIGNATURE_BINS = 24

    data class RecordedSample(
        val audioFilePath: String,
        val durationMs: Long,
        val signatureCsv: String,
        val peakRms: Float,
        val waveformPreview: List<Float>
    )

    @SuppressLint("MissingPermission")
    suspend fun recordWakeWordSample(
        context: Context,
        durationMs: Long = 2200L,
        onLevelUpdate: (Float, List<Float>) -> Unit
    ): Result<RecordedSample> = withContext(Dispatchers.IO) {
        runCatching {
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            val recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 2
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                error("Mikrofon başlatılamadı")
            }

            val totalSamplesTarget = (SAMPLE_RATE * durationMs / 1000L).toInt()
            val allSamples = ShortArray(totalSamplesTarget)
            var collected = 0
            val chunk = ShortArray(1024)

            try {
                recorder.startRecording()
                while (collected < totalSamplesTarget) {
                    val read = recorder.read(chunk, 0, minOf(chunk.size, totalSamplesTarget - collected))
                    if (read > 0) {
                        System.arraycopy(chunk, 0, allSamples, collected, read)
                        collected += read
                        val rms = computeRmsNormalized(chunk, read)
                        val bins = computeSpectrumBins(chunk, read, 16)
                        onLevelUpdate(rms, bins)
                    } else if (read < 0) {
                        break
                    }
                }
            } finally {
                runCatching { recorder.stop() }
                recorder.release()
            }

            val trimmed = trimSilence(allSamples.copyOf(collected))
            val dir = File(context.filesDir, "wake_words").apply { mkdirs() }
            val outFile = File(dir, "wake_${System.currentTimeMillis()}.pcm")
            writePcm16(outFile, trimmed)

            val signature = extractSignature(trimmed)
            val peakRms = trimmed.maxOfOrNull { abs(it.toInt()) }?.div(32768f) ?: 0.1f
            val preview = buildWaveformPreview(trimmed, 32)

            RecordedSample(
                audioFilePath = outFile.absolutePath,
                durationMs = (trimmed.size * 1000L / SAMPLE_RATE).coerceAtLeast(350L),
                signatureCsv = signature.joinToString(",") { "%.4f".format(java.util.Locale.US, it) },
                peakRms = peakRms,
                waveformPreview = preview
            )
        }
    }

    suspend fun playRecordedWakeWord(filePath: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(filePath)
            if (!file.exists()) error("Ses kaydı bulunamadı")
            val bytes = file.readBytes()
            if (bytes.isEmpty()) error("Boş ses kaydı")

            val minBuf = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, bytes.size))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            try {
                track.write(bytes, 0, bytes.size)
                track.play()
                val playMs = (bytes.size / 2L) * 1000L / SAMPLE_RATE + 150L
                kotlinx.coroutines.delay(playMs)
            } finally {
                runCatching { track.stop() }
                track.release()
            }
        }
    }

    fun parseSignature(csv: String): FloatArray {
        if (csv.isBlank()) return FloatArray(SIGNATURE_BINS)
        val parsed = csv.split(",").mapNotNull { it.trim().toFloatOrNull() }
        return if (parsed.size == SIGNATURE_BINS) parsed.toFloatArray() else FloatArray(SIGNATURE_BINS)
    }

    /**
     * Computes 24-bin acoustic signature:
     * - 16 normalized temporal RMS envelope bins (capturing syllable cadence of the recorded word)
     * - 4 zero-crossing-rate segment ratios (voicing / fricative profile)
     * - 4 spectral band energy ratios (low/mid-low/mid-high/high frequency balance)
     */
    fun extractSignature(samples: ShortArray): FloatArray {
        val out = FloatArray(SIGNATURE_BINS)
        if (samples.isEmpty()) return out

        val envelopeBins = 16
        val step = (samples.size / envelopeBins).coerceAtLeast(1)
        var maxEnv = 1e-6f
        for (b in 0 until envelopeBins) {
            val start = b * step
            val end = minOf(samples.size, start + step)
            var sumSq = 0.0
            for (i in start until end) {
                val v = samples[i] / 32768.0
                sumSq += v * v
            }
            val rms = sqrt(sumSq / (end - start).coerceAtLeast(1)).toFloat()
            out[b] = rms
            if (rms > maxEnv) maxEnv = rms
        }
        for (b in 0 until envelopeBins) {
            out[b] = out[b] / maxEnv
        }

        // 4 ZCR segments
        val zcrStep = (samples.size / 4).coerceAtLeast(2)
        for (seg in 0 until 4) {
            val start = seg * zcrStep
            val end = minOf(samples.size - 1, start + zcrStep)
            var crossings = 0
            for (i in start until end) {
                if ((samples[i] >= 0 && samples[i + 1] < 0) || (samples[i] < 0 && samples[i + 1] >= 0)) {
                    crossings++
                }
            }
            out[16 + seg] = (crossings.toFloat() / (end - start).coerceAtLeast(1) * 4f).coerceIn(0f, 1f)
        }

        // 4 coarse spectral energy bands via Goertzel/DFT probe
        val bands = computeSpectrumBins(samples, minOf(samples.size, 2048), 4)
        for (i in 0 until 4) {
            out[20 + i] = bands[i]
        }
        return out
    }

    fun matchConfidence(windowSamples: ShortArray, targetSignature: FloatArray): Float {
        if (windowSamples.size < 1600 || targetSignature.size != SIGNATURE_BINS) return 0f
        val windowSig = extractSignature(windowSamples)
        return cosineSim(windowSig, targetSignature)
    }

    /**
     * Evaluates speaker timbre similarity focusing on frequency band ratios & voicing ZCR
     * (indices 16..23 of the 24-bin signature, capturing vocal tract formant & pitch balance).
     */
    fun verifySpeakerSimilarity(windowSamples: ShortArray, targetSignature: FloatArray): Float {
        if (windowSamples.size < 1600 || targetSignature.size != SIGNATURE_BINS) return 0f
        val windowSig = extractSignature(windowSamples)
        val voiceA = windowSig.copyOfRange(16, SIGNATURE_BINS)
        val voiceB = targetSignature.copyOfRange(16, SIGNATURE_BINS)
        return cosineSim(voiceA, voiceB)
    }

    private fun cosineSim(a: FloatArray, b: FloatArray): Float {
        var dot = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        val denom = sqrt(normA) * sqrt(normB)
        if (denom < 1e-6) return 0f
        return (dot / denom).toFloat().coerceIn(0f, 1f)
    }

    fun computeRmsDb(samples: ShortArray, count: Int): Float {
        if (count <= 0) return -60f
        var sumSq = 0.0
        for (i in 0 until count) {
            val norm = samples[i] / 32768.0
            sumSq += norm * norm
        }
        val rms = sqrt(sumSq / count).coerceAtLeast(1e-5)
        return (20.0 * log10(rms)).toFloat().coerceIn(-60f, 0f)
    }

    fun computeRmsNormalized(samples: ShortArray, count: Int): Float {
        val db = computeRmsDb(samples, count)
        return ((db + 55f) / 55f).coerceIn(0f, 1f)
    }

    fun computeSpectrumBins(samples: ShortArray, count: Int, binCount: Int): List<Float> {
        if (count <= 0) return List(binCount) { 0.05f }
        val bins = MutableList(binCount) { 0.05f }
        val usable = minOf(count, 512)
        for (b in 0 until binCount) {
            val targetFreq = 180.0 + b * (3600.0 / binCount)
            val omega = 2.0 * PI * targetFreq / SAMPLE_RATE
            var cosSum = 0.0
            var sinSum = 0.0
            for (n in 0 until usable step 2) {
                val x = samples[n] / 32768.0
                cosSum += x * cos(omega * n)
                sinSum += x * sin(omega * n)
            }
            val mag = sqrt(cosSum * cosSum + sinSum * sinSum) / (usable / 2.0)
            bins[b] = (mag * 6.5).toFloat().coerceIn(0.05f, 1f)
        }
        return bins
    }

    private fun trimSilence(samples: ShortArray): ShortArray {
        if (samples.isEmpty()) return samples
        val threshold = 420
        var start = 0
        var end = samples.lastIndex
        while (start < end && abs(samples[start].toInt()) < threshold) start++
        while (end > start && abs(samples[end].toInt()) < threshold) end--
        val paddedStart = (start - 1200).coerceAtLeast(0)
        val paddedEnd = (end + 1200).coerceAtMost(samples.lastIndex)
        return if (paddedEnd - paddedStart > 1600) {
            samples.copyOfRange(paddedStart, paddedEnd + 1)
        } else {
            samples
        }
    }

    private fun buildWaveformPreview(samples: ShortArray, bars: Int): List<Float> {
        if (samples.isEmpty()) return List(bars) { 0.1f }
        val step = (samples.size / bars).coerceAtLeast(1)
        return List(bars) { i ->
            val s = i * step
            val e = minOf(samples.size, s + step)
            var peak = 0
            for (k in s until e) {
                val a = abs(samples[k].toInt())
                if (a > peak) peak = a
            }
            (peak / 32768f).coerceIn(0.08f, 1f)
        }
    }

    private fun writePcm16(file: File, samples: ShortArray) {
        val baos = ByteArrayOutputStream(samples.size * 2)
        for (s in samples) {
            baos.write(s.toInt() and 0xFF)
            baos.write((s.toInt() shr 8) and 0xFF)
        }
        file.writeBytes(baos.toByteArray())
    }
}
