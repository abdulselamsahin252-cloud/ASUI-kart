package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Pure on-device 16kHz PCM Audio Recorder, Playback & Biometric Speaker Voiceprint Matcher.
 *
 * Extracts a 44-bin acoustic + speaker biometric signature:
 * - [0..15]  16 normalized temporal RMS envelope bins (syllable cadence of the wake word)
 * - [16..19] 4 zero-crossing-rate voicing segment ratios
 * - [20..35] 16-band multi-frame averaged Log-Mel vocal tract formant profile (200Hz–4000Hz)
 * - [36..39] F0 fundamental pitch quartiles (p25, median, p75) & autocorrelation harmonicity
 * - [40..43] Spectral centroid, low/high balance, spectral contrast & voiced frame ratio
 */
object AcousticWakeWordEngine {
    const val SAMPLE_RATE = 16_000
    const val LEGACY_SIGNATURE_BINS = 24
    const val SIGNATURE_BINS = 44

    private val melCenterFreqsHz: DoubleArray = DoubleArray(16) { idx ->
        val melMin = 2595.0 * log10(1.0 + 200.0 / 700.0)
        val melMax = 2595.0 * log10(1.0 + 4000.0 / 700.0)
        val mel = melMin + (melMax - melMin) * idx / 15.0
        700.0 * (10.0.pow(mel / 2595.0) - 1.0)
    }

    data class RecordedSample(
        val audioFilePath: String,
        val durationMs: Long,
        val signatureCsv: String,
        val peakRms: Float,
        val waveformPreview: List<Float>
    )

    @SuppressLint("MissingPermission")
    suspend fun recordWakeWordSample(
        context: Context,
        durationMs: Long = 2200L,
        onLevelUpdate: (Float, List<Float>) -> Unit
    ): Result<RecordedSample> = withContext(Dispatchers.IO) {
        runCatching {
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            val recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 2
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                error("Mikrofon başlatılamadı")
            }

            val totalSamplesTarget = (SAMPLE_RATE * durationMs / 1000L).toInt()
            val allSamples = ShortArray(totalSamplesTarget)
            var collected = 0
            val chunk = ShortArray(1024)

            try {
                recorder.startRecording()
                while (collected < totalSamplesTarget) {
                    val read = recorder.read(chunk, 0, minOf(chunk.size, totalSamplesTarget - collected))
                    if (read > 0) {
                        System.arraycopy(chunk, 0, allSamples, collected, read)
                        collected += read
                        val rms = computeRmsNormalized(chunk, read)
                        val bins = computeSpectrumBins(chunk, read, 16)
                        onLevelUpdate(rms, bins)
                    } else if (read < 0) {
                        break
                    }
                }
            } finally {
                runCatching { recorder.stop() }
                recorder.release()
            }

            val trimmed = trimSilence(allSamples.copyOf(collected))
            val peakRms = trimmed.maxOfOrNull { abs(it.toInt()) }?.div(32768f) ?: 0f
            if (trimmed.size < 3200 || peakRms < 0.03f) {
                error("Net bir ses kaydı alınamadı; lütfen mikrofona konuşarak tekrar deneyin.")
            }

            val dir = File(context.filesDir, "wake_words").apply { mkdirs() }
            val outFile = File(dir, "wake_${System.currentTimeMillis()}.pcm")
            writePcm16(outFile, trimmed)

            val signature = extractSignature(trimmed)
            val preview = buildWaveformPreview(trimmed, 32)

            RecordedSample(
                audioFilePath = outFile.absolutePath,
                durationMs = (trimmed.size * 1000L / SAMPLE_RATE).coerceAtLeast(350L),
                signatureCsv = signature.joinToString(",") { "%.4f".format(java.util.Locale.US, it) },
                peakRms = peakRms,
                waveformPreview = preview
            )
        }
    }

    suspend fun playRecordedWakeWord(filePath: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(filePath)
            if (!file.exists()) error("Ses kaydı bulunamadı")
            val bytes = file.readBytes()
            if (bytes.isEmpty()) error("Boş ses kaydı")

            val minBuf = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, bytes.size))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            try {
                track.write(bytes, 0, bytes.size)
                track.play()
                val playMs = (bytes.size / 2L) * 1000L / SAMPLE_RATE + 150L
                kotlinx.coroutines.delay(playMs)
            } finally {
                runCatching { track.stop() }
                track.release()
            }
        }
    }

    fun hasBiometricVoiceprint(csv: String): Boolean {
        return csv.split(",").count { it.trim().toFloatOrNull() != null } >= SIGNATURE_BINS
    }

    fun parseSignature(csv: String): FloatArray {
        if (csv.isBlank()) return FloatArray(SIGNATURE_BINS)
        val parsed = csv.split(",").mapNotNull { it.trim().toFloatOrNull() }
        return when (parsed.size) {
            SIGNATURE_BINS -> parsed.toFloatArray()
            LEGACY_SIGNATURE_BINS -> parsed.toFloatArray()
            else -> FloatArray(SIGNATURE_BINS)
        }
    }

    /**
     * Computes 44-bin acoustic + speaker biometric signature across the entire spoken utterance:
     * - 0..15: 16 temporal RMS envelope bins
     * - 16..19: 4 ZCR segment voicing dynamics
     * - 20..35: 16-band multi-frame averaged Log-Mel vocal tract formant profile
     * - 36..39: F0 pitch distribution (p25, median, p75) + harmonicity strength
     * - 40..43: Spectral centroid, low/high energy balance, spectral contrast & voiced ratio
     */
    fun extractSignature(samples: ShortArray): FloatArray {
        val out = FloatArray(SIGNATURE_BINS)
        if (samples.isEmpty()) return out

        // 0..15: Temporal syllable envelope
        val envelopeBins = 16
        val step = (samples.size / envelopeBins).coerceAtLeast(1)
        var maxEnv = 1e-6f
        for (b in 0 until envelopeBins) {
            val start = b * step
            val end = minOf(samples.size, start + step)
            var sumSq = 0.0
            for (i in start until end) {
                val v = samples[i] / 32768.0
                sumSq += v * v
            }
            val rms = sqrt(sumSq / (end - start).coerceAtLeast(1)).toFloat()
            out[b] = rms
            if (rms > maxEnv) maxEnv = rms
        }
        for (b in 0 until envelopeBins) {
            out[b] = out[b] / maxEnv
        }

        // 16..19: 4 ZCR segments
        val zcrStep = (samples.size / 4).coerceAtLeast(2)
        for (seg in 0 until 4) {
            val start = seg * zcrStep
            val end = minOf(samples.size - 1, start + zcrStep)
            var crossings = 0
            for (i in start until end) {
                if ((samples[i] >= 0 && samples[i + 1] < 0) || (samples[i] < 0 && samples[i + 1] >= 0)) {
                    crossings++
                }
            }
            out[16 + seg] = (crossings.toFloat() / (end - start).coerceAtLeast(1) * 4f).coerceIn(0f, 1f)
        }

        // Multi-frame voiced spectral + F0 pitch analysis
        var globalPeak = 0.0
        for (s in samples) {
            val a = abs(s.toInt()) / 32768.0
            if (a > globalPeak) globalPeak = a
        }
        val frameSize = 512
        val hop = 256
        val melAccum = DoubleArray(16)
        val f0Values = mutableListOf<Float>()
        var harmSum = 0.0
        var centroidSum = 0.0
        var lowHighSum = 0.0
        var contrastSum = 0.0
        var totalFrames = 0
        var voicedFrames = 0

        if (samples.size >= frameSize) {
            val hann = DoubleArray(frameSize) { n -> 0.5 * (1.0 - cos(2.0 * PI * n / (frameSize - 1))) }
            val frameBuf = DoubleArray(frameSize)
            val energyGate = maxOf(0.014, globalPeak * 0.13)

            var pos = 0
            while (pos + frameSize <= samples.size) {
                totalFrames++
                var sumSq = 0.0
                for (n in 0 until frameSize) {
                    val norm = samples[pos + n] / 32768.0
                    sumSq += norm * norm
                    frameBuf[n] = norm * hann[n]
                }
                val frameRms = sqrt(sumSq / frameSize)
                if (frameRms >= energyGate) {
                    voicedFrames++
                    val frameMel = DoubleArray(16)
                    var weightedFreqSum = 0.0
                    var magSum = 1e-9
                    var lowSum = 0.0
                    var highSum = 0.0
                    var geomLogSum = 0.0

                    for (b in 0 until 16) {
                        val freq = melCenterFreqsHz[b]
                        val omega = 2.0 * PI * freq / SAMPLE_RATE
                        var cSum = 0.0
                        var sSum = 0.0
                        for (n in 0 until frameSize step 2) {
                            val x = frameBuf[n]
                            cSum += x * cos(omega * n)
                            sSum += x * sin(omega * n)
                        }
                        val mag = sqrt(cSum * cSum + sSum * sSum) / (frameSize / 2.0)
                        val logMag = log10(1.0 + mag * 140.0)
                        frameMel[b] = logMag
                        melAccum[b] += logMag

                        weightedFreqSum += freq * mag
                        magSum += mag
                        geomLogSum += ln(mag + 1e-6)
                        if (b < 6) lowSum += mag else if (b >= 10) highSum += mag
                    }

                    centroidSum += ((weightedFreqSum / magSum - 200.0) / 3800.0).coerceIn(0.0, 1.0)
                    lowHighSum += (lowSum / (lowSum + highSum + 1e-9)).coerceIn(0.0, 1.0)
                    val arithMean = magSum / 16.0
                    val geomMean = exp(geomLogSum / 16.0)
                    val flatness = (geomMean / (arithMean + 1e-9)).coerceIn(0.0, 1.0)
                    contrastSum += (1.0 - flatness)

                    // F0 pitch via normalized autocorrelation over lags 50..213 (75 Hz .. 320 Hz)
                    val pitchRes = estimateFramePitchAndHarmonicity(samples, pos, 280)
                    harmSum += pitchRes.second
                    if (pitchRes.second >= 0.42f && pitchRes.first in 72f..325f) {
                        f0Values.add(pitchRes.first)
                    }
                }
                pos += hop
            }
        }

        if (voicedFrames > 0) {
            var minM = Double.MAX_VALUE
            var maxM = Double.MIN_VALUE
            val avgMel = DoubleArray(16) { b ->
                val v = melAccum[b] / voicedFrames
                if (v < minM) minM = v
                if (v > maxM) maxM = v
                v
            }
            val span = (maxM - minM).coerceAtLeast(1e-5)
            for (b in 0 until 16) {
                out[20 + b] = ((avgMel[b] - minM) / span).toFloat().coerceIn(0f, 1f)
            }

            if (f0Values.isNotEmpty()) {
                f0Values.sort()
                val p25 = f0Values[(f0Values.size * 0.25f).toInt().coerceIn(0, f0Values.lastIndex)]
                val p50 = f0Values[(f0Values.size * 0.50f).toInt().coerceIn(0, f0Values.lastIndex)]
                val p75 = f0Values[(f0Values.size * 0.75f).toInt().coerceIn(0, f0Values.lastIndex)]
                out[36] = ((p25 - 70f) / 260f).coerceIn(0f, 1f)
                out[37] = ((p50 - 70f) / 260f).coerceIn(0f, 1f)
                out[38] = ((p75 - 70f) / 260f).coerceIn(0f, 1f)
            }
            out[39] = (harmSum / voicedFrames).toFloat().coerceIn(0f, 1f)
            out[40] = (centroidSum / voicedFrames).toFloat().coerceIn(0f, 1f)
            out[41] = (lowHighSum / voicedFrames).toFloat().coerceIn(0f, 1f)
            out[42] = (contrastSum / voicedFrames).toFloat().coerceIn(0f, 1f)
            out[43] = (voicedFrames.toFloat() / totalFrames.coerceAtLeast(1)).coerceIn(0f, 1f)
        } else {
            val bands = computeSpectrumBins(samples, minOf(samples.size, 512), 4)
            for (i in 0 until 4) out[20 + i] = bands[i]
        }

        return out
    }

    private fun estimateFramePitchAndHarmonicity(
        samples: ShortArray,
        offset: Int,
        windowLen: Int
    ): Pair<Float, Float> {
        val minLag = 50
        val maxLag = minOf(213, samples.size - offset - windowLen - 1)
        if (maxLag <= minLag + 2) return 0f to 0f

        var baseEnergy = 0.0
        for (n in 0 until windowLen step 2) {
            val v = samples[offset + n] / 32768.0
            baseEnergy += v * v
        }
        if (baseEnergy < 1e-6) return 0f to 0f

        val acfCurve = DoubleArray(maxLag - minLag + 1)
        var globalBestAcf = 0.0
        var globalBestLag = minLag
        for (lag in minLag..maxLag) {
            var dot = 0.0
            var shiftEnergy = 0.0
            for (n in 0 until windowLen step 2) {
                val a = samples[offset + n] / 32768.0
                val b = samples[offset + n + lag] / 32768.0
                dot += a * b
                shiftEnergy += b * b
            }
            val denom = sqrt(baseEnergy * shiftEnergy).coerceAtLeast(1e-9)
            val normAcf = (dot / denom).coerceIn(0.0, 1.0)
            acfCurve[lag - minLag] = normAcf
            if (normAcf > globalBestAcf) {
                globalBestAcf = normAcf
                globalBestLag = lag
            }
        }

        // Pick the FIRST local peak >= 85% of global peak to avoid 2T/3T octave doubling errors
        var chosenLag = globalBestLag
        var chosenAcf = globalBestAcf
        val threshold = globalBestAcf * 0.85
        for (i in 1 until acfCurve.lastIndex) {
            val cur = acfCurve[i]
            if (cur >= threshold && cur >= acfCurve[i - 1] && cur >= acfCurve[i + 1]) {
                chosenLag = minLag + i
                chosenAcf = cur
                break
            }
        }
        val f0Hz = SAMPLE_RATE.toFloat() / chosenLag.toFloat()
        return f0Hz to chosenAcf.toFloat().coerceIn(0f, 1f)
    }

    /**
     * Isolates the active speech window at the tail of the rolling buffer matching the recorded phrase's duration.
     * Returns null if there is no clear speech boundary or the speech segment is just continuous background chatter.
     */
    fun extractActiveSpeechWindow(ringWindow: ShortArray, targetDurationMs: Long): ShortArray? {
        if (ringWindow.size < 1600) return null
        val targetSamples = ((targetDurationMs.coerceIn(350L, 2600L) * SAMPLE_RATE) / 1000L).toInt()
        val windowLen = (targetSamples * 1.15f).toInt().coerceIn(3200, ringWindow.size)
        val tailStart = (ringWindow.size - windowLen).coerceAtLeast(0)
        val tail = ringWindow.copyOfRange(tailStart, ringWindow.size)
        val trimmed = trimSilence(tail)
        if (trimmed.size < (targetSamples * 0.48f).toInt()) return null

        if (tailStart > 2400) {
            val preSilenceRatio = computeLowEnergyFraction(ringWindow, 0, minOf(tailStart, 3200))
            if (preSilenceRatio < 0.12f && trimmed.size >= (windowLen * 0.96f).toInt()) {
                return null
            }
        }
        return trimmed
    }

    private fun computeLowEnergyFraction(samples: ShortArray, from: Int, to: Int): Float {
        if (to <= from) return 1f
        var quiet = 0
        for (i in from until to) {
            if (abs(samples[i].toInt()) < 550) quiet++
        }
        return quiet.toFloat() / (to - from).toFloat()
    }

    fun matchConfidence(
        windowSamples: ShortArray,
        targetSignature: FloatArray,
        targetDurationMs: Long = 0L
    ): Float {
        if (windowSamples.size < 1600 || targetSignature.size < LEGACY_SIGNATURE_BINS) return 0f

        val activeSlice = if (targetDurationMs > 0L) {
            extractActiveSpeechWindow(windowSamples, targetDurationMs) ?: return 0f
        } else {
            windowSamples
        }

        val windowSig = extractSignature(activeSlice)
        val envPearson = pearsonSim(
            windowSig.copyOfRange(0, 16),
            targetSignature.copyOfRange(0, 16)
        ).coerceAtLeast(0f)

        val timbreSim = if (targetSignature.size >= SIGNATURE_BINS) {
            val formantPearson = pearsonSim(
                windowSig.copyOfRange(20, 36),
                targetSignature.copyOfRange(20, 36)
            ).coerceAtLeast(0f)
            val zcrPearson = pearsonSim(
                windowSig.copyOfRange(16, 20),
                targetSignature.copyOfRange(16, 20)
            ).coerceAtLeast(0f)
            0.78f * formantPearson + 0.22f * zcrPearson
        } else {
            pearsonSim(
                windowSig.copyOfRange(16, 24),
                targetSignature.copyOfRange(16, 24)
            ).coerceAtLeast(0f)
        }

        val commonLen = minOf(windowSig.size, targetSignature.size)
        val rawCos = cosineSim(windowSig.copyOfRange(0, commonLen), targetSignature.copyOfRange(0, commonLen))
        val envMin = windowSig.copyOfRange(0, 16).minOrNull() ?: 0f
        val contrastFactor = if (envMin > 0.68f) 0.55f else 1f

        val durationFactor = if (targetDurationMs > 0L) {
            val actualMs = (activeSlice.size * 1000f) / SAMPLE_RATE
            val ratio = actualMs / targetDurationMs.toFloat().coerceAtLeast(350f)
            if (ratio in 0.6f..1.5f) 1f else 0.72f
        } else 1f

        return ((0.54f * envPearson + 0.32f * timbreSim + 0.14f * rawCos) * contrastFactor * durationFactor)
            .coerceIn(0f, 1f)
    }

    /**
     * Strict biometric speaker verification comparing vocal tract formants (20..35),
     * F0 pitch semitone distance & harmonicity (36..39), and voice quality/ZCR (16..19, 40..43).
     * Applies dual safety caps so a different speaker's pitch or vocal tract cannot pass.
     */
    fun verifySpeakerSimilarity(windowSamples: ShortArray, targetSignature: FloatArray): Float {
        if (windowSamples.size < 1600 || targetSignature.size < LEGACY_SIGNATURE_BINS) return 0f
        val windowSig = extractSignature(windowSamples)

        // Legacy 24-bin fallback for profiles saved before the 44-bin voiceprint upgrade
        if (targetSignature.size < SIGNATURE_BINS) {
            val voiceA = windowSig.copyOfRange(16, 24)
            val voiceB = targetSignature.copyOfRange(16, 24)
            val pearson = pearsonSim(voiceA, voiceB).coerceAtLeast(0f)
            val cos = cosineSim(voiceA, voiceB)
            return (0.65f * pearson + 0.35f * cos).coerceIn(0f, 1f)
        }

        // 1. 16-band Log-Mel vocal tract formant correlation
        val formA = windowSig.copyOfRange(20, 36)
        val formB = targetSignature.copyOfRange(20, 36)
        val formantPearson = pearsonSim(formA, formB).coerceAtLeast(0f)
        val formantCos = cosineSim(formA, formB)
        val formantSim = (0.85f * formantPearson + 0.15f * formantCos).coerceIn(0f, 1f)

        // 2. F0 fundamental pitch semitone proximity & harmonicity
        val candHarm = windowSig[39]
        val ownerHarm = targetSignature[39]
        val pitchSim: Float = when {
            ownerHarm >= 0.30f && candHarm < 0.24f -> 0.10f // noise/unvoiced sound cannot impersonate voiced owner
            ownerHarm >= 0.30f && candHarm >= 0.24f && windowSig[37] > 0.005f && targetSignature[37] > 0.005f -> {
                val candF0 = (windowSig[37] * 260f + 70f).toDouble()
                val ownerF0 = (targetSignature[37] * 260f + 70f).toDouble()
                val semitones = abs(12.0 * (ln(candF0 / ownerF0) / ln(2.0)))
                val spreadDiff = abs((windowSig[38] - windowSig[36]) - (targetSignature[38] - targetSignature[36]))
                val f0Match = exp(-(semitones / 3.0) * (semitones / 3.0)).toFloat()
                val harmMatch = (1f - abs(candHarm - ownerHarm) * 1.4f).coerceIn(0f, 1f)
                val rangeMatch = (1f - spreadDiff * 2.0f).coerceIn(0.3f, 1f)
                (0.72f * f0Match + 0.16f * harmMatch + 0.12f * rangeMatch).coerceIn(0f, 1f)
            }
            else -> 0.55f
        }

        // 3. ZCR voicing + Spectral centroid / tilt / contrast quality
        val qualA = floatArrayOf(
            windowSig[16], windowSig[17], windowSig[18], windowSig[19],
            windowSig[40], windowSig[41], windowSig[42], windowSig[43]
        )
        val qualB = floatArrayOf(
            targetSignature[16], targetSignature[17], targetSignature[18], targetSignature[19],
            targetSignature[40], targetSignature[41], targetSignature[42], targetSignature[43]
        )
        val qualPearson = pearsonSim(qualA, qualB).coerceAtLeast(0f)
        val qualCos = cosineSim(qualA, qualB)
        val qualitySim = (0.80f * qualPearson + 0.20f * qualCos).coerceIn(0f, 1f)

        var score = (0.48f * formantSim + 0.34f * pitchSim + 0.18f * qualitySim).coerceIn(0f, 1f)
        // Hard biometric safety caps: a different speaker's F0 or vocal tract cannot pass strict threshold
        if (pitchSim < 0.45f) score = minOf(score, 0.58f)
        if (formantSim < 0.62f) score = minOf(score, 0.64f)
        return score
    }

    private fun pearsonSim(a: FloatArray, b: FloatArray): Float {
        if (a.isEmpty() || a.size != b.size) return 0f
        val meanA = a.average()
        val meanB = b.average()
        var num = 0.0
        var denA = 0.0
        var denB = 0.0
        for (i in a.indices) {
            val da = a[i] - meanA
            val db = b[i] - meanB
            num += da * db
            denA += da * da
            denB += db * db
        }
        val denom = sqrt(denA) * sqrt(denB)
        if (denom < 1e-6) {
            return if (denA < 1e-6 && denB < 1e-6 && abs(meanA - meanB) < 0.15) 1f else 0f
        }
        return (num / denom).toFloat().coerceIn(-1f, 1f)
    }

    private fun cosineSim(a: FloatArray, b: FloatArray): Float {
        var dot = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        val denom = sqrt(normA) * sqrt(normB)
        if (denom < 1e-6) return 0f
        return (dot / denom).toFloat().coerceIn(0f, 1f)
    }

    fun computeRmsDb(samples: ShortArray, count: Int): Float {
        if (count <= 0) return -60f
        var sumSq = 0.0
        for (i in 0 until count) {
            val norm = samples[i] / 32768.0
            sumSq += norm * norm
        }
        val rms = sqrt(sumSq / count).coerceAtLeast(1e-5)
        return (20.0 * log10(rms)).toFloat().coerceIn(-60f, 0f)
    }

    fun computeRmsNormalized(samples: ShortArray, count: Int): Float {
        val db = computeRmsDb(samples, count)
        return ((db + 55f) / 55f).coerceIn(0f, 1f)
    }

    fun computeSpectrumBins(samples: ShortArray, count: Int, binCount: Int): List<Float> {
        if (count <= 0) return List(binCount) { 0.05f }
        val bins = MutableList(binCount) { 0.05f }
        val usable = minOf(count, 512)
        for (b in 0 until binCount) {
            val targetFreq = 180.0 + b * (3600.0 / binCount)
            val omega = 2.0 * PI * targetFreq / SAMPLE_RATE
            var cosSum = 0.0
            var sinSum = 0.0
            for (n in 0 until usable step 2) {
                val x = samples[n] / 32768.0
                cosSum += x * cos(omega * n)
                sinSum += x * sin(omega * n)
            }
            val mag = sqrt(cosSum * cosSum + sinSum * sinSum) / (usable / 2.0)
            bins[b] = (mag * 6.5).toFloat().coerceIn(0.05f, 1f)
        }
        return bins
    }

    private fun trimSilence(samples: ShortArray): ShortArray {
        if (samples.isEmpty()) return samples
        val threshold = 420
        var start = 0
        var end = samples.lastIndex
        while (start < end && abs(samples[start].toInt()) < threshold) start++
        while (end > start && abs(samples[end].toInt()) < threshold) end--
        val paddedStart = (start - 1200).coerceAtLeast(0)
        val paddedEnd = (end + 1200).coerceAtMost(samples.lastIndex)
        return if (paddedEnd - paddedStart > 1600) {
            samples.copyOfRange(paddedStart, paddedEnd + 1)
        } else {
            samples
        }
    }

    private fun buildWaveformPreview(samples: ShortArray, bars: Int): List<Float> {
        if (samples.isEmpty()) return List(bars) { 0.1f }
        val step = (samples.size / bars).coerceAtLeast(1)
        return List(bars) { i ->
            val s = i * step
            val e = minOf(samples.size, s + step)
            var peak = 0
            for (k in s until e) {
                val a = abs(samples[k].toInt())
                if (a > peak) peak = a
            }
            (peak / 32768f).coerceIn(0.08f, 1f)
        }
    }

    private fun writePcm16(file: File, samples: ShortArray) {
        val baos = ByteArrayOutputStream(samples.size * 2)
        for (s in samples) {
            baos.write(s.toInt() and 0xFF)
            baos.write((s.toInt() shr 8) and 0xFF)
        }
        file.writeBytes(baos.toByteArray())
    }
}
