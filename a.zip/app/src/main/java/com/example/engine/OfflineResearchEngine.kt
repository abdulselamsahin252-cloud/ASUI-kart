package com.example.engine

import com.example.data.CachedSiteEntity
import com.example.data.ResearchSummaryResult
import com.example.data.SiteComparisonResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Pure Kotlin Offline Extractive Summarizer & Two-Site Comparative Analyzer.
 * Uses TF-IDF sentence scoring, TR/EN stop-word filtering, keyword extraction,
 * and cosine/Jaccard similarity for completely offline research & comparison.
 */
object OfflineResearchEngine {

    private val trStopWords = setOf(
        "ve", "ile", "bir", "bu", "şu", "o", "da", "de", "için", "icin", "olan", "olarak",
        "gibi", "daha", "çok", "cok", "en", "her", "ama", "fakat", "veya", "ya", "hem",
        "mi", "mı", "mu", "mü", "ki", "ne", "nasıl", "neden", "üzerinden", "uzerinden",
        "tarafından", "tarafindan", "sonra", "önce", "once", "kadar", "sadece", "ancak",
        "tüm", "tum", "bazı", "bazi", "ise", "var", "yok", "kendi", "diğer", "diger"
    )

    private val enStopWords = setOf(
        "the", "and", "is", "are", "was", "were", "a", "an", "in", "on", "at", "to", "for",
        "of", "with", "by", "from", "that", "this", "it", "as", "be", "or", "which", "can",
        "has", "have", "had", "not", "but", "into", "also", "more", "its", "their", "they",
        "used", "such", "than", "when", "where", "while", "through", "across", "without"
    )

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(7, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    fun findBestSiteMatch(query: String, sites: List<CachedSiteEntity>): CachedSiteEntity? {
        if (sites.isEmpty()) return null
        if (query.isBlank()) return sites.first()
        val qNorm = OfflineNluEngine.normalizeTrEn(query)
        return sites.maxByOrNull { site ->
            val target = OfflineNluEngine.normalizeTrEn("${site.domain} ${site.title} ${site.url} ${site.category}")
            var score = 0
            if (target.contains(qNorm)) score += 100
            qNorm.split(" ").filter { it.length >= 2 }.forEach { token ->
                if (target.contains(token)) score += 20
                if (OfflineNluEngine.normalizeTrEn(site.rawContent).contains(token)) score += 4
            }
            score
        }?.takeIf {
            val target = OfflineNluEngine.normalizeTrEn("${it.domain} ${it.title} ${it.url} ${it.category} ${it.rawContent}")
            qNorm.split(" ").any { t -> t.length >= 2 && target.contains(t) }
        } ?: sites.first()
    }

    fun summarizeSite(site: CachedSiteEntity): ResearchSummaryResult {
        val cleaned = stripHtmlIfNeeded(site.rawContent)
        val sentences = splitSentences(cleaned)
        val words = tokenize(cleaned)
        val freqs = termFrequencies(words)

        val scoredSentences = sentences.mapIndexed { idx, sentence ->
            val tokens = tokenize(sentence)
            val tfScore = if (tokens.isEmpty()) 0.0 else tokens.sumOf { freqs[it] ?: 0.0 } / sqrt(tokens.size.toDouble())
            val positionBoost = if (idx == 0) 1.35 else if (idx == 1) 1.15 else 1.0
            Triple(idx, sentence, tfScore * positionBoost)
        }

        val topSentences = scoredSentences
            .sortedByDescending { it.third }
            .take(minOf(4, sentences.size))
            .sortedBy { it.first }
            .map { it.second }

        val keywords = freqs.entries
            .sortedByDescending { it.value }
            .take(6)
            .map { it.key.replaceFirstChar { c -> c.titlecase(Locale("tr", "TR")) } }

        val readingMin = (words.size / 180).coerceAtLeast(1)
        val verdict = buildString {
            append("${site.title} kaynağı çevrimdışı çekirdekte analiz edildi. ")
            append("Toplam ${words.size} kelime içinde öne çıkan ana temalar: ")
            append(keywords.take(4).joinToString(", "))
            append(".")
        }

        return ResearchSummaryResult(
            siteTitle = site.title,
            siteUrl = site.url,
            language = site.language.uppercase(Locale.US),
            wordCount = words.size,
            readingMinutes = readingMin,
            keySentences = topSentences,
            keywords = keywords,
            bulletPoints = topSentences.map { "• $it" },
            verdict = verdict
        )
    }

    fun compareSites(siteA: CachedSiteEntity, siteB: CachedSiteEntity): SiteComparisonResult {
        val textA = stripHtmlIfNeeded(siteA.rawContent)
        val textB = stripHtmlIfNeeded(siteB.rawContent)

        val wordsA = tokenize(textA)
        val wordsB = tokenize(textB)
        val freqA = termFrequencies(wordsA)
        val freqB = termFrequencies(wordsB)

        val cosineSim = computeCosineSimilarity(freqA, freqB)
        val similarityPct = (cosineSim * 100.0).toInt().coerceIn(4, 96)

        val topA = freqA.entries.sortedByDescending { it.value }.map { it.key }
        val topB = freqB.entries.sortedByDescending { it.value }.map { it.key }
        val setA = topA.take(16).toSet()
        val setB = topB.take(16).toSet()

        val shared = (setA intersect setB).take(5).map { cap(it) }
        val uniqueA = (setA subtract setB).take(5).map { cap(it) }
        val uniqueB = (setB subtract setA).take(5).map { cap(it) }

        val summaryA = summarizeSite(siteA)
        val summaryB = summarizeSite(siteB)

        val executive = buildString {
            append("${siteA.domain} ve ${siteB.domain} içerikleri tamamen çevrimdışı olarak karşılaştırıldı. ")
            append("Anlamsal kavram örtüşmesi %$similarityPct düzeyinde. ")
            if (shared.isNotEmpty()) {
                append("Ortak odak noktaları: ${shared.joinToString(", ")}. ")
            }
            append("${siteA.domain} özellikle ${uniqueA.take(3).joinToString(", ")} konularında yoğunlaşırken; ")
            append("${siteB.domain} ise ${uniqueB.take(3).joinToString(", ")} kavramlarıyla ayrışıyor.")
        }

        return SiteComparisonResult(
            siteATitle = siteA.title,
            siteAUrl = siteA.url,
            siteBTitle = siteB.title,
            siteBUrl = siteB.url,
            similarityPercent = similarityPct,
            sharedTopics = shared,
            uniqueToA = uniqueA,
            uniqueToB = uniqueB,
            wordCountA = wordsA.size,
            wordCountB = wordsB.size,
            keyHighlightsA = summaryA.keySentences.take(2),
            keyHighlightsB = summaryB.keySentences.take(2),
            executiveSummary = executive
        )
    }

    /**
     * Optional live HTML downloader that ONLY runs if the user explicitly disables
     * the Offline Shield toggle and taps "Canlı Sayfayı Önbelleğe Al".
     */
    suspend fun fetchLiveSiteToCache(urlInput: String): Result<CachedSiteEntity> = withContext(Dispatchers.IO) {
        runCatching {
            val normalizedUrl = if (urlInput.startsWith("http://") || urlInput.startsWith("https://")) {
                urlInput
            } else {
                "https://$urlInput"
            }
            val req = Request.Builder()
                .url(normalizedUrl)
                .header("User-Agent", "YankiAI-OfflineCacher/1.0")
                .build()
            val bodyStr = httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                resp.body?.string().orEmpty()
            }
            val title = Regex("""<title[^>]*>(.*?)</title>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(bodyStr)?.groupValues?.get(1)?.trim()?.take(80)
                ?: normalizedUrl.substringAfter("://").substringBefore("/")
            val cleanText = stripHtmlIfNeeded(bodyStr).take(12_000)
            if (cleanText.length < 40) error("Sayfadan yeterli metin çıkarılamadı")

            val domain = normalizedUrl.substringAfter("://").substringBefore("/").lowercase(Locale.US)
            CachedSiteEntity(
                url = normalizedUrl,
                title = title,
                domain = domain,
                language = if (cleanText.contains(" ve ") || cleanText.contains(" için ")) "tr" else "en",
                rawContent = cleanText,
                category = "Canlı Önbellek",
                isPreseeded = false
            )
        }
    }

    fun stripHtmlIfNeeded(raw: String): String {
        val noScripts = raw
            .replace(Regex("""<script[^>]*>.*?</script>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), " ")
            .replace(Regex("""<style[^>]*>.*?</style>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), " ")
            .replace(Regex("""<[^>]+>"""), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
        return noScripts.replace(Regex("""\s+"""), " ").trim()
    }

    private fun splitSentences(text: String): List<String> {
        return text.split(Regex("""(?<=[.!?])\s+"""))
            .map { it.trim() }
            .filter { it.length >= 24 }
            .ifEmpty { listOf(text.take(260)) }
    }

    private fun tokenize(text: String): List<String> {
        return text.lowercase(Locale("tr", "TR"))
            .replace(Regex("""[^a-z0-9çğıöşü\s]"""), " ")
            .split(Regex("""\s+"""))
            .filter { it.length >= 3 && it !in trStopWords && it !in enStopWords }
    }

    private fun termFrequencies(tokens: List<String>): Map<String, Double> {
        if (tokens.isEmpty()) return emptyMap()
        val counts = mutableMapOf<String, Int>()
        for (t in tokens) counts[t] = (counts[t] ?: 0) + 1
        val total = tokens.size.toDouble()
        return counts.mapValues { (term, c) ->
            val tf = c / total
            val lengthBonus = 1.0 + ln(term.length.coerceAtMost(12).toDouble()) * 0.2
            tf * lengthBonus
        }
    }

    private fun computeCosineSimilarity(a: Map<String, Double>, b: Map<String, Double>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        var dot = 0.0
        var normA = 0.0
        var normB = 0.0
        for ((k, v) in a) {
            normA += v * v
            dot += v * (b[k] ?: 0.0)
        }
        for (v in b.values) normB += v * v
        val denom = sqrt(normA) * sqrt(normB)
        return if (denom == 0.0) 0.0 else dot / denom
    }

    private fun cap(word: String): String =
        word.replaceFirstChar { it.titlecase(Locale("tr", "TR")) }
}
