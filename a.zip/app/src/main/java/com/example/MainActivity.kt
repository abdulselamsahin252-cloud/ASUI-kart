package com.example

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import com.example.service.WakeWordForegroundService
import com.example.ui.MainViewModel
import com.example.ui.YankiApp

class MainActivity : FragmentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureLockScreenWakeBehavior()
        val wakeTriggered = intent?.getBooleanExtra(WakeWordForegroundService.EXTRA_WAKE_TRIGGERED, false) == true

        setContent {
            YankiApp(
                viewModel = viewModel,
                activity = this,
                initialWakeTriggered = wakeTriggered
            )
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDiagnosticsAndApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(WakeWordForegroundService.EXTRA_WAKE_TRIGGERED, false)) {
            configureLockScreenWakeBehavior()
        }
    }

    fun requestSystemKeyguardDismiss() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager ?: return
            km.requestDismissKeyguard(this, null)
        }
    }

    private fun configureLockScreenWakeBehavior() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
    }
}
