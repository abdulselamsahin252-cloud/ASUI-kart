package com.example

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.example.engine.AssistantRuntimeHub
import com.example.service.WakeWordForegroundService
import com.example.ui.MainViewModel
import com.example.ui.YankiApp
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var lockScreenMiniMode by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureLockScreenWakeBehavior()
        val wakeTriggered = intent?.getBooleanExtra(WakeWordForegroundService.EXTRA_WAKE_TRIGGERED, false) == true
        lockScreenMiniMode = intent?.getBooleanExtra(WakeWordForegroundService.EXTRA_LOCK_SCREEN_MINI_MODE, false) == true

        lifecycleScope.launch {
            AssistantRuntimeHub.lockScreenSessionFinished.collect {
                if (lockScreenMiniMode) {
                    lockScreenMiniMode = false
                    moveTaskToBack(true)
                }
            }
        }
        lifecycleScope.launch {
            AssistantRuntimeHub.requestKeyguardDismiss.collect {
                lockScreenMiniMode = false
                requestSystemKeyguardDismiss()
            }
        }

        setContent {
            YankiApp(
                viewModel = viewModel,
                activity = this,
                initialWakeTriggered = wakeTriggered,
                isLockScreenMiniMode = lockScreenMiniMode
            )
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDiagnosticsAndApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(WakeWordForegroundService.EXTRA_WAKE_TRIGGERED, false)) {
            configureLockScreenWakeBehavior()
        }
        lockScreenMiniMode = intent.getBooleanExtra(WakeWordForegroundService.EXTRA_LOCK_SCREEN_MINI_MODE, false)
    }

    fun requestSystemKeyguardDismiss() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            if (km == null) {
                moveTaskToBack(true)
                return
            }
            km.requestDismissKeyguard(
                this,
                object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() {
                        moveTaskToBack(true)
                    }

                    override fun onDismissCancelled() {
                        moveTaskToBack(true)
                    }

                    override fun onDismissError() {
                        moveTaskToBack(true)
                    }
                }
            )
        } else {
            moveTaskToBack(true)
        }
    }

    private fun configureLockScreenWakeBehavior() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
    }
}
