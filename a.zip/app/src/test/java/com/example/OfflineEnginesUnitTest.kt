package com.example

import com.example.data.AutomationActionType
import com.example.data.CachedSiteEntity
import com.example.engine.AcousticWakeWordEngine
import com.example.engine.CommandIntent
import com.example.engine.OfflineNluEngine
import com.example.engine.OfflineResearchEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class OfflineEnginesUnitTest {

    @Test
    fun `parses power, wifi, bluetooth and flashlight commands in Turkish and English`() {
        assertTrue(OfflineNluEngine.parse("telefonu kapat") is CommandIntent.PowerDialog)
        assertTrue(OfflineNluEngine.parse("ekranı kilitle") is CommandIntent.LockScreen)

        val wifiOn = OfflineNluEngine.parse("wifi aç") as CommandIntent.WifiControl
        assertTrue(wifiOn.enable)

        val wifiOff = OfflineNluEngine.parse("turn off wi-fi") as CommandIntent.WifiControl
        assertTrue(!wifiOff.enable)

        val btOn = OfflineNluEngine.parse("Bluetooth aç") as CommandIntent.BluetoothControl
        assertTrue(btOn.enable)

        val torch = OfflineNluEngine.parse("feneri aç") as CommandIntent.FlashlightControl
        assertTrue(torch.enable)
    }

    @Test
    fun `parses multi-step app automation commands`() {
        val intent = OfflineNluEngine.parse("Ayarlar uygulamasına girip Bluetooth'a tıkla ve 'test' yaz")
        assertTrue(intent is CommandIntent.AppAutomation)
        val auto = intent as CommandIntent.AppAutomation
        assertEquals("Ayarlar", auto.appNameQuery)
        assertTrue(auto.steps.any { it.type == AutomationActionType.OPEN_APP })
        assertTrue(auto.steps.any { it.type == AutomationActionType.CLICK_TEXT && it.target.contains("Bluetooth", ignoreCase = true) })
        assertTrue(auto.steps.any { it.type == AutomationActionType.INPUT_TEXT && it.value == "test" })
    }

    @Test
    fun `parses site research and two-site comparison commands`() {
        val research = OfflineNluEngine.parse("kotlinlang.org sitesini araştır özetle")
        assertTrue(research is CommandIntent.ResearchSite)
        assertEquals("kotlinlang.org", (research as CommandIntent.ResearchSite).siteQuery)

        val compare = OfflineNluEngine.parse("kotlinlang.org ile python.org sitelerini karşılaştır")
        assertTrue(compare is CommandIntent.CompareSites)
        val c = compare as CommandIntent.CompareSites
        assertEquals("kotlinlang.org", c.siteAQuery)
        assertEquals("python.org", c.siteBQuery)
    }

    @Test
    fun `offline research engine summarizes and compares two sites accurately`() {
        val siteA = CachedSiteEntity(
            id = 1,
            url = "https://kotlinlang.org",
            title = "Kotlin",
            domain = "kotlinlang.org",
            language = "tr",
            category = "Yazılım",
            rawContent = "Kotlin modern bir programlama dilidir. Android geliştirme için yüksek performans ve null güvenliği sunar. Coroutines ile asenkron işlemler kolaylaşır."
        )
        val siteB = CachedSiteEntity(
            id = 2,
            url = "https://python.org",
            title = "Python",
            domain = "python.org",
            language = "tr",
            category = "Yazılım",
            rawContent = "Python yapay zeka ve veri bilimi için yüksek performans sunan bir programlama dilidir. Zengin kütüphaneler ile makine öğrenmesi kolaylaşır."
        )

        val summary = OfflineResearchEngine.summarizeSite(siteA)
        assertTrue(summary.wordCount > 10)
        assertTrue(summary.keySentences.isNotEmpty())
        assertTrue(summary.keywords.isNotEmpty())

        val comparison = OfflineResearchEngine.compareSites(siteA, siteB)
        assertTrue(comparison.similarityPercent in 1..99)
        assertTrue(comparison.sharedTopics.isNotEmpty())
        assertTrue(comparison.uniqueToA.isNotEmpty())
        assertTrue(comparison.uniqueToB.isNotEmpty())
    }

    @Test
    fun `acoustic wake word signature matches identical speech cadence and rejects unrelated chatter or flat media`() {
        val sampleRate = AcousticWakeWordEngine.SAMPLE_RATE
        // Simulate a 1.0s two-syllable wake phrase ("Hey Axiom") with silence padding & syllable modulation
        val wakeSamples = ShortArray(sampleRate) { i ->
            val t = i.toDouble() / sampleRate
            val env = when {
                t < 0.12 || t > 0.88 -> 0.0
                t in 0.12..0.34 -> sin(PI * (t - 0.12) / 0.22)
                t in 0.42..0.84 -> sin(PI * (t - 0.42) / 0.42)
                else -> 0.05
            }
            val carrier = 0.65 * sin(2.0 * PI * 145.0 * t) + 0.35 * sin(2.0 * PI * 520.0 * t)
            (16000.0 * env * carrier).toInt().toShort()
        }

        val sig = AcousticWakeWordEngine.extractSignature(wakeSamples)
        val selfConf = AcousticWakeWordEngine.matchConfidence(wakeSamples, sig, targetDurationMs = 950L)
        val speakerSim = AcousticWakeWordEngine.verifySpeakerSimilarity(wakeSamples, sig)
        assertTrue("Expected high self-match confidence, got $selfConf", selfConf > 0.90f)
        assertTrue("Expected high speaker similarity, got $speakerSim", speakerSim > 0.95f)

        // Simulate continuous Reels / conversation chatter filling a 2.0s buffer with flat loud high-freq cadence
        val chatterSamples = ShortArray(sampleRate * 2) { i ->
            val t = i.toDouble() / sampleRate
            val env = 0.85 + 0.15 * sin(2.0 * PI * 7.5 * t)
            val carrier = 0.5 * sin(2.0 * PI * 1450.0 * t) + 0.5 * sin(2.0 * PI * 2700.0 * t)
            (11000.0 * env * carrier).toInt().toShort()
        }
        val falseConf = AcousticWakeWordEngine.matchConfidence(chatterSamples, sig, targetDurationMs = 950L)
        assertTrue("Expected unrelated continuous audio to be rejected (< 0.65), got $falseConf", falseConf < 0.65f)
    }

    @Test
    fun `biometric voiceprint rejects different speakers saying the same wake phrase`() {
        val sampleRate = AcousticWakeWordEngine.SAMPLE_RATE
        fun synthVoicePhrase(f0Hz: Double, f1Hz: Double, f2Hz: Double, amplitude: Double): ShortArray {
            return ShortArray(sampleRate) { i ->
                val t = i.toDouble() / sampleRate
                val env = when {
                    t < 0.10 || t > 0.90 -> 0.0
                    t in 0.10..0.34 -> sin(PI * (t - 0.10) / 0.24)
                    t in 0.42..0.86 -> sin(PI * (t - 0.42) / 0.44)
                    else -> 0.04
                }
                // Voiced glottal harmonics + F1/F2 vocal tract formants
                val glottal = 0.50 * sin(2.0 * PI * f0Hz * t) +
                    0.32 * sin(2.0 * PI * (f0Hz * 2.0) * t) +
                    0.18 * sin(2.0 * PI * (f0Hz * 3.0) * t)
                val formants = 0.45 * sin(2.0 * PI * f1Hz * t) + 0.28 * sin(2.0 * PI * f2Hz * t)
                (amplitude * env * (0.65 * glottal + 0.35 * formants)).toInt().toShort()
            }
        }

        // Recorded owner voice (deep male 122 Hz, F1=420 Hz, F2=1150 Hz)
        val ownerSample = synthVoicePhrase(f0Hz = 122.0, f1Hz = 420.0, f2Hz = 1150.0, amplitude = 15000.0)
        val ownerSig = AcousticWakeWordEngine.extractSignature(ownerSample)
        assertEquals(AcousticWakeWordEngine.SIGNATURE_BINS, ownerSig.size)

        // Owner speaking slightly softer matches cleanly (> 0.90)
        val ownerSofter = synthVoicePhrase(f0Hz = 125.0, f1Hz = 425.0, f2Hz = 1160.0, amplitude = 10500.0)
        val ownerSim = AcousticWakeWordEngine.verifySpeakerSimilarity(ownerSofter, ownerSig)
        assertTrue("Expected owner voiceprint to pass (>= 0.88), got $ownerSim", ownerSim >= 0.88f)

        // Foreign speaker A: higher pitch (215 Hz) saying exact same phrase cadence -> rejected (< 0.70)
        val higherPitchSpeaker = synthVoicePhrase(f0Hz = 215.0, f1Hz = 780.0, f2Hz = 1950.0, amplitude = 15000.0)
        val foreignSimA = AcousticWakeWordEngine.verifySpeakerSimilarity(higherPitchSpeaker, ownerSig)
        assertTrue("Expected different-pitch speaker to be rejected (< 0.70), got $foreignSimA", foreignSimA < 0.70f)

        // Foreign speaker B: close pitch (130 Hz) but different vocal tract formants -> rejected (< 0.78)
        val diffFormantSpeaker = synthVoicePhrase(f0Hz = 130.0, f1Hz = 790.0, f2Hz = 2350.0, amplitude = 15000.0)
        val foreignSimB = AcousticWakeWordEngine.verifySpeakerSimilarity(diffFormantSpeaker, ownerSig)
        assertTrue("Expected different-formant speaker to be rejected (< 0.78), got $foreignSimB", foreignSimB < 0.78f)
    }

    @Test
    fun `parses generalized zip extraction, voice unlock and offline calculation commands`() {
        val genericZip = OfflineNluEngine.parse("bu dosya zip bunu aç şu klasörü ana dizine çıkar")
        assertTrue(genericZip is CommandIntent.ZipArchiveOp)
        val z1 = genericZip as CommandIntent.ZipArchiveOp
        assertEquals(com.example.engine.ZipAction.EXTRACT, z1.action)
        assertTrue(z1.extractToRoot)
        assertEquals(null, z1.subFolder)

        val specificZip = OfflineNluEngine.parse("proje_yedek.zip içindeki belgeler klasörünü ana dizine çıkar")
        assertTrue(specificZip is CommandIntent.ZipArchiveOp)
        val z2 = specificZip as CommandIntent.ZipArchiveOp
        assertEquals("proje_yedek.zip", z2.archiveName)
        assertEquals("belgeler", z2.subFolder)
        assertTrue(z2.extractToRoot)

        assertTrue(OfflineNluEngine.parse("şifreyi aç") is CommandIntent.UnlockDeviceWithVoice)
        assertTrue(OfflineNluEngine.parse("hesapla 1250 * 4") is CommandIntent.QuickCalculate)
    }

    @Test
    fun `gguf binary header inspector validates magic bytes, version and tensor counts`() {
        val tempFile = java.io.File.createTempFile("test_model", ".gguf")
        try {
            val buf = java.nio.ByteBuffer.allocate(24).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            buf.put("GGUF".toByteArray(Charsets.US_ASCII))
            buf.putInt(3)
            buf.putLong(212L)
            buf.putLong(28L)
            tempFile.writeBytes(buf.array())

            val valid = com.example.engine.LocalLlmEngine.inspectGgufHeader(tempFile)
            assertTrue(valid.isValidGguf)
            assertEquals(3, valid.formatVersion)
            assertEquals(212L, valid.tensorCount)
            assertEquals(28L, valid.kvCount)

            tempFile.writeText("NOT_A_GGUF_FILE_1234567890")
            val invalid = com.example.engine.LocalLlmEngine.inspectGgufHeader(tempFile)
            assertTrue(!invalid.isValidGguf)
            assertTrue(com.example.engine.LocalLlmEngine.powerfulCatalog.size >= 4)
        } finally {
            tempFile.delete()
        }
    }
}
