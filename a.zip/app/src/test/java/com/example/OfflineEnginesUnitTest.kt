package com.example

import com.example.data.AutomationActionType
import com.example.data.CachedSiteEntity
import com.example.engine.AcousticWakeWordEngine
import com.example.engine.CommandIntent
import com.example.engine.OfflineNluEngine
import com.example.engine.OfflineResearchEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class OfflineEnginesUnitTest {

    @Test
    fun `parses power, wifi, bluetooth and flashlight commands in Turkish and English`() {
        assertTrue(OfflineNluEngine.parse("telefonu kapat") is CommandIntent.PowerDialog)
        assertTrue(OfflineNluEngine.parse("ekranı kilitle") is CommandIntent.LockScreen)

        val wifiOn = OfflineNluEngine.parse("wifi aç") as CommandIntent.WifiControl
        assertTrue(wifiOn.enable)

        val wifiOff = OfflineNluEngine.parse("turn off wi-fi") as CommandIntent.WifiControl
        assertTrue(!wifiOff.enable)

        val btOn = OfflineNluEngine.parse("Bluetooth aç") as CommandIntent.BluetoothControl
        assertTrue(btOn.enable)

        val torch = OfflineNluEngine.parse("feneri aç") as CommandIntent.FlashlightControl
        assertTrue(torch.enable)
    }

    @Test
    fun `parses multi-step app automation commands`() {
        val intent = OfflineNluEngine.parse("Ayarlar uygulamasına girip Bluetooth'a tıkla ve 'test' yaz")
        assertTrue(intent is CommandIntent.AppAutomation)
        val auto = intent as CommandIntent.AppAutomation
        assertEquals("Ayarlar", auto.appNameQuery)
        assertTrue(auto.steps.any { it.type == AutomationActionType.OPEN_APP })
        assertTrue(auto.steps.any { it.type == AutomationActionType.CLICK_TEXT && it.target.contains("Bluetooth", ignoreCase = true) })
        assertTrue(auto.steps.any { it.type == AutomationActionType.INPUT_TEXT && it.value == "test" })
    }

    @Test
    fun `parses site research and two-site comparison commands`() {
        val research = OfflineNluEngine.parse("kotlinlang.org sitesini araştır özetle")
        assertTrue(research is CommandIntent.ResearchSite)
        assertEquals("kotlinlang.org", (research as CommandIntent.ResearchSite).siteQuery)

        val compare = OfflineNluEngine.parse("kotlinlang.org ile python.org sitelerini karşılaştır")
        assertTrue(compare is CommandIntent.CompareSites)
        val c = compare as CommandIntent.CompareSites
        assertEquals("kotlinlang.org", c.siteAQuery)
        assertEquals("python.org", c.siteBQuery)
    }

    @Test
    fun `offline research engine summarizes and compares two sites accurately`() {
        val siteA = CachedSiteEntity(
            id = 1,
            url = "https://kotlinlang.org",
            title = "Kotlin",
            domain = "kotlinlang.org",
            language = "tr",
            category = "Yazılım",
            rawContent = "Kotlin modern bir programlama dilidir. Android geliştirme için yüksek performans ve null güvenliği sunar. Coroutines ile asenkron işlemler kolaylaşır."
        )
        val siteB = CachedSiteEntity(
            id = 2,
            url = "https://python.org",
            title = "Python",
            domain = "python.org",
            language = "tr",
            category = "Yazılım",
            rawContent = "Python yapay zeka ve veri bilimi için yüksek performans sunan bir programlama dilidir. Zengin kütüphaneler ile makine öğrenmesi kolaylaşır."
        )

        val summary = OfflineResearchEngine.summarizeSite(siteA)
        assertTrue(summary.wordCount > 10)
        assertTrue(summary.keySentences.isNotEmpty())
        assertTrue(summary.keywords.isNotEmpty())

        val comparison = OfflineResearchEngine.compareSites(siteA, siteB)
        assertTrue(comparison.similarityPercent in 1..99)
        assertTrue(comparison.sharedTopics.isNotEmpty())
        assertTrue(comparison.uniqueToA.isNotEmpty())
        assertTrue(comparison.uniqueToB.isNotEmpty())
    }

    @Test
    fun `acoustic wake word signature matches identical waveform with high confidence`() {
        val sampleRate = AcousticWakeWordEngine.SAMPLE_RATE
        val samples = ShortArray(sampleRate) { i ->
            (12000.0 * sin(2.0 * PI * 440.0 * i / sampleRate)).toInt().toShort()
        }
        val sig = AcousticWakeWordEngine.extractSignature(samples)
        val conf = AcousticWakeWordEngine.matchConfidence(samples, sig)
        val speakerSim = AcousticWakeWordEngine.verifySpeakerSimilarity(samples, sig)
        assertTrue("Expected high self-match confidence, got $conf", conf > 0.98f)
        assertTrue("Expected high speaker similarity, got $speakerSim", speakerSim > 0.98f)
    }

    @Test
    fun `parses generalized zip extraction, voice unlock and offline calculation commands`() {
        val genericZip = OfflineNluEngine.parse("bu dosya zip bunu aç şu klasörü ana dizine çıkar")
        assertTrue(genericZip is CommandIntent.ZipArchiveOp)
        val z1 = genericZip as CommandIntent.ZipArchiveOp
        assertEquals(com.example.engine.ZipAction.EXTRACT, z1.action)
        assertTrue(z1.extractToRoot)
        assertEquals(null, z1.subFolder)

        val specificZip = OfflineNluEngine.parse("proje_yedek.zip içindeki belgeler klasörünü ana dizine çıkar")
        assertTrue(specificZip is CommandIntent.ZipArchiveOp)
        val z2 = specificZip as CommandIntent.ZipArchiveOp
        assertEquals("proje_yedek.zip", z2.archiveName)
        assertEquals("belgeler", z2.subFolder)
        assertTrue(z2.extractToRoot)

        assertTrue(OfflineNluEngine.parse("şifreyi aç") is CommandIntent.UnlockDeviceWithVoice)
        assertTrue(OfflineNluEngine.parse("hesapla 1250 * 4") is CommandIntent.QuickCalculate)
    }

    @Test
    fun `gguf binary header inspector validates magic bytes, version and tensor counts`() {
        val tempFile = java.io.File.createTempFile("test_model", ".gguf")
        try {
            val buf = java.nio.ByteBuffer.allocate(24).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            buf.put("GGUF".toByteArray(Charsets.US_ASCII))
            buf.putInt(3)
            buf.putLong(212L)
            buf.putLong(28L)
            tempFile.writeBytes(buf.array())

            val valid = com.example.engine.LocalLlmEngine.inspectGgufHeader(tempFile)
            assertTrue(valid.isValidGguf)
            assertEquals(3, valid.formatVersion)
            assertEquals(212L, valid.tensorCount)
            assertEquals(28L, valid.kvCount)

            tempFile.writeText("NOT_A_GGUF_FILE_1234567890")
            val invalid = com.example.engine.LocalLlmEngine.inspectGgufHeader(tempFile)
            assertTrue(!invalid.isValidGguf)
            assertTrue(com.example.engine.LocalLlmEngine.powerfulCatalog.size >= 4)
        } finally {
            tempFile.delete()
        }
    }
}
